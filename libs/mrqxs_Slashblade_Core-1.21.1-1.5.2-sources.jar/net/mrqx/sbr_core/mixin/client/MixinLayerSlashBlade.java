package net.mrqx.sbr_core.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import mods.flammpfeil.slashblade.client.renderer.layers.LayerSlashBlade;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.mrqx.sbr_core.client.layer.LayerSlashEntityBlade;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LayerSlashBlade.class)
public abstract class MixinLayerSlashBlade<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    public MixinLayerSlashBlade(RenderLayerParent<T, M> renderer) {
        super(renderer);
    }
    
    @SuppressWarnings("all")
    @WrapOperation(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/LivingEntity;FFFFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/EntityType;is(Lnet/minecraft/tags/TagKey;)Z"))
    private boolean wrapIs(EntityType<?> instance, TagKey<EntityType<?>> tag, Operation<Boolean> original) {
        return LayerSlashEntityBlade.class.isInstance(this) ? false : original.call(instance, tag);
    }
}
