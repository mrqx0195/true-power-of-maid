package net.mrqx.sbr_core.client.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.client.renderer.layers.LayerMainBlade;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.world.entity.LivingEntity;
import net.mrqx.sbr_core.animation.VanillaConvertedVmdAnimation;
import net.mrqx.sbr_core.entity.ISlashBladeEntity;

import javax.annotation.Nullable;

/**
 * 支持 MMD 骨骼驱动的拔刀剑渲染层。
 * <p>
 * 重写了原版的 {@link LayerMainBlade}，使用 MMD 骨骼动画（VMD）
 * 渲染刀与鞘，并支持充能特效显示。
 */
public class LayerSlashEntityBlade<T extends LivingEntity, M extends EntityModel<T>> extends LayerMainBlade<T, M> {
    /**
     * @param entityRendererIn 父渲染器
     */
    public LayerSlashEntityBlade(RenderLayerParent<T, M> entityRendererIn) {
        super(entityRendererIn);
    }
    
    /**
     * 设置用户的姿态：如果存在 VMD 动画，则更新其帧插值。
     */
    @Override
    public void setUserPose(PoseStack matrixStack, T entity, float partialTicks, @Nullable ISlashBladeState state) {
        if (entity instanceof ISlashBladeEntity slashBladeEntity) {
            VanillaConvertedVmdAnimation animationPlayer = slashBladeEntity.getCurrentAnimation();
            if (animationPlayer != null) {
                animationPlayer.setTickDelta(partialTicks);
            }
        }
    }
}
