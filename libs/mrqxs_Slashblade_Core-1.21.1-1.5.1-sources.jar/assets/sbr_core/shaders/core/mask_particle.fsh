#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);
    vec4 color = vertexColor * ColorModulator;
    // 形状与强度都由来源贴图的 alpha 给出：RGB 是折射方向（逐顶点已定，不随贴图变），A 是强度
    fragColor = vec4(color.rgb, color.a * texel.a);
}
