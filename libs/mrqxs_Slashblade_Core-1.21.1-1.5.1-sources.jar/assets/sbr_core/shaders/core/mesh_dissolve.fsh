#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float Dissolve;
uniform float Ripple;
uniform float MaskAlpha;
// 光环材质（メッシュ　シールド2 / メッシュ　収束オーラ0）的两路纹波参数，逐项对应材质的 UserMaterial 覆写。
uniform vec2 RippleUvScroll;    // [3] 红/绿两路 V 轴相位（材质里是 Red_Offset / Green_Offset 曲线）
uniform vec4 RippleUvScale;     // [3] 两路基础 UV 缩放 (Red_Scale, Red_Scale2, Green_Scale, Green_Scale2)
uniform vec2 RipplePower;       // [7] 两路通道幂次 (Red_Power, Green_Power)
uniform vec4 RippleColorParam;  // [10] 颜色低色端 ColorParam（含总不透明度 .a）
uniform vec4 RippleColorHigh;   // [10] 颜色高色端 ColorHigh
uniform float RippleEmissive;   // [10] EmissiveRate（着色器取它的平方）
uniform vec2 RippleUvFade;      // [8] 半径遮罩的 smoothstep 区间 (UVFade_Low, UVFade_High)
uniform vec2 RippleEdge;        // [9] 菲涅尔归一化区间 (OutsideAngle, InsideAngle)
uniform float CloudTime;
// 云层球壳的自发光色（乘在下面的自发光权重上）。
uniform vec4 CloudEmissive;
// 云层球壳的按层参数：CloudTiling = Mask01_Tiling。
uniform vec2 CloudTiling;
// 云量归一化的除数（材质参数 Mie_Max，mdf2 默认 0.25）。名字里带 "Mie"（大气散射）但实际充当
// **云量 / 对比度控制器**：云量 I = saturate(两路遮罩的合成 / Mie_Max)，再经 1 − I²(3 − 2I) 整形。
uniform float CloudMieMax;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

// 云层密度：贴图 R / G / W 三个通道分别承载三路遮罩（B 通道恒为 0、A 是整体透明度）。
// 本项目只用前两路；第三路（.w，不平铺也不滚动、只乘进 alpha）与两层法线尚未实现。
// 两层各有独立平铺、方向与圈数（当前只有 ドーム / ドーム0 走这条分支，故内联值直接写在这里；若有别的云层复用再提升为 uniform）。
// 必须采样两层再按分段方式合成：只取单通道做平均会退化成一层云，且该图蓝通道恒为 0，把 RGB 当 albedo 会渲染成黄绿色的"彩色球壳"。
//
// 材质侧的算式（逐条对应其像素着色器反汇编）：
//   相位_k = frac( floor(|LoopNum_k|) × t )
//   UV_k   = Tiling_k ⊙ ( UV0 + 相位_k × ScrollDirection_k )
// 三条易错点分别写在下面各处。
// ⚠ t 的单位绝不能取"秒"：圈数是"每 1 个时间单位滚多少圈"，取秒时 fract(20 × age/20) = fract(age) 恒为整数，
// 整格偏移等于没有偏移，两层云会完全静止；须用着色器共有口径的 age / 1200。
float cloudDensity(vec2 uv, float t, out float a2) {
    // 两路遮罩的相位取 LoopNum 的 .x / .y（.z / .w 属两层法线，本项目没有法线通道）。
    // ⚠ 取整必须是 floor 而不是 round：|LoopNum| < 1 时 floor 给 0，该层永久静止——
    //   这是"静态云球"的第二个根因（第一个是 t 取"秒"，见上）。
    float phaseLoopX = fract(floor(abs(20.0)) * t);   // LoopNum.x
    float phaseLoopY = fract(floor(abs(19.0)) * t);   // LoopNum.y
    // ⚠ 相位项先加进 UV、再整体乘平铺：平铺乘在相位之后。写成 uv * 平铺 + 相位 * 方向，
    //   滚动速度会差平铺倍（ドーム 系是 8 / 4 倍）。
    // ⚠ 平铺 / 相位 / 滚动方向的配对是**交叉**的，不要按名字对齐（该 mmtr 的另一个通道汇编也一致）：
    //   Mask01_Tiling 那一路（按层覆写，即 CloudTiling）配 LoopNum.y + Layer02 方向 (2,2)
    //   Mask02_Tiling 那一路（从未被任何层覆写，取 mdf2 静态默认）配 LoopNum.x + Layer01 方向 (1,1)
    // 至于这两路各去读贴图的哪个通道，那是**本项目替代贴图自己的通道安排**（R / G），
    // 不是可以照抄的引擎事实：引擎读的是它自己的 MSK4 遮罩图，通道分配还随材质通道而变
    // （同一 mmtr 的两个通道里，第二路遮罩一个取 .y、另一个取 .z）。
    vec2 uvX = CloudTiling * (uv + vec2(phaseLoopY) * vec2(2.0, 2.0));
    vec2 uvY = vec2(4.0, 7.0) * (uv + vec2(phaseLoopX) * vec2(1.0, 1.0));
    float m1 = texture(Sampler0, uvX).x;
    float m2 = texture(Sampler0, uvY).y;
    // 两路遮罩的合并是一个分段混合：m2 低于半程时相乘、高于半程时走 screen 的变体。
    // 正是这一步让两路云叠成一层变化丰富的云，而不是各自一片。
    // ⚠ 分支判据用的是 .y 通道那一路（m2），不是 m1。
    // 另外把 m2 交出去：材质侧的最终透明度 `saturate(2(1 − a2))` **只由它决定**，与云量整形无关。
    a2 = m2;
    return (m2 < 0.5) ? (m1 * m2) : (1.0 - 2.0 * (1.0 - m2) * (1.0 - m1));
}

// 程序化噪声：二维散列 + 双线性插值。粒子顶点格式只有 Position / Color / UV0 / UV2，
// 没有多余通道挂第二张纹理，而这里只需要"空间连续、肉眼无规律"的一层值。
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// 网格溶解 / 纹波 / 云层共用的片元着色器：溶解层按噪声阈值裁像素并留提亮烧蚀边；
// 纹波层走 rippleShade() 的独立管线；云层走 cloudDensity() 的多层异速滚动。
// 贴图未显式声明 clamp 即为 GL_REPEAT，平移越界时自然平铺，不会夹边拉丝。
// 光环材质的片元着色：纹波层不用贴图颜色，只用 R / G 两个通道当遮罩，颜色来自材质的两端色参数。
// 三处取舍：贴图绝不乘进颜色（R/G 是稀疏遮罩而非 albedo）；FlowMap 未实现（两层 FlowIntensity 均覆写为 0）；
// UVFade_Enable 两层均取默认 0，此时半径项退化为 1 − 2|UV0.y − 0.5|，对这张"V 即半径"的圆盘网格恰好是一圈环带。
vec4 rippleShade() {
    // [2][3] 两路基础 UV：先翻转（1 − UV0）再乘各自的缩放，最后叠上各自的相位
    vec2 uvBase = vec2(1.0) - texCoord0;
    vec2 uvRed = uvBase * RippleUvScale.xy + vec2(0.0, RippleUvScroll.x);
    vec2 uvGreen = uvBase * RippleUvScale.zw + vec2(0.0, RippleUvScroll.y);
    // [7] 两路各自的幂次；取幂前的 max(·, 1e-6) 保底是为了防止 log(0)
    float redMask = pow(max(texture(Sampler0, uvRed).r, 1.0e-6), RipplePower.x);
    float greenMask = pow(max(texture(Sampler0, uvGreen).g, 1.0e-6), RipplePower.y);
    // [8] 两路相加后夹到 1，再乘半径遮罩的 smoothstep
    float powerSum = min(redMask + greenMask, 1.0);
    float volumeRadius = 1.0 - 2.0 * abs(texCoord0.y - 0.5);
    float radiusSpan = max(RippleUvFade.y - RippleUvFade.x, 1.0e-4);
    float radiusT = clamp((volumeRadius - RippleUvFade.x) / radiusSpan, 0.0, 1.0);
    float smoothT = radiusT * radiusT * (3.0 - 2.0 * radiusT);
    float mask = powerSum * smoothT;
    // [9] 菲涅尔：N·V 由顶点色的 R 通道传入（顶点格式里没有法线，只有颜色可用），"正对镜头最强"
    float nDotV = vertexColor.r;
    float edgeSpan = max(RippleEdge.y - RippleEdge.x, 1.0e-4);
    float edgeT = clamp((nDotV - RippleEdge.x) / edgeSpan, 0.0, 1.0);
    float fresnelTerm = edgeT * edgeT * (3.0 - 2.0 * edgeT);
    // [10] 两端色按 mask 插值，再乘 EmissiveRate 的平方
    vec3 blended = mix(RippleColorParam.rgb, RippleColorHigh.rgb, mask)
        * RippleEmissive * RippleEmissive;
    // [11] 菲涅尔 × 遮罩 × ColorParam.a × 顶点色 A 通道里的生命期不透明度。
    // 本类型的混合是 SRC_ALPHA / 1−SRC_ALPHA（见 mesh_dissolve.json），故输出**未预乘**颜色。
    float opacity = fresnelTerm * mask * RippleColorParam.a * vertexColor.a;
    return vec4(blended, opacity);
}

void main() {
    // 纹波层走上面那条独立管线并直接产出最终颜色，不再参与"贴图 × 顶点色"那套合成
    if (Ripple > 0.5) {
        vec4 rippled = rippleShade();
        // 稀疏遮罩下 alpha 本就很低，阈值取得比溶解层更松，避免把整层裁空
        if (rippled.a < 0.004) {
            discard;
        }
        fragColor = rippled;
        return;
    }
    // 云层与溶解层一律按原始 UV 采样：平移只发生在光环纹波那条管线的两路相位里
    vec2 uv = texCoord0;
    vec4 texel = texture(Sampler0, uv);
    vec4 albedo = texel * vertexColor * ColorModulator;
    // 遮罩层：用贴图亮度当不透明度，把"石质底图 / 灰阶遮罩"变成有明暗的通透表面。
    // 云层模式下把多层流动的采样结果也算进遮罩，于是"哪里透"本身也在缓慢变化。
    if (CloudTime > 0.0) {
        // 云层球壳（材质侧的真实链路，逐条对应其 Forward 通道的反汇编）：
        //   1. cloudMask = 两路遮罩的分段合成（cloudDensity 里顺带取出第二路的值 a2）
        //   2. I     = saturate(cloudMask / Mie_Max)       ← 云量，Mie_Max 是除数
        //   3. thin  = 1 − I²(3 − 2I)                     ← 密度整形，云薄处接近 1
        //   4. alpha = saturate(2(1 − a2))                ← 最终透明度**只由第二路遮罩决定**
        //   5. 自发光 = EmissiveColor × thin               ← 薄处发光
        // ⚠ 材质侧这条链里**没有** discard，也**没有**"密度 → 不透明度"的幂曲线与 gradation 斜坡：
        //   AlphaFade_Pow / GradationAlpha* / Alpha_Max / AlphaValue 在本通道全被标 [unused]，
        //   所以本项目原先那两个旋钮是主动扩展，已按还原口径删掉（见 EfxAttributeCloudLayer 的 alphaPow 说明）。
        // ⚠ 仍未建模：参与自发光的 Emissive_Intensity（mdf2 默认 30000）与 Roughness·N.z 项，以及法线两层。
        float a2;
        float cloudMask = cloudDensity(uv, CloudTime, a2);
        float amount = clamp(cloudMask / max(CloudMieMax > 0.0 ? CloudMieMax : 1.0, 1.0e-4), 0.0, 1.0);
        float thin = 1.0 - amount * amount * (3.0 - 2.0 * amount);
        albedo.rgb = vertexColor.rgb + CloudEmissive.rgb * thin;
        albedo.a *= clamp(2.0 * (1.0 - a2), 0.0, 1.0);
    } else if (MaskAlpha > 0.5) {
        // ---------- 覆写贴图的普通网格层（如 インバース0） ----------
        // 贴图是真实颜色图，但本项目让颜色走顶点色（预设里已按 fresnel 在 color1 / color2 之间混合），
        // 贴图只用来决定"哪里亮、哪里透"。稀疏遮罩会让整层几乎全透，故留 0.35 的底。
        float maskLuma = clamp(pow(max(texel.g, 1.0e-6), 1.2) + pow(max(texel.r, 1.0e-6), 1.2), 0.0, 1.0);
        albedo.rgb = vertexColor.rgb;
        albedo.a *= clamp(max(maskLuma * 4.0, 0.35), 0.0, 1.0);
    }
    if (albedo.a < 0.02) {
        discard;
    }
    // 24 是噪声频率：太小会让缺口大而稀疏、太大则碎成噪点。
    // 云层与纹波层的 Dissolve 恒为 0（纹波层在函数开头就分流走了），整段跳过，避免留下烧蚀边。
    vec3 color = albedo.rgb;
    if (Dissolve > 0.001) {
        float n = noise(uv * 24.0);
        if (n < Dissolve) {
            discard;
        }
        // 溶解边缘提亮：贴近阈值的一圈加自发光，缺口边界因此有"被烧蚀"的亮边
        float edge = smoothstep(Dissolve, Dissolve + 0.12, n);
        color += (1.0 - edge) * vec3(0.35, 0.55, 0.85) * 0.8;
    }
    fragColor = vec4(color, albedo.a);
}
