#version 150

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

uniform vec4 ColorModulator;
uniform vec2 InvScreenSize;
uniform float NearPlane;
uniform float FarPlane;
// ---------- 火焰带的剖面 ----------
uniform float WidthTop;
uniform float WidthBottom;
uniform float VolumePower;
uniform float AlphaFadePower;
// ---------- 双通道颜色：Base 路把贴图推亮到过曝（白心），Lim 路给出蓝色边缘光，两路取大 ----------
uniform float BaseIntensity;
uniform float BasePower;
uniform float LimIntensity;
uniform float LimPower;
uniform vec4 LimColor;
uniform vec4 ColorParam;
// 火焰贴图在网格表面上的<b>平铺次数</b>与<b>滚动相位</b>。
uniform vec2 GlowUvScale;
uniform vec2 GlowUvScroll;

in vec2 texCoord0;
// 相交层只用两个分量：.r = |N·V|（朝向项）、.a = 生命期不透明度；普通网格层仍用 RGB 承载 color1→color2 的渐变。
in vec4 vertexColor;

out vec4 fragColor;

// 把窗口空间深度（0~1）还原成到相机的距离。
// 透视投影下 z_ndc 与视距是非线性的，不还原就无法用世界单位表达"接近程度"的阈值。
float linearDepth(float windowDepth) {
    float z = windowDepth * 2.0 - 1.0;
    return (2.0 * NearPlane * FarPlane) / (FarPlane + NearPlane - z * (FarPlane - NearPlane));
}

// 相交火焰的片元着色器：把"片元视距与场景视距之差"做成一条带宽 + 体积项 + 朝向项的发光带。
// 曾经的三个错误：带宽取窄了一个数量级；视距差取了对称的 |Δ|（只有可见侧才有火焰）；
// 用贴图 RGB 亮度当形状（实际形状来自贴图 alpha，RGB 另有 Base 通路）。
void main() {
    // 贴图 UV 必须先按 UVscale 平铺、再叠加滚动相位；否则只有 UV 恰好落在火焰图案上的那一小块会亮。
    vec2 glowUv = texCoord0 * GlowUvScale + GlowUvScroll;
    vec4 baseTexel = texture(Sampler0, glowUv);
    if (baseTexel.a <= 0.001) {
        discard;
    }
    vec2 screenUv = gl_FragCoord.xy * InvScreenSize;
    float sceneDepth = texture(Sampler1, screenUv).r;
    // 深度为 1 表示那里是天空（没有任何几何），天空不会与球面相交，直接跳过
    if (sceneDepth >= 1.0) {
        discard;
    }
    
    // ---------- ① 带符号的视距差 ----------
    // dist < 0（片元被地面挡住的那一侧）不该有火焰；显式 discard 等价于把负侧压到 0，且更省。
    float dist = linearDepth(sceneDepth) - linearDepth(gl_FragCoord.z) - WidthBottom;
    if (dist <= 0.0) {
        discard;
    }
    // ---------- ② 体积项：贴图 alpha 门控 ----------
    // 火焰形状来自贴图的 alpha 通道，不是 RGB。
    float volume = clamp(pow(max(dist, 1.0E-6), VolumePower) * baseTexel.a, 0.0, 1.0);
    // ---------- ③ 火焰带的剖面 ----------
    // 交线处 dist → 0，带值最大；越往可见侧越暗，到 WidthTop 处归零。
    float band = pow(max(1.0 - clamp(dist / max(WidthTop, 1.0E-6), 0.0, 1.0), 1.0E-6), VolumePower);
    // ---------- ④ 朝向项 ----------
    // |N·V| 由顶点色传入：正对镜头最亮、掠射变暗。
    float ndotv = clamp(vertexColor.r, 0.0, 1.0);
    float facing = pow(max(ndotv, 1.0E-6), AlphaFadePower);
    
    // ---------- ⑤ 双通道颜色 ----------
    // Base 路明亮、Lim 路沿掠射圈最亮，两者取大。
    // ColorParam 由 Java 侧从该层的 color1 写入，颜色就来自这一乘——把它写死成白色会让 Base 恒为白、压掉蓝。
    //
    // HDR_GAIN_SCALE 是本项目 LDR 管线必须做的归一化：材质的 Base / Lim 增益是相对"HDR 白点"的，
    // 照搬会让两条通路在任何纹理像素上都直接到顶、火焰退化成纯色板。
    // 0.01 使 Lim 恰好落到 LDR 满值 1.0，Base : Lim 的比值保持不变，同时保住了贴图蓝通道的明暗层次。
    // 这是本项目唯一一处不照抄材质数值的地方，观感偏亮/偏暗时调它即可。
    const float HDR_GAIN_SCALE = 0.01;
    vec3 baseCh = pow(max(baseTexel.rgb * BaseIntensity * HDR_GAIN_SCALE, vec3(1.0E-6)), vec3(BasePower))
        * ColorParam.rgb;
    vec3 limCh = vec3(pow(max(1.0 - ndotv, 1.0E-6), LimPower)) * (LimIntensity * HDR_GAIN_SCALE) * LimColor.rgb;
    vec3 rgb = clamp(max(baseCh, limCh) * ColorModulator.rgb, 0.0, 1.0);
    
    // ---------- ⑥ alpha ----------
    // 输出非预乘：本类型的混合是"源 alpha × 源色 + 目标色"（见 mesh_intersect.json）。
    float alpha = clamp(band * volume * facing * vertexColor.a * ColorParam.a, 0.0, 1.0);
    fragColor = vec4(rgb, alpha);
}
