#version 150

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in vec2 UV2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;
out vec4 vertexColor;

// 相交发光的顶点着色器：只做位置变换与属性透传。
// 配套的片元着色器要用 gl_FragCoord 取屏幕像素坐标，故这里必须输出标准投影结果。
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    vertexColor = Color;
}
