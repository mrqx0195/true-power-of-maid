#version 150

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in vec2 UV2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;
out vec4 vertexColor;

// 网格溶解的顶点着色器：只做位置变换与属性透传。溶解阈值由片元着色器的 Dissolve uniform 提供，
// 它由粒子侧逐 tick 写入，因此同一批（同一层）的所有粒子共用同一个阈值。
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    vertexColor = Color;
}
