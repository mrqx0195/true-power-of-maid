#version 150

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in vec2 UV2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;
out vec4 vertexColor;

// 玻璃碎片的顶点着色器：与 われ 网格一致，只做位置变换与属性透传；
// 材质表现（ALB 采样、NRM 光照、边缘 Fresnel）全部在片元着色器里完成。
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    vertexColor = Color;
}
