#version 150

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform vec4 ColorModulator;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

// 玻璃碎片的片元着色器：采样真实材质的 ALB（基础色）与 NRM（切线空间法线）。
// 粒子渲染阶段拿不到完整 TBN 与世界光照，故用两条近似：固定斜向"环境光"的朗伯漫反射 + 法线朝向的 Fresnel。
// 视觉目标是"碎片有清晰的切面明暗 + 边缘发亮"，而不是物理正确的折射。
void main() {
    vec4 albedo = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (albedo.a < 0.02) {
        discard;
    }
    // NRM 贴图为切线空间法线：xy 存法线分量，z 由单位长度约束反推
    vec3 normal = texture(Sampler1, texCoord0).xyz * 2.0 - 1.0;
    normal = normalize(vec3(normal.xy, sqrt(max(0.0, 1.0 - dot(normal.xy, normal.xy)))));
    // 视线方向近似为 +Z（相机空间），法线越背向视线越接近掠射
    float facing = clamp(normal.z, 0.0, 1.0);
    float fresnel = pow(1.0 - facing, 2.0);
    vec3 lightDirection = normalize(vec3(0.35, 0.55, 0.75));
    float diffuse = clamp(dot(normal, lightDirection) * 0.5 + 0.5, 0.0, 1.0);
    vec3 color = albedo.rgb * (0.75 + 0.45 * diffuse) + vec3(0.35, 0.45, 0.55) * fresnel * 0.5;
    fragColor = vec4(color, albedo.a);
}
