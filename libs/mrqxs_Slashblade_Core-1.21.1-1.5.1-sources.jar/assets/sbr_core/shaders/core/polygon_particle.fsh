#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float AlphaLowPass;
// alpha 曲线的宽度（材质属性 AlphaCorrection.highPass）；与 AlphaLowPass 一起构成曲线。
uniform float AlphaHighPass;
// 本层贴图 alpha 的上下限（Java 侧一次性预处理得到）：着色器先把贴图 alpha 缩放到 0~1 再进曲线，
// 于是按材质自带贴图标定的 lowPass / highPass 恢复原义，不必为替代贴图逐层手调阈值。
uniform float AlphaMin;
uniform float AlphaMax;
uniform vec4 DualColorMain;
uniform vec4 DualColorRange;
uniform float DualColorSplit;
uniform float DualColorBrightness;
// 是否按<b>预乘 alpha</b> 输出（1 = 预乘）。该族材质的片元输出是预乘的：rgb 已乘过最终的 alpha，
// 于是混合因子取 ONE 而不是 SRC_ALPHA。本项目的顶点格式装不下那套逐顶点 alpha 通道，
// 观感是由"输出预乘 + 混合因子 ONE"还是"输出非预乘 + 混合因子 SRC_ALPHA"决定的，
// 两者在软边上差别明显（非预乘相当于把混合因子又乘了一遍 alpha、边缘更暗），故做成开关由 Java 侧按混合模式下发。
uniform float Premultiply;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);
    vec4 color;
    if (DualColorSplit > 0.0) {
        float a = texel.a;
        vec3 mainRgb = clamp(DualColorMain.rgb * DualColorBrightness, 0.0, 1.0);
        vec3 rangeRgb = clamp(DualColorRange.rgb * DualColorBrightness, 0.0, 1.0);
        float vAlpha = vertexColor.a * ColorModulator.a;

        if (a > DualColorSplit) {
            float high = clamp((a - DualColorSplit) / max(1.0 - DualColorSplit, 1.0e-4), 0.0, 1.0);
            color = vec4(mainRgb * ColorModulator.rgb, high * vAlpha);
        } else {
            float low = clamp(a / max(DualColorSplit, 1.0e-4), 0.0, 1.0);
            color = vec4(rangeRgb * ColorModulator.rgb, low * vAlpha);
        }
    } else {
        color = texel * vertexColor * ColorModulator;
    }

    // 材质侧的 alpha 曲线（复刻，只取两个自由度）：
    //   normalized = (贴图 alpha − AlphaMin) ÷ (AlphaMax − AlphaMin)   ← 先把替代贴图的 alpha 缩放到 0~1
    //   t          = normalized ^ 4.84
    //   曲线        = saturate((t − lowPass) ÷ highPass)
    // ⚠ lowPass / highPass 是曲线的**起点与宽度**，不是"低于即丢弃"的硬阈值；材质侧全程没有 discard。
    // ⚠ 那两个值是按**材质自带贴图**标定的（其 alpha 上限为 1.0），所以必须先按本层贴图自己的上下限缩放回同一量程；
    //   否则照抄原值会把整层压成全透明（例如上限 0.81 的替代贴图，其 4.84 次幂只有约 0.36）。
    // ⚠ 只取两个自由度：原作另两个（固定 alpha 与两段平滑权重）来自逐顶点插值通道，本项目顶点格式装不下。
    if (AlphaLowPass > 0.0) {
        float normalized = (texel.a - AlphaMin) / max(AlphaMax - AlphaMin, 1.0e-4);
        float curveBase = pow(max(normalized, 1.0e-6), 4.84);
        color.a *= clamp((curveBase - AlphaLowPass) / max(AlphaHighPass, 1.0e-4), 0.0, 1.0);
    }
    // 全透明片元不写：这是填充率保护，不是曲线本身（材质侧没有 discard）。
    if (color.a < 1.0e-4) {
        discard;
    }
    // ⚠ 必须放在 alpha 曲线的<b>后面</b>：预乘要把"曲线之后的最终 alpha"乘进 rgb，提前乘等于用未校正的
    //  贴图 alpha 去压颜色，曲线就白做了。
    if (Premultiply > 0.0) {
        color.rgb *= color.a;
    }
    fragColor = color;
}