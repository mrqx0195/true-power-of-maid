#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 OutSize;
uniform float Aspect;
uniform float SceneBlur;

// 光斑槽位：GPU 端固定提供 6 组，未使用的槽位由 Java 侧把强度清零
uniform vec3 GlowColor0;
uniform vec2 GlowCenter0;
uniform vec4 GlowParams0;
uniform vec3 GlowColor1;
uniform vec2 GlowCenter1;
uniform vec4 GlowParams1;
uniform vec3 GlowColor2;
uniform vec2 GlowCenter2;
uniform vec4 GlowParams2;
uniform vec3 GlowColor3;
uniform vec2 GlowCenter3;
uniform vec4 GlowParams3;
uniform vec3 GlowColor4;
uniform vec2 GlowCenter4;
uniform vec4 GlowParams4;
uniform vec3 GlowColor5;
uniform vec2 GlowCenter5;
uniform vec4 GlowParams5;

in vec2 texCoord;
out vec4 fragColor;

// 叠加模式（与 Java 侧 GlowSpec.MODE_* 一一对应）
const float MODE_ADD = 0.0;
const float MODE_SCREEN = 1.0;
const float MODE_DARKEN = 2.0;

// 叠加单个光斑。params = (强度, 屏幕半径(以屏幕高度为单位), 模式, 边缘柔和度)；
// 光斑以发射点的屏幕投影为中心向外柔和衰减，没有面片那种被视角拉伸、边缘被裁切的问题。
vec3 applyGlow(vec3 scene, vec2 uv, vec2 center, vec3 color, vec4 params) {
    float strength = params.x;
    float radius = params.y;
    float mode = params.z;
    // softness 至少留一点：smoothstep 的两个边界相等时是未定义行为
    float softness = clamp(params.w, 0.01, 1.0);
    // 空闲槽位：强度或半径为零时该光斑不参与叠加
    if (strength <= 0.0 || radius <= 0.0) {
        return scene;
    }
    // 乘上屏幕宽高比，把 UV 距离换算成"以屏幕高度为统一尺度"的距离，保证光斑是正圆而非随窗口拉伸的椭圆
    vec2 delta = (uv - center) * vec2(Aspect, 1.0);
    float dist = length(delta) / radius;
    if (dist >= 1.0) {
        return scene;
    }
    // 中心 1 → 边缘 0 的柔和衰减；再平方一次让能量向中心聚拢，形成辉光贴图那样的径向衰减
    float falloff = 1.0 - smoothstep(1.0 - softness, 1.0, dist);
    falloff *= falloff;
    if (mode < 0.5) {
        // 线性加法（对应 Flags=2 的加法混合）
        return scene + color * (strength * falloff);
    }
    if (mode < 1.5) {
        // 滤色（过曝）：ColorRate 极大值的层其顶点色会被截断成纯白，用滤色叠加能得到同样的
        // "中心曝白、边缘留色"渐变，且不会先溢出再被硬截断
        vec3 light = clamp(color * strength * falloff, 0.0, 1.0);
        return 1.0 - (1.0 - scene) * (1.0 - light);
    }
    // 乘法压暗（对应 Flags=4 的减算）：按比例压暗，避免暗部被线性相减压成死黑；
    // 颜色的各通道比例参与运算，因此"减去深蓝"会相对更多地压掉蓝色通道
    vec3 darken = clamp(color * strength * falloff, 0.0, 1.0);
    return scene * (1.0 - darken);
}

void main() {
    vec3 scene = texture(DiffuseSampler, texCoord).rgb;
    // 场景整体软化：用后处理做才不会有面片边缘；十字五点采样，权重和为 1
    if (SceneBlur > 0.0) {
        vec2 texel = SceneBlur / OutSize;
        vec3 blurred = scene * 0.4;
        blurred += texture(DiffuseSampler, texCoord + vec2(texel.x, 0.0)).rgb * 0.15;
        blurred += texture(DiffuseSampler, texCoord - vec2(texel.x, 0.0)).rgb * 0.15;
        blurred += texture(DiffuseSampler, texCoord + vec2(0.0, texel.y)).rgb * 0.15;
        blurred += texture(DiffuseSampler, texCoord - vec2(0.0, texel.y)).rgb * 0.15;
        scene = blurred;
    }
    scene = applyGlow(scene, texCoord, GlowCenter0, GlowColor0, GlowParams0);
    scene = applyGlow(scene, texCoord, GlowCenter1, GlowColor1, GlowParams1);
    scene = applyGlow(scene, texCoord, GlowCenter2, GlowColor2, GlowParams2);
    scene = applyGlow(scene, texCoord, GlowCenter3, GlowColor3, GlowParams3);
    scene = applyGlow(scene, texCoord, GlowCenter4, GlowColor4, GlowParams4);
    scene = applyGlow(scene, texCoord, GlowCenter5, GlowColor5, GlowParams5);
    // 输出 alpha 固定为 1：本 pass 的结果会被 blit 回主目标，
    // 若保留画面原有 alpha，半透明像素会在回写时被再混合一次而发黑
    fragColor = vec4(clamp(scene, 0.0, 1.0), 1.0);
}
