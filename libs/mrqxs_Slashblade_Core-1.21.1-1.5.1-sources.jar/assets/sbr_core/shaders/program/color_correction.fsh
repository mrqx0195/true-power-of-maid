#version 150

uniform sampler2D DiffuseSampler;
uniform float Saturation;
uniform float Contrast;
uniform float Brightness;
uniform vec3 Tint;
uniform float RefractiveIndex;
uniform float Dispersion;
// 宽高比（每帧由 ColorCorrectionPostEffect 写入）：把屏幕偏移换算成**各向同性**的半径，
// 圆形透镜的"圆"就靠它。json 里声明 uniform 只代表会推送这个值，着色器侧仍要自己声明。
uniform float Aspect;

in vec2 texCoord;
out vec4 fragColor;

// 斩击瞬间的全屏色彩与光学强化：圆形凸透镜放大 + RGB 三通道沿半径的棱镜色散 + 调色。
void main() {
    vec2 center = vec2(0.5);
    vec2 delta = texCoord - center;
    // 不乘 Aspect 时 radius 只反映垂直距离，圆形透镜会退化成一条横向通带（Aspect 为 0 时就是这个症状）
    vec2 aspectDelta = delta * vec2(Aspect, 1.0);
    float radius = length(aspectDelta) * 2.0;

    // 圆形凸透镜：屏幕中心权重 1、向边缘 smoothstep 归零
    float lensMask = 1.0 - smoothstep(0.75, 1.0, radius);
    float lens = (RefractiveIndex - 1.0) * lensMask;
    vec2 lensUV = center + delta * (1.0 - lens);

    // 色散：沿半径方向对 R/B 通道反向偏移，幅度随同一个圆遮罩衰减
    vec2 dir = normalize(delta + vec2(1.0e-6));
    float amount = Dispersion * radius * lensMask;
    float r = texture(DiffuseSampler, lensUV + dir * amount).r;
    vec4 base = texture(DiffuseSampler, lensUV);
    float b = texture(DiffuseSampler, lensUV - dir * amount).b;
    vec3 rgb = vec3(r, base.g, b);

    rgb += Brightness;
    rgb = (rgb - 0.5) * Contrast + 0.5;
    float luma = dot(rgb, vec3(0.2126, 0.7152, 0.0722));
    rgb = mix(vec3(luma), rgb, Saturation);
    rgb *= Tint;
    // 全屏后处理的输出 alpha 固定为 1：若把主目标里半透明粒子的 alpha 原样写回，
    // 后续 blit 会把它们与自身再混合一次，表现是"半透明部分变黑"。
    fragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}
