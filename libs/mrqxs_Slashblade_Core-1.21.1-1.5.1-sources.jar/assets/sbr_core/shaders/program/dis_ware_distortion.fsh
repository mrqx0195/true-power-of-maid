#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D DistortionSampler;
// 材质色彩滤镜遮罩：RGB = 滤镜目标色、A = 该像素的滤镜强度。
// 与 DistortionSampler 并列的第二张缓冲，由 DistortionRenderHook 分两次绘制写入（RenderTarget 不支持多颜色附件）。
uniform sampler2D FilterSampler;
// 屏幕空间逐通道增益遮罩：RGB = 增益目标色、A = 强度与逐像素权重的乘积。
// 与上面两张并列的第三张缓冲，由 DistortionRenderHook 分三次绘制写入。
uniform sampler2D GradingSampler;
// 色散幅度（屏幕 UV 单位）与屏幕边缘遮罩宽度；两者都是**逐层常量**，故走 uniform。
uniform float GradingDispersion;
uniform float GradingEdge;
uniform float Strength;
// ---------- 材质色调参数（逐层 uniform，由 DistortionEffectManager#setFilterProfile 写入）----------
// 逐项对应材质色调级别、自发光强度与去色调速率；与几何无关，故按"同一批写同一个值、最后一个写入者生效"走 uniform。
uniform float FilterToneLevel;
uniform float FilterEmissive;
uniform float FilterDetone;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 mask = texture(DistortionSampler, texCoord);

    // RG 通道编码的偏移方向（0~1 映射自 -1~1），A 通道为折射强度。
    // A 里**已经折进视深因子**：该族材质的折射偏移与视深成反比，而 Strength 是逐帧常量、吸收不了逐像素的
    // 深度，故由遮罩写入侧逐顶点乘上「参考视深 ÷ 视深」再写进来；此处只管乘全局 Strength。
    vec2 dir = (mask.rg - 0.5) * 2.0;
    float amount = mask.a * Strength;

    // B 通道存放大倍率增量（遮罩侧写入 zoom-1）：放大畸变后的内容，向屏幕中心收缩采样 UV （受折射强度影响），
    // 预留屏幕边缘余量，从根源减少折射偏移把屏幕外未渲染内容拉进画面
    float zoom = (1.0 + mask.b * mask.a);
    vec2 patchedCoord = (texCoord - 0.5) / zoom + 0.5;

    vec2 offsetUV = clamp(patchedCoord + dir * amount, vec2(0.001), vec2(0.999));
    vec3 sceneColor = texture(DiffuseSampler, offsetUV).rgb;

    // ---------- 材质色彩滤镜（白黒 / 開始　青 的"黑白滤镜 / 青色滤镜"）----------
    // 材质把色阶、自发光、去色三项串联在 HDR 缓冲上工作，本项目没有 HDR 缓冲，故参数化后按下面的形式近似。
    vec4 filter = texture(FilterSampler, texCoord);
    if (filter.a > 0.0) {
        // 向"滤镜色的单色"收敛：tint = 白即去色（白黒），tint = 淡青即青色滤镜（開始　青）
        float luma = dot(sceneColor, vec3(0.2126, 0.7152, 0.0722));
        vec3 tinted = filter.rgb * luma;
        vec3 filtered = mix(sceneColor, tinted, clamp(filter.a, 0.0, 1.0));
        // 色阶指数：去色调速率在"原色"与"取幂后的调色"之间插值（0 = 纯滤镜）
        filtered = mix(filtered, pow(max(filtered, vec3(1.0e-6)), vec3(max(FilterToneLevel, 1.0e-6))),
                       clamp(FilterDetone, 0.0, 1.0));
        // EmissiveIntensity 的 LDR 上限：白点已由 CPU 侧折进 FilterEmissive（0~1）
        filtered = min(filtered, vec3(clamp(FilterEmissive, 0.0, 1.0)));
        sceneColor = filtered;
    }

    // ---------- 屏幕空间逐通道增益 + 色散 ----------
    // 与上一段是**并列**的两条语义：上一段是"向目标色收敛"（tinted = tint × luma，再 mix），
    // 本段是"逐通道乘性增益"。把强度权重预乘进遮罩的 A、把增益目标色写进遮罩的 RGB，于是只剩一行乘法。
    vec4 grading = texture(GradingSampler, texCoord);
    if (grading.a > 0.0) {
        // 色散：沿屏幕径向把 R / B 两路错开采样
        if (GradingDispersion > 0.0) {
            vec2 dispersion = (texCoord - 0.5) * GradingDispersion * grading.a;
            sceneColor.r = texture(DiffuseSampler, clamp(offsetUV + dispersion, vec2(0.001), vec2(0.999))).r;
            sceneColor.b = texture(DiffuseSampler, clamp(offsetUV - dispersion, vec2(0.001), vec2(0.999))).b;
        }
        sceneColor *= 1.0 + grading.a * (grading.rgb - 1.0);
    }
    // 屏幕边缘遮罩：把画面四边外侧平滑压到 0，避免球把屏幕染成硬边。
    // ⚠ 必须限定在"本像素确实被滤镜覆盖"（grading.a > 0）且按 grading.a 加权：否则只要遮罩缓冲里
    // 有任何一像素非零，整幅画面的四边就会被压暗，且压暗量与 a 无关、渐弱段也不会减弱。
    if (GradingEdge > 0.0 && grading.a > 0.0) {
        vec2 edgeDistance = min(texCoord, vec2(1.0) - texCoord);
        float edgeFade = smoothstep(0.0, GradingEdge, min(edgeDistance.x, edgeDistance.y));
        sceneColor *= mix(1.0, edgeFade, clamp(grading.a, 0.0, 1.0));
    }

    fragColor = vec4(sceneColor, 1.0);
}
