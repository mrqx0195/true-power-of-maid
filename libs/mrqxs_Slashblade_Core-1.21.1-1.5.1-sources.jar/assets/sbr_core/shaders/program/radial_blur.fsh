#version 150

uniform sampler2D DiffuseSampler;
uniform float BlurPower;
uniform vec2 Center;
uniform float ColorRate;
uniform float MaskRate;
uniform vec2 MaskSmoothstep;
uniform vec2 ScreenPosition;
// 输入画面的像素尺寸（由 PostChain 自动写入）：只用于把"屏幕距离"折算成各向同性的圆。
uniform vec2 InSize;

in vec2 texCoord;
out vec4 fragColor;

// 沿半径方向向画面中心收缩采样：越靠外收缩越多，形成"焦点中心清晰、四周发散"的径向模糊
const int SAMPLES = 12;

void main() {
    vec2 dir = texCoord - Center;
    vec3 sum = vec3(0.0);
    for (int i = 0; i < SAMPLES; i++) {
        float t = float(i) / float(SAMPLES - 1);
        float scale = 1.0 - BlurPower * 0.02 * t;
        // 色差：让 R 与 B 两个通道沿半径的收缩量略微反向偏移，边缘于是出现红蓝分离的彩色描边，
        // "速度感"主要来自它；ColorRate = 0 时三通道完全同步，退化成纯亮度模糊。
        float spread = ColorRate * 0.002 * t;
        sum.r += texture(DiffuseSampler, Center + dir * (scale + spread)).r;
        sum.g += texture(DiffuseSampler, Center + dir * scale).g;
        sum.b += texture(DiffuseSampler, Center + dir * (scale - spread)).b;
    }
    vec3 blurred = sum / float(SAMPLES);

    // 局部遮罩：以 ScreenPosition 为心、MaskSmoothstep 为过渡带，把模糊限制在画面的一角/一带；
    // MaskRate = 0 时 mask 恒为 1，退化成全屏均匀模糊。
    // 宽高比修正：texCoord 横纵 1 个 UV 覆盖的像素数不同，直接取长度会让圆遮罩在 16:9 屏幕上变成横向拉长的椭圆。
    float aspect = InSize.x / max(InSize.y, 1.0);
    float maskDistance = length((texCoord - ScreenPosition) * vec2(aspect, 1.0));
    float mask = 1.0 - MaskRate * smoothstep(MaskSmoothstep.x, MaskSmoothstep.y, maskDistance);
    fragColor = vec4(mix(texture(DiffuseSampler, texCoord).rgb, blurred, mask), 1.0);
}
