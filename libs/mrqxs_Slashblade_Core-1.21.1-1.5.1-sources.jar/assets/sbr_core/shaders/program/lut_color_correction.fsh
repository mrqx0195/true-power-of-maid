#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D LutSampler;
uniform vec2 InSize;
uniform vec2 OutSize;
uniform float LutBlendRate;

in vec2 texCoord;
out vec4 fragColor;

// 立方 LUT 的边长（图集按 32 片切片拼成 256x128 的 2D 纹理，硬件没有 3D 采样可用）。
const int LUT_SIZE = 32;

// 图集列数：32 片切片按 8 列 4 行拼成 256x128。
const int ATLAS_COLS = 8;

// LUT 色彩校正：把画面颜色当 LUT 索引，手工三线性查表后按效果强度混合回去。
// DiffuseSampler 收到的已是显示空间（sRGB 编码）的成品画面，正是查表要用的编码，故索引直接取 color。

// 取立方体中的一个体素。入参分量为 (红索引, 绿索引, 蓝索引)。
vec3 lutTexel(ivec3 index) {
    int col = index.z % ATLAS_COLS;
    int row = index.z / ATLAS_COLS;
    return texelFetch(LutSampler, ivec2(col * LUT_SIZE + index.x, row * LUT_SIZE + index.y), 0).rgb;
}

// 手工三线性采样立方 LUT。
// 用 texelFetch 而不是 texture()：图集里相邻切片首尾相接，硬件双线性会在切片边界把相邻两片混起来。
vec3 sampleLut(vec3 color) {
    vec3 coord = clamp(color, 0.0, 1.0) * float(LUT_SIZE - 1);
    ivec3 lo = ivec3(floor(coord));
    ivec3 hi = min(lo + 1, ivec3(LUT_SIZE - 1));
    vec3 t = coord - vec3(lo);

    vec3 c000 = lutTexel(ivec3(lo.x, lo.y, lo.z));
    vec3 c100 = lutTexel(ivec3(hi.x, lo.y, lo.z));
    vec3 c010 = lutTexel(ivec3(lo.x, hi.y, lo.z));
    vec3 c110 = lutTexel(ivec3(hi.x, hi.y, lo.z));
    vec3 c001 = lutTexel(ivec3(lo.x, lo.y, hi.z));
    vec3 c101 = lutTexel(ivec3(hi.x, lo.y, hi.z));
    vec3 c011 = lutTexel(ivec3(lo.x, hi.y, hi.z));
    vec3 c111 = lutTexel(ivec3(hi.x, hi.y, hi.z));

    vec3 c00 = mix(c000, c100, t.x);
    vec3 c10 = mix(c010, c110, t.x);
    vec3 c01 = mix(c001, c101, t.x);
    vec3 c11 = mix(c011, c111, t.x);
    return mix(mix(c00, c10, t.y), mix(c01, c11, t.y), t.z);
}

void main() {
    vec4 source = texture(DiffuseSampler, texCoord);
    vec3 graded = sampleLut(source.rgb);
    // LutBlendRate = 本效果的强度包络（EFX Life 的 Appear/Keep/Vanish）× 该层的 Cube2BlendRateMax。
    // ⚠ 后者在数据里**可以大于 1**（`カラコレ` 那一层是 1.25，含义是"比完全应用再多一点"），
    //   故这里只做下限保护、**不**把上界夹到 1——GLSL 的 mix 本身支持 t > 1 的外插。
    // 输出 alpha 固定为 1（同 color_correction.fsh）：保留场景 alpha 会让半透明粒子在 blit 时被二次混合而变黑
    fragColor = vec4(mix(source.rgb, graded, max(LutBlendRate, 0.0)), 1.0);
}
