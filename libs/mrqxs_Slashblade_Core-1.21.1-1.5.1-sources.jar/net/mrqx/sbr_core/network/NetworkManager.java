package net.mrqx.sbr_core.network;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * 网络管理器，负责注册自定义网络数据包。
 */
@EventBusSubscriber
public class NetworkManager {
    private static final String PROTOCOL_VERSION = "1";
    
    @SubscribeEvent
    public static void onRegisterPayloadHandlersEvent(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);
        registrar.playToClient(SlashEntitySyncMessage.TYPE, SlashEntitySyncMessage.STREAM_CODEC, SlashEntitySyncMessage::handle);
        registrar.playToClient(JudgementCutEndEffectMessage.TYPE, JudgementCutEndEffectMessage.STREAM_CODEC, JudgementCutEndEffectMessage::handle);
        registrar.playToClient(JudgementCutEndRangeEffectMessage.TYPE, JudgementCutEndRangeEffectMessage.STREAM_CODEC, JudgementCutEndRangeEffectMessage::handle);
        registrar.playToClient(DimensionSlashNormalEffectMessage.TYPE, DimensionSlashNormalEffectMessage.STREAM_CODEC, DimensionSlashNormalEffectMessage::handle);
        registrar.playToClient(DimensionSlashPerfectEffectMessage.TYPE, DimensionSlashPerfectEffectMessage.STREAM_CODEC, DimensionSlashPerfectEffectMessage::handle);
        registrar.playToClient(DimensionSlashBossEffectMessage.TYPE, DimensionSlashBossEffectMessage.STREAM_CODEC, DimensionSlashBossEffectMessage::handle);
    }
}
