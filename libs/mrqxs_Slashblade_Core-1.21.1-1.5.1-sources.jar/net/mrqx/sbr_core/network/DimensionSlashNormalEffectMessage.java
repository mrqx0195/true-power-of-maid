package net.mrqx.sbr_core.network;

import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.timeline.DimensionSlashNormalTimeline;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * 次元斩（小技能）<b>普通变体</b>的触发包；载荷语义同 {@link DimensionSlashBossEffectMessage}。
 *
 * @param position 目标位置（特效中心）
 */
public record DimensionSlashNormalEffectMessage(Vec3 position) implements CustomPacketPayload {
    public static final Type<DimensionSlashNormalEffectMessage> TYPE =
        new Type<>(MrqxSlashBladeCore.prefix("dimension_slash_normal_effect"));
    public static final StreamCodec<RegistryFriendlyByteBuf, DimensionSlashNormalEffectMessage> STREAM_CODEC =
        CustomPacketPayload.codec(DimensionSlashNormalEffectMessage::write,
            DimensionSlashNormalEffectMessage::new);
    
    /**
     * 从网络缓冲区反序列化。
     */
    private DimensionSlashNormalEffectMessage(RegistryFriendlyByteBuf buf) {
        this(buf.readVec3());
    }
    
    /**
     * 序列化至网络缓冲区。
     */
    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeVec3(this.position);
    }
    
    @Override
    public Type<DimensionSlashNormalEffectMessage> type() {
        return TYPE;
    }
    
    /**
     * 客户端收到数据包后：播放普通变体的演出。
     */
    public static void handle(DimensionSlashNormalEffectMessage msg, IPayloadContext ctx) {
        if (Minecraft.getInstance().level != null) {
            DimensionSlashNormalTimeline.play(Minecraft.getInstance().level, msg.position());
        }
    }
}
