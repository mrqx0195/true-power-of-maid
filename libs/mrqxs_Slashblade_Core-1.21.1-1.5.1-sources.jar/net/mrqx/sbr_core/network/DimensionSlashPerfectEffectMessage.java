package net.mrqx.sbr_core.network;

import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.timeline.DimensionSlashPerfectTimeline;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * 次元斩（小技能）<b>完美变体</b>的触发包；载荷语义同 {@link DimensionSlashBossEffectMessage}。
 *
 * @param position 目标位置（特效中心）
 */
public record DimensionSlashPerfectEffectMessage(Vec3 position) implements CustomPacketPayload {
    public static final Type<DimensionSlashPerfectEffectMessage> TYPE =
        new Type<>(MrqxSlashBladeCore.prefix("dimension_slash_perfect_effect"));
    public static final StreamCodec<RegistryFriendlyByteBuf, DimensionSlashPerfectEffectMessage> STREAM_CODEC =
        CustomPacketPayload.codec(DimensionSlashPerfectEffectMessage::write,
            DimensionSlashPerfectEffectMessage::new);
    
    /**
     * 从网络缓冲区反序列化。
     */
    private DimensionSlashPerfectEffectMessage(RegistryFriendlyByteBuf buf) {
        this(buf.readVec3());
    }
    
    /**
     * 序列化至网络缓冲区。
     */
    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeVec3(this.position);
    }
    
    @Override
    public Type<DimensionSlashPerfectEffectMessage> type() {
        return TYPE;
    }
    
    /**
     * 客户端收到数据包后：播放完美变体的演出。
     */
    public static void handle(DimensionSlashPerfectEffectMessage msg, IPayloadContext ctx) {
        if (Minecraft.getInstance().level != null) {
            DimensionSlashPerfectTimeline.play(Minecraft.getInstance().level, msg.position());
        }
    }
}
