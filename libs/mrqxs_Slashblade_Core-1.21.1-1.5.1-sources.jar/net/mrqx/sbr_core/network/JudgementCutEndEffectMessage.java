package net.mrqx.sbr_core.network;

import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.timeline.JudgementCutEndTimeline;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * 次元斩绝特效
 *
 * @param position 特效中心位置
 */
public record JudgementCutEndEffectMessage(Vec3 position) implements CustomPacketPayload {
    public static final Type<JudgementCutEndEffectMessage> TYPE = new Type<>(MrqxSlashBladeCore.prefix("judgement_cut_end_effect"));
    public static final StreamCodec<RegistryFriendlyByteBuf, JudgementCutEndEffectMessage> STREAM_CODEC = CustomPacketPayload
        .codec(JudgementCutEndEffectMessage::write, JudgementCutEndEffectMessage::new);
    
    /**
     * 从网络缓冲区反序列化。
     */
    private JudgementCutEndEffectMessage(RegistryFriendlyByteBuf buf) {
        this(buf.readVec3());
    }
    
    /**
     * 序列化至网络缓冲区。
     */
    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeVec3(this.position);
    }
    
    @Override
    public Type<JudgementCutEndEffectMessage> type() {
        return TYPE;
    }
    
    /**
     * 客户端收到数据包后：播放斩绝效果。
     */
    public static void handle(JudgementCutEndEffectMessage msg, IPayloadContext ctx) {
        if (Minecraft.getInstance().level != null) {
            JudgementCutEndTimeline.play(Minecraft.getInstance().level, msg.position());
        }
    }
}