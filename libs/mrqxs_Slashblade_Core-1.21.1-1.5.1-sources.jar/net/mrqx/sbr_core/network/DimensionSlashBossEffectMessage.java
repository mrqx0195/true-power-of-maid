package net.mrqx.sbr_core.network;

import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.timeline.DimensionSlashBossTimeline;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * 次元斩（小技能）<b>BOSS 变体</b>的触发包。
 * <p>
 * 载荷只带一个位置——本组演出的原点是<b>目标位置</b>（命中点），与施法者位置无关，
 * 也不需要传朝向或半径：各层的位置完全由数据里的 {@code LocalPosition} 决定。
 *
 * @param position 目标位置（特效中心）
 */
public record DimensionSlashBossEffectMessage(Vec3 position) implements CustomPacketPayload {
    public static final Type<DimensionSlashBossEffectMessage> TYPE =
        new Type<>(MrqxSlashBladeCore.prefix("dimension_slash_boss_effect"));
    public static final StreamCodec<RegistryFriendlyByteBuf, DimensionSlashBossEffectMessage> STREAM_CODEC =
        CustomPacketPayload.codec(DimensionSlashBossEffectMessage::write, DimensionSlashBossEffectMessage::new);
    
    /**
     * 从网络缓冲区反序列化。
     */
    private DimensionSlashBossEffectMessage(RegistryFriendlyByteBuf buf) {
        this(buf.readVec3());
    }
    
    /**
     * 序列化至网络缓冲区。
     */
    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeVec3(this.position);
    }
    
    @Override
    public Type<DimensionSlashBossEffectMessage> type() {
        return TYPE;
    }
    
    /**
     * 客户端收到数据包后：播放 BOSS 变体的演出。
     */
    public static void handle(DimensionSlashBossEffectMessage msg, IPayloadContext ctx) {
        if (Minecraft.getInstance().level != null) {
            DimensionSlashBossTimeline.play(Minecraft.getInstance().level, msg.position());
        }
    }
}
