package net.mrqx.sbr_core.network;

import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.timeline.JudgementCutEndRangeTimeline;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * 次元斩绝·范围效果的触发包。
 * <p>
 * 与 {@link JudgementCutEndEffectMessage} 相互独立：本包只负责"范围效果"这一套演出，
 * 改动它不会影响已在使用的斩绝演出。
 * <p>
 * <b>载荷只带一个位置</b>——本项目两个特效的施法者位置与命中点一致，
 * 因此不需要额外传施法者 id / 朝向 / 半径；层内的骨骼高度差异由
 * {@code BoneOffset} 的固定偏移承担。
 *
 * @param position 特效中心位置（施法者位置 = 命中点）
 */
public record JudgementCutEndRangeEffectMessage(Vec3 position) implements CustomPacketPayload {
    public static final Type<JudgementCutEndRangeEffectMessage> TYPE =
        new Type<>(MrqxSlashBladeCore.prefix("dimension_slash_range_effect"));
    public static final StreamCodec<RegistryFriendlyByteBuf, JudgementCutEndRangeEffectMessage> STREAM_CODEC =
        CustomPacketPayload.codec(JudgementCutEndRangeEffectMessage::write, JudgementCutEndRangeEffectMessage::new);
    
    /**
     * 从网络缓冲区反序列化。
     */
    private JudgementCutEndRangeEffectMessage(RegistryFriendlyByteBuf buf) {
        this(buf.readVec3());
    }
    
    /**
     * 序列化至网络缓冲区。
     */
    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeVec3(this.position);
    }
    
    @Override
    public Type<JudgementCutEndRangeEffectMessage> type() {
        return TYPE;
    }
    
    /**
     * 客户端收到数据包后：播放范围效果演出。
     */
    public static void handle(JudgementCutEndRangeEffectMessage msg, IPayloadContext ctx) {
        if (Minecraft.getInstance().level != null) {
            JudgementCutEndRangeTimeline.play(Minecraft.getInstance().level, msg.position());
        }
    }
}
