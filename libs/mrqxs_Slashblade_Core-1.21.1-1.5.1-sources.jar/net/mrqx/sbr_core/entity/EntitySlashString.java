package net.mrqx.sbr_core.entity;

import mods.flammpfeil.slashblade.entity.Projectile;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

import java.util.List;
import java.util.Objects;

/**
 * This class is based on the original work from slashblade_project_-s.-l.-r by dinzeer.
 * <p>
 * Original source: <a href="https://gitee.com/dinzeer/slashblade_project_-s.-l.-r/blob/master/src/main/java/com/dinzeer/slashblade_project_slr/entity/TheSlashStringEntity.java">dinzeer/slashblade_project_-s.-l.-r/.../TheSlashStringEntity.java</a>
 * <p>
 * License: <a href="https://gitee.com/dinzeer/slashblade_project_-s.-l.-r/blob/master/LICENSE">LGPL v3.0</a>
 *
 * @author dinzeer
 */
public class EntitySlashString extends Projectile {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(EntitySlashString.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> LIFETIME = SynchedEntityData.defineId(EntitySlashString.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> ROT_X = SynchedEntityData.defineId(EntitySlashString.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ROT_Y = SynchedEntityData.defineId(EntitySlashString.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DAMAGE = SynchedEntityData.defineId(EntitySlashString.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> AllTimeDamage = SynchedEntityData.defineId(EntitySlashString.class, EntityDataSerializers.BOOLEAN);
    
    public EntitySlashString(EntityType<? extends net.minecraft.world.entity.projectile.Projectile> type, Level level) {
        super(type, level);
    }
    
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(COLOR, 3355647);
        builder.define(ROT_X, random.nextInt(-360, 360));
        builder.define(ROT_Y, random.nextInt(-360, 360));
        builder.define(LIFETIME, 10.0F);
        builder.define(DAMAGE, 1.0F);
        builder.define(AllTimeDamage, false);
    }
    
    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return true;
    }
    
    @Override
    public boolean isPickable() {
        
        return false;
    }
    
    @Override
    public void tick() {
        super.tick();
        if (this.tickCount == 1) {
            if (!this.level().isClientSide()) {
                this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 1.0F);
            }
        }
        if (this.tickCount == this.getLifetime() - 10 || this.getAllTimeDamage()) {
            damage();
        }
        if (this.tickCount > this.getLifetime()) {
            if (!this.level().isClientSide()) {
                this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F,
                    random.nextFloat() * 0.1F + 0.9F);
            } else {
                // 客户端破碎粒子已停用，仅保留音效（spawnBreakParticles 暂不调用）
            }
            this.discard();
        }
    }
    
    private void spawnBreakParticles() {
        int color = this.getColor();
        float r = ((color >> 16) & 0xFF) / 255.0F;
        float g = ((color >> 8) & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        
        DustParticleOptions particleOptions = new DustParticleOptions(new Vector3f(r, g, b), 1.0F);
        
        for (int i = 0; i < 15; i++) {
            double offsetX = (random.nextDouble() - 0.5) * 1.5;
            double offsetY = (random.nextDouble() - 0.5) * 1.5;
            double offsetZ = (random.nextDouble() - 0.5) * 1.5;
            double speedX = (random.nextDouble() - 0.5) * 0.2;
            double speedY = (random.nextDouble() - 0.5) * 0.2;
            double speedZ = (random.nextDouble() - 0.5) * 0.2;
            
            this.level().addParticle(particleOptions,
                this.getX() + offsetX,
                this.getY() + offsetY,
                this.getZ() + offsetZ,
                speedX, speedY, speedZ);
        }
        
        for (int i = 0; i < 8; i++) {
            double offsetX = (random.nextDouble() - 0.5);
            double offsetY = (random.nextDouble() - 0.5);
            double offsetZ = (random.nextDouble() - 0.5);
            
            this.level().addParticle(ParticleTypes.CRIT,
                this.getX() + offsetX,
                this.getY() + offsetY,
                this.getZ() + offsetZ,
                0, 0, 0);
        }
    }
    
    
    public void damage() {
        List<LivingEntity> entityList = this.level()
            .getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(10));
        for (LivingEntity entity : entityList) {
            if (this.getOwner() instanceof LivingEntity owner) {
                if (!Objects.equals(entity, owner)) {
                    entity.invulnerableTime = 0;
                    entity.hurt(new DamageSource(owner.level().registryAccess()
                        .registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE)
                        .getHolderOrThrow(getDamageType()), owner), getDamage());
                }
            }
        }
    }
    
    public ResourceKey<DamageType> getDamageType() {
        return DamageTypes.GENERIC_KILL;
    }
    
    public Boolean getAllTimeDamage() {
        return this.getEntityData().get(AllTimeDamage);
    }
    
    public void setAllTimeDamage(Boolean value) {
        this.getEntityData().set(AllTimeDamage, value);
    }
    
    public int getRotX() {
        return this.getEntityData().get(ROT_X);
    }
    
    public void setRotX(int value) {
        this.getEntityData().set(ROT_X, value);
    }
    
    public int getRotY() {
        return this.getEntityData().get(ROT_Y);
    }
    
    public void setRotY(int value) {
        this.getEntityData().set(ROT_Y, value);
    }
    
    public int getColor() {
        return this.getEntityData().get(COLOR);
    }
    
    public void setColor(int value) {
        this.getEntityData().set(COLOR, value);
    }
    
    public float getLifetime() {
        return this.getEntityData().get(LIFETIME);
    }
    
    public void setLifetime(float value) {
        this.getEntityData().set(LIFETIME, value);
    }
    
    public float getDamage() {
        return this.getEntityData().get(DAMAGE);
    }
    
    public void setDamage(float value) {
        this.getEntityData().set(DAMAGE, value);
    }
}
