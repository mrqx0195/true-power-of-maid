package net.mrqx.sbr_core.registry;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class MrqxParticleType {
    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES = DeferredRegister.create(BuiltInRegistries.PARTICLE_TYPE, MrqxSlashBladeCore.MODID);
    public static final DeferredHolder<ParticleType<?>, ParticleType<?>> POLYGON_PARTICLE = PARTICLE_TYPES.register("polygon_particle", () -> new SimpleParticleType(true));
    
}
