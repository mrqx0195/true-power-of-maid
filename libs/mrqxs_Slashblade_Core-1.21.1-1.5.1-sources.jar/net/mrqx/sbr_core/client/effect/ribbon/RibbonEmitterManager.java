package net.mrqx.sbr_core.client.effect.ribbon;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxRibbonView;
import net.mrqx.sbr_core.client.effect.polygon.PolygonBlendMode;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL14;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 屏幕空间飘带效果的运行时管理器：把粒子的运动轨迹拉成一条三角形带。几何随时间生长：每 tick 积分一次
 * 速度（含重力）把新位置压入轨迹，每帧沿"切线 × 视线"向两侧展开半个宽度，故带子始终面向镜头，
 * 且只保留最近 {@code segmentCount + 1} 个点、尾部不断收缩；绘制在 {@code AFTER_PARTICLES} 阶段，
 * 深度写入关闭、按 {@code BlendFlags} 选混合模式。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class RibbonEmitterManager {
    /**
     * 轨迹点之间的最小间隔（tick）：防止一 tick 内多次推进。
     */
    public static final long MIN_SAMPLE_INTERVAL = 1L;
    
    /**
     * 正在生效的飘带。
     */
    public static final List<ActiveRibbon> ACTIVE = new ArrayList<>();
    
    private RibbonEmitterManager() {
    }
    
    /**
     * 触发一层飘带特效，收尾时刻取默认值。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config) {
        spawn(level, origin, config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 触发一层飘带特效，并指定本段演出的收尾时刻。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks) {
        spawn(level, origin, new EfxRibbonView(config, sustainedKeepTicks));
    }
    
    /**
     * 同上，并指定本场演出的<b>效果范围倍率</b>（逐层的 {@code EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}）。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                             float effectRangeScale) {
        spawn(level, origin, new EfxRibbonView(config, sustainedKeepTicks, effectRangeScale));
    }
    
    /**
     * 触发一层飘带特效（直接给定已摊平的视图）。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxRibbonView view) {
        RandomSource random = level.getRandom();
        Vec3 center = origin.add(view.localOffset.x, view.localOffset.y, view.localOffset.z);
        for (int i = 0; i < view.spawnCount; i++) {
            Vec3 start = center.add(sampleOffset(view, random));
            float radialSpeed = view.speedPerTick
                + (random.nextFloat() - 0.5F) * view.speedRandomPerTick;
            ACTIVE.add(new ActiveRibbon(view, center, start, radialSpeed,
                sampleAlphaScale(view, random), level.getGameTime()));
        }
    }
    
    /**
     * 给一条飘带抽一个透明度系数：RGB 恒为黑，故在 {@code Color} 与 {@code ColorRange} 的 alpha 之间抖动取值。
     */
    public static float sampleAlphaScale(EfxRibbonView view, RandomSource random) {
        float base = (view.color >>> 24 & 0xFF) / 255.0F;
        float range = (view.colorRange >>> 24 & 0xFF) / 255.0F;
        if (range <= 0.0F) {
            return base;
        }
        return base + (range - base) * random.nextFloat();
    }
    
    /**
     * 按发射器形状采样一个相对发射中心的偏移：形状 2 为水平圆盘的边界，形状 1 为球 / 椭球内均匀采样，其余按盒采样。
     */
    public static Vec3 sampleOffset(EfxRibbonView view, RandomSource random) {
        Vector3f range = view.rangeXYZ;
        if (view.shapeType == 2) {
            // 出生在**边界**上（实测"在水平效果边界持续出现"）：内圈是消失处、不是出生地
            double theta = random.nextDouble() * Math.PI * 2.0D;
            return new Vec3(
                Math.cos(theta) * view.outerRadius,
                random.nextDouble() * range.y,
                Math.sin(theta) * view.outerRadius);
        }
        if (view.shapeType == 1) {
            double u = random.nextDouble();
            double v = random.nextDouble();
            double theta = 2.0D * Math.PI * u;
            double phi = Math.acos(2.0D * v - 1.0D);
            double radius = Math.cbrt(random.nextDouble());
            double sinPhi = Math.sin(phi);
            return new Vec3(
                sinPhi * Math.cos(theta) * radius * range.x,
                Math.cos(phi) * radius * range.y,
                sinPhi * Math.sin(theta) * radius * range.z);
        }
        return new Vec3(
            (random.nextDouble() * 2.0D - 1.0D) * range.x,
            (random.nextDouble() * 2.0D - 1.0D) * range.y,
            (random.nextDouble() * 2.0D - 1.0D) * range.z);
    }
    
    /**
     * 清空全部飘带（资源重载或世界切换时调用）。
     */
    public static void clear() {
        ACTIVE.clear();
    }
    
    /**
     * 每个客户端 tick 推进一步：对每条飘带做一次速度积分并采样轨迹点。
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            ACTIVE.clear();
            return;
        }
        long now = level.getGameTime();
        Iterator<ActiveRibbon> iterator = ACTIVE.iterator();
        while (iterator.hasNext()) {
            ActiveRibbon ribbon = iterator.next();
            if (now - ribbon.startGameTime > ribbon.view.totalTicks) {
                iterator.remove();
                continue;
            }
            if (now - ribbon.lastSampleTime >= MIN_SAMPLE_INTERVAL) {
                ribbon.advance(now);
            }
        }
    }
    
    /**
     * 关卡粒子渲染完成后绘制全部飘带。
     */
    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || ACTIVE.isEmpty()) {
            return;
        }
        render(event);
    }
    
    /**
     * 逐条构建并提交三角形带：带与带之间需断开，分别绘制比插入退化三角形更简单可靠。
     */
    public static void render(RenderLevelStageEvent event) {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null) {
            return;
        }
        Camera camera = event.getCamera();
        Vec3 cameraPos = camera.getPosition();
        float renderTime = (float) level.getGameTime()
            + event.getPartialTick().getGameTimeDeltaPartialTick(true);
        
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        // 面片粒子的减法刀光可能把混合方程残留为 REVERSE_SUBTRACT，这里显式复位
        RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        // 顶点色恒为黑，引擎的着色器颜色若不复位会一起乘进 alpha
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        
        for (ActiveRibbon ribbon : ACTIVE) {
            if (ribbon.trail.size() < 2) {
                continue;
            }
            float alpha = ribbon.envelope(renderTime);
            if (alpha <= 0.0F) {
                continue;
            }
            RenderSystem.setShaderTexture(0, ribbon.view.texture);
            applyBlendMode(ribbon.view.blendMode);
            drawRibbon(ribbon, cameraPos, alpha, ribbon.frameIndex(renderTime));
        }
        
        RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
    }
    
    /**
     * 按混合模式设置混合函数。
     */
    public static void applyBlendMode(PolygonBlendMode blendMode) {
        switch (blendMode) {
            case ADDITIVE -> RenderSystem.blendFunc(
                GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            case REVERSE_SUBTRACT -> {
                RenderSystem.blendEquation(GL14.GL_FUNC_REVERSE_SUBTRACT);
                RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            }
            default -> RenderSystem.defaultBlendFunc();
        }
    }
    
    /**
     * 把一条飘带的轨迹构建成三角形带并提交，{@code frame} 为当前序列帧下标。
     */
    public static void drawRibbon(ActiveRibbon ribbon, Vec3 cameraPos, float alpha, int frame) {
        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder buffer = tesselator.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_TEX_COLOR);
        
        // 当前序列帧在图集里的 UV 窗口：沿飘带长度铺满横向一格、宽度方向铺满纵向一格
        int columns = Math.max(1, ribbon.view.frameColumns);
        int rows = Math.max(1, ribbon.view.frameRows);
        float uMin = (float) (frame % columns) / columns;
        float uSpan = 1.0F / columns;
        int row = Math.min(rows - 1, frame / columns);
        float vMin = (float) row / rows;
        float vMax = vMin + 1.0F / rows;
        float red = 0.0F;
        float green = 0.0F;
        float blue = 0.0F;
        // 顶点色 RGB 恒为黑、只有 alpha 生效；贴图只提供形状，颜色由混合模式决定
        float baseAlpha = Mth.clamp(alpha * ribbon.alphaScale, 0.0F, 1.0F);
        
        List<Vec3> trail = ribbon.trail;
        Vector3f toCamera = new Vector3f();
        for (int i = 0; i < trail.size(); i++) {
            Vec3 point = trail.get(i);
            Vec3 previous = trail.get(Math.max(0, i - 1));
            Vec3 next = trail.get(Math.min(trail.size() - 1, i + 1));
            Vector3f tangent = new Vector3f(
                (float) (next.x - previous.x), (float) (next.y - previous.y), (float) (next.z - previous.z));
            if (tangent.lengthSquared() < 1.0E-8F) {
                // 轨迹退化时兜底：取"圆心 → 该点"的径向在水平面内转 90° 作切线
                float rx = (float) (point.x - ribbon.center.x);
                float rz = (float) (point.z - ribbon.center.z);
                tangent.set(rz, 0.0F, -rx);
            }
            toCamera.set(
                (float) (cameraPos.x - point.x), (float) (cameraPos.y - point.y), (float) (cameraPos.z - point.z));
            // 侧向 = 切线 × 视线，带子因此落在屏幕平面内、正面永远正对镜头
            Vector3f side = new Vector3f(tangent).cross(toCamera);
            if (side.lengthSquared() < 1.0E-8F) {
                continue;
            }
            // 带宽沿带长插值：最后一个元素是头端、第一个元素是尾端
            float taper = trail.size() > 1 ? (float) i / (float) (trail.size() - 1) : 1.0F;
            side.normalize().mul(Mth.lerp(taper, ribbon.widthTail, ribbon.widthHead) * 0.5F);
            
            float u = uMin + (float) i / (float) (trail.size() - 1) * uSpan;
            // 顶点必须写成"相机相对坐标"，否则位置完全错乱而不可见
            putVertex(buffer, point.x + side.x - cameraPos.x, point.y + side.y - cameraPos.y,
                point.z + side.z - cameraPos.z, red, green, blue, baseAlpha, u, vMax);
            putVertex(buffer, point.x - side.x - cameraPos.x, point.y - side.y - cameraPos.y,
                point.z - side.z - cameraPos.z, red, green, blue, baseAlpha, u, vMin);
        }
        
        MeshData meshData = buffer.build();
        if (meshData != null) {
            BufferUploader.drawWithShader(meshData);
        }
    }
    
    /**
     * 写入一个顶点。
     */
    public static void putVertex(BufferBuilder buffer, double x, double y, double z,
                                 float red, float green, float blue, float alpha, float u, float v) {
        buffer.addVertex((float) x, (float) y, (float) z)
            .setColor(red, green, blue, alpha)
            .setUv(u, v);
    }
    
    /**
     * 把向量绕 Y 轴旋转给定弧度（{@code radians} 正值为俯视逆时针，用于模拟发射器旋转的弧形轨迹）。
     */
    public static Vec3 rotateY(Vec3 vector, double radians) {
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        return new Vec3(
            vector.x * cos + vector.z * sin,
            vector.y,
            -vector.x * sin + vector.z * cos);
    }
    
    /**
     * 一条正在生长的飘带。
     */
    public static final class ActiveRibbon {
        
        /**
         * 静态参数。
         */
        public final EfxRibbonView view;
        
        /**
         * 轨迹点（世界坐标），最后一个元素是当前位置。
         */
        public final List<Vec3> trail = new ArrayList<>();
        
        /**
         * 水平圆的圆心（世界坐标）：切向的逆时针流动与"径向"都以它为中心。
         */
        public final Vec3 center;
        
        /**
         * 当前的<b>径向</b>速度（格 / tick）：负值向内、正值向外、0 表示只做切向流动。
         */
        public float radialSpeed;
        
        /**
         * 该条飘带的透明度系数（0~1）：RGB 恒为黑，故它就是这条飘带全部的"强度"。
         */
        public final float alphaScale;
        
        /**
         * 起始游戏刻。
         */
        public final long startGameTime;
        
        /**
         * 最近一次采样轨迹的游戏刻。
         */
        public long lastSampleTime;
        
        /**
         * 带子头端（最新采样点、运动前方）的带宽（格）：出生时由类型属性的 {@code SizeScalar} 决定。
         */
        public final float widthHead;
        
        /**
         * 带子尾端（最旧采样点、发射处）的带宽（格）；中间各点沿带长在两者之间线性插值。
         */
        public final float widthTail;
        
        /**
         * 当前切向角速度（弧度 / tick），逐 tick 按 {@link EfxRibbonView#spinAcceleration} 复利变化。
         */
        public double spinSpeed;
        
        /**
         * 记录一条飘带的初始状态。
         */
        public ActiveRibbon(EfxRibbonView view, Vec3 center, Vec3 start, float radialSpeed,
                            float alphaScale, long startGameTime) {
            this.view = view;
            this.center = center;
            this.radialSpeed = radialSpeed;
            this.alphaScale = alphaScale;
            this.startGameTime = startGameTime;
            this.lastSampleTime = startGameTime;
            this.widthHead = view.widthHead;
            this.widthTail = view.widthTail;
            this.spinSpeed = view.spinRadiansPerTick;
            this.trail.add(start);
        }
        
        /**
         * 推进一步：切向旋转 + 径向位移 + 重力，压入轨迹并裁剪到分段数。
         * <p>
         * 速度是两条<b>独立分量</b>之和（实测）：切向为位置绕圆心旋转 ω（半径 r 处线速度恰为 ω·r），
         * 径向为沿"圆心 → 当前位置"位移 {@code Speed}（正外负内）；不能把速度当整体向量连方向一起旋转。
         */
        public void advance(long now) {
            this.lastSampleTime = now;
            Vec3 current = this.trail.getLast();
            Vec3 horizontal = new Vec3(current.x - this.center.x, 0.0D, current.z - this.center.z);
            Vec3 rotated = rotateY(horizontal, this.spinSpeed);
            // 螺旋加速度率：> 1 角速度逐 tick 复利增长、< 1 衰减、1 为匀速
            this.spinSpeed *= this.view.spinAcceleration;
            double nextX = this.center.x + rotated.x;
            double nextZ = this.center.z + rotated.z;
            double nextY = current.y;
            double radius = Math.sqrt(rotated.x * rotated.x + rotated.z * rotated.z);
            if (radius > 1.0E-4D && this.radialSpeed != 0.0F) {
                nextX += rotated.x / radius * this.radialSpeed;
                nextZ += rotated.z / radius * this.radialSpeed;
            }
            this.radialSpeed *= this.view.speedDecayPerTick;
            nextY += this.view.gravityPerTick;
            
            this.trail.add(new Vec3(nextX, nextY, nextZ));
            int keep = this.view.segmentCount + 1;
            while (this.trail.size() > keep) {
                this.trail.removeFirst();
            }
        }
        
        /**
         * 当前生命阶段的不透明度系数（渐入 → 满 → 渐出）。
         */
        public float envelope(float now) {
            float elapsed = now - this.startGameTime;
            if (elapsed < 0.0F) {
                return 0.0F;
            }
            if (elapsed < this.view.appearTicks) {
                return this.view.appearTicks <= 0 ? 1.0F : elapsed / (float) this.view.appearTicks;
            }
            // 保持段内恒为满强度（实测该层"生成后一直 Keep 至效果结束"）
            float keepEnd = (float) (this.view.appearTicks + this.view.keepTicks);
            if (elapsed < keepEnd) {
                return 1.0F;
            }
            if (this.view.vanishTicks <= 0) {
                return 0.0F;
            }
            return Mth.clamp(1.0F - (elapsed - keepEnd) / (float) this.view.vanishTicks, 0.0F, 1.0F);
        }
        
        /**
         * 当前应显示的序列帧下标（沿演出时间推进，越界回绕）。
         */
        public int frameIndex(float now) {
            int total = this.view.frameCount;
            if (total <= 1) {
                return 0;
            }
            float elapsed = Math.max(0.0F, now - this.startGameTime);
            float speed = Math.max(1.0E-3F, this.view.framePlaySpeed);
            int index = (int) (elapsed * speed);
            return ((index % total) + total) % total;
        }
    }
}
