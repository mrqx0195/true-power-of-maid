package net.mrqx.sbr_core.client.effect.manager;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;

import java.util.ArrayList;
import java.util.List;

/**
 * 效果触发入口：按 EFX 的类型属性把配置委派给对应的效果管理器；本类不做渲染、也不持有状态。
 * <p>
 * <b>注册顺序即优先级</b>：判别条件更具体的管理器先注册。
 * <p>
 * <b>已知例外</b>：玻璃碎屑（{@code DebrisManager}）不在这张表里——它的类型属性与球体同为
 * {@code EFXAttributeTypeMesh}，按类型无法区分这两条渲染路径，故仍由调用方显式指定。
 */
@SuppressWarnings("StaticInitializerReferencesSubClass")
public abstract class EfxEffectManager {
    /**
     * 已注册的管理器，按注册顺序匹配，先注册者优先。
     */
    private static final List<EfxEffectManager> MANAGERS = new ArrayList<>();
    
    static {
        // 判别越具体越靠前：GlowEfxManager 与 PolygonEfxManager 都认 Billboard3D，前者还要求显式声明屏幕空间辉光后端
        register(new NoDrawEfxManager());
        register(new GlowEfxManager());
        register(new RibbonEfxManager());
        register(new PolygonEfxManager());
        register(new MeshEfxManager());
    }
    
    /**
     * 注册一个效果管理器，注册顺序即匹配优先级。
     */
    protected static void register(EfxEffectManager manager) {
        MANAGERS.add(manager);
    }
    
    /**
     * 触发一层效果，并显式给出本段演出的收尾时刻与<b>效果范围倍率</b>。
     * <p>
     * {@code sustainedKeepTicks}：EFX 的 {@code Life.Flags} 第 0 位要求保持到收尾，而演出总长只有时间轴知道；
     * 取 {@link EfxTimeline#USE_DEFAULT_SUSTAINED_KEEP} 时回退到默认值。
     * <p>
     * {@code effectRangeScale}：本场演出的效果范围倍率，决定这一层的范围 / 速度 / 尺寸是否被放大；
     * 逐层的 {@code EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}。它由时间轴给出，
     * 不再是一个全局常量——"以角色为中心的范围效果"与"以目标位置为中心的局部效果"共用同一条链路。
     * <p>
     * 没有任何管理器认领该类型时返回 {@code false}，调用方据此发现"这层的类型还没接进来"，而不是让它无声消失。
     */
    public static boolean spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                                float effectRangeScale) {
        for (EfxEffectManager manager : MANAGERS) {
            if (manager.handles(config)) {
                manager.dispatch(level, origin, config, sustainedKeepTicks, effectRangeScale);
                return true;
            }
        }
        return false;
    }
    
    /**
     * 本管理器认领哪些配置，默认按类型属性判别。
     * 子类若需要更细的条件（同一类型属性下的两种实现），应在此加判据并把更具体者注册在前面。
     */
    public boolean handles(EfxConfig config) {
        return config.isType(this.typeAttribute());
    }
    
    /**
     * 子类返回本管理器负责的类型属性类，默认判别即依据它。
     */
    public abstract Class<? extends EfxAttribute> typeAttribute();
    
    /**
     * 子类在此用该配置触发一次效果：时机（第几个 tick、以哪个原点）由调用方决定，
     * 本方法只负责把这层交给对应的实现。
     */
    public abstract void dispatch(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                                  float effectRangeScale);
}
