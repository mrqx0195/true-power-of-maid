package net.mrqx.sbr_core.client.effect.manager;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeGlowRender;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeBillboard3D;
import net.mrqx.sbr_core.client.effect.post.GlowPostEffect;

/**
 * 全屏辉光层的管理器：把带 {@link EfxAttributeGlowRender} 的层交给屏幕空间辉光后端。
 * <p>
 * <b>判别条件为什么不是类型属性</b>：这一族层就是 {@code TypeBillboard3D}
 * （減算0、ブラー、Back_ADD1、体 Add グロー、Back_ADD），而本项目里同样是
 * {@code TypeBillboard3D} 的层还有一大批（割れ系列、烟雾、刀光……）走的是<b>面片</b>渲染路径。
 * 两者在 EFX 数据里的区别只有"这一层要不要用屏幕空间后端表现"，这件事 EFX 数据里没有，
 * 因此由本项目的扩展属性 {@link EfxAttributeGlowRender} 显式声明——
 * 声明了的走这里，没声明的仍归 {@link PolygonEfxManager}。
 * <p>
 * 本管理器因此必须<b>注册在 {@link PolygonEfxManager} 之前</b>（更具体的判别在前），
 * 这也是 {@link EfxEffectManager} 注释里说的"子类可加更细的条件"的实际用例。
 */
public final class GlowEfxManager extends EfxEffectManager {
    @Override
    public Class<? extends EfxAttribute> typeAttribute() {
        return EfxTypeBillboard3D.class;
    }
    
    @Override
    public boolean handles(EfxConfig config) {
        return config.has(EfxAttributeGlowRender.class);
    }
    
    @Override
    public void dispatch(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                         float effectRangeScale) {
        // 屏幕空间辉光没有世界尺寸，故不消费 effectRangeScale
        GlowPostEffect.trigger(origin, config, sustainedKeepTicks);
    }
}
