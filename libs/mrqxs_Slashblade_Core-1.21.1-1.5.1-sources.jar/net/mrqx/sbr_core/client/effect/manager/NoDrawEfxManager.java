package net.mrqx.sbr_core.client.effect.manager;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxNoDrawView;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeNoDraw;
import net.mrqx.sbr_core.client.effect.efx.script.EfxScriptContext;
import net.mrqx.sbr_core.client.effect.efx.script.EfxScriptRegistry;

/**
 * 脚本驱动层（{@code EFXAttributeTypeNoDraw}）的管理器。
 * <p>
 * NoDraw 层<b>不绘制任何几何</b>，它的"表现"是执行某个脚本，因此这里做的事只有三步：
 * 把配置摊平成只读视图（{@link EfxNoDrawView}）→ 组装上下文（{@link EfxScriptContext}）→
 * 交给 {@link EfxScriptRegistry} 按层上挂的脚本名派发。本类不持有任何运行时状态。
 * <p>
 * 该层没有脚本（纯占位层）、或脚本在本项目里还没有对应执行者时，派发不出去——
 * {@link EfxScriptRegistry#dispatch(EfxScriptContext)} 会返回 {@code false}，
 * 调用方据此可以记录"这一层没有被执行"，而不是让它无声消失。
 */
public final class NoDrawEfxManager extends EfxEffectManager {
    @Override
    public Class<? extends EfxAttribute> typeAttribute() {
        return EfxTypeNoDraw.class;
    }
    
    @Override
    public void dispatch(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                         float effectRangeScale) {
        // 脚本层不绘制几何，没有"尺寸"可言，故不消费 effectRangeScale
        EfxNoDrawView view = new EfxNoDrawView(config, sustainedKeepTicks);
        if (!view.hasScript()) {
            return;
        }
        EfxScriptRegistry.dispatch(new EfxScriptContext(level, origin, view));
    }
}
