package net.mrqx.sbr_core.client.effect.manager;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeGpuRibbonFollow;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeRibbonFollow;
import net.mrqx.sbr_core.client.effect.ribbon.RibbonEmitterManager;

/**
 * 飘带类（{@code EFXAttributeTypeRibbonFollow} / {@code EFXAttributeTypeGpuRibbonFollow}）的管理器。
 * <p>
 * 飘带是"跟着宿主移动、按时间采样成条"的层，与面片 / 网格的状态模型不同
 * （{@link RibbonEmitterManager} 持有一张活动飘带表并逐帧采样轨迹）。
 * <p>
 * 两种飘带类型是<b>两套字段集</b>，但走同一条渲染路径、共用 {@code EfxRibbonView}，故由本管理器一并认领。
 */
public final class RibbonEfxManager extends EfxEffectManager {
    @Override
    public Class<? extends EfxAttribute> typeAttribute() {
        return EfxTypeRibbonFollow.class;
    }
    
    @Override
    public boolean handles(EfxConfig config) {
        return config.isType(EfxTypeRibbonFollow.class) || config.isType(EfxTypeGpuRibbonFollow.class);
    }
    
    @Override
    public void dispatch(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                         float effectRangeScale) {
        RibbonEmitterManager.spawn(level, origin, config, sustainedKeepTicks, effectRangeScale);
    }
}
