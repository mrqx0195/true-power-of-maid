package net.mrqx.sbr_core.client.effect.manager;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeMesh;
import net.mrqx.sbr_core.client.effect.mesh.MeshEmitterManager;

/**
 * 网格类（{@code EFXAttributeTypeMesh}）的管理器。
 * <p>
 * <b>注意</b>：玻璃碎屑（{@code DebrisManager}）的配置<b>同样是</b>
 * {@code EfxTypeMesh}，但走的是另一条渲染路径（逐块真实模型）。类型属性区分不了两者，
 * 故碎屑不经过本派发表，仍由调用方显式指定——原因见
 * {@link EfxEffectManager} 的类注释。
 */
public final class MeshEfxManager extends EfxEffectManager {
    @Override
    public Class<? extends EfxAttribute> typeAttribute() {
        return EfxTypeMesh.class;
    }
    
    @Override
    public void dispatch(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                         float effectRangeScale) {
        MeshEmitterManager.spawn(level, origin, config, sustainedKeepTicks, effectRangeScale);
    }
}
