package net.mrqx.sbr_core.client.effect.manager;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeBillboard3D;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeGpuBillboard;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypePolygon;
import net.mrqx.sbr_core.client.effect.polygon.PolygonEmitterManager;

/**
 * 面片类（{@code TypePolygon} / {@code TypeBillboard3D} / {@code TypeGpuBillboard}）的管理器。
 * <p>
 * 三种类型属性在本项目里走同一条渲染路径（{@link PolygonEmitterManager}），
 * 差别由配置里的属性表达（是否面向相机、是否 GPU 实例化等），因此这里一并认领。
 */
public final class PolygonEfxManager extends EfxEffectManager {
    @Override
    public Class<? extends EfxAttribute> typeAttribute() {
        return EfxTypePolygon.class;
    }
    
    @Override
    public boolean handles(EfxConfig config) {
        return config.isType(EfxTypePolygon.class)
            || config.isType(EfxTypeBillboard3D.class)
            || config.isType(EfxTypeGpuBillboard.class);
    }
    
    @Override
    public void dispatch(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                         float effectRangeScale) {
        PolygonEmitterManager.spawn(level, origin, config, sustainedKeepTicks, effectRangeScale);
    }
}
