package net.mrqx.sbr_core.client.effect.polygon;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxPolygonView;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeFixRandomGenerator;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import net.mrqx.sbr_core.client.effect.util.GroundSurface;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * 面片粒子发射管理器：按 {@link EfxPolygonView} 采样位置与初速度，把"分批连续生成"转化为各面片的出生延迟
 * （由粒子自身 {@code delayTicks} 承担，无需额外 tick 调度）。随机性开关见 {@link #randomSource}。
 */
public final class PolygonEmitterManager {
    /**
     * EFX 速度单位为"格 / 帧"，1 tick = 3 帧。
     */
    public static final double TICK_TO_FRAME = 3.0D;
    
    /**
     * 参与屏幕空间畸变的面片，供后处理阶段遍历。
     */
    private static final List<PolygonParticle> TRACKED_DISTORTION = new ArrayList<>();
    
    private PolygonEmitterManager() {
    }
    
    /**
     * 以该层自身的随机策略发射一次面片特效。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config) {
        spawn(level, origin, config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 同上，并指定从本层触发时刻到本段演出收尾的 tick 数。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks) {
        spawn(level, origin, new EfxPolygonView(config, sustainedKeepTicks));
    }
    
    /**
     * 同上，并指定本场演出的<b>效果范围倍率</b>（逐层的 {@code EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}）。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                             float effectRangeScale) {
        spawn(level, origin, new EfxPolygonView(config, EfxPolygonView.FALLBACK_TEXTURE, sustainedKeepTicks,
            effectRangeScale));
    }
    
    /**
     * 使用外部随机源发射，便于同一 Entry 的多次触发共享同一条种子序列。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, RandomSource rnd) {
        spawn(level, origin, new EfxPolygonView(config), rnd);
    }
    
    /**
     * 以该层自身的随机策略发射一次面片特效。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxPolygonView view) {
        spawn(level, origin, view, randomSource(view, origin));
    }
    
    /**
     * 按视图的随机策略构造随机源——<b>本项目的随机性开关就在这里</b>：配置含 {@link EfxAttributeFixRandomGenerator}
     * 时用其种子槽位叠加原点坐标派生<b>可复现</b>种子（同配置同原点必得同一套布局），不含时用 {@link RandomSource#create()} 真随机。
     * 不能回退成"配置哈希 × 原点哈希"：那样种子只由常量与原点决定，同一层连续两次触发的布局会完全相同。
     */
    public static RandomSource randomSource(EfxPolygonView view, Vec3 origin) {
        EfxAttributeFixRandomGenerator fix = view.fixRandomGenerator;
        if (fix == null || view.randomSeed == null) {
            return RandomSource.create();
        }
        long seed = view.randomSeed;
        seed = seed * 31L + Double.hashCode(origin.x);
        seed = seed * 31L + Double.hashCode(origin.y);
        seed = seed * 31L + Double.hashCode(origin.z);
        return RandomSource.create(seed);
    }
    
    /**
     * 使用给定的视图与随机源发射。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxPolygonView view, RandomSource rnd) {
        int batches = Math.max(1, view.batches);
        int perBatch = Math.max(1, view.spawnPerBatch);
        for (int batch = 0; batch < batches; batch++) {
            float delayTicks = batch * Math.max(0.0F, view.intervalTicks);
            for (int i = 0; i < perBatch; i++) {
                // 环向分割要用跨批累计的全局序号，只用批内序号会让每批都从第 0 扇区重来
                int ordinal = batch * perBatch + i;
                Vector3f offset = sampleOffset(view, rnd, ordinal);
                float rollPhase = Float.isNaN(view.rollRadians)
                    ? rnd.nextFloat() * (float) Math.PI * 2.0F
                    : view.rollRadians + (rnd.nextFloat() - 0.5F) * view.rollRadiansVariation;
                double[] velocity = sampleVelocity(offset, view, rnd);
                Vector3f velocityOffset = view.velocityOffset;
                double spawnX = origin.x + offset.x + view.centerOffset.x + velocityOffset.x;
                double spawnY = origin.y + offset.y + view.centerOffset.y + velocityOffset.y;
                double spawnZ = origin.z + offset.z + view.centerOffset.z + velocityOffset.z;
                if (view.snapToGround) {
                    // 简化版 PtCollision：吸附会覆盖 Offset 的 Y 分量，改成"吸附后再叠加 Offset.y"会让烟雾整体抬高 1 格
                    spawnY = GroundSurface.snap(level, spawnX, spawnY, spawnZ, view.collisionRadius) + 0.5;
                }
                PolygonParticle particle = new PolygonParticle(
                    level, spawnX, spawnY, spawnZ,
                    view, origin, rnd, delayTicks, rollPhase,
                    velocity[0], velocity[1], velocity[2]);
                Minecraft.getInstance().particleEngine.add(particle);
                if (view.distortionStrength > 0.0F) {
                    TRACKED_DISTORTION.add(particle);
                }
            }
        }
    }
    
    /**
     * 返回当前仍活跃的畸变面片，顺带剔除已移除者。
     */
    public static List<PolygonParticle> activeDistortionParticles() {
        TRACKED_DISTORTION.removeIf(particle -> !particle.hasDistortion());
        return TRACKED_DISTORTION;
    }
    
    /**
     * 同上，并支持<b>环向分割</b>（{@code ordinal} 为跨批累计的粒子全局序号）；形状 0 = 盒、1 = 球内均匀、2 = 圆柱。
     */
    public static Vector3f sampleOffset(EfxPolygonView view, RandomSource rnd, int ordinal) {
        Vector3f range = view.rangeXYZ;
        // 环向分割：一圈均分 N 个扇区，本片落在"第 ordinal % N 个扇区"内取随机角；只在圆柱上消费
        int divideNum = view.rangeDivideNum;
        if (view.shapeType == 2) {
            double theta = divideNum > 0
                ? ((ordinal % divideNum) + rnd.nextDouble()) * (Math.PI * 2.0D / divideNum)
                : rnd.nextDouble() * Math.PI * 2.0D;
            double radius = Math.sqrt(rnd.nextDouble());
            double height = rnd.nextDouble();
            float scaleX = innerRatio(view.rangeInner.x, range.x, radius);
            float scaleZ = innerRatio(view.rangeInner.z, range.z, radius);
            return new Vector3f(
                (float) (Math.cos(theta) * scaleX * range.x),
                (float) (height * range.y),
                (float) (Math.sin(theta) * scaleZ * range.z));
        }
        if (view.shapeType == 1) {
            double u = rnd.nextDouble();
            double v = rnd.nextDouble();
            double theta = 2.0D * Math.PI * u;
            double phi = Math.acos(2.0D * v - 1.0D);
            double radius = Math.cbrt(rnd.nextDouble());
            double sinPhi = Math.sin(phi);
            return new Vector3f(
                (float) (sinPhi * Math.cos(theta) * radius * range.x),
                (float) (Math.cos(phi) * radius * range.y),
                (float) (sinPhi * Math.sin(theta) * radius * range.z));
        }
        return new Vector3f(
            (float) ((rnd.nextDouble() * 2.0D - 1.0D) * range.x),
            (float) ((rnd.nextDouble() * 2.0D - 1.0D) * range.y),
            (float) ((rnd.nextDouble() * 2.0D - 1.0D) * range.z));
    }
    
    /**
     * 把"面积均匀的半径系数"（{@code sqrt(u)}，0~1）重映射到 {@code [内半径比例, 1]}；内半径为 0 时原样返回。
     */
    public static float innerRatio(float inner, float outer, double radius) {
        if (outer <= 0.0F) {
            return 0.0F;
        }
        double ratio = Math.clamp((double) inner / (double) outer, 0.0D, 1.0D);
        return (float) (ratio + (1.0D - ratio) * radius);
    }
    
    /**
     * 采样初速度（返回 格/tick 的三个分量）；优先级 {@code noMove} → {@code radial} → {@code direction} → 完全随机方向。
     */
    public static double[] sampleVelocity(Vector3f offset, EfxPolygonView view, RandomSource rnd) {
        double speed = view.speed * TICK_TO_FRAME
            * (1.0D + (rnd.nextDouble() - 0.5D) * 2.0D * view.speedRandom);
        double dx;
        double dy;
        double dz;
        if (view.noMove) {
            dx = 0;
            dy = 0;
            dz = 0;
            return new double[]{dx * speed, dy * speed, dz * speed};
        }
        // 径向必须先判：径向层即使同时写了方向分量也应沿发射偏移向外，先判方向会把径向运动整个吞掉
        if (view.radial && offset.lengthSquared() > 1.0E-6F) {
            Vector3f radialDirection = new Vector3f(offset).normalize();
            return new double[]{radialDirection.x * speed, radialDirection.y * speed, radialDirection.z * speed};
        }
        if (view.direction.lengthSquared() > 1.0E-6F) {
            Vector3f spread = view.directionSpread;
            Vector3f direction = new Vector3f(
                view.direction.x + (rnd.nextFloat() - 0.5F) * 2.0F * spread.x,
                view.direction.y + (rnd.nextFloat() - 0.5F) * 2.0F * spread.y,
                view.direction.z + (rnd.nextFloat() - 0.5F) * 2.0F * spread.z);
            if (direction.lengthSquared() > 1.0E-6F) {
                direction.normalize();
                return new double[]{direction.x * speed, direction.y * speed, direction.z * speed};
            }
        }
        double theta = rnd.nextDouble() * Math.PI * 2.0D;
        double phi = Math.acos(2.0D * rnd.nextDouble() - 1.0D);
        double sinPhi = Math.sin(phi);
        dx = sinPhi * Math.cos(theta);
        dy = Math.cos(phi);
        dz = sinPhi * Math.sin(theta);
        return new double[]{dx * speed, dy * speed, dz * speed};
    }
}
