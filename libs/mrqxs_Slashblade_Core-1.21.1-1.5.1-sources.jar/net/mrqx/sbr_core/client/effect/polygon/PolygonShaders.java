package net.mrqx.sbr_core.client.effect.polygon;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.util.TextureAlphaRange;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * 面片粒子的自定义着色器（{@code sbr_core:polygon_particle}）。
 * <p>
 * 之所以需要它：原版粒子着色器做不了**逐像素的 alpha 曲线校正**，
 * 而"按曲线压制低 alpha 像素"正是刀光保持纤细的关键。
 * <p>
 * 该着色器在片元阶段按 {@code AlphaLowPass} / {@code AlphaHighPass} 两个 uniform 应用
 * {@code saturate((贴图 alpha ^ 4.84 − lowPass) ÷ highPass)}，由 {@link PolygonRenderTypes}
 * 在绑定渲染类型时设置。⚠ 这是**曲线**而不是硬裁切：材质侧全程没有 {@code discard}，
 * 本项目只在曲线把 alpha 压到接近 0 时做一次填充率保护。
 */
@EventBusSubscriber(modid = MrqxSlashBladeCore.MODID, value = Dist.CLIENT)
public final class PolygonShaders {
    /**
     * 着色器资源 id。
     */
    public static final ResourceLocation POLYGON_PARTICLE = MrqxSlashBladeCore.prefix("polygon_particle");
    
    /**
     * 编译后的着色器实例；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    private static ShaderInstance polygonParticleShader;
    
    private PolygonShaders() {
    }
    
    /**
     * 注册着色器（资源重载时由 NeoForge 调用）。
     */
    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        // 贴图内容可能已随资源重载变化，alpha 上下限的缓存必须一起失效
        TextureAlphaRange.clear();
        try {
            event.registerShader(
                new ShaderInstance(event.getResourceProvider(), POLYGON_PARTICLE, DefaultVertexFormat.PARTICLE),
                shader -> polygonParticleShader = shader);
        } catch (IOException e) {
            polygonParticleShader = null;
            MrqxSlashBladeCore.LOGGER.error("加载面片粒子着色器失败: {}", POLYGON_PARTICLE, e);
        }
    }
    
    /**
     * 取得面片粒子着色器实例。
     * <p>
     * <b>调用方不得关闭该实例</b>：它是全局共享的缓存，{@link ShaderInstance#close()} 会删除 GL program，
     * 对共享实例调用会让之后的所有绘制使用已失效的 program。
     *
     * @return 着色器实例；未加载成功时返回 null（此时回退到原版粒子着色器）
     */
    @Nullable
    public static ShaderInstance shader() {
        return polygonParticleShader;
    }
}
