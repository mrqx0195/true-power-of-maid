package net.mrqx.sbr_core.client.effect.polygon;

/**
 * 面片的朝向模式。
 * <p>
 * 面片类属性分为自由朝向与面向相机两种，末项 {@link #GROUND} 是本项目的扩展。
 */
public enum PolygonOrientation {
    /**
     * 自由朝向：按自身随机旋转摆放（裂纹类层）。
     */
    FREE,
    
    /**
     * 面向相机：用相机右 / 上基向量构造四边形。
     */
    BILLBOARD,
    
    /**
     * <b>水平面朝向</b>（本项目扩展）：四边形固定躺在世界水平面上（法线恒为 +Y），只在平面内做滚转。
     * <p>
     * 平面朝向在数据里与面向相机同写成 billboard 类型，无法据字段区分，
     * 故由预设显式声明（{@code EfxAttributeSbrRender#groundPlane()}）。
     */
    GROUND
}
