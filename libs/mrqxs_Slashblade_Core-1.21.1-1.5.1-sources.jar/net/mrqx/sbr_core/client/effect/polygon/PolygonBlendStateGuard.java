package net.mrqx.sbr_core.client.effect.polygon;

import com.mojang.blaze3d.systems.RenderSystem;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.lwjgl.opengl.GL14;

/**
 * 面片粒子的混合状态清理器。
 * <p>
 * <b>为什么需要它</b>：1.21.1 的 {@link net.minecraft.client.particle.ParticleRenderType} 只有
 * {@code begin} 回调、**没有 {@code end}**，粒子引擎在渲染完一个粒子类型后仅恢复
 * {@code depthMask} 与 blend 开关，**不会重置混合方程**。而"减法刀光"
 * （割れ黒 / 減算0，见 {@link PolygonBlendMode#REVERSE_SUBTRACT}）必须把方程设为
 * {@code GL_FUNC_REVERSE_SUBTRACT} 才能得到"压暗"效果；若它恰好是最后渲染的粒子类型，
 * 该方程就会残留到全局 GL 状态中。由于 Minecraft 绝大多数渲染路径只调用
 * {@code RenderSystem.defaultBlendFunc()}（只改混合因子、不改方程），残留状态会被一路带到
 * GUI、透明方块与其它特效上，把它们的颜色"减"成黑色，并且会持续到游戏关闭为止。
 * <p>
 * 因此这里在粒子阶段结束（以及关卡渲染结束做兜底）时把混合方程与混合因子复位。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class PolygonBlendStateGuard {
    /**
     * 在粒子渲染完成、以及关卡渲染全部结束时复位混合状态。
     */
    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        RenderLevelStageEvent.Stage stage = event.getStage();
        if (stage != RenderLevelStageEvent.Stage.AFTER_PARTICLES
            && stage != RenderLevelStageEvent.Stage.AFTER_LEVEL) {
            return;
        }
        // 复位混合方程（减法混合会把它改成 REVERSE_SUBTRACT）、混合因子与剔除状态（面片为双面渲染）
        RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
    }
}
