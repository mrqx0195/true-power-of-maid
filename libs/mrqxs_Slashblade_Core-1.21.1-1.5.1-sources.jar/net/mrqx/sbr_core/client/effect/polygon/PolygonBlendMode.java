package net.mrqx.sbr_core.client.effect.polygon;

/**
 * 面片粒子的混合模式，对应 EFX Polygon 的混合 Flags。
 */
public enum PolygonBlendMode {
    /**
     * 普通 alpha 混合：半透明裂纹、烟雾。
     */
    TRANSLUCENT,
    
    /**
     * 加法混合：高光、刀光、过曝闪。
     */
    ADDITIVE,
    
    /**
     * 反向减法混合（{@code dst - src}）：压暗型裂纹与暗部压制。
     */
    REVERSE_SUBTRACT
}
