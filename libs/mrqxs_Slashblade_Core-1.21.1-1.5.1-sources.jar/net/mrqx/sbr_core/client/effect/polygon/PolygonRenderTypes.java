package net.mrqx.sbr_core.client.effect.polygon;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.opengl.GL14;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

/**
 * 面片粒子的渲染类型工厂：按"混合模式 + 贴图 + 是否写深度 + alpha 曲线起点与宽度 + 是否预乘"缓存
 * {@link ParticleRenderType} 实例，供原版粒子引擎按类型分桶批量绘制。
 * <p>
 * 三个要点：
 * <ul>
 *   <li><b>双面渲染</b>：{@code begin} 中关闭背面剔除；</li>
 *   <li><b>alpha 曲线校正</b>：曲线起点大于 0 时改用 {@link PolygonShaders} 的自定义着色器，
 *       在片元阶段按 {@code saturate((贴图 alpha ^ 4.84 − lowPass) ÷ highPass)} 压制低 alpha 像素（<b>不是</b>硬裁切，材质侧全程没有 {@code discard}），这是刀光"纤细"的关键；</li>
 *   <li><b>输出约定</b>：普通混合下按<b>预乘 alpha</b>输出（见 {@link #premultiplyFor}），与引擎该族的
 *       片元输出一致；加色与减法两种模式<b>不预乘</b>——它们与引擎本来就是等价的，预乘反而会多乘一遍 alpha；</li>
 *   <li>1.21.1 的 {@link ParticleRenderType} 没有 {@code end} 回调，因此每个实例的 {@code begin}
 *       都会**完整重设**混合方程（避免反向减法残留污染全局）与剔除状态。</li>
 * </ul>
 */
public final class PolygonRenderTypes {
    private static final Map<Key, ParticleRenderType> CACHE = new HashMap<>();
    
    private PolygonRenderTypes() {
    }
    
    /**
     * 取得（或创建）对应参数组合的渲染类型。
     *
     * @param blendMode     混合模式
     * @param texture       面片贴图
     * @param depthWrite    是否写入深度
     * @param alphaLowPass  alpha 曲线的起点（0 表示不做 alpha 校正，使用原版粒子着色器）
     * @param alphaHighPass alpha 曲线的宽度
     * @param alphaMin      本层贴图 alpha 的下限（着色器先把贴图 alpha 缩放到 0~1 再进曲线）
     * @param alphaMax      本层贴图 alpha 的上限；与 {@code alphaMin} 相等时按"不缩放"处理
     * @param premultiply   是否按预乘 alpha 输出（见 {@link #premultiplyFor}）
     * @param dualColor     双色分段规格；{@code null} 表示不做分段（用逐片粒子抖动的近似路径）
     * @return 可交给粒子使用的渲染类型实例
     */
    public static ParticleRenderType get(PolygonBlendMode blendMode, ResourceLocation texture,
                                         boolean depthWrite, float alphaLowPass, float alphaHighPass,
                                         float alphaMin, float alphaMax, boolean premultiply,
                                         @Nullable DualColorSpec dualColor) {
        return CACHE.computeIfAbsent(new Key(blendMode, texture, depthWrite, alphaLowPass, alphaHighPass,
            alphaMin, alphaMax, premultiply, dualColor), Impl::new);
    }
    
    /**
     * 该混合模式下是否应当按<b>预乘 alpha</b>输出。
     * <p>
     * 该族材质的片元输出是预乘的（rgb 已乘过最终 alpha，混合因子取 {@code ONE}）。本项目与它是
     * <b>数学等价</b>还是<b>等价于多乘一遍 alpha</b>，完全由混合模式决定：
     * <ul>
     *   <li>{@code ADDITIVE}：源因子本来就是 {@code SRC_ALPHA}（加色），预乘后再乘一次等于
     *       {@code rgb × a²}——那<b>不是</b>加色，所以<b>不预乘</b>；</li>
     *   <li>{@code REVERSE_SUBTRACT}：结果 {@code = 目标 − 源 × 源 alpha}，预乘会多乘一遍 alpha、
     *       降低减淡幅度，同样<b>不预乘</b>；</li>
     *   <li>普通混合（{@link PolygonBlendMode#NORMAL}）：非预乘路径实际得到
     *       {@code rgb × a × a + 目标 × (1 − a)}，而引擎的预乘路径是
     *       {@code rgb × a + 目标 × (1 − a)}。两者在软边上差别明显（前者边缘更暗），
     *       <b>故在此启用预乘</b>以对齐引擎。</li>
     * </ul>
     * 这样改动只落在普通混合上，加色与减法刀光的观感不受影响。
     */
    public static boolean premultiplyFor(PolygonBlendMode blendMode) {
        return blendMode == PolygonBlendMode.TRANSLUCENT;
    }
    
    /**
     * 双色分段规格：{@code Color} 与 {@code ColorRange} 按材质 alpha 的高低分工着色。
     * <p>
     * 这里携带渲染所需的四个量
     * （两色、分界、亮度），让渲染类型可以按组合缓存。
     *
     * @param mainColor  主体色（{@code Color}，常规 ARGB）
     * @param rangeColor 第二色（{@code ColorRange}，常规 ARGB）
     * @param split      高低两段的分界（材质 alpha）
     * @param brightness 亮度倍率（{@code max(1, Intensity) × ColorBrightness}）
     */
    public record DualColorSpec(int mainColor, int rangeColor, float split, float brightness) {
    }
    
    /**
     * 渲染类型缓存键。
     */
    private record Key(PolygonBlendMode blendMode, ResourceLocation texture, boolean depthWrite,
                       float alphaLowPass, float alphaHighPass, float alphaMin, float alphaMax,
                       boolean premultiply, @Nullable DualColorSpec dualColor) {
    }
    
    /**
     * 具体渲染类型实现：统一使用 {@code PARTICLE} 顶点格式与四边形绘制。
     */
    private record Impl(Key key) implements ParticleRenderType {
        @Override
        public BufferBuilder begin(Tesselator tesselator, TextureManager textureManager) {
            RenderSystem.depthMask(this.key.depthWrite());
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            switch (this.key.blendMode()) {
                case ADDITIVE -> {
                    RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
                    RenderSystem.blendFuncSeparate(
                        GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE,
                        GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
                }
                case REVERSE_SUBTRACT -> {
                    // 结果 = 目标色 − 源色 × 源 alpha（GL_FUNC_REVERSE_SUBTRACT 的定义），用于"压暗"型刀光
                    RenderSystem.blendEquation(GL14.GL_FUNC_REVERSE_SUBTRACT);
                    RenderSystem.blendFuncSeparate(
                        GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE,
                        GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
                }
                default -> {
                    RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
                    RenderSystem.defaultBlendFunc();
                }
            }
            applyShader(this.key.alphaLowPass(), this.key.alphaHighPass(),
                this.key.alphaMin(), this.key.alphaMax(), this.key.premultiply(), this.key.dualColor());
            RenderSystem.setShaderTexture(0, this.key.texture());
            return tesselator.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
        }
        
        /**
         * 曲线起点大于 0（或有双色分段）时绑定自定义着色器，否则回退原版粒子着色器。
         * <p>
         * <b>切勿用 try-with-resources 持有这里取得的着色器</b>：{@link ShaderInstance} 实现了
         * {@link AutoCloseable}，而 {@code close()} 会删除底层的 GL program；但
         * {@link PolygonShaders#shader()} 返回的是**全局共享的缓存实例**（并非每次新建的资源），
         * 一旦被关闭，后续所有绘制都会拿着已失效的 program id 调用
         * {@code glUseProgram} 与 {@code glUniform}，直接产生
         * {@code GL_INVALID_VALUE（Program handle does not refer to an object generated by OpenGL）}
         * 与 {@code GL_INVALID_OPERATION（No active program）}。
         */
        private static void applyShader(float alphaLowPass, float alphaHighPass,
                                        float alphaMin, float alphaMax, boolean premultiply,
                                        @Nullable DualColorSpec dualColor) {
            // alpha 曲线与双色分段都只有自定义着色器做得到
            ShaderInstance shader = (alphaLowPass > 0.0F || dualColor != null)
                ? PolygonShaders.shader() : null;
            if (shader == null) {
                RenderSystem.setShader(GameRenderer::getParticleShader);
                return;
            }
            RenderSystem.setShader(() -> shader);
            shader.safeGetUniform("AlphaLowPass").set(alphaLowPass);
            shader.safeGetUniform("AlphaHighPass").set(alphaHighPass);
            // 替代贴图的 alpha 量程：着色器先据此把 alpha 缩放到 0~1，再进按原图标定的曲线
            shader.safeGetUniform("AlphaMin").set(alphaMin);
            shader.safeGetUniform("AlphaMax").set(alphaMax);
            // 预乘开关：uniform 是全局的，每次绘制都要显式下发，否则会带上一次绘制的残留
            shader.safeGetUniform("Premultiply").set(premultiply ? 1.0F : 0.0F);
            if (dualColor == null) {
                // 关掉上一次绘制的分段状态：uniform 是全局的，残留会让别的层被误分段
                shader.safeGetUniform("DualColorSplit").set(0.0F);
                return;
            }
            setUniformColor(shader, "DualColorMain", dualColor.mainColor());
            setUniformColor(shader, "DualColorRange", dualColor.rangeColor());
            shader.safeGetUniform("DualColorSplit").set(dualColor.split());
            shader.safeGetUniform("DualColorBrightness").set(dualColor.brightness());
        }
        
        /**
         * 把一个常规 ARGB 写进 vec4 uniform（各分量 0~1）。
         *
         * @param shader 目标着色器
         * @param name   uniform 名
         * @param argb   常规 ARGB（A 在高位）
         */
        private static void setUniformColor(ShaderInstance shader, String name, int argb) {
            shader.safeGetUniform(name).set(
                (argb >> 16 & 0xFF) / 255.0F,
                (argb >> 8 & 0xFF) / 255.0F,
                (argb & 0xFF) / 255.0F,
                (argb >>> 24 & 0xFF) / 255.0F);
        }
        
        @Override
        public String toString() {
            return "sbr_core:polygon_" + this.key.blendMode() + "_" + this.key.texture();
        }
    }
}
