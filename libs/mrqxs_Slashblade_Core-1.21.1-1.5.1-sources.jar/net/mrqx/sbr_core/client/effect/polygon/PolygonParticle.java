package net.mrqx.sbr_core.client.effect.polygon;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxPolygonView;
import net.mrqx.sbr_core.client.effect.post.DistortionSource;
import net.mrqx.sbr_core.client.effect.util.RefractionDepthScale;
import net.mrqx.sbr_core.client.utils.ParticleUtils;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * 通用面片粒子：把一片带贴图的四边形按 {@link EfxPolygonView} 做
 * "随机朝向 + 持续自转 + 尺寸拉伸 + 生命淡出"的演出，并支持序列帧 UV、三种混合模式与屏幕空间畸变。
 * <p>
 * 覆盖自由朝向（割れ、輝度、閃、辉光等面片类层）与面向相机（{@link PolygonOrientation#BILLBOARD}）两种摆法。
 * <p>
 * <b>时间基准</b>：动画进度用 {@code elapsed = (level.getGameTime() - spawnGameTime) + partialTick - delay}
 * 计算，不用自增 tick 计数，故旋转/拉伸/淡出在帧间平滑插值，暂停与卡顿都不会造成进度漂移。
 */
public class PolygonParticle extends Particle implements DistortionSource {
    /**
     * 强制全亮光照，模拟自发光不受环境光影响。
     */
    public static final int FULLBRIGHT_LIGHTMAP = 0xF000F0;
    
    /**
     * 1 tick = 3 EFX 帧（EFX 60fps → Minecraft 20tps）。
     */
    public static final float TICK_TO_FRAME = 3.0F;
    
    /**
     * 该面片的配置视图（构造时已把 EFX 属性摊平成扁平字段）。
     */
    protected final EfxPolygonView view;
    
    /**
     * 本次演出的原点（世界坐标），径向层靠它做"持续指向中心"的修正。
     */
    protected final Vec3 origin;
    
    /**
     * 径向层的意图：{@code true} = 向外扩散、{@code false} = 向心收拢；出生时由速度基准的符号定死，此后不再改变。
     */
    protected final boolean radialOutward;
    
    /**
     * 出生时的游戏时间（动画进度基准）。
     */
    protected final long spawnGameTime;
    
    /**
     * 出生延迟（tick），用于分批连续生成。
     */
    protected final float delayTicks;
    
    /**
     * 初始随机朝向（对应 EFX Polygon 的 RotationX/Y/Z 随机）。
     */
    protected final Quaternionf initialRotation = new Quaternionf();
    
    /**
     * 面向相机模式下的滚转初相（弧度），避免所有面片同相旋转。
     */
    protected final float rollPhase;
    
    /**
     * 尺寸随机系数（1 ± sizeRandom）。
     */
    protected final float sizeScale;
    
    /**
     * 宽度自身的随机系数（1 ± widthRandom），在 {@link #sizeScale} 之上再抖一次，是"每片刀光宽窄不一"的来源。
     */
    protected final float widthScale;
    
    /**
     * 高度自身的随机系数（1 ± heightRandom）。
     */
    protected final float heightScale;
    
    /**
     * 沿视线方向的深度偏移（格，基准 + 随机幅度）：让贴脸的刀光离开镜头。
     */
    protected final float depthOffset;
    
    /**
     * 本实例在 {@code color} 与 {@code colorRange} 之间的插值因子（0 = 主体色、1 = 抖动色），出生时抽取一次、整个生命周期不变。
     * <b>alpha 为 0 表示"不抖动"</b>，此时本因子恒为 0。
     */
    protected final float colorMix;
    
    /**
     * 渲染类型（构造时解析一次，避免每帧查表）。
     */
    protected final ParticleRenderType renderType;
    
    /**
     * 固定展示的序列帧索引；-1 表示按 {@code framePlaySpeed} 播放。
     */
    protected final int fixedFrame;
    
    /**
     * 序列帧播放速度的个体倍率（每片一个，围绕 1 浮动）；
     * 不实现它的话，同层所有面片的序列帧会完全同步，整片火焰看起来像"一张整体动画"而不是"各自在烧"。
     */
    protected float frameSpeedScale;
    
    /**
     * 速度分量（格 / tick）。
     */
    protected double vx;
    protected double vy;
    protected double vz;
    
    /**
     * 当前螺旋角速度（弧度 / tick）：出生时取 {@link EfxPolygonView#spinRadiansPerTick}，
     * 此后逐 tick 按 {@link EfxPolygonView#spinAcceleration} 复利变化（与飘带路径同一口径）。
     */
    protected double spinSpeed;
    
    /**
     * 本片的自转角速度（<b>度 / EFX 帧</b>）：出生时逐片抽
     * {@code 基准 + (随机 − 0.5) × 随机全宽}（见 {@link EfxPolygonView#rotationSpeedXVariation}）。
     * 逐片抽而不是整层共用，是"碎屑 / 水晶类层每片转速不同"的来源；
     * 基准与全宽都为 0 的层，三个值恒为 0（等价于不自转）。
     */
    protected final float spinX;
    protected final float spinY;
    protected final float spinZ;
    
    /**
     * 创建一片面片粒子。
     *
     * @param origin    本次演出的原点（径向层靠它做"持续指向中心"的修正）
     * @param rollPhase 面向相机模式的滚转初相（弧度）
     */
    public PolygonParticle(ClientLevel level, double x, double y, double z,
                           EfxPolygonView view, Vec3 origin, RandomSource rnd, float delayTicks,
                           float rollPhase, double vx, double vy, double vz) {
        super(level, x, y, z);
        this.view = view;
        this.origin = origin;
        // 径向层的"意图"在出生时定死，不能在每 tick 用"速度 · 径向"的夹角判断——穿越中心后夹角会翻转
        this.radialOutward = view.speed > 0.0F;
        this.spawnGameTime = level.getGameTime();
        this.delayTicks = Math.max(0.0F, delayTicks);
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        this.spinSpeed = this.view.spinRadiansPerTick;
        // 自转角速度逐片抽一次：EFX 的 RotationAdd 是"基准 + 随机全宽"，只取基准会让 s = 0 的层完全不转
        this.spinX = sampleSpin(this.view.rotationSpeedX, this.view.rotationSpeedXVariation, rnd);
        this.spinY = sampleSpin(this.view.rotationSpeedY, this.view.rotationSpeedYVariation, rnd);
        this.spinZ = sampleSpin(this.view.rotationSpeedZ, this.view.rotationSpeedZVariation, rnd);
        
        this.initialRotation.rotationXYZ(
            toRadians((rnd.nextFloat() - 0.5F) * this.view.rotationRandomX),
            toRadians((rnd.nextFloat() - 0.5F) * this.view.rotationRandomY),
            toRadians((rnd.nextFloat() - 0.5F) * this.view.rotationRandomZ));
        this.rollPhase = rollPhase;
        this.colorMix = (view.colorRange >>> 24 & 0xFF) == 0 ? 0.0F : rnd.nextFloat();
        this.sizeScale = Math.max(0.01F, 1.0F + (rnd.nextFloat() - 0.5F) * 2.0F * this.view.sizeRandom);
        this.widthScale = Math.max(0.01F, 1.0F + (rnd.nextFloat() - 0.5F) * 2.0F * this.view.widthRandom);
        this.heightScale = Math.max(0.01F, 1.0F + (rnd.nextFloat() - 0.5F) * 2.0F * this.view.heightRandom);
        this.depthOffset = this.view.depthOffset + (rnd.nextFloat() - 0.5F) * this.view.depthOffsetVariation;
        this.frameSpeedScale = Math.max(0.05F,
            1.0F + (rnd.nextFloat() - 0.5F) * this.view.framePlaySpeedRandom);
        this.renderType = PolygonRenderTypes.get(this.view.blendMode, this.view.texture,
            this.view.depthWrite, this.view.alphaLowPass, this.view.alphaHighPass,
            this.view.alphaRangeMin, this.view.alphaRangeMax,
            PolygonRenderTypes.premultiplyFor(this.view.blendMode), dualColorSpec());
        int frameSpan = this.view.frameStartRandom > 0
            ? Math.min(this.view.frameStartRandom, this.view.frameCount)
            : this.view.frameCount;
        this.fixedFrame = this.view.randomStartFrame && this.view.frameCount > 1
            ? rnd.nextInt(frameSpan)
            : -1;
        
        this.lifetime = Mth.ceil(this.view.totalLifeTicks()) + 2;
        this.hasPhysics = false;
        this.gravity = 0.0F;
    }
    
    /**
     * 当前动画进度（tick，含帧间插值）；小于 0 表示仍处于出生延迟期。
     */
    public float elapsedTicks(float partialTicks) {
        return (float) (this.level.getGameTime() - this.spawnGameTime) + partialTicks - this.delayTicks;
    }
    
    @Override
    public void tick() {
        float elapsed = this.elapsedTicks(0.0F);
        if (elapsed < 0.0F) {
            return;
        }
        if (elapsed > this.view.totalLifeTicks()) {
            this.remove();
            return;
        }
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        this.x += this.vx;
        this.y += this.vy;
        this.z += this.vz;
        this.vy -= this.view.gravityRate;
        this.applySpeedDecay();
        this.applyVectorField(elapsed);
        this.applyInwardSpiral();
        this.applyRadialHoming();
    }
    
    /**
     * 向内螺旋：把"演出原点 → 当前位置"的<b>水平</b>分量绕 Y 轴旋转当前角速度，轨迹因此被卷成螺旋；
     * 角速度逐 tick 按 {@link EfxPolygonView#spinAcceleration} 复利变化。垂直分量不动，故"一边螺旋一边上飘"仍成立。
     * <p>
     * 角速度来自数据里真实存在的 {@code EFXAttributeTransform3DModifier}，与飘带路径
     * （{@code RibbonEmitterManager} 的 {@code spinSpeed}）<b>同一口径、同一旋转式</b>——
     * 两条路径都必须保持这个式子一致，否则同一个属性在飘带与面片上会往相反方向转。
     * <p>
     * ⚠ 这是面片路径<b>唯一</b>的螺旋来源。此前另有一条"把 {@code VectorFieldParameter} 的 {@code z}
     * 分量当角速度、转速旋转"的自造通路，已按裁决退役：它没有数据依据，且与飘带机制不同。
     */
    protected void applyInwardSpiral() {
        if (this.view.spinRadiansPerTick == 0.0D) {
            return;
        }
        double offsetX = this.x - this.origin.x;
        double offsetZ = this.z - this.origin.z;
        double cos = Math.cos(this.spinSpeed);
        double sin = Math.sin(this.spinSpeed);
        this.x = this.origin.x + offsetX * cos + offsetZ * sin;
        this.z = this.origin.z + -offsetX * sin + offsetZ * cos;
        this.spinSpeed *= this.view.spinAcceleration;
    }
    
    /**
     * 径向层的水指向心 / 离心修正：把速度的<b>水平分量</b>重新指向（或背离）演出原点，大小保持不变；
     * 垂直分量不动，因此"向心 + 上升"这类组合仍然是"一边收拢一边上飘"。
     * 只在 {@link EfxPolygonView#radial} 的层生效，意图由 {@link #radialOutward} 在出生时定死；
     * 不这样做，粒子沿出生时那条直线穿过中心后会继续向外飞，看起来恰好是"从角色处发散出去"。
     */
    protected void applyRadialHoming() {
        if (!this.view.radial) {
            return;
        }
        double horizontal = Math.sqrt(this.vx * this.vx + this.vz * this.vz);
        if (horizontal <= 1.0E-6D) {
            return;
        }
        double offsetX = this.x - this.origin.x;
        double offsetZ = this.z - this.origin.z;
        double distance = Math.sqrt(offsetX * offsetX + offsetZ * offsetZ);
        if (distance <= 1.0E-6D) {
            return;
        }
        double sign = this.radialOutward ? 1.0D : -1.0D;
        this.vx = offsetX / distance * horizontal * sign;
        this.vz = offsetZ / distance * horizontal * sign;
    }
    
    /**
     * 施加矢量场扰动：用<b>程序化 value noise</b> 采样当前位置（并叠加 {@code lfoRange} 折算的相位漂移让场缓慢流动），
     * 把三个分量当作加速度加到速度上。
     */
    protected void applyVectorField(float elapsed) {
        float strength = this.view.vectorFieldStrength;
        if (strength <= 0.0F) {
            return;
        }
        double frequency = this.view.vectorFieldFrequency;
        double flow = this.view.vectorFieldFlow * elapsed;
        double noiseX = valueNoise(this.x * frequency, this.y * frequency + flow, this.z * frequency);
        double noiseY = valueNoise(this.x * frequency + 37.1D, this.y * frequency + flow, this.z * frequency + 11.3D);
        double noiseZ = valueNoise(this.x * frequency + 71.9D, this.y * frequency + flow, this.z * frequency + 53.7D);
        this.vx += (float) (noiseX * strength);
        this.vy += (float) (noiseY * strength);
        this.vz += (float) (noiseZ * strength);
    }
    
    /**
     * 三线性插值的 value noise（自带实现，不依赖 Minecraft 内部噪声类），值域 {@code -1 ~ 1}。
     */
    protected static double valueNoise(double x, double y, double z) {
        int xi = Mth.floor(x);
        int yi = Mth.floor(y);
        int zi = Mth.floor(z);
        double xf = x - xi;
        double yf = y - yi;
        double zf = z - zi;
        double u = xf * xf * (3.0D - 2.0D * xf);
        double v = yf * yf * (3.0D - 2.0D * yf);
        double w = zf * zf * (3.0D - 2.0D * zf);
        double x00 = Mth.lerp(u, hashNoise(xi, yi, zi), hashNoise(xi + 1, yi, zi));
        double x10 = Mth.lerp(u, hashNoise(xi, yi + 1, zi), hashNoise(xi + 1, yi + 1, zi));
        double x01 = Mth.lerp(u, hashNoise(xi, yi, zi + 1), hashNoise(xi + 1, yi, zi + 1));
        double x11 = Mth.lerp(u, hashNoise(xi, yi + 1, zi + 1), hashNoise(xi + 1, yi + 1, zi + 1));
        return Mth.lerp(w, Mth.lerp(v, x00, x10), Mth.lerp(v, x01, x11));
    }
    
    /**
     * 整数坐标的确定性散列，作为 value noise 的格点值，值域 {@code -1 ~ 1}。
     */
    protected static double hashNoise(int x, int y, int z) {
        int hash = x * 374761393 + y * 668265263 + z * 1274126177;
        hash = (hash ^ (hash >>> 13)) * 1274126177;
        hash = hash ^ (hash >>> 16);
        return (hash & 0x7FFFFFFF) / (double) 0x7FFFFFFF * 2.0D - 1.0D;
    }
    
    /**
     * 按 {@code speedDecay} 衰减当前速度（系数已由"每帧"换算为"每 tick"）。
     */
    protected void applySpeedDecay() {
        float decay = Mth.clamp(this.view.speedDecay, 0.0F, 1.0F);
        if (decay >= 1.0F) {
            return;
        }
        this.vx *= decay;
        this.vy *= decay;
        this.vz *= decay;
    }
    
    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        float elapsed = this.elapsedTicks(partialTicks);
        if (elapsed < 0.0F || elapsed > this.view.totalLifeTicks()) {
            return;
        }
        // 只写折射的层不在颜色通道出现（见 EfxPolygonView#distortionOnly）：这里的"不写"就是本层可见性的全部依据
        if (this.view.distortionOnly) {
            return;
        }
        
        Vec3 camPos = camera.getPosition();
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - camPos.x);
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - camPos.y);
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - camPos.z);
        
        float alpha = this.lifeAlpha(elapsed) * this.distanceAlpha(px, py, pz);
        float baseAlpha = FastColor.ARGB32.alpha(this.view.color) / 255.0F;
        float finalAlpha = baseAlpha * alpha;
        if (finalAlpha <= 0.0F) {
            return;
        }
        
        Vector3f[] corners = this.corners(camPos, cameraRight(camera), cameraUp(camera), partialTicks);
        // Intensity = 0 表示"不加额外强度"而非"全黑"，故取下限 1。
        // ⚠ 这只是**近似**：引擎的 `I = cbIntensity3D` 按着色模式分用（mode 4 影响 alpha、mode 3 乘内色、
        //   mode 0/1 根本不读它），本项目则一刀切乘进顶点色 ⇒ 仅对 mode 0/2/4 近似等价。"按模式分派"已获裁决，
        //   但前置是"`Flags` → 引擎 mode"的映射、尚未解开，故暂维持现状。
        // ⚠ 这里**不消费** `ColorRate`。此前本行断言它"只管颜色随时间的变化速率、不参与亮度"——那个说法没有证据，
        // 而已抓到的反汇编指向相反：原型引擎里与它数值吻合的自发光倍率（1 / 10 / 50）在 mode 0/2/4 里是
        // **整体乘进颜色**的（mode 1 只进 boost、mode 3 只进内色）。是否改为消费属待裁决项；
        // 在裁决前保持现状，并把"未决"如实写在这里，不要沿用旧断言的措辞。
        float brightness = Math.max(1.0F, this.view.intensity) * this.view.shaderBrightness;
        // ColorRange 只插值 RGB、alpha 一律取主体色，免得"颜色抖动"顺带把透明度也抖了
        float r = Mth.clamp(Mth.lerp(this.colorMix, FastColor.ARGB32.red(this.view.color),
            FastColor.ARGB32.red(this.view.colorRange)) / 255.0F * brightness, 0.0F, 1.0F);
        float g = Mth.clamp(Mth.lerp(this.colorMix, FastColor.ARGB32.green(this.view.color),
            FastColor.ARGB32.green(this.view.colorRange)) / 255.0F * brightness, 0.0F, 1.0F);
        float b = Mth.clamp(Mth.lerp(this.colorMix, FastColor.ARGB32.blue(this.view.color),
            FastColor.ARGB32.blue(this.view.colorRange)) / 255.0F * brightness, 0.0F, 1.0F);
        // 双色分段层的顶点色只承载生命期不透明度，故 RGB 一律写 0，否则会与屏幕空间的分段颜色相乘把两段都压暗
        if (this.view.dualColorSplit > 0.0F) {
            r = 0.0F;
            g = 0.0F;
            b = 0.0F;
        }
        // Saturation 不消费，理由是**有证据的**（不要退回"语义待定"这句含糊话）：已抓到的着色器
        // （粒子族两支 PS + 延迟 GBuffer 材质 PS）**都不读它**；而它的取值以 1 为恒等、0 为"全灰"，
        // 配合 LayerPositive 恒为 4、ColorBrightness 恒为 1，整组更像"材质 / 卡通着色参数"。
        // 按"饱和度倍率"处理会把蓝焰洗成灰白——而数据里 範囲　収束　炎1/2 的 Saturation 正是 0.05，
        // 即"照数据做也应该是灰的"，说明那条路本身就不成立，故维持不消费。
        
        float[] uv = this.uvWindow(elapsed);
        float uMin = uv[0];
        float vMin = uv[1];
        float uSize = uv[2];
        float vSize = uv[3];
        
        putVertex(buffer, corners[0], uMin, vMin + vSize, r, g, b, finalAlpha);
        putVertex(buffer, corners[1], uMin + uSize, vMin + vSize, r, g, b, finalAlpha);
        putVertex(buffer, corners[2], uMin + uSize, vMin, r, g, b, finalAlpha);
        putVertex(buffer, corners[3], uMin, vMin, r, g, b, finalAlpha);
    }
    
    @Override
    public boolean hasDistortion() {
        return this.view.distortionStrength > 0.0F && !this.removed;
    }
    
    /**
     * 遮罩的形状取自本层贴图：弧线刀光的轮廓、模糊面片的软边全部由贴图 alpha 决定。
     */
    @Override
    public ResourceLocation maskTexture() {
        return this.view.texture;
    }
    
    /**
     * 把面片写入畸变遮罩：自由朝向面片以自身法线在相机右/上基向量上的投影作为折射方向；
     * 面向相机的面片法线朝向视线，方向分量为 0（仅贡献强度）。
     * A 通道写的是<b>已乘视深标度</b>的强度（见 {@link RefractionDepthScale}）。
     */
    @Override
    public void buildDistortionQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
        float elapsed = this.elapsedTicks(partialTicks);
        if (elapsed < 0.0F || elapsed > this.view.totalLifeTicks()) {
            return;
        }
        float strength = this.view.distortionStrength;
        if (strength <= 0.0F) {
            return;
        }
        float alpha = this.lifeAlpha(elapsed);
        if (alpha <= 0.0F) {
            return;
        }
        
        float dx = 0.0F;
        float dy = 0.0F;
        if (this.view.orientation == PolygonOrientation.FREE) {
            Vector3f normal = new Vector3f(0.0F, 0.0F, 1.0F).rotate(this.rotationAt(elapsed));
            dx = normal.dot(camRight);
            dy = normal.dot(camUp);
        }
        int r = (int) (Mth.clamp(dx * 0.5F + 0.5F, 0.0F, 1.0F) * 255.0F);
        int g = (int) (Mth.clamp(dy * 0.5F + 0.5F, 0.0F, 1.0F) * 255.0F);
        
        // UV 与颜色通道取同一套窗口：遮罩的形状与强度都要跟着贴图 alpha 走（见 DistortionSource#maskTexture），
        // 缺了这一步写进遮罩的只是一个实心四边形
        float[] uv = this.uvWindow(elapsed);
        float uMin = uv[0];
        float vMin = uv[1];
        float uSize = uv[2];
        float vSize = uv[3];
        float[] cornerU = {0.0F, 1.0F, 1.0F, 0.0F};
        float[] cornerV = {1.0F, 1.0F, 0.0F, 0.0F};
        Vector3f[] corners = this.corners(camPos, camRight, camUp, partialTicks);
        // 视深因子折进 A 通道：该族材质的折射偏移与视深成反比，而后处理的 Strength 是逐帧常量、
        // 吸收不了逐像素的深度（详见 RefractionDepthScale）。深度取面片中心到相机的距离，
        // 面片自身的展布相对典型视深可忽略，逐顶点重算一遍没有意义。
        float depthScale = RefractionDepthScale.factorOf(
            (float) (Mth.lerp(partialTicks, this.xo, this.x) - camPos.x),
            (float) (Mth.lerp(partialTicks, this.yo, this.y) - camPos.y),
            (float) (Mth.lerp(partialTicks, this.zo, this.z) - camPos.z));
        int a = (int) (Mth.clamp(strength * alpha * depthScale, 0.0F, 1.0F) * 255.0F);
        // 遮罩缓冲以 TRIANGLES 提交（见 DistortionRenderHook#drawSources），故四边形必须展开成 6 个顶点；
        // 直接写 4 个顶点只能得到一个三角形，折射区域会只剩面片的一半、看起来落在弧线之外
        int[] order = {0, 1, 2, 0, 2, 3};
        for (int index : order) {
            Vector3f corner = corners[index];
            buffer.addVertex(corner.x, corner.y, corner.z)
                .setUv(uMin + uSize * cornerU[index], vMin + vSize * cornerV[index])
                .setUv2(0, 0)
                .setColor(r, g, 0, a);
        }
    }
    
    /**
     * 计算当前时刻面片的<b>渲染尺寸</b>（{@code x} = 宽、{@code y} = 高，单位：格）；抽成独立方法是为了让
     * {@link #corners} 与 {@link #getRenderBoundingBox} 共用同一份公式，否则包围盒盖不住真实尺寸、
     * 粒子中心的视锥剔除会把大片刀光整层判掉。
     */
    public Vector2f renderSize(float partialTicks) {
        float grow = Math.max(0.0F, this.elapsedTicks(partialTicks));
        float addScalar = integrateSize(
            this.view.sizeScalarAdd * framesPerTickWeight(this.view.sizeScalarAddCoef),
            perTickCoefficient(this.view.sizeScalarAddCoef), grow);
        float addX = addScalar
            + integrateSize(this.view.sizeAddX * framesPerTickWeight(this.view.sizeAddCoefX),
            perTickCoefficient(this.view.sizeAddCoefX), grow);
        float addY = addScalar
            + integrateSize(this.view.sizeAddY * framesPerTickWeight(this.view.sizeAddCoefY),
            perTickCoefficient(this.view.sizeAddCoefY), grow);
        return new Vector2f(
            (this.view.width + addX) * this.sizeScale * this.widthScale * this.view.sizeScale,
            (this.view.height + addY) * this.sizeScale * this.heightScale * this.view.sizeScale);
    }
    
    /**
     * 给出覆盖<b>实际渲染尺寸</b>的包围盒，供粒子引擎做视锥剔除。
     * <b>为什么必须覆写</b>：默认实现只覆盖粒子中心附近约 2.2 格，而本项目有整圈烟雾、地面气浪这类
     * 直径几十格的效果，中心一出视野整层就消失。外接半径取"宽 + 高"，再补上深度偏移 {@link #depthOffset}。
     */
    @Override
    public AABB getRenderBoundingBox(float partialTicks) {
        double centerX = Mth.lerp(partialTicks, this.xo, this.x);
        double centerY = Mth.lerp(partialTicks, this.yo, this.y);
        double centerZ = Mth.lerp(partialTicks, this.zo, this.z);
        Vector2f size = this.renderSize(partialTicks);
        float extent = Math.max(0.5F, size.x + size.y + Math.abs(this.depthOffset));
        return new AABB(centerX - extent, centerY - extent, centerZ - extent,
            centerX + extent, centerY + extent, centerZ + extent);
    }
    
    /**
     * 计算四个角点的**相机相对**世界坐标（顺序：左下、右下、右上、左上）；
     * 自由朝向用随机旋转四元数，面向相机用相机右/上基向量并按视线滚转。
     */
    protected Vector3f[] corners(Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
        float elapsed = this.elapsedTicks(partialTicks);
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - camPos.x);
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - camPos.y);
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - camPos.z);
        
        float grow = Math.max(0.0F, elapsed);
        Vector2f size = this.renderSize(partialTicks);
        float width = size.x;
        float height = size.y;
        float halfWidth = width * 0.5F;
        float halfHeight = height * 0.5F;
        
        float[] localX = {-halfWidth, halfWidth, halfWidth, -halfWidth};
        float[] localY = {-halfHeight, -halfHeight, halfHeight, halfHeight};
        Vector3f[] corners = new Vector3f[4];
        if (this.view.orientation == PolygonOrientation.GROUND) {
            // 水平面朝向：四边形躺在世界 XZ 平面上（法线恒为 +Y），只允许平面内滚转
            float roll = this.rollPhase + toRadians(this.spinZ * TICK_TO_FRAME * grow);
            float cos = Mth.cos(roll);
            float sin = Mth.sin(roll);
            float anchorX = (this.view.anchorU - 0.5F) * width;
            float anchorY = (0.5F - this.view.anchorV) * height;
            for (int i = 0; i < 4; i++) {
                float relX = localX[i] - anchorX;
                float relY = localY[i] - anchorY;
                float offsetX = relX * cos - relY * sin;
                float offsetZ = relX * sin + relY * cos;
                corners[i] = new Vector3f(offsetX, 0.0F, offsetZ).add(px, py, pz);
            }
        } else if (this.view.orientation == PolygonOrientation.BILLBOARD) {
            float roll = this.rollPhase + toRadians(this.spinZ * TICK_TO_FRAME * grow);
            float cos = Mth.cos(roll);
            float sin = Mth.sin(roll);
            // 旋转锚点：把贴图中 anchorU/anchorV 对应的位置固定在粒子处，
            // 使弧形刀光绕"贴图内的圆弧中心"扫过，而不是绕面片中心甩动
            float anchorX = (this.view.anchorU - 0.5F) * width;
            float anchorY = (0.5F - this.view.anchorV) * height;
            for (int i = 0; i < 4; i++) {
                float relX = localX[i] - anchorX;
                float relY = localY[i] - anchorY;
                float offsetRight = relX * cos - relY * sin;
                float offsetUp = relX * sin + relY * cos;
                corners[i] = new Vector3f(camRight).mul(offsetRight)
                    .add(new Vector3f(camUp).mul(offsetUp))
                    .add(px, py, pz);
            }
        } else {
            Quaternionf rotation = this.rotationAt(elapsed);
            // 自由朝向同样支持旋转锚点：把锚点移到原点后旋转，再回到粒子位置
            float anchorX = (this.view.anchorU - 0.5F) * width;
            float anchorY = (0.5F - this.view.anchorV) * height;
            for (int i = 0; i < 4; i++) {
                corners[i] = new Vector3f(localX[i] - anchorX, localY[i] - anchorY, 0.0F)
                    .rotate(rotation)
                    .add(px, py, pz);
            }
        }
        // 沿相机视线方向把整片面片前后平移；相机前方 = up × right（Minecraft 为右手坐标系）
        if (this.depthOffset != 0.0F) {
            Vector3f forward = new Vector3f(camUp).cross(camRight).normalize().mul(this.depthOffset);
            for (Vector3f corner : corners) {
                corner.add(forward);
            }
        }
        return corners;
    }
    
    /**
     * 逐片抽一次自转角速度（度 / EFX 帧）：{@code 基准 + (随机 − 0.5) × 随机全宽}。
     * <p>
     * ⚠ 这里把 {@code r} 当<b>全宽</b>读（实际范围 {@code ±r/2}），与初始朝向
     * （{@code GenericMeshParticle} 的出生朝向）同一读法；同一个 {@code {s, r}} 在别的字段上还有
     * "外缘 {@code s + r}"（尺寸 / 范围）与"中值 {@code s + r/2}"（生命）两种读法，不能混用。
     * 全宽为 0 时直接返回基准值，不消耗随机数——否则同层的其它随机量会跟着错位。
     */
    protected static float sampleSpin(float base, float variation, RandomSource rnd) {
        if (variation == 0.0F) {
            return base;
        }
        return base + (rnd.nextFloat() - 0.5F) * variation;
    }
    
    /**
     * 自转后的朝向四元数（角速度按 EFX「度 / 帧」记录，1 tick = 3 帧）。
     */
    protected Quaternionf rotationAt(float elapsed) {
        return new Quaternionf(this.initialRotation)
            .rotateX(toRadians(this.spinX * TICK_TO_FRAME * elapsed))
            .rotateY(toRadians(this.spinY * TICK_TO_FRAME * elapsed))
            .rotateZ(toRadians(this.spinZ * TICK_TO_FRAME * elapsed));
    }
    
    /**
     * 计算序列帧 UV 窗口，返回 {@code [uMin, vMin, uSize, vSize]}。
     * 两种取帧方式：<b>固定帧</b>（构建时随机抽一帧并保持到消散）与<b>按时间播放</b>（{@code framePlaySpeed} 序列帧 / tick）。
     */
    @SuppressWarnings("IntegerDivisionInFloatingPointContext")
    protected float[] uvWindow(float elapsed) {
        // UV 沿 V 轴的滚动只对单帧贴图生效：多帧贴图的窗口必须对齐到帧格，叠加滚动会跨帧显示错误内容
        float vScroll = this.view.uvScrollV * Math.max(0.0F, elapsed);
        int columns = Math.max(1, this.view.frameColumns);
        // 行数取素材实际帧数推出的行数：按播放帧数推行数会偏小、每帧采样高度翻倍，整层贴图错位
        int rows = Math.max(1, this.view.frameRows);
        // 只有图集本身仅一帧时才整张铺满；多帧图集而本层只播第 0 帧时仍须只取左上角那一格
        if (this.view.frameCount <= 1 && this.view.atlasFrameCount <= 1) {
            return new float[]{0, vScroll - Mth.floor(vScroll), 1, 1};
        }
        int frame = this.view.frameCount <= 1
            ? 0
            : (this.fixedFrame >= 0
               ? this.fixedFrame
               : (int) (Math.max(0.0F, elapsed) * this.frameSpeedScale * this.view.framePlaySpeed) % this.view.frameCount);
        float uSize = 1.0F / columns;
        float vSize = 1.0F / rows;
        return new float[]{
            (frame % columns) * uSize,
            (frame / columns) * vSize,
            uSize,
            vSize};
    }
    
    /**
     * 把已算好的相机相对角点写入粒子缓冲。
     */
    protected void putVertex(VertexConsumer buffer, Vector3f corner, float u, float v,
                             float r, float g, float b, float alpha) {
        buffer.addVertex(corner.x, corner.y, corner.z)
            .setColor(r, g, b, alpha)
            .setUv(u, v)
            .setLight(FULLBRIGHT_LIGHTMAP);
    }
    
    /**
     * 生命三段的不透明度：出现渐显 → 保持满亮 → 消散渐隐。
     */
    protected float lifeAlpha(float elapsed) {
        if (elapsed < this.view.appearTicks) {
            return this.view.appearTicks <= 0.0F ? 1.0F : Mth.clamp(elapsed / this.view.appearTicks, 0.0F, 1.0F);
        }
        float keepEnd = this.view.appearTicks + this.view.keepTicks;
        if (elapsed < keepEnd) {
            return 1.0F;
        }
        return this.view.vanishTicks <= 0.0F
            ? 0.0F
            : Mth.clamp(1.0F - (elapsed - keepEnd) / this.view.vanishTicks, 0.0F, 1.0F);
    }
    
    /**
     * 按相机距离淡出（对应 FadeByDepth：过近与过远都淡出）。
     */
    protected float distanceAlpha(float px, float py, float pz) {
        return ParticleUtils.distanceAlpha(px, py, pz, this.view.fadeNearEnd, this.view.fadeNearStart, this.view.fadeFarEnd, this.view.fadeFarStart);
    }
    
    @Override
    public ParticleRenderType getRenderType() {
        return this.renderType;
    }
    
    /**
     * 本层的双色分段规格；未启用时为 {@code null}。
     * 亮度与顶点色口径一致（{@code max(1, Intensity) × ColorBrightness}），由片元着色器在<b>乘以颜色之后
     * 逐通道裁到 0~1</b>，使"分段着色"与"逐片粒子抖动"两条路径的明度基准相同、切换时不跳变。
     */
    @Nullable
    protected PolygonRenderTypes.DualColorSpec dualColorSpec() {
        if (this.view.dualColorSplit <= 0.0F) {
            return null;
        }
        return new PolygonRenderTypes.DualColorSpec(this.view.color, this.view.colorRange,
            this.view.dualColorSplit,
            Math.max(1.0F, this.view.intensity) * this.view.shaderBrightness);
    }
    
    /**
     * 相机屏幕右方向的世界基向量（内部工具）。
     */
    protected static Vector3f cameraRight(Camera camera) {
        return new Vector3f(camera.getLookVector()).cross(camera.getUpVector()).normalize();
    }
    
    /**
     * 相机屏幕上方向的世界基向量（内部工具）。
     */
    protected static Vector3f cameraUp(Camera camera) {
        return new Vector3f(camera.getUpVector()).normalize();
    }
    
    /**
     * 把"每 EFX 帧"的尺寸增量衰减系数折算成"每 tick"（三个 {@code *Coef} 都是逐帧倍率，故一 tick 的等效倍率是它的 {@link #TICK_TO_FRAME} 次方）。
     */
    protected static float perTickCoefficient(float frameCoefficient) {
        return EfxPolygonView.perTickCoefficient(frameCoefficient);
    }
    
    /**
     * 把"每 EFX 帧的增量"折算成"每 tick 的等效增量"；面片 / 网格 / 飘带三个视图必须共用同一套折算，
     * 否则同一份 EFX 数据在三处会得到不同的尺寸曲线。
     */
    protected static float framesPerTickWeight(float frameCoefficient) {
        return EfxPolygonView.framesPerTickWeight(frameCoefficient);
    }
    
    /**
     * 增量累积：每 tick 增加 {@code perTick} 且增量按 {@code coefficient} 逐 tick 衰减，用等比数列求和得累计增量（{@code coefficient} ≥ 1 时退化为线性增长）。
     */
    protected static float integrateSize(float perTick, float coefficient, float ticks) {
        if (coefficient >= 1.0F) {
            return perTick * ticks;
        }
        float decay = Mth.clamp(coefficient, 0.0F, 1.0F);
        if (decay <= 0.0F) {
            return perTick;
        }
        return perTick * (1.0F - (float) Math.pow(decay, ticks)) / (1.0F - decay);
    }
    
    /**
     * 角度转弧度（内部工具）。
     */
    protected static float toRadians(float degrees) {
        return degrees * 0.017453292F;
    }
}
