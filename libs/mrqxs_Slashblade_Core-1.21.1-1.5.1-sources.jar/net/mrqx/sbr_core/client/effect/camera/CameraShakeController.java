package net.mrqx.sbr_core.client.effect.camera;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * 镜头震动控制器
 * <p>
 * 实现方式：在 {@link ViewportEvent.ComputeCameraAngles} 中叠加随时间衰减、带距离衰减的
 * 伪随机角度偏移（滚转为主、偏航/俯仰为辅）。震动由时间轴按上述节奏多次调用
 * {@link #trigger(Vec3, int, float)} 触发。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class CameraShakeController {
    /**
     * 单次震动的基准幅度（度，滚转方向）
     */
    public static final float DEFAULT_AMPLITUDE = 0.35F;
    
    /**
     * 距离衰减起点（格）：小于该距离不衰减
     */
    public static final float ATTENUATION_START = 60.0F;
    
    /**
     * 距离衰减终点（格）：大于该距离完全失效
     */
    public static final float ATTENUATION_END = 80.0F;
    
    /**
     * 当前震动的中心位置（用于距离衰减）
     */
    private static Vec3 origin = Vec3.ZERO;
    
    /**
     * 最近一次震动的起始与结束游戏时间
     */
    private static long startGameTime;
    private static long endGameTime;
    
    /**
     * 当前震动幅度（度）
     */
    private static float amplitude;
    
    private CameraShakeController() {
    }
    
    /**
     * 触发一次镜头震动
     *
     * @param origin        震动中心（用于距离衰减）
     * @param durationTicks 持续 tick 数
     * @param amplitude     基准幅度（度）
     */
    public static void trigger(Vec3 origin, int durationTicks, float amplitude) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        long now = minecraft.level.getGameTime();
        // 结束时间取较晚者，避免连发时被前一次提前截断
        endGameTime = Math.max(endGameTime, now + Math.max(1, durationTicks));
        startGameTime = Math.min(startGameTime == 0L ? now : startGameTime, now);
        CameraShakeController.origin = origin;
        CameraShakeController.amplitude = amplitude;
    }
    
    /**
     * 在计算相机角度时叠加震动偏移。
     */
    @SubscribeEvent
    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        long gameTime = minecraft.level.getGameTime();
        if (gameTime >= endGameTime || amplitude <= 0.0F) {
            return;
        }
        float partialTick = (float) event.getPartialTick();
        float elapsed = (gameTime + partialTick) - startGameTime;
        float total = Math.max(1.0F, endGameTime - startGameTime);
        if (elapsed < 0.0F || elapsed > total) {
            return;
        }
        // 时间衰减 × 距离衰减
        float strength = (1.0F - elapsed / total) * distanceAttenuation(event.getCamera().getPosition(), origin);
        if (strength <= 0.0F) {
            return;
        }
        float magnitude = amplitude * strength;
        double time = (gameTime + partialTick) * 1.7D;
        // 多频正弦叠加做伪随机抖动，避免各帧同相位
        float roll = (float) (Math.sin(time * 3.1D) * 0.6D + Math.sin(time * 7.3D) * 0.4D);
        float yaw = (float) (Math.sin(time * 4.7D) * 0.6D + Math.sin(time * 9.1D) * 0.4D);
        float pitch = (float) (Math.cos(time * 5.3D) * 0.6D + Math.cos(time * 8.9D) * 0.4D);
        event.setRoll(event.getRoll() + roll * magnitude);
        event.setYaw(event.getYaw() + yaw * magnitude * 0.5F);
        event.setPitch(event.getPitch() + pitch * magnitude * 0.5F);
    }
    
    /**
     * 距离衰减：60 格内不衰减，60~80 格线性衰减，80 格外完全失效。
     *
     * @param cameraPos 相机位置
     * @param center    震动中心
     * @return 衰减系数（0~1）
     */
    public static float distanceAttenuation(Vec3 cameraPos, Vec3 center) {
        double distance = cameraPos.distanceTo(center);
        if (distance <= ATTENUATION_START) {
            return 1.0F;
        }
        if (distance >= ATTENUATION_END) {
            return 0.0F;
        }
        return (float) (1.0D - (distance - ATTENUATION_START) / (ATTENUATION_END - ATTENUATION_START));
    }
}
