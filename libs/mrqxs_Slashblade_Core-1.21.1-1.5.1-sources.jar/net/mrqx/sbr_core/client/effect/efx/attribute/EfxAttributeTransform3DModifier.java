package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * 属性 {@code EFXAttributeTransform3DModifier}：螺旋运动修改器。字段名全是 {@code unknN}、语义未知，
 * 故本项目只建模实测过的三项：{@code spinMode}（{@code unkn0}，2 = 向内螺旋、0/1 = 不螺旋做直线向内）、
 * {@code spinPerFrame}（{@code unkn35}，螺旋角速度初值，弧度 / EFX 帧，越大越快）、{@code spinAcceleration}
 * （{@code unkn37}，角速度的每帧复利系数，&gt; 1 越来越快、&lt; 1 越来越慢、1 为匀速）；其余字段一概不保留
 * （语义缺失，待裁决）。
 * <p>
 * <b>这样够不够？——已用数据侧分布核实（脚本 {@code efx_field_histogram.py}）</b>：全部 11 处该属性里
 * 取过非零值的只有 6 个字段，除上面三个外是 {@code unkn33}（<b>恒为 1</b>，像个常量开关，不建模不影响行为）、
 * {@code unkn41}（<b>恒等于 {@code unkn37}</b>）与 {@code unkn39}（只在唯一一处出现，且<b>恒等于 {@code unkn35}</b>）。
 * 也就是说后两对是**同值的镜像组**，建模其中一对即可；其余四十多个 {@code unknN} 在数据里从未取过非零值。
 * ⇒ 不补字段是完备的，缺的只是这两对镜像的语义。
 * <p>
 * ⚠ <b>适用面</b>：数据里它<b>不止</b>出现在飘带层（{@code 範囲　GPU}），面片层也有
 * （如范围效果的 {@code 範囲　収束　炎1/2} 与 {@code 収束　炎2}）。
 * <b>两条路径现在都消费它</b>：飘带侧是 {@code EfxRibbonView}，面片侧是
 * {@code EfxPolygonView#spinRadiansPerTick} / {@code spinAcceleration}（面片侧原本没读，
 * 那时给面片层配本属性等于死数据，后补）。两边的消费口径必须一致——旋转式与复利方式都要同式，
 * 否则同一个属性会让飘带与面片往相反方向转。
 * <p>
 * 分工：本类只管绕圆心的切向旋转，向内收拢的径向分量由 {@link EfxAttributeTransform3D} 一侧负责。
 * 注意 {@code spinPerFrame} 与 {@code spinAcceleration} 都按 EFX 帧（60fps）计，消费侧须折算
 * {@code 1 tick = 3 帧}。
 *
 * @param spinMode         螺旋模式；取值 {@link #SPIN_MODE_INWARD_SPIRAL}（2）表示向内螺旋，0 / 1 表示无螺旋
 * @param spinPerFrame     螺旋角速度的初值，单位弧度 / EFX 帧
 * @param spinAcceleration 螺旋角速度的加速度率，逐帧复利
 */
public record EfxAttributeTransform3DModifier(
    int spinMode,
    float spinPerFrame,
    float spinAcceleration
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = -3;
    
    /**
     * 螺旋模式的取值：向内螺旋（2）；0 与 1 都表示不螺旋。
     */
    public static final int SPIN_MODE_INWARD_SPIRAL = 2;
    
    /**
     * 1 tick 对应的 EFX 帧数（EFX 帧率是本项目的 3 倍），用于把本类的"弧度 / 帧"折算成"弧度 / tick"。
     */
    public static final float FRAMES_PER_TICK = 3.0F;
    
    /**
     * 默认值：不螺旋、无角速度、匀速——等价于该层没有配置本属性。
     */
    public static final EfxAttributeTransform3DModifier DEFAULT =
        new EfxAttributeTransform3DModifier(0, 0.0F, 1.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTransform3DModifier";
    }
    
    /**
     * 该层是否要求向内螺旋：{@link #spinMode} 等于 {@link #SPIN_MODE_INWARD_SPIRAL} 时为 true。
     */
    public boolean inwardSpiral() {
        return this.spinMode == SPIN_MODE_INWARD_SPIRAL;
    }
    
    /**
     * 螺旋角速度的初值，已由"弧度 / 帧"折算成"弧度 / tick"（× {@link #FRAMES_PER_TICK}）；模式不是向内螺旋时返回 0。
     */
    public double spinRadiansPerTick() {
        if (!this.inwardSpiral()) {
            return 0.0D;
        }
        return this.spinPerFrame * FRAMES_PER_TICK;
    }
}
