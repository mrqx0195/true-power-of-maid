package net.mrqx.sbr_core.client.effect.efx.preset.judgementcut;

import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack.EfxJceNoDrawPresets;
import org.joml.Vector3f;

/**
 * 次元斩（小技能）三套演出的<b>脚本类</b>层预设（{@code TypeNoDraw} + {@code PtBehavior}），本身不绘制几何。
 */
public final class EfxSlashNoDrawPresets {
    /**
     * {@code カメラシェイク小}：一次轻微镜头晃动，三套变体的差别只在触发时刻。
     * <p>
     * ⚠ 后四项参数（距离 / 角度衰减）在导出的属性块里被截断，暂沿用同族的标定值；
     * 前七项（周期与三个平移 / 三个旋转的幅度）是三套数据的共同原值。
     */
    public static EfxAttributePtBehavior cameraShake(float transY0, float transY1, float rotY0, float rotY1) {
        return EfxJceNoDrawPresets.behavior("EffectShakeCameraCustom",
            EfxJceNoDrawPresets.prop("Period", EfxBehaviorValue.ofRaw(20, 2L, 8)),
            EfxJceNoDrawPresets.prop("TranslationXRange", EfxBehaviorValue.ofFloat2(-0.05F, 0.1F)),
            EfxJceNoDrawPresets.prop("TranslationYRange", EfxBehaviorValue.ofFloat2(transY0, transY1)),
            EfxJceNoDrawPresets.prop("TranslationZRange", EfxBehaviorValue.ofFloat2(-0.05F, 0.1F)),
            EfxJceNoDrawPresets.prop("RotationXRange", EfxBehaviorValue.ofFloat2(-0.15F, 0.3F)),
            EfxJceNoDrawPresets.prop("RotationYRange", EfxBehaviorValue.ofFloat2(rotY0, rotY1)),
            EfxJceNoDrawPresets.prop("RotationZRange", EfxBehaviorValue.ofFloat2(-0.15F, 0.3F)),
            EfxJceNoDrawPresets.prop("UseDistanceAttenuation", EfxBehaviorValue.ofInt(1)),
            EfxJceNoDrawPresets.prop("DistanceAttenuationStart", EfxBehaviorValue.ofFloat(40.0F)),
            EfxJceNoDrawPresets.prop("DistanceAttenuationEnd", EfxBehaviorValue.ofFloat(70.0F)),
            EfxJceNoDrawPresets.prop("UseAngleAttenuation", EfxBehaviorValue.ofInt(1)));
    }
    
    /** BOSS 变体的镜头晃动，在第 4 帧触发。 */
    public static final EfxConfig BOSS_CAMERA_SHAKE = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 4, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(8.0F, 8.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(EfxSlashNoDrawPresets.cameraShake(-0.05F, 0.1F, -0.15F, 0.3F))
        .build();
    
    /** 完美变体的镜头晃动，在第 15 帧触发。 */
    public static final EfxConfig PERFECT_CAMERA_SHAKE = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 15, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(8.0F, 8.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(EfxSlashNoDrawPresets.cameraShake(-0.05F, 0.1F, -0.15F, 0.3F))
        .build();
    
    /**
     * {@code hit_light1}：命中处一闪而过的 1500 流明补光。
     * <p>
     * 本项目不做真实光注入，这一族层由 {@code LightScriptAdapter} 转成屏幕空间辉光。
     */
    public static final EfxConfig PERFECT_HIT_LIGHT = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 8, 8, 3, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(0.75F, 1.25F), new EfxRange(0.75F, 1.25F), new EfxRange(0.75F, 1.25F),
            0, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(EfxJceNoDrawPresets.behavior("EffectLight1500lm",
            EfxJceNoDrawPresets.prop("Intensity", EfxBehaviorValue.ofFloat(230000.0F)),
            EfxJceNoDrawPresets.prop("Radius", EfxBehaviorValue.ofFloat(0.35F)),
            EfxJceNoDrawPresets.prop("ReferenceEffectiveRange", EfxBehaviorValue.ofFloat(9.5F))))
        .build();
    
    /** 普通变体的镜头晃动：纵向的平移与旋转幅度是另两套的两倍。 */
    public static final EfxConfig NORMAL_CAMERA_SHAKE = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 15, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(8.0F, 8.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(EfxSlashNoDrawPresets.cameraShake(-0.1F, 0.2F, -0.3F, 0.6F))
        .build();
    
    /** 普通变体的命中补光：强度与参考范围都略低于完美变体。 */
    public static final EfxConfig NORMAL_HIT_LIGHT = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 8, 8, 3, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(0.5F, 1.0F), new EfxRange(0.5F, 1.0F), new EfxRange(0.5F, 1.0F),
            0, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(EfxJceNoDrawPresets.behavior("EffectLight1500lm",
            EfxJceNoDrawPresets.prop("Intensity", EfxBehaviorValue.ofFloat(150000.0F)),
            EfxJceNoDrawPresets.prop("Radius", EfxBehaviorValue.ofFloat(0.25F)),
            EfxJceNoDrawPresets.prop("ReferenceEffectiveRange", EfxBehaviorValue.ofFloat(8.0F))))
        .build();
    
    private EfxSlashNoDrawPresets() {
    }
}
