package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import org.joml.Vector3f;

/**
 * 类型属性 {@code EFXAttributeTypeNoDraw}：<b>不绘制本体</b>的层（json 的 {@code type} = 74）。
 * <p>
 * 它承载"画面上没有几何、表现全部由脚本产生"的效果。这类层<b>不产生任何绘制</b>，
 * 但它携带的信息一点也不比其他类型少——恰恰相反，本项目此前丢掉这一对属性
 * （{@code TypeNoDraw} + {@link EfxAttributePtBehavior}）、改在时间轴里手抄参数，
 * 才导致了效果落点被写错（把世界位置写成了相机局部位置）。
 * <p>
 * <b>本类为什么仍然如实保留 Size / Color 这些"看起来用不到"的字段</b>：
 * NoDraw 层不绘制，但这些字段是<b>脚本的输入</b>。例如 {@code ライト} 层带
 * {@code Size = (1, 0, 1)}、{@code SizeRandom = (0, 1, 0)}，脚本 {@code EffectLight5000lm}
 * 正是拿它当作光源空间范围；{@code Color} / {@code ColorRange} 同理。
 * 丢掉它们就等于把"脚本参数"从属性表里抹掉，与"以 EFX 为准"相悖。
 * <p>
 * {@code Rotation} / {@code Size} 是<b>基准值</b>，与之成对的 {@code RotationRandom} / {@code SizeRandom}
 * 是<b>随机全宽</b>（与 {@link EfxTypeMesh} 里 {@code scaleX} / {@code scaleXVariation} 是同一套语义）。
 * 字段声明顺序与 json 完全一致；{@code unkn14} / {@code unkn15} 在现有数据里恒为 0，
 * 原样保留以便逐字段对照 json。
 *
 * @param flags          混合标志（{@code Flags}；NoDraw 不绘制，故不参与渲染，仅供对照）
 * @param color          颜色 1（常规 ARGB，由 json 的 rgba 交换 R/B 得到）
 * @param colorRange     颜色 2（常规 ARGB；与 {@code color} 一起构成颜色抖动区间）
 * @param rotationOrder  旋转顺序（EFX {@code RotationOrder}）
 * @param rotation       初始旋转基准（弧度，XYZ）
 * @param rotationRandom 初始旋转的随机全宽（弧度，XYZ）
 * @param size           尺寸基准（格，XYZ）
 * @param sizeRandom     尺寸的随机全宽（格，XYZ）
 * @param unknown14      未确证字段（现有数据恒为 0）
 * @param unknown15      未确证字段（现有数据恒为 0）
 */
public record EfxTypeNoDraw(
    int flags,
    int color,
    int colorRange,
    int rotationOrder,
    Vector3f rotation,
    Vector3f rotationRandom,
    Vector3f size,
    Vector3f sizeRandom,
    int unknown14,
    int unknown15
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 74;
    
    /**
     * 默认值：无色、无旋转、尺寸基准 {@code (1,0,1)}、无随机。
     * <p>
     * {@code EffectRadialBlur} 与 BOSS范围效果 efx 的同类层都取这一组值——本效果集里的 NoDraw 层共用它。
     */
    public static final EfxTypeNoDraw DEFAULT = new EfxTypeNoDraw(
        0, 0xFFFFFFFF, 0xFFFFFFFF, 4,
        new Vector3f(), new Vector3f(),
        new Vector3f(1.0F, 0.0F, 1.0F), new Vector3f(0.0F, 1.0F, 0.0F),
        0, 0);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeNoDraw";
    }
}
