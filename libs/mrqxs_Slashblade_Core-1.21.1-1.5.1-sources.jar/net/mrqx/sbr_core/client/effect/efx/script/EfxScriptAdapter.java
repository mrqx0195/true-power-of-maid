package net.mrqx.sbr_core.client.effect.efx.script;

/**
 * EFX 脚本执行者：把 {@code via.effect.script.*} 脚本在本项目里落地。
 * <p>
 * {@code TypeNoDraw} 层（引擎不绘制本体）把表现整层交给脚本；分工是
 * <b>NoDraw 层负责"是什么、在哪、多久、什么参数"，执行者负责"用什么手段表现"</b>。
 * <p>
 * 执行者是<b>后端</b>：既可以是全屏后处理（径向模糊、LUT 校正），也可以是场景里的东西
 * （相机震动、贴花、辉光面片）。故本接口刻意不限定表现手段，只要求"按上下文执行一次"。
 * 后处理链（{@code PostEffect} / {@code PostChain} / {@code PostEffectRegistry}）与
 * 畸变通道（{@code DistortionEffectManager}）是引擎级设施，执行者调用它们即可。
 * <p>
 * 执行者按 {@link #scriptName()} 注册进 {@link EfxScriptRegistry}，由后者按层上的脚本名派发；
 * 一个脚本名只应有一个执行者。
 */
public interface EfxScriptAdapter {
    /**
     * 本执行者对应的脚本短名（去掉 {@code via.effect.script.} 前缀），即派发键。
     * <p>
     * 必须与 EFX 数据里 {@code behaviorString} 的短名逐字符一致（例如 {@code EffectRadialBlur}），
     * 否则 {@link EfxScriptRegistry#dispatch(EfxScriptContext)} 找不到执行者。
     *
     * @return 脚本短名
     */
    String scriptName();
    
    /**
     * 执行一次脚本。调用时机由时间轴决定（层被触发的那一刻）。
     * <p>
     * 时长、位置、参数一律从上下文读取，<b>不得写死在实现里</b>：上下文里的 {@code view}
     * 就是该层 EFX 配置的只读视图。同一次演出里同一脚本可能被多层触发，
     * 各层调用互不干扰由执行者自己保证（例如后处理类执行者通常以后触发的为准）。
     *
     * @param context 本次执行的上下文（世界、演出原点、层的配置视图）
     */
    void execute(EfxScriptContext context);
}
