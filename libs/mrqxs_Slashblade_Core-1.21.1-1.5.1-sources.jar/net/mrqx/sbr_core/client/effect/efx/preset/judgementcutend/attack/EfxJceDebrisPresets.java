package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack;

import net.mrqx.sbr_core.client.effect.debris.DebrisMesh;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

/**
 * 碎屑层的 EFX 风格预设：常量本身就是一份 {@link EfxConfig}，由
 * {@link net.mrqx.sbr_core.client.effect.efx.EfxDebrisView} 在触发时摊平成发射与渲染所需的扁平字段。
 * <p>
 * {@link #GLASS_LARGE}：从命中处炸开的浅蓝白玻璃碎片；{@link #STONE_SMALL}：从角色脚下一格向四周炸开的碎石。
 */
public final class EfxJceDebrisPresets {
    /**
     * {@code ガラス 大0}：从命中处炸开的一堆浅蓝白玻璃碎片。
     * <p>
     * 碎片数、批间隔、尺寸、生命与初速度都是<b>手调值</b>（与 EFX 数据原值不同）；
     * 翻滚三轴与逐帧衰减则**照数据**写在这里（从前由 {@code EfxDebrisView} 以常量承载，
     * 而那三个常量是把数据的随机全宽当成了基准值）。
     */
    public static final EfxConfig GLASS_LARGE = EfxConfigBuilder.create(
            new EfxTypeMesh(
                8, 0, 5, 1.0F, 1.0F, 0,
                0.0F, 3.1415927F,
                0.0F, 3.1415927F,
                0.0F, 3.1415927F,
                1.0F, 0.5F,
                1.0F, 0.0F,
                0.2F, 0.1F,
                3.0F, 2.0F,
                0xFFBBC1FF, 0xFF9C9EB1,
                DebrisMesh.MODEL_LOCATION))
        .put(new EfxAttributeSpawn(10, 0, 10, 10, 0, 8, 4, false, 164, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(10.0F, 0.0F), new EfxRange(375.0F, 0.0F),
            new EfxRange(100.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new EfxRange(0.5F, 0.2F), new EfxRange(0.994F, 0.005F), EfxRange.ZERO,
            new Vector3f(0.0F, 0.0F, 1.0F), new Vector3f(1.1F, 1.0F, 1.1F), 1,
            new EfxRange(0.2F, 0.0F), EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(new EfxRange(7.5F, 7.5F), new EfxRange(2.5F, 2.5F),
            new EfxRange(7.5F, 7.5F), 0, 0, 0, 4, new Vector3f(),
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F)))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            8.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        // 翻滚：照数据。三轴的**基准是 0**、角速度全在随机全宽里（X/Z 各 30°、Y 3°），
        // 故每片在 ±15° / ±1.5° / ±15° 内各转各的；X/Z 逐帧衰减 0.95、Y 不衰减。
        .put(new EfxAttributeRotateAnim(0,
            new EfxRange(0.0F, 0.5235988F), new EfxRange(0.0F, 0.052359883F), new EfxRange(0.0F, 0.5235988F),
            new EfxRange(0.95F, 0.0F), new EfxRange(1.0F, 0.0F), new EfxRange(0.95F, 0.0F), EfxRange.ZERO))
        .build();
    
    /**
     * {@code 小石メッシュ0}：从角色脚下一格向四周炸开的一堆碎石。
     * <p>
     * 与玻璃层共用 {@code DebrisParticle} 的渲染路径（按形状组随机取、逐组归一化、单批多实例），差别只在 OBJ、贴图与数值；
     * {@code DebrisMesh} 为此从"玻璃专用"泛化为按模型路径取组，{@code MeshParticleRenderType} 也新增了石头变体
     * ——否则石头会顶着玻璃的法线被照亮。
     * <p>
     * <b>范围类参数曾按需求 ×3，实机确认整层几乎不可见，已回调到 EFX 原值</b>；若将来仍需放大，请给出具体量级而非沿用全局倍率。
     */
    public static final EfxConfig STONE_SMALL = EfxConfigBuilder.create(
            new EfxTypeMesh(
                3, 0, 3, 1.0F, 1.0F, 0,
                0.0F, 3.1415927F,
                0.0F, 3.1415927F,
                0.0F, 3.1415927F,
                1.0F, 0.3F,
                1.0F, 0.3F,
                1.0F, 0.3F,
                2.0F, 0.3F,
                0xFF15120E, 0xFFFFFFFF,
                DebrisMesh.STONE_LOCATION))
        .put(new EfxAttributeSpawn(180, 0, 10, 10, 0, 0, 15, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(100.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(0.0F, 0.8660254F), new EfxRange(0.75F, 0.25F), new EfxRange(0.0F, 0.8660254F),
            new EfxRange(5.0F, 1.0F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(1.2F, 1.3F, 1.2F), 1,
            new EfxRange(1.3F, 0.2F), EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(new EfxRange(-0.008F, 0.001F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(5.0F, 15.0F), new EfxRange(0.0F, 10.0F), new EfxRange(15.0F, 15.0F),
            1, 8, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        // 翻滚：石头层在数据里**没有**这条属性（`EFXAttributeRotateAnim` 只出现在玻璃与被斩系列上），
        // 故这里保留本项目原先的手调值 30 / 20 / 30 度每帧 + 逐帧衰减 0.95（Y 轴的 20° 是有意放大，数据无关可依）。
        .put(new EfxAttributeRotateAnim(0,
            new EfxRange(30.0F, 0.0F), new EfxRange(20.0F, 0.0F), new EfxRange(30.0F, 0.0F),
            new EfxRange(0.95F, 0.0F), new EfxRange(0.95F, 0.0F), new EfxRange(0.95F, 0.0F), EfxRange.ZERO))
        .build();
}
