package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：网格层的<b>材质色彩滤镜</b>——把该层覆盖到的屏幕像素按"滤镜色 + 亮度"重新着色
 * （本项目两个透镜球的青色滤镜与黑白滤镜），是与折射并列的第二条遮罩通道。
 * <p>
 * 由 {@code GenericMeshParticle#buildFilterQuads} 用与折射完全相同的四边形（同一套透镜空间权重）写进
 * {@code DistortionEffectManager} 的滤镜遮罩（RGB = 滤镜目标色、A = 该像素强度），再由 {@code dis_ware_distortion} 消费。
 * <p>
 * 三项材质参数在 HDR 缓冲上串联工作，本项目无 HDR，故按近似式参数化送进后处理链
 * ——<b>证据等级：LDR 近似，非等价实现</b>。白点取 {@value #HDR_WHITE_POINT}：两条预设的
 * {@code EmissiveIntensity}（2000 与 10）折算后均为 1.0，当前不产生额外压暗；{@code DetoneRate}
 * （0 与 0.001）亦近似恒等，<b>故这两层可见效果实际只来自 {@link #tintColor} 与 {@link #strength}</b>。
 *
 * @param strength          滤镜总强度（0 = 不滤镜）；作为滤镜遮罩 A 通道的乘数
 * @param tintColor         滤镜目标色（常规 ARGB）；{@code 0xFFFFFFFF} 即向灰收敛＝去色
 * @param toneLevel         色阶指数 k（{@code Emit_ToneLevel}；1 = 恒等）
 * @param emissiveIntensity HDR 上限（{@code EmissiveIntensity}；按 {@link #HDR_WHITE_POINT} 折算到 LDR）
 * @param detoneRate        色调插值率（{@code DetoneRate}；0 = 纯滤镜、1 = 纯色调曲线）
 */
public record EfxAttributeColorFilter(
    float strength,
    int tintColor,
    float toneLevel,
    float emissiveIntensity,
    float detoneRate
) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -6;
    
    /**
     * LDR 近似用的 HDR 白点：{@code 開始　青} 覆写的 {@code EmissiveIntensity = 10} 即"可显示白"。
     */
    public static final float HDR_WHITE_POINT = 10.0F;
    
    /**
     * 默认值：强度 0，即完全不滤镜（等价于"该层没有配置本属性"）。
     */
    public static final EfxAttributeColorFilter DEFAULT =
        new EfxAttributeColorFilter(0.0F, 0xFFFFFFFF, 1.0F, 1.0F, 0.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeColorFilter";
    }
    
    /**
     * 该层是否真的参与滤镜遮罩：强度非零即参与。允许配置强度 0 的"关闭态"，故读取侧不能只看属性是否存在。
     */
    public boolean enabled() {
        return this.strength != 0.0F;
    }
    
    /**
     * LDR 自发光上限：{@code clamp(emissiveIntensity / HDR_WHITE_POINT, 0, 1)}；不小于白点时返回 1（即不压暗）。
     */
    public float emissiveClamp() {
        return Math.clamp(this.emissiveIntensity / HDR_WHITE_POINT, 0.0F, 1.0F);
    }
}
