package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：让网格层的表面只在"与场景中其它物体相交处"发光（{@code インバース0} 的相交蓝焰）。
 * <p>
 * 片元算式（照抄模板材质的 Forward 像素着色器）：
 * {@code dist = 场景视距 − 片元视距 − Width_Bottom}（正 = 片元在场景之前），
 * {@code alpha = (1 − saturate(dist / Width_Top))^Volume_Power × saturate(pow(dist, Volume_Power) × 贴图 alpha) × |N·V|^AlphaFade_Power × ColorParam.a}，
 * {@code 颜色 = max(pow(贴图RGB × Base_Intensity, Base_Power), pow(1 − |N·V|, Lim_Power) × Lim_Intensity × LimColor.rgb)}。
 * <p>
 * 三个坑：① 带宽是<b>单侧</b>的（正侧 {@code Width_Top}、负侧 {@code Width_Bottom}），不是对称的深度差容差；
 * ② 火焰贴图<b>只以自身的 alpha 参与</b>，取 RGB 亮度当颜色是用错了通道；③ 朝向项 {@code pow(|N·V|, ·)} 是正对镜头最亮，
 * 与菲涅尔边缘增强方向相反。{@code uvScaleU/V} 不可省：采样前会先算 {@code uv = UV0 × UVscale + 相位}，
 * 缺了它球面自身的 0~1 UV 会把火焰缩到球壳的一小块上，其余采样到透明区被 discard。
 *
 * @param enabled        是否启用相交发光；{@code false} 时该层完全不受影响
 * @param widthTop       片元在场景<b>之前</b>一侧的交线带宽，世界单位（{@code Width_Top}，模板默认 8、EFX 覆写 13）；距离达到该值时带剖面归零
 * @param widthBottom    片元在场景<b>之后</b>一侧的带宽（{@code Width_Bottom}，模板默认 1）；{@code 0} = 只朝可见的一侧展开
 * @param limColor       边缘通道颜色，常规 ARGB（{@code LimColor}，模板默认 {@code 0xFFFFFFFF}）
 * @param volumePower    体积项与带剖面共用的幂次（{@code Volume_Power}，模板默认 3）；越大火焰越"贴住"交线
 * @param alphaFadePower 朝向项的幂次（{@code AlphaFade_Power}，模板默认 2）；{@code 1} 时线性
 * @param baseIntensity  基础通道的亮度增益（{@code Base_Intensity}，模板默认 50）；把贴图整体推亮到过曝
 * @param basePower      基础通道的幂次整形（{@code Base_Power}，模板默认 1）
 * @param limIntensity   边缘通道的亮度增益（{@code Lim_Intensity}，模板默认 0 = 该通道关闭）
 * @param limPower       边缘通道的幂次（{@code Lim_Power}，模板默认 1）；越大蓝边越窄
 * @param uvScaleU       火焰贴图在网格表面的 U 方向平铺次数（{@code UVscale.x}，默认 1）
 * @param uvScaleV       火焰贴图在网格表面的 V 方向平铺次数（{@code UVscale.y}，默认 1）
 * @param uvSpeedU       相位的 U 方向滚动速度（{@code UVSpeed.x}，默认 0；口径为每时间单位的圈数，消费端 ×600 后 round）
 * @param uvSpeedV       相位的 V 方向滚动速度（{@code UVSpeed.y}，默认 0；口径同 {@code uvSpeedU}）
 */
public record EfxAttributeIntersectGlow(
    boolean enabled,
    float widthTop,
    float widthBottom,
    int limColor,
    float volumePower,
    float alphaFadePower,
    float baseIntensity,
    float basePower,
    float limIntensity,
    float limPower,
    float uvScaleU,
    float uvScaleV,
    float uvSpeedU,
    float uvSpeedV
) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -2;
    
    /**
     * 模板默认值：EFX 未覆写时各参数的原始值（映射顺序同 record 声明），UV 不缩放不滚动；
     * {@code enabled = false} ⇒ 未显式挂该属性的层完全不受影响。
     */
    public static final EfxAttributeIntersectGlow DEFAULT =
        new EfxAttributeIntersectGlow(false, 8.0F, 1.0F, 0xFFFFFFFF, 3.0F, 2.0F,
            50.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeIntersectGlow";
    }
}
