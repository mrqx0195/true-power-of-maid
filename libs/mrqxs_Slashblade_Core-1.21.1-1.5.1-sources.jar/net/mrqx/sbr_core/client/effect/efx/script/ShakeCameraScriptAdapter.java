package net.mrqx.sbr_core.client.effect.efx.script;

import net.mrqx.sbr_core.client.effect.camera.CameraShakeController;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributePtBehavior;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxBehaviorValue;

/**
 * 脚本 {@code via.effect.script.EffectShakeCameraCustom}（镜头震动）的执行者。
 * <p>
 * <b>参数映射</b>：时长取生命三段之和（{@link EfxScriptContext#totalLifeTicks()}，EFX 帧 ÷ 3 折 tick）；
 * 幅度取 {@code RotationX / Y / ZRange} 三者的<b>幅度分量 {@code r}</b> 最大值——EFX 的
 * {@code via.Range} 是"基准 {@code s} + 随机幅度 {@code r}"，{@code r} 才是摆动幅度，
 * 三轴取最大者是因为 {@code CameraShakeController} 只实现单轴（滚转）偏移。
 * <p>
 * <b>已知缺口</b>：{@code CameraShakeController.ATTENUATION_START / END} 是常量、不能逐层设置，
 * 故本执行者<b>无法如实还原距离衰减</b>；要还原需把这两个常量改成逐次触发的参数（属既有类的改动，
 * 留待后续决定）。
 * <p>
 * <b>明确不消费的参数</b>（记录而非静默丢弃）：{@code Period}（震动周期：类型编号 20、内容为两个整数；
 * {@code CameraShakeController} 走的是自身的时间衰减曲线、没有周期参数，故两个整数的编码含义无从确证、
 * 不猜其语义）、{@code TranslationX / Y / ZRange}（本项目只偏移相机角度，不做位移）、
 * {@code DistanceAttenuationStart / End}、{@code UseDistanceAttenuation} / {@code UseAngleAttenuation}
 * （开关在衰减本身尚不能逐层设置之前没有意义）。
 */
public final class ShakeCameraScriptAdapter implements EfxScriptAdapter {
    /**
     * 本执行者对应的脚本短名，即派发键。
     */
    public static final String SCRIPT_NAME = "EffectShakeCameraCustom";
    
    /**
     * 三轴旋转幅度都缺失时的兜底幅度（度），同 {@code CameraShakeController} 的默认值。
     */
    public static final float DEFAULT_AMPLITUDE = CameraShakeController.DEFAULT_AMPLITUDE;
    
    @Override
    public String scriptName() {
        return SCRIPT_NAME;
    }
    
    @Override
    public void execute(EfxScriptContext context) {
        EfxAttributePtBehavior behavior = context.behavior();
        float amplitude = Math.max(
            rangeMagnitude(behavior, "RotationXRange"),
            Math.max(rangeMagnitude(behavior, "RotationYRange"), rangeMagnitude(behavior, "RotationZRange")));
        CameraShakeController.trigger(context.position(), context.totalLifeTicks(),
            amplitude > 0.0F ? amplitude : DEFAULT_AMPLITUDE);
    }
    
    /**
     * 取某个"数值区间"参数的幅度分量 {@code r}（区间口径为"基准 {@code s} + 随机幅度 {@code r}"）。
     *
     * @param behaviorProperty 参数名，如 {@code RotationXRange}
     * @return 幅度；参数缺失或类型不符时返回 0
     */
    public static float rangeMagnitude(EfxAttributePtBehavior behavior, String behaviorProperty) {
        EfxBehaviorValue.Float2Value range =
            behavior.value(behaviorProperty, EfxBehaviorValue.Float2Value.class);
        return range != null ? range.y() : 0.0F;
    }
}
