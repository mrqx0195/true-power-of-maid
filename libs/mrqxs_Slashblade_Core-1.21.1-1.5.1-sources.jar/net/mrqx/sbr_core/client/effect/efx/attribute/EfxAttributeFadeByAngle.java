package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import org.joml.Vector3f;

/**
 * 属性 {@code EFXAttributeFadeByAngle}：按**锥角**淡出（对应 json 的 {@code type} = 112）。
 * <p>
 * 它与 {@link EfxAttributeFadeByDepth} 是两条<b>并列且可叠加</b>的淡出属性：后者按到相机的距离
 * 划出"近端 + 远端"两段矩形带，本属性再按"粒子相对参考点的方向与锥轴 {@code coneDirection}
 * 的夹角"乘一层角度权重。原型引擎把两者折算进同一组着色器常量——<b>区间端点来自
 * {@link EfxAttributeFadeByDepth}、角度族（锥内外边界 / 锥轴 / 边界 alpha / 启用权重）来自本属性</b>，
 * 这也是本类必须存在的原因：本项目的面片顶点着色器里早就读到了那组角度常量，
 * 却一直没有对应的数据来源。
 * <p>
 * <b>算式</b>（A 级，逐行来自面片顶点着色器的反汇编）：记 {@code c = dot(coneDirection, 方向)}，
 * <pre>
 *   c &gt;= cone             →  角度系数 = alphaRate
 *   spread &lt;= c &lt; cone    →  角度系数 = lerp(alphaRate, 1, (c − spread) / (cone − spread))
 *   c &lt;  spread           →  角度系数 = 1
 *   最终 = 角度系数 × 权重 + (1 − 权重)
 * </pre>
 * 即"锥内保留 {@code alphaRate}、锥外完全不淡出、锥壳上线性过渡"，最后按一个启用权重与"不淡出"混合。
 * <p>
 * <b>两处仍是 D 级近似</b>（本项目的取证路径读不到——只能靠运行时观测才能定）：
 * <ol>
 *   <li>{@code flags} 到那个"0~1 启用权重"的折算规则未定。本项目取<b>非 0 即权重 = 1、为 0 即整体关闭</b>。
 *       若将来发现它是连续权重，只需改 {@link #coneAlpha(Vector3f)} 的最后一步。</li>
 *   <li>夹角所用的<b>参考点</b>由引擎常量缓冲的一个位在"顶点位置 / 发射器原点"之间二选一，
 *       本项目固定取<b>发射器原点</b>（由调用方传入的方向向量体现）。</li>
 * </ol>
 * 两处都只在 {@code flags != 0} 时才有影响，因此默认值（{@code flags = 0}）下本属性<b>恒不生效</b>——
 * 这也是本项目当前全部预设的实际状态（六份 EFX 导出里没有任何层覆写本属性）。
 *
 * @param flags         启用标志（非 0 即启用角度淡出）
 * @param cone          锥的<b>内</b>边界（方向余弦，越大越靠近锥轴）
 * @param spread        锥的<b>外</b>边界（方向余弦，应小于 {@code cone}）
 * @param alphaRate     锥内保留的 alpha
 * @param coneDirection 锥轴方向（世界空间）；调用方保证其为单位向量
 */
public record EfxAttributeFadeByAngle(
    int flags,
    float cone,
    float spread,
    float alphaRate,
    Vector3f coneDirection
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     * <p>
     * 该值取自参考实现的版本无关枚举，并由同一枚举内四个已验证成员的线性关系校准
     * （{@code ShaderSettings = 104} / {@code Distortion = 106} / {@code PtBehavior = 111} /
     * {@code FadeByDepth = 113}），本成员紧邻 {@code FadeByDepth} 之前。
     */
    public static final int TYPE = 112;
    
    /**
     * 默认值：关闭（{@code flags = 0}），锥轴取 +Z。
     */
    public static final EfxAttributeFadeByAngle DEFAULT =
        new EfxAttributeFadeByAngle(0, 0.0F, 0.0F, 0.0F, new Vector3f(0.0F, 0.0F, 1.0F));
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeFadeByAngle";
    }
    
    /**
     * 角度淡出是否启用（见类注释的第 1 条 D 级近似）。
     */
    public boolean enabled() {
        return this.flags != 0;
    }
    
    /**
     * 锥角淡出的 alpha 系数。
     *
     * @param direction 从参考点指向该粒子的<b>单位</b>方向向量
     * @return {@code 0~1} 的 alpha 系数；未启用时恒为 {@code 1}
     */
    public float coneAlpha(Vector3f direction) {
        if (!this.enabled()) {
            return 1.0F;
        }
        float cosine = this.coneDirection.dot(direction);
        float coefficient;
        if (cosine >= this.cone) {
            coefficient = this.alphaRate;
        } else if (cosine >= this.spread && this.cone > this.spread) {
            float t = (cosine - this.spread) / (this.cone - this.spread);
            coefficient = t * (1.0F - this.alphaRate) + this.alphaRate;
        } else {
            coefficient = 1.0F;
        }
        // 启用权重取 1 ⇒ 最后那步 "系数 × 权重 + (1 − 权重)" 退化为系数本身；
        // 若将来确认 flags 是连续权重，就在这里改成 coefficient * weight + (1 - weight)
        return coefficient;
    }
}
