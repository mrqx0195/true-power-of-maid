package net.mrqx.sbr_core.client.effect.efx;

/**
 * EFX 属性（{@code EFXAttribute*}）在代码中的统一抽象，是"一个类型属性 + 若干修饰属性"模型的根类型。
 * <p>
 * 各属性彼此独立，缺少某个属性时对应逻辑直接跳过、或退回该属性的 {@code DEFAULT}；每类属性一个 record 实现。
 * 取用方式见 {@link EfxConfig}：按 {@code Class} 取属性，取不到即表示该层未配置该项。
 */
public interface EfxAttribute {
    /**
     * 属性类型编号（对应 EFX 数据中的 {@code type} 字段）。
     *
     * @return 属性类型编号；未知编号返回 -1
     */
    int type();
    
    /**
     * 属性名（如 {@code EFXAttributeVelocity3D}）。
     */
    String attributeName();
}
