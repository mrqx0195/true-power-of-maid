package net.mrqx.sbr_core.client.effect.efx;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.polygon.PolygonBlendMode;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import org.joml.Vector3f;

/**
 * 飘带层（{@link EfxTypeRibbonFollow} / {@link EfxTypeGpuRibbonFollow}）配置的<b>只读派生视图</b>，与 {@link EfxPolygonView}
 * 并列：把飘带摊平成"一条由若干段组成的带子"所需字段。与面片的根本差别是<b>几何随时间生长</b>，故给出的是速度而非姿态。
 */
public final class EfxRibbonView {
    /**
     * 1 tick 对应的 EFX 帧数。
     */
    public static final int TICK_TO_FRAME = 3;
    
    /**
     * 分段数的兜底值：两种飘带类型的"分段"字段在现有数据里都没给出有效值——{@link EfxTypeRibbonFollow}
     * 的 {@code ShapeDivision} / {@code SplineDivision} 均为 0，{@link EfxTypeGpuRibbonFollow} 的
     * {@code SegmentNum} 也为 0（此前一直退回 {@code UknDmc5}）。取 8 是与后者一致的推断（D 级）；
     * 实机若条带过于棱角分明或过于平滑，改这一处即可。
     */
    public static final int DEFAULT_SEGMENT_COUNT = 8;
    
    /**
     * 飘带使用的贴图（{@link EfxAttributeUVSequence#resource()}）；缺失时回退到面片层的兜底贴图。
     */
    public final ResourceLocation texture;
    
    /**
     * 序列帧总数（1 表示单帧）。
     */
    public final int frameCount;
    
    /**
     * 序列帧播放速度（序列帧 / tick）。
     */
    public final float framePlaySpeed;
    
    /**
     * 飘带分段数（轨迹保留点数减一）：{@link EfxTypeRibbonFollow} 取 {@code ShapeDivision} / {@code SplineDivision}
     * 中较大的一个，{@link EfxTypeGpuRibbonFollow} 取 {@code SegmentNum}（为 0 时退回 {@code UknDmc5}）；
     * 两者都没给出有效分段数时落 {@link #DEFAULT_SEGMENT_COUNT}。
     */
    public final int segmentCount;
    
    /**
     * 飘带<b>头端</b>（最新采样点、运动前方）的带宽（格）。
     * <p>
     * {@code SizeScalar} 的区间两端在这里被解读为带宽<b>沿带长的剖面</b>：{@code s + r} 是头端、{@code s} 是尾端。
     * 依据是实机观感——{@code GPU フォロー0}（{@code s = 0.2, r = 1}）的带子头端明显更粗，而
     * {@code 範囲　GPU}（{@code s = 2, r = 0.4}）两端宽度相差不大，与旧实测"宽度始终不变"也不矛盾。
     * 这是推断（D 级）；推翻它需要给出带宽演化的真实来源。
     * <p>
     * {@code ScaleAnim} 的 {@code SizeScalarAdd} 在本层为负（{@code -0.07}），与"头端更粗"方向相反，
     * 故<b>不</b>参与带宽——它是否在本类型上另有语义尚无证据。
     */
    public final float widthHead;
    
    /**
     * 飘带<b>尾端</b>（最旧采样点、发射处）的带宽（格），见 {@link #widthHead}。
     */
    public final float widthTail;
    
    /**
     * 主体颜色（ARGB）：实测该层不受 {@code Color} 影响、总是纯黑，故<b>只有 alpha 被消费</b>，RGB 一律输出黑色。
     */
    public final int color;
    
    /**
     * 配色抖动范围（ARGB）：RGB 恒为黑，实际只在 {@link #color} 与它的 alpha 之间给每条飘带抽一个透明度。
     */
    public final int colorRange;
    
    /**
     * 混合模式，固定为普通 alpha。<b>不能走 {@link EfxPolygonView#blendMode(int)}</b>：那是面片的位掩码语义，
     * 会把本层 {@code BlendFlags = 3} 判成加算，而飘带是纯黑的——纯黑在加算下等于什么都不画。
     * 参考表现里飘带把背景<b>压暗</b>，语义即 {@code 结果 = 背景 × (1 − alpha)}。
     */
    public final PolygonBlendMode blendMode;
    
    /**
     * <b>径向</b>速度（格 / tick）：负值向内收缩、正值向外发散、0 表示不径向移动。实测 {@code Velocity3D} 的
     * {@code Speed} / {@code Speed Coef} <b>只影响向内收缩</b>，设为 0 时飘带沿水平边界逆时针流动；切向分量见
     * {@link #spinRadiansPerTick}。故<b>不能</b>把它当成整体向量、每 tick 连同方向一起旋转。
     */
    public final float speedPerTick;
    
    /**
     * 径向速度的随机幅度（格 / tick）。
     */
    public final float speedRandomPerTick;
    
    /**
     * 径向速度的每 tick 衰减系数（{@code SpeedCoef}，逐帧量，已按 1 tick = 3 帧折算；本层原值 1 不衰减）。
     * 该字段的语义按其在其它 EFX 属性里的一贯含义"速度自身的逐帧衰减率"实现；若实测不是，改这一处即可。
     */
    public final float speedDecayPerTick;
    
    /**
     * 每 tick 的重力加速度（格 / tick²），换算口径见 {@link #SPEED_SCALE}。
     */
    public final float gravityPerTick;
    
    /**
     * 是否径向模式（{@code VelocityType = 2}）：从发射原点沿径向往外，配合负速度即"向心收束"。
     */
    public final boolean radial;
    
    /**
     * 主方向（径向模式下不使用）。
     */
    public final Vector3f direction;
    
    /**
     * 螺旋角速度（弧度 / tick）：{@link EfxAttributeTransform3DModifier#spinRadiansPerTick()}——本层原值 1°/帧 已折成 3°/tick；0 表示不螺旋。
     */
    public final double spinRadiansPerTick;
    
    /**
     * 螺旋角速度的每 tick 复利系数（{@link EfxAttributeTransform3DModifier#spinAcceleration()}）：大于 1 越来越快、小于 1 越来越慢，1 为匀速。
     */
    public final float spinAcceleration;
    
    /**
     * 同时存在的飘带条数（{@link EfxAttributeSpawn#spawnNumX()}）：{@code MaxParticles} 恒为 1，照抄只会得到一条。
     */
    public final int spawnCount;
    
    /**
     * 发射范围的椭球半轴（格）：各轴取区间期望 {@code s + r / 2}。
     * <p>
     * <b>不沿用面片视图的"外缘 {@code s + r}"</b>（面片按上界取值是为了贴合"水平效果范围 = 半径 10 格"的标定基线，
     * 见 {@link EfxPolygonView#rangeXYZ}）：飘带取上界会把 {@code s = 2.8, r = 3} 读成 5.8 格而不是 4.3 格，
     * 实测表现为"起点位置偏外"。飘带的发射半径只决定"它出现在哪一圈上"，取区间中点与观感一致。
     */
    public final Vector3f rangeXYZ;
    
    /**
     * 发射圆盘的<b>外半径</b>（格），即 {@link #rangeXYZ} 的 {@code x}。发射点取在<b>边界</b>而非铺满圆盘：
     * 实测飘带在水平效果范围边界持续出现。
     */
    public final float outerRadius;
    
    /**
     * 发射中心相对演出原点的局部偏移（格）。
     */
    public final Vector3f localOffset;
    
    /**
     * 渐入段（tick）。
     */
    public final int appearTicks;
    
    /**
     * 渐出段（tick）。
     */
    public final int vanishTicks;
    
    /**
     * 保持段（tick）：{@code KeepFrame} 与 {@code KeepHoldFrame} 各取中值相加再 ÷3；该层原值为 0，但其 {@code Life.Flags} 第 0 位为 1（实测"生成后一直 Keep 至效果结束"），故补足到演出收尾。
     */
    public final int keepTicks;
    
    /**
     * 发射器形状：0 = 盒/点，1 = 球（三轴不等时呈椭球），2 = 圆柱（水平圆盘）；该层为 2，故发射点落在水平圆盘上。
     */
    public final int shapeType;
    
    /**
     * 总时长（tick）：渐入 + 保持 + 渐出。
     */
    public final int totalTicks;
    
    /**
     * 序列帧图集的列数，固定为素材约定 {@link EfxPolygonView#FRAME_COLUMNS}（8 列）。<b>不能</b>按
     * {@code round(sqrt(frameCount))} 反推：素材本身是 8 列 8 行图集，反推得到 5 列会使 UV 窗口整体错位。
     */
    public final int frameColumns;
    
    /**
     * 序列帧图集的行数，由<b>素材实际帧数</b>除以 {@link #frameColumns} 得到；{@code PatternNo} 只决定播到第几帧回绕，不参与切图。
     */
    public final int frameRows;
    
    /**
     * 本层的长度口径系数：由本场演出的效果范围倍率与逐层的 {@link EfxAttributeCharacterSpace} 共同决定
     * （后者声明"按角色尺寸标定"时取 {@code 1.0}）；带宽、发射范围与速度都乘它。
     */
    public final float sizeScale;
    
    /**
     * 逐项解析配置，构造只读视图（类型属性应为 {@link EfxTypeRibbonFollow} 或 {@link EfxTypeGpuRibbonFollow}）。
     */
    public EfxRibbonView(EfxConfig config) {
        this(config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 逐项解析配置，构造只读视图，并指定本场演出的收尾时刻。{@code sustainedKeepTicks} 为
     * {@link EfxTimeline#USE_DEFAULT_SUSTAINED_KEEP} 时回退到 {@link EfxTimeline#SUSTAINED_KEEP_TICKS}。
     */
    public EfxRibbonView(EfxConfig config, int sustainedKeepTicks) {
        this(config, sustainedKeepTicks, EfxPolygonView.SIZE_SCALE);
    }
    
    /**
     * 逐项解析配置，构造只读视图，并指定本场演出的收尾时刻与<b>效果范围倍率</b>。
     * <p>
     * 该倍率只作用于"按效果范围标定"的层；逐层的 {@link EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}。
     */
    public EfxRibbonView(EfxConfig config, int sustainedKeepTicks, float effectRangeScale) {
        float sustainedKeep = sustainedKeepTicks >= 0
            ? sustainedKeepTicks
            : EfxTimeline.SUSTAINED_KEEP_TICKS;
        this.sizeScale = config
            .getOrDefault(EfxAttributeCharacterSpace.class, EfxAttributeCharacterSpace.DEFAULT)
            .characterSized() ? 1.0F : effectRangeScale;
        // 速度换算：EFX 的 Speed / GravityRate 单位是"格 / 秒"，故每 tick 位移取其 1/20；换算只跟效果范围倍率走，
        // 不再叠面片路径的 VELOCITY_SCALE（那会让飘带慢一个数量级，实测"条带过短、运动过慢"）
        float speedScale = this.sizeScale / 20.0F;
        EfxTypeRibbonFollow follow = config.get(EfxTypeRibbonFollow.class);
        EfxTypeGpuRibbonFollow gpuRibbon =
            config.getOrDefault(EfxTypeGpuRibbonFollow.class, EfxTypeGpuRibbonFollow.DEFAULT);
        // 两种类型只共享"带宽 / 颜色 / 分段"这几项语义，其余字段各自承载
        EfxRange ribbonSize = follow != null ? follow.sizeScalar() : gpuRibbon.sizeScalar();
        int ribbonColor = follow != null ? follow.color() : gpuRibbon.color();
        int ribbonColorRange = follow != null ? follow.colorRange() : gpuRibbon.colorRange();
        int declaredSegments = follow != null
            ? Math.max(follow.shapeDivision(), follow.splineDivision())
            : (gpuRibbon.segmentNum() > 0 ? gpuRibbon.segmentNum() : gpuRibbon.unknDmc5());
        EfxAttributeUVSequence uv = config.getOrDefault(EfxAttributeUVSequence.class, EfxAttributeUVSequence.DEFAULT);
        EfxAttributeSpawn spawn = config.getOrDefault(EfxAttributeSpawn.class, EfxAttributeSpawn.DEFAULT);
        EfxAttributeLife life = config.getOrDefault(EfxAttributeLife.class, EfxAttributeLife.DEFAULT);
        EfxAttributeVelocity3D velocity =
            config.getOrDefault(EfxAttributeVelocity3D.class, EfxAttributeVelocity3D.DEFAULT);
        EfxAttributeEmitterShape3D shape =
            config.getOrDefault(EfxAttributeEmitterShape3D.class, EfxAttributeEmitterShape3D.DEFAULT);
        EfxAttributeTransform3D transform =
            config.getOrDefault(EfxAttributeTransform3D.class, EfxAttributeTransform3D.DEFAULT);
        EfxAttributeTransform3DModifier modifier =
            config.getOrDefault(EfxAttributeTransform3DModifier.class, EfxAttributeTransform3DModifier.DEFAULT);
        
        this.texture = uv.resource() != null ? uv.resource() : EfxPolygonView.FALLBACK_TEXTURE;
        this.frameCount = Math.max(1, uv.frameCount());
        this.framePlaySpeed = uv.playSpeed().s() * TICK_TO_FRAME;
        
        // 分段数：SegmentNum 为 0 时退回 UknDmc5
        this.segmentCount = Math.max(2, declaredSegments > 0 ? declaredSegments : DEFAULT_SEGMENT_COUNT);
        // 带宽同样乘以本场演出的效果范围倍率；区间两端分别是头端与尾端的带宽
        this.widthHead = (ribbonSize.s() + ribbonSize.r()) * this.sizeScale;
        this.widthTail = ribbonSize.s() * this.sizeScale;
        this.color = ribbonColor;
        this.colorRange = ribbonColorRange;
        // 混合模式直接指定普通 alpha（理由见 blendMode）：不再消费 ColorRate / Intensity——它们此前只用来给"加算下的纯黑"强行提亮，改回普通 alpha 后已无观测到的效果
        this.blendMode = PolygonBlendMode.TRANSLUCENT;
        
        this.speedPerTick = velocity.speed().s() * speedScale;
        this.speedRandomPerTick = velocity.speed().r() * speedScale;
        this.speedDecayPerTick = EfxPolygonView.perTickCoefficient(velocity.speedCoef().s());
        this.gravityPerTick = velocity.gravityRate().s() * speedScale;
        this.radial = velocity.velocityType() == 2;
        this.direction = new Vector3f(velocity.direction());
        this.spinRadiansPerTick = modifier.spinRadiansPerTick();
        this.spinAcceleration = Math.max(0.0F, modifier.spinAcceleration());
        
        this.spawnCount = Math.max(1, spawn.spawnNumX());
        this.shapeType = shape.shapeType();
        this.rangeXYZ = new Vector3f(
            EfxPolygonView.rangeMean(shape.rangeX()) * this.sizeScale,
            EfxPolygonView.rangeMean(shape.rangeY()) * this.sizeScale,
            EfxPolygonView.rangeMean(shape.rangeZ()) * this.sizeScale);
        this.outerRadius = this.rangeXYZ.x;
        this.localOffset = new Vector3f(transform.localPosition());
        
        this.appearTicks = Math.max(0, Math.round(EfxPolygonView.rangeMean(life.appearFrame()) / TICK_TO_FRAME));
        this.vanishTicks = Math.max(0, Math.round(EfxPolygonView.rangeMean(life.vanishFrame()) / TICK_TO_FRAME));
        int keep = Math.max(0, Math.round(
            (EfxPolygonView.rangeMean(life.keepFrame()) + EfxPolygonView.rangeMean(life.keepHoldFrame()))
                / TICK_TO_FRAME));
        if ((life.flags() & EfxPolygonView.SUSTAINED_FLAG_BIT) != 0) {
            keep = Math.max(keep, Math.max(0, Math.round(sustainedKeep) - this.appearTicks));
        }
        this.keepTicks = keep;
        this.totalTicks = Math.max(1, this.appearTicks + this.keepTicks + this.vanishTicks);
        // 图集布局：列数固定为素材约定（8 列），行数由素材实际帧数推出（frameCount 只决定回绕、不参与切图）
        this.frameColumns = EfxPolygonView.FRAME_COLUMNS;
        int atlasFrames = Math.max(this.frameColumns, uv.atlasFrameCount());
        this.frameRows = Math.max(1, atlasFrames / this.frameColumns);
    }
}
