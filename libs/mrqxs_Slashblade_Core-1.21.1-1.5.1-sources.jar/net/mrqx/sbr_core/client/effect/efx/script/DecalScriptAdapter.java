package net.mrqx.sbr_core.client.effect.efx.script;

import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributePtBehavior;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range.EfxJceRangePolygonPresets;
import net.mrqx.sbr_core.client.effect.polygon.PolygonEmitterManager;

/**
 * 脚本 {@code via.effect.script.EffectDecal}（地面贴花）的执行者：贴花在本项目里是躺在地面上的面片，
 * 故交给 {@link PolygonEmitterManager} 而不是后处理，与径向模糊 / LUT 那两类执行者不同。
 * <p>
 * 面片配置由 {@link EfxJceRangePolygonPresets#groundDecal(EfxAttributePtBehavior)} 按本层的脚本参数现算——
 * 那九项（{@code DecalPrefab} / {@code DecalDirection} / {@code DecalUpDirection} / {@code RandomRollRange} /
 * {@code Extent} / {@code ScaleXY} / {@code SearchTerrainDistance} / {@code BaseColorMod} / {@code EmissiveMod}）
 * 里<b>已接线的几项、以及仍未消费的几项，都连推断等级一起记在那个方法的 Javadoc 里</b>。本执行者只做一件事：
 * 把"层的位置"与"层的参数表"交给它，数据因此只有一个出处，改参数不需要改两处。
 * <p>
 * EFX 层的 {@code LocalPosition} 就是<b>世界位置</b>（命中点上方若干格），贴花落点只以
 * {@link EfxScriptContext#position()} 为唯一依据：面片配置里写的是零偏移，落点不会与层的位置叠加。
 */
public final class DecalScriptAdapter implements EfxScriptAdapter {
    /**
     * 本执行者对应的脚本短名，即派发键。
     */
    public static final String SCRIPT_NAME = "EffectDecal";
    
    @Override
    public String scriptName() {
        return SCRIPT_NAME;
    }
    
    @Override
    public void execute(EfxScriptContext context) {
        PolygonEmitterManager.spawn(context.level(), context.position(),
            EfxJceRangePolygonPresets.groundDecal(context.behavior()));
    }
    
    /**
     * 该层是否挂着本执行者能处理的脚本参数（用于诊断：贴花层必然带 {@code DecalPrefab}）。
     */
    public static boolean hasDecalPrefab(EfxAttributePtBehavior behavior) {
        return behavior.stringValue("DecalPrefab") != null;
    }
}
