package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 材质关键帧动画属性（{@code EFXAttributeTypeMeshClip}，{@code type = 26}）：按时间曲线驱动网格材质的若干参数。
 * <p>
 * 只承载关键帧曲线本身（时长 + 关键帧序列），不保留材质属性哈希与切线——插值一律按线性处理，
 * 切线仅影响缓动手感。轨道语义由材质属性名的 UTF-8 原文经 Murmur3_x86_32 反查确定。
 *
 * @param tracks 材质参数轨道，顺序与材质的 {@code properties} 数组一致
 */
public record EfxAttributeMeshClip(List<Track> tracks) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 26;
    
    /**
     * 默认值：没有任何轨道（等价于"不配置该属性"）。
     */
    public static final EfxAttributeMeshClip DEFAULT = new EfxAttributeMeshClip(List.of());
    
    /**
     * {@code EmissiveRate}（自发光强度）所在轨道：护盾 {@code 10 → 0}，即"扩大到最大时熄灭"。
     */
    public static final int EMISSIVE_RATE_TRACK_INDEX = 0;
    
    /**
     * {@code Red_Offset} 所在轨道：驱动 {@code FlowMap} 红通道 UV 偏移，是真正的波纹行进，增减方向决定波纹朝哪边走。
     */
    public static final int RED_OFFSET_TRACK_INDEX = 1;
    
    /**
     * {@code Green_Offset} 所在轨道：驱动 {@code FlowMap} 绿通道 UV 偏移，与 {@link #RED_OFFSET_TRACK_INDEX} 成对异速，避免波纹单层平推。
     */
    public static final int GREEN_OFFSET_TRACK_INDEX = 2;
    
    /**
     * {@code Morf_MaskScroll} 所在轨道：形变遮罩的滚动量。
     */
    public static final int MORF_MASK_SCROLL_TRACK_INDEX = 3;
    
    /**
     * 防御性拷贝：视图与预设可能长期持有该 record，避免外部改动影响已构造的配置。
     */
    public EfxAttributeMeshClip {
        tracks = List.copyOf(tracks);
    }
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeMeshClip";
    }
    
    /**
     * 取 {@link #EMISSIVE_RATE_TRACK_INDEX} 上的首条轨道。
     *
     * @return 首条轨道；没有任何轨道时返回 {@code null}
     */
    @Nullable
    public Track primary() {
        return this.at(EMISSIVE_RATE_TRACK_INDEX);
    }
    
    /**
     * 按索引取某一条轨道；各轨道语义已反查清楚，读取侧应按参数语义取用，而非笼统取第一条
     * （例如纹波要用 {@link #RED_OFFSET_TRACK_INDEX} 的 {@code Red_Offset} 曲线）。
     *
     * @return 该轨道；下标越界时返回 {@code null}
     */
    @Nullable
    public Track at(int index) {
        return index >= 0 && index < this.tracks.size() ? this.tracks.get(index) : null;
    }
    
    /**
     * 一条材质参数的时间曲线。
     *
     * @param duration  曲线总时长（帧）
     * @param keyframes 关键帧序列（按 {@code frameTime} 递增）
     */
    public record Track(float duration, List<Keyframe> keyframes) {
        /**
         * 防御性拷贝。
         */
        public Track {
            keyframes = List.copyOf(keyframes);
        }
        
        /**
         * 按帧号取曲线值：关键帧之间线性插值，超出两端则取端点值；无关键帧时返回 0。
         */
        public float valueAt(float frame) {
            if (this.keyframes.isEmpty()) {
                return 0.0F;
            }
            Keyframe first = this.keyframes.getFirst();
            if (frame <= first.frameTime()) {
                return first.value();
            }
            for (int i = 1; i < this.keyframes.size(); i++) {
                Keyframe previous = this.keyframes.get(i - 1);
                Keyframe current = this.keyframes.get(i);
                if (frame <= current.frameTime()) {
                    float span = current.frameTime() - previous.frameTime();
                    if (span <= 0.0F) {
                        return current.value();
                    }
                    float ratio = (frame - previous.frameTime()) / span;
                    return previous.value() + (current.value() - previous.value()) * ratio;
                }
            }
            return this.keyframes.getLast().value();
        }
        
        /**
         * 曲线从起始值走到结束值的进度（0~1），用于把取值范围各异的材质轨道统一成"溶解程度"；
         * 首尾值相同时恒为 0。
         */
        public float progressAt(float frame) {
            if (this.keyframes.isEmpty()) {
                return 0.0F;
            }
            float start = this.keyframes.getFirst().value();
            float end = this.keyframes.getLast().value();
            if (start == end) {
                return 0.0F;
            }
            float progress = (valueAt(frame) - start) / (end - start);
            return Math.clamp(progress, 0.0F, 1.0F);
        }
    }
    
    /**
     * 一个关键帧。
     */
    public record Keyframe(float frameTime, float value) {
    }
}
