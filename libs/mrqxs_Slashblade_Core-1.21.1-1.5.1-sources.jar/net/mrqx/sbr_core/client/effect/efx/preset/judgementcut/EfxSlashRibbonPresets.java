package net.mrqx.sbr_core.client.effect.efx.preset.judgementcut;

import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

/**
 * 次元斩（小技能）三套演出的<b>飘带类</b>层预设（{@code TypeRibbonFollow}）。
 * <p>
 * 带宽沿带长渐变由 {@code SizeScalar} 的区间两端给出（头端 {@code s + r}、尾端 {@code s}），
 * 其余分段参数在本组数据里全是中性默认值，只承载不消费。
 */
public final class EfxSlashRibbonPresets {
    /**
     * {@code GPU フォロー0}：半径 3 ± 3.3 格的球面边界上持续生成、逆时针螺旋向中心收拢的烟雾条带。
     * <p>
     * <b>本层有意改用非 GPU 版的带状类型</b>：该层在参考数据里是 GPU 版带状类型，而本预设用
     * {@link EfxTypeRibbonFollow} 承载——两套字段集不同，因此本层<b>无法与参考数据逐字段比对</b>。
     * 不换成 GPU 版的理由：GPU 版那一套（52 字节）的字段取值尚未取证，贸然替换会让本层已验收的观感
     * 失去依据；而决定观感的量（带宽区间 / 分段 / 配色 / 拉伸）在两套里是同一组语义，
     * 参照抄写的效果等价。
     */
    public static final EfxConfig BOSS_FOLLOW0 = EfxConfigBuilder.create(
            new EfxTypeRibbonFollow(
                1152, 0x4C0005FF, 0x730A06FF, 1.0F, 0.0F, 0.0F, 2.5F, 0,
                new EfxRange(0.2F, 1.0F), new EfxRange(0.0F, 1.0F), 0.0F, 1.0F, 0.0F, 6.0F, 0,
                1, 0, 0, 0, 0, 0, 0,
                0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0.5F, 1.0F,
                1.0F, 1.0F, 1.0F, 0.5F, 1.0F,
                0.0F, 0.0F, EfxRange.ZERO))
        .put(new EfxAttributeSpawn(30, 0, 3, 3, 0, 0, 10, false, 13, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3DModifier(2, 0.08726647F, 0.98F))
        .put(new EfxAttributeLife(new EfxRange(18.0F, 18.0F), EfxRange.ZERO,
            new EfxRange(22.0F, 18.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(-20.0F, 2.0F), new EfxRange(0.925F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 2,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.07F, 0.01F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(19.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 10, EfxSlashPolygonPresets.texture("fire_explosive"), 64))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(3.0F, 3.3F), new EfxRange(3.0F, 3.3F), new EfxRange(3.0F, 3.3F),
            1, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(1.5F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(5.5F, 7.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * {@code 余韻_ribon}（完美 / 普通共用）：半径 2.8 ± 3 格的球面边界上生成、向中心收拢的烟雾条带。
     * <p>
     * 带宽区间是 {@code 0.5 ± 0.5}，头尾相差一倍，比 BOSS 变体那层温和得多。
     */
    public static final EfxConfig PERFECT_REMAIN_RIBBON = EfxConfigBuilder.create(
            new EfxTypeRibbonFollow(
                1024, 0xA0032260, 0x730A06FF, 1.0F, 0.0F, 0.0F, 2.5F, 0,
                new EfxRange(0.5F, 0.5F), new EfxRange(0.1F, 1.0F), 0.0F, 1.0F, 0.0F, 5.0F, 0,
                20, 1, 0, 0, 0, 0, 0,
                0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0.5F, 1.0F,
                1.0F, 1.0F, 1.0F, 0.5F, 1.0F,
                0.0F, 0.0F, EfxRange.ZERO))
        .put(new EfxAttributeSpawn(10, 0, 2, 2, 0, 0, 5, false, 20, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3DModifier(18, 0.17453294F, 0.98F))
        .put(new EfxAttributeLife(new EfxRange(10.0F, 10.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(-20.0F, 2.0F), new EfxRange(0.95F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 2,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.07F, 0.01F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(19.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 10, EfxSlashPolygonPresets.texture("fire_explosive"), 64))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(2.8F, 3.0F), new EfxRange(2.8F, 3.0F), new EfxRange(2.8F, 3.0F),
            1, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(1.5F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(7.0F, 10.0F, 100.0F, 120.0F))
        .build();
    
    /** 普通变体：与完美变体同源，只是每批只投一条、洛普次数更少。 */
    public static final EfxConfig NORMAL_REMAIN_RIBBON = EfxConfigBuilder.create(
            new EfxTypeRibbonFollow(
                1024, 0xA0032260, 0x730A06FF, 1.0F, 0.0F, 0.0F, 2.5F, 0,
                new EfxRange(0.5F, 0.5F), new EfxRange(0.1F, 1.0F), 0.0F, 1.0F, 0.0F, 5.0F, 0,
                20, 1, 0, 0, 0, 0, 0,
                0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0.5F, 1.0F,
                1.0F, 1.0F, 1.0F, 0.5F, 1.0F,
                0.0F, 0.0F, EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 0, 4, false, 20, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3DModifier(18, 0.17453294F, 0.98F))
        .put(new EfxAttributeLife(new EfxRange(10.0F, 10.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(-20.0F, 2.0F), new EfxRange(0.95F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 2,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.07F, 0.01F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(19.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 10, EfxSlashPolygonPresets.texture("fire_explosive"), 64))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(2.8F, 3.0F), new EfxRange(2.8F, 3.0F), new EfxRange(2.8F, 3.0F),
            1, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(1.5F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(7.0F, 10.0F, 100.0F, 120.0F))
        .build();
    
    private EfxSlashRibbonPresets() {
    }
}
