package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * 属性 {@code EFXAttributeShaderSettings}：材质级着色参数（对应 json 的 {@code type} = 104）。
 * <p>
 * 常用字段是饱和度与"负/正层级"（{@code layerNegative} / {@code layerPositive}），
 * 以及整体亮度与颜色偏移。缺少该属性即"按中性参数着色"。
 * <p>
 * EFX 有数十个字段（大量 {@code unkn*} 与按版本开关的 {@code toggle_*}），本项目只取其中五个与渲染
 * 有关的：饱和度、负/正层级、颜色偏移、整体亮度；其余未建模。
 * <p>
 * <b>这五个字段目前都不参与渲染，而且"不参与"是有证据的</b>：已抓到的着色器里<b>没有一支读它们</b>
 * ——粒子族的两支 PS 与延迟 GBuffer 的那支材质 PS，其常量缓冲字段表里都没有
 * {@code Saturation} / {@code LayerPositive} / {@code LayerNegative} / {@code color0}。
 * 再结合字段形态：{@code layerPositive} 在数据里恒为 {@code 4}（43/51，像卡通着色的"正向明暗层数"）、
 * {@code colorBrightness} 恒为 {@code 1}（50/51）、{@code saturation} 是以 {@code 1} 为恒等、
 * {@code 0} 为"全灰"的一族取值——整组更像是<b>材质 / 卡通着色参数</b>，而不是"逐面片的颜色调节"。
 * ⇒ 把它当"饱和度倍率"乘进精灵色会把蓝焰洗成灰白（数据里 {@code 範囲　収束　炎1/2} 的
 * {@code saturation} 正是 {@code 0.05}，即"照数据做就应该是灰的"），那条路本身就不成立。
 * 注意 {@code layerPositive} 的 {@code DEFAULT} 取 1（中性），而数据里该值多为 4——同样只作对照记录。
 *
 * @param saturation      饱和度倍率（以 1 为恒等：数据里 {@code 1}×14、{@code 0}×8、小于 1 共 27 处、大于 1 共 10 处）
 * @param layerNegative   负层级偏移（{@code LayerNegative}）
 * @param layerPositive   正层级偏移（{@code LayerPositive}；数据里 {@code 4}×43）
 * @param color0          颜色偏移（ARGB）
 * @param colorBrightness 整体亮度
 */
public record EfxAttributeShaderSettings(
    float saturation,
    float layerNegative,
    float layerPositive,
    int color0,
    float colorBrightness
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 104;
    
    /**
     * 默认值：中性着色。
     */
    public static final EfxAttributeShaderSettings DEFAULT = new EfxAttributeShaderSettings(
        1.0F, 0.0F, 1.0F, 0xFF000000, 1.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeShaderSettings";
    }
}
