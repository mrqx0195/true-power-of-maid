package net.mrqx.sbr_core.client.effect.efx;

/**
 * EFX 中大量出现的 {@code {"s": …, "r": …}} 数值对。
 * <p>
 * <b>语义</b>：{@code s} 是起始值（区间下限），{@code r} 是叠加在其上的随机幅度（区间宽度），
 * 即实际取值落在 {@code [s, s + r]}，期望值为 {@code s + r / 2}——不是"中心 ± 半幅"。
 * <p>
 * 整数版本 {@code RangeI} 的字段顺序是 {@code r} 在前、{@code s} 在后；
 * 本项目中生命四段与 {@code BounceNum} 等 {@code RangeI} 字段一律用本类型承载。
 *
 * @param s 起始值（区间下限）
 * @param r 随机幅度（区间宽度）
 */
public record EfxRange(float s, float r) {
    /**
     * 零值（基准 0、随机 0）。
     */
    public static final EfxRange ZERO = new EfxRange(0.0F, 0.0F);
    
    /**
     * 在 {@code [s, s + r]} 上取值（{@code r} 为负时自动交换端点）。
     *
     * @param random 0~1 的随机数
     * @return 采样值
     */
    public float sample(float random) {
        float min = Math.min(this.s, this.s + this.r);
        float max = Math.max(this.s, this.s + this.r);
        return min + (max - min) * random;
    }
    
    /**
     * 以 {@code s} 为中心、{@code ±r} 为半径取值（供"基准值 ± 浮动"的调用方使用）。
     * <p>
     * 公式为 {@code s + random × 2r}：{@code r} 在这里被当作<b>半幅</b>使用——与 {@link #sample(float)}
     * 把 {@code r} 当作区间宽度的口径不同，调用方需自行确认取哪一种。
     *
     * @param random -0.5~0.5 的随机数
     * @return 采样值
     */
    public float sampleCentered(float random) {
        return this.s + random * 2.0F * this.r;
    }
}
