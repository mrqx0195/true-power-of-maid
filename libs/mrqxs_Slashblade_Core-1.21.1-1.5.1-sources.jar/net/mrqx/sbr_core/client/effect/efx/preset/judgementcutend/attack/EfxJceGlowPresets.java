package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack;

import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.post.GlowSpec;
import org.joml.Vector3f;

/**
 * 「次元斩·絶」全屏辉光层的 EFX 预设：数据里皆为 {@code EFXAttributeTypeBillboard3D} 面片，本项目改为屏幕空间辉光，
 * 由 {@code GlowEfxManager} 按类型属性派发；尺寸与增益的标定理由见 {@link EfxAttributeGlowRender}。
 */
public final class EfxJceGlowPresets {
    /**
     * {@code 減算0}：斩击瞬间压暗画面，制造"光被抽走"的沉重感；屏幕空间按比例压暗而非线性相减，免得暗部死黑。
     * <p>
     * 增益取绝对值 0.9，<b>不要</b>再乘 {@code STRENGTH_SCALE}：压暗层取绝对强度，乘上该系数会让本层单独启用时不可见。
     */
    public static final EfxConfig GLOW_SUBTRACT = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(4, 0xFF0E1634, 0xFFFFFFFF, 1.0F, 0.9F, 0.0F, 0.0F,
                new EfxRange(0.0F, 40.0F), new EfxRange(0.0F, 1.5F),
                new EfxRange(0.0F, 1.0F), new EfxRange(0.0F, 1.0F),
                0, 0, false, false, false, new EfxRange(0.0F, 0.075F)))
        .put(spawn(0, 1, 0, 1))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(25.0F, 25.0F),
            new EfxRange(100.0F, 100.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeGlowRender(60, 0.9F, GlowSpec.MODE_DARKEN, 0.5F, 0.0F))
        .build();
    
    /**
     * {@code ブラー}：与镜头震动同步的过曝闪光（三连发），场景模糊 3 像素。
     */
    public static final EfxConfig BLUR_FLASH = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(2, 0x6600030D, 0xFFFFFFFF, 5.0F, 2.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 20.0F), new EfxRange(10.0F, 1.0F),
                new EfxRange(0.0F, 1.0F), new EfxRange(0.0F, 0.0F),
                0, 0, false, false, false, EfxRange.ZERO))
        .put(spawn(0, 2, 6, 3))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(2.0F, 1.0F),
            new EfxRange(1.0F, 1.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeGlowRender(1.25F, 1.0F, GlowSpec.MODE_SCREEN, 0.75F, 3.0F))
        .build();
    
    /**
     * {@code Back_ADD1}：斩击瞬间铺开的蓝色背景辉光（三连发），增益沿用已验收的标定值。
     */
    public static final EfxConfig BACK_ADD_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(2, 0x660038FF, 0xFFFFFFFF, 60.0F, 0.5F, 0.0F, 0.0F,
                new EfxRange(0.0F, 25.0F), new EfxRange(0.0F, 1.5F),
                new EfxRange(0.0F, 1.0F), new EfxRange(0.0F, 0.0F),
                0, 0, false, false, false, new EfxRange(0.0F, 0.125F)))
        .put(spawn(10, 2, 8, 3))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeGlowRender(20.0F, 0.3F, GlowSpec.MODE_ADD, 0.85F, 0.0F))
        .build();
    
    /**
     * {@code 体 Add グロー}：范围技起手时从腰部炸开的过曝蓝光；屏幕空间用滤色叠加即得"中心曝白、边缘留蓝"。
     */
    public static final EfxConfig BODY_ADD_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(2, 0xFF0044FF, 0xFFFFFFFF, 800.0F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 6.0F), new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F), new EfxRange(0.0F, 0.0F),
                0, 0, false, false, false, EfxRange.ZERO))
        .put(spawn(0, 1, 0, 1))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(50.0F, 50.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeGlowRender(15.0F, 0.3F, GlowSpec.MODE_SCREEN, 0.9F, 0.0F))
        .build();
    
    /**
     * {@code Back_ADD}：崩解收尾时补上的一层巨大蓝色辉光，按色率 × 强度过曝成白。
     */
    public static final EfxConfig BACK_ADD_LATE = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(2, 0xFF0038FF, 0xFFFFFFFF, 128.0F, 5.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 25.0F), new EfxRange(0.0F, 1.5F),
                new EfxRange(0.0F, 1.0F), new EfxRange(0.0F, 0.0F),
                0, 0, false, false, false, new EfxRange(0.0F, 0.125F)))
        .put(spawn(3, 1, 0, 1))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(4.0F, 4.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeGlowRender(20F, 0.8F, GlowSpec.MODE_SCREEN, 0.3F, 0.0F))
        .build();
    
    /**
     * 构造辉光层共用的生成属性：分批信息照抄数据以备对照，但后端只按一次触发处理。
     */
    public static EfxAttributeSpawn spawn(int spawnFrame, int maxParticles, int intervalFrame,
                                          int loopNumDmc5) {
        return new EfxAttributeSpawn(maxParticles, 0, 1, 1, intervalFrame, intervalFrame, loopNumDmc5,
            false, spawnFrame, 0, 0, 0, false, false, false, false, 0, false);
    }
}
