package net.mrqx.sbr_core.client.effect.efx;

import java.util.HashMap;
import java.util.Map;

/**
 * {@link EfxConfig} 的构建器：以"属性类 → 实例"的方式累加属性，最后产出不可变配置。
 * <p>
 * 把该 Entry 拥有的属性逐个 {@code put} 进去即可，没有的属性就不用写，读取侧自然走默认分支：
 * <pre>{@code
 * EfxConfig config = EfxConfigBuilder.create(new EfxTypeBillboard3D(...))
 *     .put(new EfxAttributeSpawn(...))
 *     .put(new EfxAttributeLife(...))
 *     .build();
 * }</pre>
 */
public final class EfxConfigBuilder {
    /**
     * 类型属性（每个 Entry 必有其一）。
     */
    private final EfxAttribute type;
    
    /**
     * 已收集的修饰属性。
     */
    private final Map<Class<? extends EfxAttribute>, EfxAttribute> attributes = new HashMap<>();
    
    private EfxConfigBuilder(EfxAttribute type) {
        this.type = type;
    }
    
    /**
     * 以类型属性开启一次构建。
     *
     * @param type 类型属性（{@code EfxTypeBillboard3D} / {@code EfxTypePolygon} / {@code EfxTypeMesh} …）
     * @return 构建器
     */
    public static EfxConfigBuilder create(EfxAttribute type) {
        return new EfxConfigBuilder(type);
    }
    
    /**
     * 添加一个属性；同类属性重复添加时以后者为准。
     *
     * @param attribute 属性实例
     * @param <T>       属性类型
     * @return 本构建器（链式调用）
     */
    public <T extends EfxAttribute> EfxConfigBuilder put(T attribute) {
        Class<? extends EfxAttribute> key = attribute.getClass();
        this.attributes.put(key, attribute);
        return this;
    }
    
    /**
     * 生成不可变配置。
     */
    public EfxConfig build() {
        return new EfxConfig(this.type, this.attributes);
    }
}
