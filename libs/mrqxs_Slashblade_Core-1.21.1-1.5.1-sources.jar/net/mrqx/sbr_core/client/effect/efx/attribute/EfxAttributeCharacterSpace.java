package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：声明该层的长度与速度数值是<b>按角色尺寸标定</b>的，
 * 不参与本场演出的效果范围倍率。
 * <p>
 * <b>为什么需要它</b>：以角色为中心的那两套演出会把自己的"水平效果范围"整体放大（倍率见
 * {@code EfxTimeline#effectRangeScale()}），做法是让该场演出所有层的范围 / 速度 / 尺寸统一乘该倍率。
 * 这对<b>范围类</b>的层是对的（球壳、光环、飘带、收束火焰环），但有一类层的数值本来就是"贴着角色"的：
 * {@code 地面　収束　炎} 与 {@code GPU　胸　上昇青炎}。角色并没有跟着放大，把这两层一起放大就会得到
 * "角色身边 10 格开外的火圈"与"钻到地下、窜过头顶的火团"。
 * <p>
 * EFX 属性表里<b>没有</b>任何字段表达"这层的单位是角色尺度还是世界尺度"——两种层的数据形态
 * 完全一样，故只能由预设逐层声明。
 * <p>
 * <b>不要拿它去"调小"任何一个范围类层</b>：它只是把"这层不属于效果范围口径"这件事
 * 写成数据。若某层的实测描述是"扩大至效果范围"，就<b>不该</b>挂它。
 *
 * @param characterSized 是否按角色尺寸标定（{@code true} 时该层不乘本场演出的效果范围倍率）
 */
public record EfxAttributeCharacterSpace(boolean characterSized) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -8;
    
    /**
     * 默认值：按效果范围口径标定（即照常乘本场演出的效果范围倍率）。
     * <p>
     * 缺省取"放大"是与既有行为一致的保守选择——绝大多数层都属范围类。
     */
    public static final EfxAttributeCharacterSpace DEFAULT = new EfxAttributeCharacterSpace(false);
    
    /**
     * 便捷常量：按角色尺寸标定的层，直接 {@code .put(EfxAttributeCharacterSpace.CHARACTER_SIZED)}。
     */
    public static final EfxAttributeCharacterSpace CHARACTER_SIZED = new EfxAttributeCharacterSpace(true);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeCharacterSpace";
    }
}
