package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

/**
 * 面片类特效的 EFX 风格预设：<b>每个常量就是一个 {@link EfxConfig}</b>，值按 EFX 数据填写，
 * 由读取侧的 {@link net.mrqx.sbr_core.client.effect.efx.EfxPolygonView} 在触发时摊平成渲染/发射所需的扁平字段；
 * 逐字段的换算口径（尺寸 / 朝向 / 生命 ÷3 / 速度倍率 / 数量 / 颜色通道顺序 / 随机种子表）见该视图类。
 * <p>
 * 本类字面量的两条易读错约定：十六进制颜色是<b>交换 R 与 B 两通道</b>后的常规 ARGB；所有"帧"值 ÷3 才是 tick。
 * <p>
 * <b>近似点</b>：负层级 / 正层级 / 饱和度 / 颜色亮度在本项目渲染层无对应语义，只记录在
 * {@link EfxAttributeShaderSettings} 而不参与映射；玻璃碎屑的可见层是 GPU 实例化 billboard，属性库暂无该类型，
 * 故以 {@link EfxTypePolygon} 承载其基准贴图与数量。
 * <b>不属本类的层</b>：辉光 / 暗部压制 / 点光源这类"全屏性质"的层改用屏幕空间后处理 {@code GlowPostEffect}。
 */
public final class EfxJcePolygonPresets {
    /**
     * 时停时长（帧）：时停中的层停在 Keep 阶段，保持段直接取该值（169 帧 ≈ 56.3 tick）。
     */
    public static final float TIME_STOP_FRAMES = 169.0F;
    
    /**
     * 拼出贴图完整路径（TextureManager 需要 {@code textures/….png} 全路径）。
     */
    public static ResourceLocation texture(String name) {
        return MrqxSlashBladeCore.prefix("textures/effect/" + name + ".png");
    }
    
    /**
     * 给不含类型属性的层补一个画面内自转角速度。
     * <p>
     * 自转角速度由 {@link EfxAttributeRotateAnim}（{@code type} = 82）承载——它本来就是数据里那个字段的载体。
     * 此前的做法是伪造一个 {@link EfxTypePolygon} 塞进属性表、借"类型属性不匹配时仍会查属性表"取到角速度；
     * 那是权宜之计（{@code EfxTypePolygon} 里<b>并没有</b> {@code RotationAdd*} 字段，是抄写时塞进去的），现已改回。
     *
     * @param rotationAddZ 画面内滚转角速度（弧度 / 帧，1 tick = 3 帧）
     */
    public static EfxAttributeRotateAnim attachedPolygonRotation(float rotationAddZ) {
        return new EfxAttributeRotateAnim(rotationAddZ);
    }
    
    /**
     * 绝大多数面片层的"发射中心抬高 1 格"：把刀光抬到角色胸口而非脚底，缺了它整组刀光与裂纹会下移 1 格。
     */
    public static final EfxAttributeTransform3D CENTER_ONE_ABOVE_ORIGIN =
        new EfxAttributeTransform3D(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4);
    
    /**
     * 地面煙：地面蓝色烟雾，单帧贴图。
     */
    public static final EfxConfig GROUND_SMOKE = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                0, 0xBD222222, 0x523331D2, 1.0F, 1.0F, 0.0F, 0.0F,
                // 画面内滚转：固定 60°（数据 Rotation.s = 1.0471976），**不随机**——原作实测如此，
                // 故 r 写 0（数据里的 r = 1 未被采用，该字段的语义待核，与 AlphaRateLegacy 同类）。
                new EfxRange(1.0471976F, 0.0F),
                new EfxRange(0.2F, 0.2F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 0.0F),
                0, 0, false, false, false,
                new EfxRange(0.0F, 0.05F)))
        .put(new EfxAttributeSpawn(24, 0, 1, 1, 0, 0, 24, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 0.0F), new EfxRange(TIME_STOP_FRAMES, 0.0F),
            new EfxRange(11.0F, 0.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new EfxRange(3.0F, 2.0F), new EfxRange(0.9F, 0.0F), EfxRange.ZERO,
            new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(1.2F, 1.0F, 1.2F), 1,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.15F, 0.05F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(0.02F, 0.0F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(0.5F, 0.8F), 8, texture("crack_smoke_blue")))
        .put(new EfxAttributeEmitterShape3D(new EfxRange(14.0F, 14.0F), new EfxRange(0.25F, 0.25F),
            new EfxRange(14.0F, 14.0F), 2, 18, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributePtCollision(16, new EfxRange(0.1F, 0.1F), new EfxRange(3.0F, 3.0F),
            new EfxRange(0.7F, 0.7F), 1, 1, 0, 0.0F, 5.0F, 0.0F, EfxRange.ZERO))
        .put(new EfxAttributeFadeByDepth(3.0F, 6.0F, 100.0F, 120.0F))
        .put(new EfxAttributeAlphaCorrection(0.0F, 1.0F))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(new EfxAttributeShaderSettings(2F, -0.5F, 4F, 0xBD222222, 1.0F))
        .put(new EfxAttributeFixRandomGenerator(1, 1, -1, -1, -1, 0, 0, 0, 0, 0))
        .build();
    
    /**
     * 地面　縦煙：纵向烟柱，贴图在生成时从序列中随机抽一帧固定展示。
     */
    public static final EfxConfig GROUND_SMOKE_VERTICAL = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                0, 0xBDC0C0C0, 0x523331D2, 1.0F, 1.0F, 0.0F, 0.0F,
                // 画面内滚转：固定 20°（数据 Rotation.s = 0.34906587），不随机，故 r 写 0（同 GROUND_SMOKE）
                new EfxRange(0.34906587F, 0.0F),
                new EfxRange(0.3F, 0.3F),
                new EfxRange(0.0F, 0.5F),
                new EfxRange(0.0F, 0.0F),
                0, 0, false, false, false,
                new EfxRange(0.0F, 0.25F)))
        .put(new EfxAttributeSpawn(24, 0, 1, 1, 0, 0, 24, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 0.0F), new EfxRange(TIME_STOP_FRAMES, 0.0F),
            new EfxRange(11.0F, 0.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.2F, 0.1F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(0.1F, 0.05F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(64.0F, 30.0F),
            new EfxRange(0.5F, 0.8F), 8, texture("smoke_vertical")))
        .put(new EfxAttributeEmitterShape3D(new EfxRange(14.0F, 14.0F), new EfxRange(0.25F, 0.25F),
            new EfxRange(14.0F, 14.0F), 2, 18, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributePtCollision(16, new EfxRange(0.1F, 0.1F), new EfxRange(3.0F, 3.0F),
            new EfxRange(0.7F, 0.7F), 1, 1, 0, 0.0F, 5.0F, 0.0F, EfxRange.ZERO))
        .put(new EfxAttributeFadeByDepth(3.0F, 6.0F, 100.0F, 120.0F))
        .put(new EfxAttributeAlphaCorrection(0.0F, 1.0F))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(new EfxAttributeShaderSettings(1F, 0F, 4F, 0xBDC0C0C0, 1.0F))
        .put(new EfxAttributeFixRandomGenerator(1, 1, -1, -1, -1, 0, 0, 0, 0, 0))
        .build();
    
    /**
     * 割れ　黒　1：黑色弧线刀光，减法混合的 {@code Polygon}。
     */
    public static final EfxConfig CRACK_BLACK = EfxConfigBuilder.create(
            new EfxTypePolygon(
                4, 0xFF10101F, 0xFFFFFFFF, 1.0F, 8.0F, 1.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(1.5F, 0.3F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 3, 16, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 0.0F), new EfxRange(5.5F, 0.0F),
            new EfxRange(2.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeFixRandomGenerator(1, 0, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(new EfxAttributeScaleAnim(
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(-0.0002667F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_black")))
        .put(new EfxAttributeAlphaCorrection(0.58F, 1.0F))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(EfxJcePolygonPresets.attachedPolygonRotation(0.6108653F))
        .put(new EfxAttributeShaderSettings(0.5F, 0F, 4F, 0xFF10101F, 1.0F))
        .build();
    
    /**
     * 割れ　Dis　1：空间扭曲层，普通半透明；球体按椭球内均匀采样近似，{@code ScaleHorizontal/Vertical} 不映射。
     * <p>
     * {@code Intensity} 取数据原值 {@code 0} ⇒ 本层落入 {@code EfxPolygonView.distortionOnly}，
     * <b>本体不向颜色通道输出</b>，观感全部来自折射——与同族的 {@code 剣軌跡1} / {@code 剣軌跡_歪み} / {@code blur}
     * 完全同一行为（那一族"本体不出现"已由作者实机确认）。
     */
    public static final EfxConfig CRACK_DIS = EfxConfigBuilder.create(
            new EfxTypePolygon(
                // 第 5 个实参（Intensity）= 0，见类注释：数据是 0，不要因为"看起来该有一层半透明本体"改回 1
                16, 0xFFFFFFFF, 0xFFFF2612, 1.0F, 0.0F, 10.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(4.0F, 2.0F), new EfxRange(1.5F, 0.03F), new EfxRange(2.0F, 0.5F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(12, 0, 1, 1, 0, 1, 25, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(0.0F, 0.0F), new EfxRange(5.0F, 0.0F),
            new EfxRange(7.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeFixRandomGenerator(1, 0, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.5F, 0.2F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.1F, 1.0F, 2.2F), 0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(0.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(5.0F, 0.0F), new EfxRange(0.6F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 0, texture("crack_distortion")))
        .put(new EfxAttributeEmitterShape3D(new EfxRange(16.0F, 0.0F), new EfxRange(2.0F, 0.0F),
            new EfxRange(16.0F, 0.0F), 1, 0, 0, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(0.0F, 1.5707964F)))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            1.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .build();
    
    /**
     * 割れ　紫　1：直线刀光，加法混合，贴图为 64 帧序列（每行 8 帧）。
     */
    public static final EfxConfig CRACK_PURPLE = EfxConfigBuilder.create(
            new EfxTypePolygon(
                3, 0xFF050334, 0xFF070E55, 1.0F, 3.0F, 0.0F, 1.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(5.0F, 4.8989795F), new EfxRange(0.5F, 0.14F), new EfxRange(1.0F, 0.5F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(12, 0, 1, 1, 0, 1, 25, false, 6, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            new EfxRange(5.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeFixRandomGenerator(1, 0, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.3F, 0.12F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.1F, 1.0F, 2.2F), 0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(-0.05F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(2.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(64.0F, 0.0F),
            new EfxRange(3.0F, 3.0F), 0, texture("crack_flow_purple")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(10.0F, 0.0F), new EfxRange(2.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            1, 0, 0, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(0.0F, 1.5707964F)))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(new EfxAttributeShaderSettings(1F, 0F, 4F, 0xFF050334, 1.0F))
        // ⚠ 本 Entry 的数据里**没有** `AlphaCorrection` 属性（该效果只有 割れ黒1 / 割れ青1 / 割れ紫輝度1
        // 三层配了它），所以这一条是<b>项目自设</b>的近似，用来还原刀光"纤细硬边"的观感，<b>不是数据原值</b>。
        // 0.15 对应的原始 alpha 阈值是 `0.15^(1/4.84) ≈ 0.676`，即只保留贴图 alpha 最高的一小截。
        .put(new EfxAttributeAlphaCorrection(0.15F, 1.0F))
        .build();
    
    /**
     * 割れ　青　1：极细暗色雾状刀光，静止、长效（≈37 tick）。
     */
    public static final EfxConfig CRACK_BLUE = EfxConfigBuilder.create(
            new EfxTypePolygon(
                16, 0x800E073B, 0x800B1627, 1.0F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(4.5F, 2.7F), new EfxRange(0.05F, 0.01F), new EfxRange(1.0F, 0.5F),
                new EfxRange(0.0F, -0.5F)))
        .put(new EfxAttributeSpawn(25, 0, 1, 1, 0, 1, 25, false, 8, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(0.0F, 0.0F), new EfxRange(100.0F, 0.0F),
            new EfxRange(7.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.3F, 0.09F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(), 0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(-0.0008F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(2.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("crack_smoke_blue")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(10.0F, 0.0F), new EfxRange(2.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            1, 0, 0, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(0.0F, 1.5707964F)))
        .put(new EfxAttributeAlphaCorrection(0.69F, 1.0F))
        .put(EfxAttributeUVScroll.vScrollPerTick(0.15F))
        .put(new EfxAttributeFixRandomGenerator(1, 1, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(new EfxAttributeShaderSettings(0F, -5F, 4F, 0x800E073B, 1.0F))
        .build();
    
    /**
     * 割れ　紫　輝度　1：亮色弧线刀光，加法混合。
     */
    public static final EfxConfig CRACK_PURPLE_GLOW = EfxConfigBuilder.create(
            new EfxTypePolygon(
                17, 0xFF271E92, 0xFF603494, 0.5F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(1.5707964F, 1.0471976F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(8.0F, 4.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 1, 14, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 0.0F), new EfxRange(5.5F, 0.0F),
            new EfxRange(2.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeFixRandomGenerator(1, 0, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_ring_purple")))
        // EFX 原值 0.84。曾为替代贴图 crack_ring_purple（alpha 上限只有 0.81）把它压到 0.2，
        // 以免整层被裁光；量程折算现由 TextureAlphaRange 在着色器里接管，故撤回该手调、回到原口径。
        .put(new EfxAttributeAlphaCorrection(0.84F, 1.0F))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(EfxJcePolygonPresets.attachedPolygonRotation(0.6108653F))
        .put(new EfxAttributeShaderSettings(0.1F, 0F, 4F, 0xFF271E92, 1.0F))
        .build();
    
    /**
     * 割れ　閃　1：最细刀光，加法混合、纵向强烈延展。
     * <p>
     * 尺寸随机为 <b>0</b>（写成 ±95% 会让每根细线的粗细乱跳）；{@code SizeXAddCoef} 的语义在两端一致，
     * 原样保留，不做 0.95³ 折算。
     */
    public static final EfxConfig SLASH_LINE = EfxConfigBuilder.create(
            new EfxTypePolygon(
                17, 0x803B1FEE, 0x801770FF, 1.5F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(4.5F, 4.275F), new EfxRange(0.02F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(17, 0, 1, 1, 0, 1, 17, false, 9, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(0.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            new EfxRange(7.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeFixRandomGenerator(1, 0, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(new EfxAttributeScaleAnim(
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(-0.001F, 0.0F), new EfxRange(0.95F, 0.0F),
            new EfxRange(5.0F, 0.0F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("slash_line")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(10.0F, 0.0F), new EfxRange(2.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            1, 0, 0, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(0.0F, 1.5707964F)))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        // ⚠ 同 CRACK_PURPLE：本 Entry 的数据里没有 `AlphaCorrection`，这条是**项目自设**的"纤细硬边"近似，
        // 不是数据原值（0.1 对应的原始 alpha 阈值是 `0.1^(1/4.84) ≈ 0.621`）。
        .put(new EfxAttributeAlphaCorrection(0.1F, 1.0F))
        .build();
    
    /**
     * 割れ　閃　2：大范围过曝刀光，加法混合；本层<b>没有 {@code Velocity3D}</b>（不移动、不受重力），
     * 速度按数据原值关闭，与割れ　青　1 口径一致（待复核）。
     */
    public static final EfxConfig SLASH_WIDE = EfxConfigBuilder.create(
            new EfxTypePolygon(
                17, 0x803B1FEE, 0x801770FF, 5.0F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(4.5F, 3.0F), new EfxRange(0.02F, 0.01F), new EfxRange(1.0F, 0.5F),
                new EfxRange(0.0F, -0.5F)))
        .put(new EfxAttributeSpawn(25, 0, 1, 1, 0, 1, 25, false, 7, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(0.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            new EfxRange(7.0F, 0.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(), 0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeFixRandomGenerator(1, 0, -1, -1, -1, 0, 0, 0, 0, 0))
        .put(new EfxAttributeScaleAnim(
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(-0.004F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(4.0F, 0.0F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("slash_wide")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(10.0F, 0.0F), new EfxRange(2.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            1, 0, 0, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(0.0F, 1.5707964F)))
        .put(EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN)
        .put(new EfxAttributeShaderSettings(0F, -5F, 4F, 0x803B1FEE, 1.0F))
        // ⚠ 同 CRACK_PURPLE：数据里没有 `AlphaCorrection`，项目自设（阈值 ≈ 0.621）
        .put(new EfxAttributeAlphaCorrection(0.1F, 1.0F))
        .build();
    
    /**
     * ガラス　小0：玻璃碎屑，径向外抛并受重力；可见层是 GPU 实例化 billboard，属性库无该类型，故由本项目的面片类型承载。
     * <p>
     * 本层没有 {@code PtCollision}，即不做贴地吸附；自转 0.5°/帧 只作对照，本层无自转属性类。
     * <b>尺寸、速度、重力、发射范围与生命三段均按这里有意保留的手调值，不要按数据原值改回（待复核）。</b>
     */
    public static final EfxConfig CRYSTAL_SMALL = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                16, 0xB2111112, 0xFFFFFFFF, 1.0F, 1.0F, 0.0F, 0.0F,
                EfxRange.ZERO,
                new EfxRange(0.5F, 0.5F),
                EfxRange.ZERO,
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(25, 0, 25, 25, 0, 3, 5, false, 164, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(20.0F, 0.0F), new EfxRange(100.0F, 0.0F),
            new EfxRange(40.0F, 0.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 4.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(1.1F, 0.77F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.1F, 1.0F, 1.1F), 2,
            new EfxRange(0.5F, 0.0F), EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.00016666667F, 0.0F), new EfxRange(0.99F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(0.3F, 0.3F), 41, texture("crystal_small")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(10.0F, 0.0F), new EfxRange(2.0F, 0.0F), new EfxRange(10.0F, 0.0F),
            1, 0, 0, 4, new Vector3f(),
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F)))
        .put(EfxJcePolygonPresets.attachedPolygonRotation(0.008726646F))
        .put(new EfxAttributeShaderSettings(0.1F, 0F, 4F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * ガラス　極小0：粉尘级玻璃碎屑，圆柱形喷散；承载方式同 {@link #CRYSTAL_SMALL}。
     * <p>
     * 速度随机比例、尺寸随机与画面内自转是这里有意保留的手调值，不要按数据原值改回（待复核）。
     */
    public static final EfxConfig CRYSTAL_TINY = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                2, 0xFFFFFFFF, 0xFFABABAB, 1.0F, 1.2F, 0.0F, 0.0F,
                EfxRange.ZERO,
                new EfxRange(0.15F, 0.18F),
                new EfxRange(0.0F, 0.12F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(EfxJcePolygonPresets.attachedPolygonRotation(0.02094395F))
        .put(new EfxAttributeSpawn(500, 0, 500, 500, 0, 0, 1, false, 169, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 0.0F), new EfxRange(30.0F, 0.0F),
            new EfxRange(10.0F, 0.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeVelocity3D(0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.25F, 0.125F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(), 0,
            new EfxRange(0.2F, 0.0F), EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.0005F, 0.0F), new EfxRange(0.99F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(16.0F, 0.0F),
            new EfxRange(0.2F, 0.2F), 41, texture("crystal_tiny")))
        .put(new EfxAttributeEmitterShape3D(new EfxRange(10.0F, 10.0F), new EfxRange(3.0F, 3.0F),
            new EfxRange(10.0F, 10.0F), 2, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(0.1F, 0F, 4F, 0xFF000000, 1.0F))
        .build();
}
