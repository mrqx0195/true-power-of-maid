package net.mrqx.sbr_core.client.effect.efx.script;

import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributePtBehavior;
import net.mrqx.sbr_core.client.effect.post.GlowPostEffect;
import net.mrqx.sbr_core.client.effect.post.GlowPresets;
import net.mrqx.sbr_core.client.effect.post.GlowSpec;

/**
 * 脚本 {@code via.effect.script.EffectLight5000lm}（光照）的执行者：不做真实光注入，
 * 改用屏幕空间辉光 {@link GlowPostEffect} 表现"被照亮"，故输出端是 {@link GlowSpec}；
 * 位置、时长、强度、范围、闪烁全部来自 EFX 层，不由 {@link GlowPresets} 常量硬编码。
 * <p>
 * 映射：半径 = {@code ReferenceEffectiveRange} ×
 * {@link GlowPresets#RADIUS_SCALE}；颜色 = 层 {@code Color}（常规 ARGB）；强度 =
 * {@code Intensity} ÷ {@link #BASE_LUMENS} × {@link #BASE_GAIN} ×
 * {@link GlowPresets#STRENGTH_SCALE}；闪烁 = 层振幅与跳变间隔；时长 = 生命三段；
 * 位置 = 层 {@code LocalPosition} 加演出原点（{@link EfxScriptContext#position()}）。
 * <p>
 * {@code Radius}（疑为光源自身几何半径）与 {@code ShadowEnable} 暂不消费，记录在案。
 */
public final class LightScriptAdapter implements EfxScriptAdapter {
    /**
     * 本执行者对应的脚本短名，即派发键。
     */
    public static final String SCRIPT_NAME = "EffectLight5000lm";
    
    /**
     * 流明基准值 {@code 250000}，即 {@code ライト2} 层标定 {@link #BASE_GAIN} 时用的 {@code Intensity}。
     */
    public static final float BASE_LUMENS = 250000.0F;
    
    /**
     * 基准增益 {@code 3.6}：流明与本项目无量纲的辉光增益之间没有换算依据，故以
     * {@link #BASE_LUMENS} 为标定点线性标定（取迁移前该层预设强度，使切换后亮度完全不变）。
     * 它是<b>观感取值</b>而非 EFX 数据，有意保留，不要按数据改回；若切换后亮度不符只改这一处。
     * <p>
     * 不要按数据改回的对照：{@code ライト2} 层的 {@code Intensity} 正是 {@link #BASE_LUMENS}，
     * 若把流明直接当增益代回就会与该层预设强度不符。
     */
    public static final float BASE_GAIN = 3.6F;
    
    /**
     * {@code ReferenceEffectiveRange} 缺失时的兜底有效范围（格），取 BOSS 层「ライト」的 6。
     */
    public static final float DEFAULT_EFFECTIVE_RANGE = 6.0F;
    
    /**
     * 光斑边缘柔和度 {@code 0.95}：EFX 属性表无对应项，沿用迁移前 {@link GlowPresets} 各常量的取值。
     */
    public static final float SOFTNESS = 0.95F;
    
    @Override
    public String scriptName() {
        return SCRIPT_NAME;
    }
    
    @Override
    public void execute(EfxScriptContext context) {
        EfxAttributePtBehavior behavior = context.behavior();
        float effectiveRange =
            behavior.floatValue("ReferenceEffectiveRange", DEFAULT_EFFECTIVE_RANGE);
        float intensity = behavior.floatValue("Intensity", 0.0F);
        GlowSpec spec = new GlowSpec(
            effectiveRange * GlowPresets.RADIUS_SCALE,
            context.view().color,
            intensity / BASE_LUMENS * BASE_GAIN * GlowPresets.STRENGTH_SCALE,
            GlowSpec.MODE_ADD,
            SOFTNESS,
            0.0F,
            context.appearTicks(),
            context.keepTicks(),
            context.vanishTicks(),
            behavior.floatValue("IntensityAmplitudeMin", 1.0F),
            behavior.floatValue("IntensityAmplitudeMax", 1.0F),
            (int) behavior.floatValue("IntensityAmplitudeChangeFrameMax", 1.0F));
        GlowPostEffect.trigger(context.position(), spec);
    }
}
