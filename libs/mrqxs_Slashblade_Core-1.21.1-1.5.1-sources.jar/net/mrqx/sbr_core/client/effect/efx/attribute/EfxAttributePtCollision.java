package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 属性 {@code EFXAttributePtCollision}：粒子与场景/碰撞体的碰撞（对应 json 的 {@code type} = 128）。
 * <p>
 * 本项目的粒子只做解析运动，不做逐帧物理，因此目前只用到"贴地"这一近似：
 * 用 {@code radius} 与 {@code projectionDist} 决定吸附的容差，用 {@code finishType}
 * 决定贴地后是否停住。缺少该属性即"不与地面交互"。
 * <p>
 * EFX 的字段是 {@code stringBitFlag} + 三个未知字节、{@code Radius}（数值对）、{@code BounceNum}（<b>整数对</b>）、
 * {@code BounceRate}（数值对）、{@code VerticalBounce} / {@code HorizontalBounce}、{@code FinishType}
 * （0 = None、1 = Kill、2 = Freeze）、{@code projectionOffset}、{@code projectionDist}、
 * {@code LookNormalDirectionOffset}、{@code DelayFrameCollision}，末尾还有两个按 {@code stringBitFlag}
 * 位决定是否存在的字符串（碰撞体/材质名）。本项目为简化：
 * <ul>
 *   <li>{@code bounceNum} 用 {@link EfxRange} 承载（EFX 是整数对）、{@code verticalBounce} /
 *       {@code horizontalBounce} 用 {@code int}（EFX 是 float）——这两处类型偏差只影响记录形状，
 *       消费侧完全没读它们；</li>
 *   <li>前三个未知字节与两个可选字符串未建模；</li>
 *   <li>{@code Radius} / {@code BounceNum} / {@code BounceRate} / {@code FinishType} 都不参与本项目的映射
 *       ——它们是"与碰撞体反弹"的参数，而本项目只借用"是否配置了本属性"来表达"贴地"。</li>
 * </ul>
 *
 * @param stringBitFlag             碰撞标志位
 * @param radius                    碰撞半径
 * @param bounceNum                 反弹次数
 * @param bounceRate                反弹速度保留比例
 * @param verticalBounce            垂直反弹开关
 * @param horizontalBounce          水平反弹开关
 * @param finishType                结束方式（0 = None、1 = Kill、2 = Freeze）
 * @param projectionOffset          投影偏移
 * @param projectionDist            投影距离
 * @param lookNormalDirectionOffset 法线方向偏移
 * @param delayFrameCollision       开始碰撞的延迟（帧）
 */
public record EfxAttributePtCollision(
    int stringBitFlag,
    EfxRange radius,
    EfxRange bounceNum,
    EfxRange bounceRate,
    int verticalBounce,
    int horizontalBounce,
    int finishType,
    float projectionOffset,
    float projectionDist,
    float lookNormalDirectionOffset,
    EfxRange delayFrameCollision
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 128;
    
    /**
     * 默认值：不与地面交互。
     */
    public static final EfxAttributePtCollision DEFAULT = new EfxAttributePtCollision(
        0, new EfxRange(0.1F, 0.0F), EfxRange.ZERO, EfxRange.ZERO, 0, 0, 0, 0.0F, 0.0F, 0.0F, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributePtCollision";
    }
}
