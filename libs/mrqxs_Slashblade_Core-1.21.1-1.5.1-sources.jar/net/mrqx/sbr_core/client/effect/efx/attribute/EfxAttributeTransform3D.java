package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import org.joml.Vector3f;

/**
 * 属性 {@code EFXAttributeTransform3D}：发射器的局部变换（对应 json 的 {@code type} = 8）。
 * <p>
 * 对应"发射中心相对宿主/原点的偏移与缩放"，例如点光源层把光晕挂在角色上方 3 格
 * （{@code localPosition = (0, 3, 0)}）。缺少该属性即"在原点、无旋转、无缩放"。
 * <p>
 * 四个字段与 EFX 的声明顺序完全一致（{@code LocalPosition} / {@code LocalRotation} / {@code LocalScale} /
 * {@code RotationOrder}）。本项目的消费侧只用 {@code localPosition}（发射中心偏移），旋转与缩放尚未参与映射。
 *
 * @param localPosition 局部位置偏移
 * @param localRotation 局部旋转（弧度）
 * @param localScale    局部缩放
 * @param rotationOrder 旋转顺序
 */
public record EfxAttributeTransform3D(
    Vector3f localPosition,
    Vector3f localRotation,
    Vector3f localScale,
    int rotationOrder
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 8;
    
    /**
     * 默认值：单位变换。
     */
    public static final EfxAttributeTransform3D DEFAULT = new EfxAttributeTransform3D(
        new Vector3f(), new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 0);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTransform3D";
    }
}
