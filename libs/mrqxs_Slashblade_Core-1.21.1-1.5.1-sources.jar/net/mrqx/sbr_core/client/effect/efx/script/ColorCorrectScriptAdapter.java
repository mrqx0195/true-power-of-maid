package net.mrqx.sbr_core.client.effect.efx.script;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributePtBehavior;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxBehaviorValue;
import net.mrqx.sbr_core.client.effect.post.LutColorCorrectionPostEffect;

import javax.annotation.Nullable;

/**
 * 脚本 {@code via.effect.script.EffectColorCorrect}（LUT 色彩校正）的执行者。
 * <p>
 * LUT 贴图逐层传入：{@code Cube2Texture} 本就逐层给出，两层用的不是同一张，
 * 共用一张会让后触发的那层把前一层的 LUT 顶掉；因此读取为 {@link ResourceLocation} 逐次指定。
 * 触发位置不参与，LUT 校正是全屏后处理，没有落点概念。
 * <p>
 * 时长取生命三段（{@link EfxScriptContext#appearTicks()} 等），口径即 EFX {@code Life} 的 5 / 0 / 1 帧。
 * <p>
 * {@code Cube2BlendRateMax} <b>会如实下发</b>：它乘在后端的强度包络上，且允许大于 1
 * （数据里 {@code カラコレ} 是 {@code 1.25}），着色器那边不再把混合率夹到 1、而是外插。
 * {@code Priority} / {@code PriorityType} 仍未消费（本项目同时只会激活一个 LUT 通道，后触发者覆盖）。
 */
public final class ColorCorrectScriptAdapter implements EfxScriptAdapter {
    /**
     * 本执行者对应的脚本短名，即派发键。
     */
    public static final String SCRIPT_NAME = "EffectColorCorrect";
    
    @Override
    public String scriptName() {
        return SCRIPT_NAME;
    }
    
    @Override
    public void execute(EfxScriptContext context) {
        LutColorCorrectionPostEffect.trigger(
            context.appearTicks(), context.keepTicks(), context.vanishTicks(),
            lutTexture(context.behavior()), blendRateMax(context.behavior()));
    }
    
    /**
     * 取该层的 {@code Cube2BlendRateMax}（乘在强度包络上的混合率上限）。
     * <p>
     * 数据里它可以大于 1（{@code カラコレ} = {@code 1.25}），**不要**在这里夹到 1——
     * 外插由着色器用 {@code mix} 完成。
     *
     * @return 混合率上限；参数缺失或类型不符时按 1（完全应用）处理
     */
    public static float blendRateMax(EfxAttributePtBehavior behavior) {
        EfxBehaviorValue.FloatValue value =
            behavior.value("Cube2BlendRateMax", EfxBehaviorValue.FloatValue.class);
        return value != null ? value.value() : 1.0F;
    }
    
    /**
     * 取该层要用的 LUT 贴图（参数名 {@code Cube2Texture}，承载实际加载的贴图路径，
     * 见 {@link EfxBehaviorValue.ResourceValue}）。
     *
     * @return LUT 贴图；参数缺失或不是资源类型时为 {@code null}（由后端退回默认 LUT）
     */
    @Nullable
    public static ResourceLocation lutTexture(EfxAttributePtBehavior behavior) {
        EfxBehaviorValue.ResourceValue resource =
            behavior.value("Cube2Texture", EfxBehaviorValue.ResourceValue.class);
        return resource != null ? resource.resource() : null;
    }
}
