package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import org.joml.Vector2f;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 引擎脚本属性（{@code EFXAttributePtBehavior}，{@code type = 111}）：把一层特效交给内置脚本执行。
 * <p>
 * 本效果集用到五条脚本：{@code EffectRadialBlur}（径向模糊）、{@code EffectShakeCameraCustom}（镜头震动）、
 * {@code EffectLight5000lm}（光照）、{@code EffectDecal}（地面贴花）、{@code EffectColorCorrect}
 * （LUT 色彩校正，用参数 {@code Cube2Texture} 给出 LUT 贴图路径）。
 * <p>
 * 参数必须留在属性表内而不是抄进调用点：NoDraw 层的位置是世界位置，脱离 EFX 手写会让落点与数值失准
 * （此前正因此把世界位置误写成相机局部位置）。
 *
 * @param properties 脚本参数表（json 的 {@code properties[]}，顺序照原样保留）
 */
public record EfxAttributePtBehavior(String behaviorString, List<EfxBehaviorProperty> properties
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 111;
    
    public static final String SCRIPT_PREFIX = "via.effect.script.";
    
    public static final EfxAttributePtBehavior DEFAULT = new EfxAttributePtBehavior("", List.of());
    
    public EfxAttributePtBehavior {
        properties = List.copyOf(properties);
    }
    
    /**
     * 便捷构造器：只给脚本名，参数表为空。
     *
     * @param behaviorString 脚本全名
     */
    public EfxAttributePtBehavior(String behaviorString) {
        this(behaviorString, List.of());
    }
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributePtBehavior";
    }
    
    /**
     * 脚本的短名（去掉 {@link #SCRIPT_PREFIX} 前缀），便于与 Java 侧的对应实现对照。
     *
     * @return 例如 {@code EffectLight5000lm}；没有脚本时返回空串
     */
    public String scriptName() {
        return this.behaviorString.startsWith(SCRIPT_PREFIX)
            ? this.behaviorString.substring(SCRIPT_PREFIX.length())
            : this.behaviorString;
    }
    
    public boolean hasScript() {
        return !this.behaviorString.isEmpty();
    }
    
    /**
     * 按参数名取参数项。
     *
     * @return 参数项；没有该名字时返回 {@code null}
     */
    @Nullable
    public EfxBehaviorProperty property(String behaviorProperty) {
        for (EfxBehaviorProperty property : this.properties) {
            if (property.behaviorProperty().equals(behaviorProperty)) {
                return property;
            }
        }
        return null;
    }
    
    public boolean has(String behaviorProperty) {
        return this.property(behaviorProperty) != null;
    }
    
    /**
     * 按参数名取参数值，并校验其类型。
     * <p>
     * 类型不符或参数不存在都返回 {@code null}，调用方据此跳过对应逻辑；参数类型写在 json 的
     * {@code dataType} 里，因此校验失败即数据与预期不符，应当显式看到。
     *
     * @param valueType 期望的取值类型（{@link EfxBehaviorValue} 的某个变体）
     * @return 参数值；不存在或类型不符时返回 {@code null}
     */
    @Nullable
    public <T extends EfxBehaviorValue> T value(String behaviorProperty, Class<T> valueType) {
        EfxBehaviorProperty property = this.property(behaviorProperty);
        if (property == null) {
            return null;
        }
        EfxBehaviorValue value = property.value();
        return valueType.isInstance(value) ? valueType.cast(value) : null;
    }
    
    /**
     * 按参数名取浮点数：{@link EfxBehaviorValue.IntValue} 提升为浮点（不损失信息），其余类型取兜底值。
     */
    public float floatValue(String behaviorProperty, float fallback) {
        EfxBehaviorValue value = this.rawValue(behaviorProperty);
        if (value instanceof EfxBehaviorValue.FloatValue(float value2)) {
            return value2;
        }
        if (value instanceof EfxBehaviorValue.IntValue(int value1)) {
            return value1;
        }
        return fallback;
    }
    
    /**
     * 按参数名取整数：额外接受 {@link EfxBehaviorValue.EnumValue}（枚举项本身即整数索引），
     * 以及长度不超过 4 字节的 {@link EfxBehaviorValue.RawValue}（对应 {@code Priority}
     * 这类编号未确证、但实测就是 4 字节整数的项）。
     */
    public int intValue(String behaviorProperty, int fallback) {
        EfxBehaviorValue value = this.rawValue(behaviorProperty);
        if (value instanceof EfxBehaviorValue.IntValue(int value2)) {
            return value2;
        }
        if (value instanceof EfxBehaviorValue.EnumValue(int value1)) {
            return value1;
        }
        if (value instanceof EfxBehaviorValue.RawValue rawValue && rawValue.byteLength() <= Integer.BYTES) {
            return rawValue.littleEndianInt();
        }
        return fallback;
    }
    
    /**
     * 按参数名取布尔值：EFX 用整数开关（{@code PropInt} / {@code PropEnum}），非 0 即真。
     */
    public boolean boolValue(String behaviorProperty, boolean fallback) {
        EfxBehaviorValue value = this.rawValue(behaviorProperty);
        if (value instanceof EfxBehaviorValue.IntValue(int value2)) {
            return value2 != 0;
        }
        if (value instanceof EfxBehaviorValue.EnumValue(int value1)) {
            return value1 != 0;
        }
        return fallback;
    }
    
    /**
     * 按参数名取字符串（预制体路径、LUT 贴图路径等）。
     *
     * @return 字符串；参数不存在或不是字符串时返回 {@code null}
     */
    @Nullable
    public String stringValue(String behaviorProperty) {
        EfxBehaviorValue.StringValue stringValue =
            this.value(behaviorProperty, EfxBehaviorValue.StringValue.class);
        return stringValue != null ? stringValue.value() : null;
    }
    
    /**
     * 按参数名取两分量浮点（{@code PropFloat2}，如贴花的 {@code ScaleXY}）。
     *
     * @param fallback 参数不存在或类型不符时的兜底值
     * @return 两分量值
     */
    public Vector2f vector2Value(String behaviorProperty, Vector2f fallback) {
        EfxBehaviorValue.Float2Value value =
            this.value(behaviorProperty, EfxBehaviorValue.Float2Value.class);
        return value != null ? new Vector2f(value.x(), value.y()) : fallback;
    }
    
    /**
     * 按参数名取三分量浮点（{@code PropFloat3}，如贴花的 {@code Extent}）。
     *
     * @param fallback 参数不存在或类型不符时的兜底值
     * @return 三分量值
     */
    public Vector3f vector3Value(String behaviorProperty, Vector3f fallback) {
        EfxBehaviorValue.Float3Value value =
            this.value(behaviorProperty, EfxBehaviorValue.Float3Value.class);
        return value != null ? new Vector3f(value.x(), value.y(), value.z()) : fallback;
    }
    
    /**
     * 按参数名取颜色（{@code PropColor}，如贴花的 {@code BaseColorMod} / {@code EmissiveMod}）。
     *
     * @param fallbackArgb 参数不存在或类型不符时的兜底值（常规 ARGB）
     * @return 常规 ARGB
     */
    public int colorValue(String behaviorProperty, int fallbackArgb) {
        EfxBehaviorValue.ColorValue value =
            this.value(behaviorProperty, EfxBehaviorValue.ColorValue.class);
        return value != null ? value.argb() : fallbackArgb;
    }
    
    /**
     * 取原始参数值，不做类型校验的内部入口。
     */
    @Nullable
    private EfxBehaviorValue rawValue(String behaviorProperty) {
        EfxBehaviorProperty property = this.property(behaviorProperty);
        return property != null ? property.value() : null;
    }
}
