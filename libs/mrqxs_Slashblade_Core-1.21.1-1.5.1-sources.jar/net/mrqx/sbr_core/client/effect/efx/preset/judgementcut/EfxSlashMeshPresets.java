package net.mrqx.sbr_core.client.effect.efx.preset.judgementcut;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;

/**
 * 次元斩（小技能）三套演出的<b>网格类</b>层预设（{@code TypeMesh}）。
 * <p>
 * 这一族的可见性都不来自本体：球体只负责"在屏幕上占一块地方"，真正的表现由它写出的
 * <b>折射 / 滤镜遮罩</b>承担，故顶点色 alpha 与材质覆写是这两件事的唯一依据。
 */
public final class EfxSlashMeshPresets {
    /**
     * 屏幕空间调色用的球体模型（与「次元斩·绝」的 {@code カラコレ} 同源）。
     */
    public static final ResourceLocation COLOR_SPHERE =
        MrqxSlashBladeCore.prefix("model/effect/color_sphere.obj");
    
    /**
     * 折射球用的球体模型：与 {@link #COLOR_SPHERE} <b>不是同一个网格</b>，两者不可互换。
     */
    public static final ResourceLocation REFRACT_SPHERE =
        MrqxSlashBladeCore.prefix("model/effect/refract_sphere.obj");
    
    /**
     * {@code カラコレ0} 一族的屏幕空间色散幅度（屏幕 UV 单位）。
     * <p>
     * <b>D 级推断</b>：这三层材质的 {@code RefractiveIndex} 覆写都是 {@code 1}，按「次元斩·绝」那套
     * {@code (RefractiveIndex − 1) × 1e-4} 折算出来就是 {@code 0}，而这层实机上是"轻微凸透镜 + 色散"。
     * 此处取「次元斩·绝」{@code カラコレ} 的四分之一（{@code 4e-4} → {@code 1e-4}）作为"远低于它"的量级，
     * 待材质参数名对位后再换成从数据反算的值。
     */
    public static final float CHROMA_DISPERSION = 1.0E-4F;
    
    /**
     * {@code カラコレ0}：包裹目标位置的一层极淡球壳，只写屏幕空间调色遮罩，本体完全不画
     * （{@code GenericMeshParticle#vertexColor} 对屏空间载体一律把本体 alpha 归零）。
     * <p>
     * ⚠ <b>强度是 D 级推断</b>：本层材质的 {@code RefractiveIndex} 覆写是 {@code 1}，按既有口径折算出的
     * 色散系数就是 {@code 0}，与实机所见"轻微凸透镜 + 色散"对不上，故暂取 {@link #CHROMA_DISPERSION}；
     * 同一材质的另一个覆写 {@code ColorOffset = −1.2} 与「次元斩·绝」差得更多，是待对位的头号候选。
     */
    public static final EfxConfig BOSS_CHROMA0 = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                6.0F, 0.0F,
                0xFFFFFFFF, 0xFFFFFFFF, COLOR_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 3, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(15.0F, 15.0F),
            new EfxRange(17.0F, 17.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScreenGrading(0xFFFFFFFF, CHROMA_DISPERSION, 1.0F, 0.0F, 0.0F))
        .build();
    
    /**
     * {@code 白黒}：缓慢胀大后拉长淡出的折射球，同时写折射与蓝色滤镜两条遮罩。
     * <p>
     * ⚠ <b>两个强度沿用「次元斩·绝」那一层的标定值</b>（D 级）：本层材质的 7 项覆写尚未与参数名对位，
     * 而两者的可见性都由同一条屏幕空间管线给出，故先取同族标定，待对位后再逐项重标。
     */
    public static final EfxConfig BOSS_MONOCHROME = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                2.0F, 0.0F,
                0xCCFFE200, 0xFFFFFFFF, REFRACT_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 13, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(6.0F, 6.0F), EfxRange.ZERO,
            new EfxRange(50.0F, 50.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.14F, 0.0F), new EfxRange(0.98F, 0.0F),
            new EfxRange(-0.01F, 0.0F), new EfxRange(1.06F, 0.0F),
            new EfxRange(-0.01F, 0.0F), new EfxRange(1.06F, 0.0F),
            new EfxRange(-0.01F, 0.0F), new EfxRange(1.06F, 0.0F), EfxRange.ZERO))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            15.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeColorFilter(1.0F, 0xFFFFFFFF, 1.15F, 2000.0F, 0.0F))
        .build();
    
    /**
     * {@code 白黒開始}：只存在一瞬间的折射球，没有滤镜通道，故本体不可见、只留下一次折射脉冲。
     */
    public static final EfxConfig BOSS_MONOCHROME_START = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                2.0F, 0.0F,
                0xFF000DFF, 0xFFFFFFFF, REFRACT_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 6, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(3.0F, 3.0F),
            new EfxRange(4.0F, 4.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.03F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            15.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .build();
    
    /**
     * 完美变体：与 {@link #BOSS_CHROMA0} 同源，但缩放倍率更大（8）且 {@code ColorOffset} 覆写不同。
     * <p>
     * ⚠ 强度来源与 BOSS 变体同样待复核（{@code RefractiveIndex} 覆写同为 {@code 1}）。
     */
    public static final EfxConfig PERFECT_CHROMA = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                8.0F, 0.0F,
                0xFFFFFFFF, 0xFFFFFFFF, COLOR_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 3, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(15.0F, 15.0F),
            new EfxRange(5.0F, 5.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScreenGrading(0xFFFFFFFF, CHROMA_DISPERSION, 1.0F, 0.0F, 0.0F))
        .build();
    
    /**
     * 完美变体：只存在一瞬间的折射球，胀大极慢（每帧 0.02）。
     */
    public static final EfxConfig PERFECT_DISTORTION_START = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                2.1F, 0.0F,
                0x8000B2FF, 0xFFFFFFFF, REFRACT_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 3, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(15.0F, 15.0F),
            new EfxRange(4.0F, 4.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.02F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            15.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .build();
    
    /**
     * 完美变体：缓慢胀大、拉长淡出的折射球（BOSS 变体里叫 {@code 白黒}）。
     */
    public static final EfxConfig PERFECT_DISTORTION = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                2.0F, 0.0F,
                0xC8FF4000, 0xFFFFFFFF, REFRACT_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 15, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(6.0F, 6.0F), EfxRange.ZERO,
            new EfxRange(50.0F, 50.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.16F, 0.0F), new EfxRange(0.92F, 0.0F),
            new EfxRange(-0.01F, 0.0F), new EfxRange(1.06F, 0.0F),
            new EfxRange(-0.01F, 0.0F), new EfxRange(1.06F, 0.0F),
            new EfxRange(-0.01F, 0.0F), new EfxRange(1.06F, 0.0F), EfxRange.ZERO))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            15.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeColorFilter(1.0F, 0xFFFFFFFF, 1.15F, 2000.0F, 0.0F))
        .build();
    
    /**
     * 普通变体：调色球可见度更高（顶点色 alpha 为 {@code CC}），并带距离淡出。
     */
    public static final EfxConfig NORMAL_CHROMA = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                6.0F, 0.0F,
                0xCCFFFFFF, 0xFFFFFFFF, COLOR_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 3, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(15.0F, 15.0F),
            new EfxRange(5.0F, 5.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScreenGrading(0xFFFFFFFF, CHROMA_DISPERSION, 1.0F, 0.0F, 0.0F))
        .put(new EfxAttributeFadeByDepth(3.0F, 9.0F, 100.0F, 120.0F))
        .build();
    
    private EfxSlashMeshPresets() {
    }
}
