package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：承载 EFX 数据里没有对应字段、但渲染实现必须知道的补充信息。
 * <p>
 * <b>只保留真正"EFX 无处可写"的几项</b>：
 * <ul>
 *   <li>{@code depthWrite}：EFX 把它交给材质层（{@code ShaderSettings} / 材质属性块），
 *       属性表里没有可直接映射的开关，而本项目的渲染类型需要显式决定是否写深度；</li>
 *   <li>{@code anchorU} / {@code anchorV}：<b>旋转锚点</b>——面片绕贴图内的哪一点旋转。
 *       EFX 里没有对应字段，而本项目的 {@code PolygonParticle} 需要显式给出锚点才能让弧线绕圆心扫动；</li>
 *   <li>{@code groundPlane}：是否把面片固定躺在世界水平面上（法线恒为 +Y，只允许平面内滚转）。
 *       贴地烟雾 / 水平畸变面片在数据里与"面向相机的面片"同样是 {@code Billboard3D} / {@code GpuBillboard}，
 *       {@code Flags} 也无法区分（实测取值为 0 与 4 两种，且两种里都同时存在贴地与非贴地层），
 *       而两者的观感差异极大（贴地层一旦跟着相机摆动就会"立"起来），故按实机观感逐层声明。</li>
 * </ul>
 * 贴图、画面内滚转、随机固定帧、畸变强度与 UV 滚动都已在 EFX 里各归其位，分别由
 * {@link EfxAttributeUVSequence#resource()}（{@code UVSPath}，已改为 Minecraft 的
 * {@code ResourceLocation}）、{@link EfxTypeBillboard3D#rotation()}、
 * {@link EfxAttributeUVSequence#patternNo()}、{@link EfxAttributeDistortion}、
 * {@link EfxAttributeUVScroll} 承载。
 *
 * @param depthWrite  是否写入深度
 * @param anchorU     旋转锚点 U（0~1，0.5 为面片水平中心）
 * @param anchorV     旋转锚点 V（0~1，0 为贴图顶部）
 * @param groundPlane 是否把面片固定躺在世界水平面上
 */
public record EfxAttributeSbrRender(
    boolean depthWrite,
    float anchorU,
    float anchorV,
    boolean groundPlane
) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -1;
    
    /**
     * 默认值：不写深度、锚点居中、不声明水平面朝向。
     */
    public static final EfxAttributeSbrRender DEFAULT = new EfxAttributeSbrRender(false, 0.5F, 0.5F, false);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeRender";
    }
}
