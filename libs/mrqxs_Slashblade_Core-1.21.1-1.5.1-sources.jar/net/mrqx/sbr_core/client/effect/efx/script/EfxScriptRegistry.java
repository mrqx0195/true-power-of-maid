package net.mrqx.sbr_core.client.effect.efx.script;

import javax.annotation.Nullable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * EFX 脚本执行者注册表：把层上的脚本名映射到本项目里负责表现的执行者。
 * <p>
 * 与后处理注册表（{@code PostEffectRegistry}）的分工：后者管的是"后处理链的加载 / 释放 /
 * 合成顺序"，是引擎级设施；本注册表管的是"层上的脚本交给谁执行"，是一次派发。
 * 一个脚本名只允许一个执行者，重复注册以后者为准。
 * <p>
 * 未注册的脚本名一律"派发失败"而不是静默当作完成——调用方据此可以记录
 * "这一层挂了脚本、本项目还没有对应实现"，避免漏掉整层却无人察觉。
 */
public final class EfxScriptRegistry {
    /**
     * 已注册的执行者（脚本短名 → 执行者）；用 {@link LinkedHashMap} 保留注册顺序，
     * 便于诊断输出稳定。
     */
    private static final Map<String, EfxScriptAdapter> ADAPTERS = new LinkedHashMap<>();
    
    static {
        register(new RadialBlurScriptAdapter());
        register(new ShakeCameraScriptAdapter());
        register(new LightScriptAdapter());
        register(new ColorCorrectScriptAdapter());
        register(new DecalScriptAdapter());
    }
    
    private EfxScriptRegistry() {
    }
    
    /**
     * 注册一个执行者（同名覆盖）。
     *
     * @param adapter 执行者
     */
    public static void register(EfxScriptAdapter adapter) {
        ADAPTERS.put(adapter.scriptName(), adapter);
    }
    
    /**
     * 按脚本名取执行者。
     *
     * @param scriptName 脚本短名（如 {@code EffectRadialBlur}）
     * @return 执行者；未注册时返回 {@code null}
     */
    @Nullable
    public static EfxScriptAdapter get(String scriptName) {
        return ADAPTERS.get(scriptName);
    }
    
    /**
     * 按层上挂的脚本派发一次执行。
     * <p>
     * 该层没有脚本（纯占位层）、或脚本尚未注册时返回 {@code false}，不做任何事。
     *
     * @param context 本次执行的上下文
     * @return 是否真的派发出去
     */
    public static boolean dispatch(EfxScriptContext context) {
        String scriptName = context.view().scriptName;
        if (scriptName.isEmpty()) {
            return false;
        }
        EfxScriptAdapter adapter = ADAPTERS.get(scriptName);
        if (adapter == null) {
            return false;
        }
        adapter.execute(context);
        return true;
    }
    
}
