package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import org.joml.Vector3f;

/**
 * 属性 {@code EFXAttributeVelocity3D}：初速度与方向（对应 json 的 {@code type} = 78）。
 * <p>
 * {@code directionVectorX/Y/Z}、{@code speed}、{@code speedCoef}、{@code gravityRate} 都是
 * {@code {s, r}} 数值对；{@code speedDelayFrame} / {@code gravityDelayFrame} 是整数对。
 * {@code offset} 与 {@code size} 都是三分量向量，<b>不是</b>数值对——因此 {@code size} 是"随机方向的
 * 逐轴椭球半径"，与速度大小无关；速度的随机量只来自 {@code speed.r}。
 * <p>
 * {@code velocityType} 是模式选择字段，本属性只承载不使用，消费侧的径向判定见各视图注释；
 * {@code inheritRate} / {@code inheritDistance} / {@code spread} 为宿主速度继承相关字段，本项目不映射。
 * <p>
 * 单位：速度按"格 / EFX 帧"，重力按"格 / EFX 帧²"（帧为 60fps，本项目渲染侧再按
 * {@code 1 tick = 3 帧} 折算）。
 *
 * @param flags             速度标志位
 * @param directionVectorX  主方向 X（{@code s} 为基准方向分量、{@code r} 为随机幅度）
 * @param directionVectorY  主方向 Y
 * @param directionVectorZ  主方向 Z
 * @param speed             速度大小（格 / 帧；{@code r} 为随机幅度）
 * @param speedCoef         速度逐帧衰减系数
 * @param speedDelayFrame   开始施加速度的延迟（帧）
 * @param offset            生成位置偏移
 * @param size              随机方向的逐轴椭球半径（与速度大小无关）
 * @param velocityType      速度类型（0 = Direction、1 = Normal、2 = Radial、3 = Spread、4 = ScreenSpace）
 * @param gravityRate       重力（格 / 帧²）
 * @param gravityDelayFrame 开始施加重力的延迟（帧）
 * @param inheritRate       宿主速度继承比例
 * @param inheritDistance   继承距离
 * @param spread            额外散布
 */
public record EfxAttributeVelocity3D(
    int flags,
    EfxRange directionVectorX,
    EfxRange directionVectorY,
    EfxRange directionVectorZ,
    EfxRange speed,
    EfxRange speedCoef,
    EfxRange speedDelayFrame,
    Vector3f offset,
    Vector3f size,
    int velocityType,
    EfxRange gravityRate,
    EfxRange gravityDelayFrame,
    EfxRange inheritRate,
    EfxRange inheritDistance,
    EfxRange spread
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 78;
    
    /**
     * 默认值：静止、无方向。
     */
    public static final EfxAttributeVelocity3D DEFAULT = new EfxAttributeVelocity3D(
        0, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
        EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
        new Vector3f(), new Vector3f(), 0,
        EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeVelocity3D";
    }
    
    /**
     * 主方向（由三个分量的基准值构成的向量），零向量表示不使用方向模式。
     */
    public Vector3f direction() {
        return new Vector3f(this.directionVectorX.s(), this.directionVectorY.s(), this.directionVectorZ.s());
    }
    
    /**
     * 是否存在有效的主方向（零向量表示"按发射器方向/随机"）。
     * <p>
     * 注意：{@code VelocityType} 才明确给出模式（0 = Direction、2 = Radial 等），
     * 本方法只是"方向向量是否为零"的便利判断，不等价于 {@code VelocityType}。
     */
    public boolean hasDirection() {
        return this.direction().lengthSquared() > 1.0E-6F;
    }
}
