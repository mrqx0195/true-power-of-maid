package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

/**
 * 「次元斩·絶」<b>范围效果</b>的飘带层预设：唯一条目 {@code 範囲　GPU}，用全项目唯一的 {@link EfxTypeGpuRibbonFollow}
 * （{@code type = 277}），由 {@code RibbonEmitterManager} 把轨迹拉成三角形带。
 */
public final class EfxJceRangeRibbonPresets {
    /**
     * 拼出贴图完整路径（TextureManager 需要 {@code textures/….png} 全路径）。
     */
    public static ResourceLocation texture(String name) {
        return MrqxSlashBladeCore.prefix("textures/effect/" + name + ".png");
    }
    
    /**
     * {@code 範囲　GPU}：水平效果范围边缘持续生成、逆时针螺旋向内收拢的黑色烟雾飘带；每批只投一条，生成后一直保持到效果结束。
     * <p>
     * 宽度照 EFX 的 {@code SizeScalar} 且整条生命期恒定——实测 {@code ScaleAnim} 对飘带无效，视图故不提供尺寸衰减字段；
     * 颜色 RGB 无效、恒纯黑而只有 alpha 生效，故取普通 alpha 混合而不是加算（纯黑加算 = 不画）。
     */
    public static final EfxConfig RANGE_RIBBON = EfxConfigBuilder.create(
            new EfxTypeGpuRibbonFollow(
                3, 0x3400247D, 0x80001AFF, 10, 0, 0, 0,
                0, 0, 0, 0,
                new EfxRange(2, 0.4F),
                0, 0, 8))
        .put(new EfxAttributeTransform3DModifier(2, 0.017453294F, 1.0F))
        .put(new EfxAttributeSpawn(1, 0, 5, 5, 0, 0, 0, false, 35, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(16, 16), EfxRange.ZERO,
            new EfxRange(18, 18), EfxRange.ZERO, 1))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(0.5F, 0.5F), new EfxRange(0, 1), new EfxRange(0, 1),
            new EfxRange(-39, 2), new EfxRange(1, 0), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1, 1, 1),
            2,
            new EfxRange(-6, 0), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.01F, 0.01F), new EfxRange(0.96F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(5, 4), new EfxRange(-0.5F, 0.5F), new EfxRange(5, 0),
            2, 0, 1, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1, 0), new EfxRange(25, 10),
            new EfxRange(1, 1), 10, EfxJceRangeRibbonPresets.texture("fire_ribbon"), 64))
        .put(new EfxAttributeShaderSettings(0.5F, -0.5F, 4, 0xFF000000, 1))
        .build();
}
