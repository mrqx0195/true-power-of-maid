package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range;

import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeLife;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeTransform3D;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxBehaviorValue;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeNoDraw;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack.EfxJceNoDrawPresets;
import org.joml.Vector3f;

/**
 * 「次元斩·絶」<b>范围效果</b>里脚本驱动层（{@code TypeNoDraw} + {@code PtBehavior}）的 EFX 预设。
 * <p>
 * 与 {@link EfxJceNoDrawPresets} 同一思路，数值逐字段照 EFX 数据书写。
 */
public final class EfxJceRangeNoDrawPresets {
    /**
     * {@code カメラシェイク小}：范围技起手的镜头震动。
     */
    public static final EfxConfig CAMERA_SHAKE = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(EfxJceNoDrawPresets.spawn(5))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(3.0F, 3.0F),
            new EfxRange(14.0F, 14.0F), EfxRange.ZERO, 1))
        .put(EfxJceNoDrawPresets.behavior("EffectShakeCameraCustom",
            EfxJceNoDrawPresets.prop("Period", EfxBehaviorValue.ofRaw(20, 0x0000000100000003L, 8)),
            EfxJceNoDrawPresets.prop("TranslationYRange", EfxBehaviorValue.ofFloat2(-0.03F, 0.06F)),
            EfxJceNoDrawPresets.prop("TranslationZRange", EfxBehaviorValue.ofFloat2(-0.03F, 0.06F)),
            EfxJceNoDrawPresets.prop("RotationXRange", EfxBehaviorValue.ofFloat2(-0.12F, 0.24F)),
            EfxJceNoDrawPresets.prop("RotationYRange", EfxBehaviorValue.ofFloat2(-0.12F, 0.24F)),
            EfxJceNoDrawPresets.prop("RotationZRange", EfxBehaviorValue.ofFloat2(-0.12F, 0.24F)),
            EfxJceNoDrawPresets.prop("UseDistanceAttenuation", EfxBehaviorValue.ofInt(1)),
            EfxJceNoDrawPresets.prop("DistanceAttenuationStart", EfxBehaviorValue.ofFloat(40.0F)),
            EfxJceNoDrawPresets.prop("DistanceAttenuationEnd", EfxBehaviorValue.ofFloat(70.0F)),
            EfxJceNoDrawPresets.prop("UseAngleAttenuation", EfxBehaviorValue.ofInt(1))))
        .build();
    
    /**
     * {@code ライト}：脚下 0.7 格处的青蓝色补光，颜色已按项目口径交换 R / B，<b>不要</b>按 EFX 数据原值改回。
     */
    public static final EfxConfig LIGHT = EfxConfigBuilder.create(
            new EfxTypeNoDraw(0, 0xFF45ACFF, 0xFFFFFFFF, 4, new Vector3f(), new Vector3f(),
                new Vector3f(1.0F, 0.0F, 1.0F), new Vector3f(0.0F, 1.0F, 0.0F), 0, 0))
        .put(EfxJceNoDrawPresets.spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 0.7F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(20.0F, 20.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 1))
        .put(EfxJceNoDrawPresets.behavior("EffectLight5000lm",
            EfxJceNoDrawPresets.prop("Intensity", EfxBehaviorValue.ofFloat(50000.0F)),
            EfxJceNoDrawPresets.prop("IntensityAmplitudeMin", EfxBehaviorValue.ofFloat(0.0F)),
            EfxJceNoDrawPresets.prop("IntensityAmplitudeMax", EfxBehaviorValue.ofFloat(0.0F)),
            EfxJceNoDrawPresets.prop("IntensityAmplitudeChangeFrameMin", EfxBehaviorValue.ofFloat(4.0F)),
            EfxJceNoDrawPresets.prop("IntensityAmplitudeChangeFrameMax", EfxBehaviorValue.ofFloat(5.0F)),
            EfxJceNoDrawPresets.prop("Radius", EfxBehaviorValue.ofFloat(0.5F)),
            EfxJceNoDrawPresets.prop("ReferenceEffectiveRange", EfxBehaviorValue.ofFloat(6.0F)),
            EfxJceNoDrawPresets.prop("ShadowEnable", EfxBehaviorValue.ofInt(0))))
        .build();
    
    /**
     * {@code radial_blur}：起手瞬间的整屏径向模糊。
     */
    public static final EfxConfig RADIAL_BLUR = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(EfxJceNoDrawPresets.spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(10.0F, 10.0F), new EfxRange(10.0F, 10.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(EfxJceNoDrawPresets.behavior("EffectRadialBlur",
            EfxJceNoDrawPresets.prop("Priority", EfxBehaviorValue.ofRaw(3, 0L, 4)),
            EfxJceNoDrawPresets.prop("ColorRate", EfxBehaviorValue.ofFloat(2.0F)),
            EfxJceNoDrawPresets.prop("BlurPower", EfxBehaviorValue.ofFloat(20.0F)),
            EfxJceNoDrawPresets.prop("LookAtType", EfxBehaviorValue.ofEnum(0))))
        .build();
    
    /**
     * {@code radial_blur0}：收束期只糊住画面一角的弱模糊。
     */
    public static final EfxConfig RADIAL_BLUR_LOCAL = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(EfxJceNoDrawPresets.spawn(30))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(10.0F, 10.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 1))
        .put(EfxJceNoDrawPresets.behavior("EffectRadialBlur",
            EfxJceNoDrawPresets.prop("Priority", EfxBehaviorValue.ofRaw(3, 0L, 4)),
            EfxJceNoDrawPresets.prop("ColorRate", EfxBehaviorValue.ofFloat(0.5F)),
            EfxJceNoDrawPresets.prop("BlurPower", EfxBehaviorValue.ofFloat(0.5F)),
            EfxJceNoDrawPresets.prop("MaskRate", EfxBehaviorValue.ofFloat(1.0F)),
            EfxJceNoDrawPresets.prop("MaskSmoothstep", EfxBehaviorValue.ofFloat2(0.0F, 0.1F)),
            EfxJceNoDrawPresets.prop("LookAtType", EfxBehaviorValue.ofEnum(1)),
            EfxJceNoDrawPresets.prop("ScreenPosition", EfxBehaviorValue.ofRange(0.0F, 1.0F))))
        .build();
    
    /**
     * {@code デカール}：命中点下方的地面印记。
     * <p>
     * 本层位置是世界位置；执行者 {@code DecalScriptAdapter} 会先把预设里的同名偏移归零，避免两处偏移叠加。
     */
    public static final EfxConfig DECAL = EfxConfigBuilder.create(
            new EfxTypeNoDraw(0, 0xFFFFFFFF, 0x342E82FF, 4, new Vector3f(), new Vector3f(),
                new Vector3f(1.0F, 0.0F, 1.0F), new Vector3f(0.0F, 1.0F, 0.0F), 0, 0))
        .put(EfxJceNoDrawPresets.spawn(10))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 4.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(50.0F, 50.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 1))
        .put(EfxJceNoDrawPresets.behavior("EffectDecal",
            // 贴花资源未随本次移植入库，留空表示该层当前不生成任何贴花
            EfxJceNoDrawPresets.prop("DecalPrefab", EfxBehaviorValue.ofPrefabPath("")),
            EfxJceNoDrawPresets.prop("DecalDirection", EfxBehaviorValue.ofEnum(3)),
            EfxJceNoDrawPresets.prop("DecalUpDirection", EfxBehaviorValue.ofEnum(0)),
            EfxJceNoDrawPresets.prop("RandomRollRange", EfxBehaviorValue.ofFloat(180.0F)),
            EfxJceNoDrawPresets.prop("Extent", EfxBehaviorValue.ofFloat3(20.0F, 3.0F, 20.0F)),
            EfxJceNoDrawPresets.prop("ScaleXY", EfxBehaviorValue.ofFloat2(1.0F, 0.0F)),
            EfxJceNoDrawPresets.prop("SearchTerrainDistance", EfxBehaviorValue.ofFloat(6.0F)),
            EfxJceNoDrawPresets.prop("BaseColorMod", EfxBehaviorValue.ofColor(0xFF131A27)),
            EfxJceNoDrawPresets.prop("EmissiveMod", EfxBehaviorValue.ofColor(0xFF0C0F22))))
        .build();
}
