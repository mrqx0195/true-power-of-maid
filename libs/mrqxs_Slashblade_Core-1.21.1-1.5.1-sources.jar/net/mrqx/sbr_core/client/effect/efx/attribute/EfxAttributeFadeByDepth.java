package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * 属性 {@code EFXAttributeFadeByDepth}：按相机距离淡出（对应 json 的 {@code type} = 113）。
 * <p>
 * 语义为"过近淡出区间 + 过远淡出区间"：距离小于 {@code nearEnd} 时逐渐透明，
 * 大于 {@code farStart} 时逐渐透明，两段之间完全不透明。缺少该属性即"不做距离淡出"。
 * <p>
 * 四个值都是独立 float，字段名即 {@code NearStart / NearEnd / FarStart / FarEnd}，与
 * {@code FadeByDepthExpression} 的位名一一对应——即"近端淡出区间 + 远端淡出区间"的读法成立。
 * 单位按"格"使用（量级与格一致），区间内部的插值方式未给出，本项目取线性。
 *
 * @param nearStart 近端开始淡出的距离（格）
 * @param nearEnd   近端完全消失的距离（格）
 * @param farStart  远端开始淡出的距离（格）
 * @param farEnd    远端完全消失的距离（格）
 */
public record EfxAttributeFadeByDepth(
    float nearStart,
    float nearEnd,
    float farStart,
    float farEnd
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 113;
    
    /**
     * 默认值：不淡出。
     */
    public static final EfxAttributeFadeByDepth DEFAULT = new EfxAttributeFadeByDepth(0.0F, 0.0F, 0.0F, 0.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeFadeByDepth";
    }
}
