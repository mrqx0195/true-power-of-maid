package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：网格层的<b>屏幕空间逐通道增益 + 色散</b>通道。
 * <p>
 * 该层不是彩色球体，而是伪装成网格绘制的屏幕空间后处理：颜色只来自已渲染画面
 * （{@code DynamicTransparentHDR}），球体几何仅贡献遮罩；片元内做逐通道乘性增益
 * {@code c0 × (1 + r4 × (ColorParam.rgb − 1))}，再由 {@code ColorParam.w} 与画面融合。
 * 该形式与 {@link EfxAttributeColorFilter}（向目标色收敛）代数不同，故另立并列通道，由
 * {@code dis_ware_distortion.fsh} 的模式位区分，不改动旧通道的任何行为。
 *
 * @param gainColor         逐通道增益的目标色（常规 ARGB）：{@code rgb} 即 {@code ColorParam.rgb}，{@code a} 即 {@code ColorParam.w}
 *                          （与画面的融合权重）；{@code 0xFFFFFFFF} 表示增益恒等、只剩色散
 * @param dispersion        色散幅度系数，已按 {@code screenSize} 口径折算但尚未除视深（视深由写入侧近似补上），
 *                          {@code 0} 表示不色散；三次采样中 {@code .r} 路偏移被丢弃，实际只有 {@code .g} / {@code .b} 有效
 * @param sphereWeightPower 球面权重指数，口径为 {@code (N·V)^p}：球心权重最大、掠射最小，
 *                          与本项目顶点侧既有的 {@code pow(1 − N·V, p)} <b>方向相反</b>，不可混用
 * @param edgeScale         屏幕边缘遮罩的缩放
 * @param edgeGradation     屏幕边缘遮罩的渐变，与 {@code edgeScale} 配合把屏幕四边外侧约 10% 平滑压到 0
 */
public record EfxAttributeScreenGrading(
    int gainColor,
    float dispersion,
    float sphereWeightPower,
    float edgeScale,
    float edgeGradation
) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -10;
    
    /**
     * 中性默认值（该层未配置本属性时的状态）：增益恒等、不色散、球面权重指数 1、无屏幕边缘遮罩。
     */
    public static final EfxAttributeScreenGrading DEFAULT =
        new EfxAttributeScreenGrading(0xFFFFFFFF, 0.0F, 1.0F, 0.0F, 0.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeScreenGrading";
    }
    
    /**
     * 该层是否真的参与这条通道：允许存在一个"什么都没做"的实例（增益恒等且不色散），
     * 因此读取侧不能只看属性是否存在；增益非恒等或色散非零时返回 true。
     */
    public boolean enabled() {
        return this.gainColor != 0xFFFFFFFF || this.dispersion != 0.0F;
    }
    
    /**
     * 增益目标色的 RGB 是否恒等（纯白）：为 true 时 {@code gain ≡ 1}，该层只剩色散、没有色偏，
     * 即色彩校正层当前数据（{@code color1 = 0xCCFFFFFF}）的情形；把 {@code Color} 改成非白才会出现色偏。
     */
    public boolean gainIsIdentity() {
        return (this.gainColor & 0xFFFFFF) == 0xFFFFFF;
    }
}
