package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

import javax.annotation.Nullable;

/**
 * 属性 {@code EFXAttributeUVSequence}：贴图与序列帧（对应 json 的 {@code type} = 89）。
 * <p>
 * 素材约定：图集固定 <b>8 列</b>（见 {@code EfxPolygonView#FRAME_COLUMNS}），行数 = {@code atlasFrameCount / 8}。
 * <p>
 * 字段语义：{@code patternNo.s} 为播放帧数、{@code patternNo.r} 为随机起始帧幅度（为 0 即固定从第 0 帧起播，
 * 见 {@link #randomStartFrame()}）、{@code playSpeed} 为每逻辑帧推进的序列帧数、{@code flags} 仅承载不消费、
 * {@code resource} 为 {@code null} 时回退兜底贴图、{@code atlasFrameCount} 为素材图集实际总帧数（{@code 0} 时等于 {@link #frameCount()}）。
 * <p>
 * {@code patternNo.s} 不能用来推 UV 行数：图集 64 帧而 {@code PatternNo = 32} 只播前一半时，早期按播放帧数算行数
 * 曾使整层火焰错位拉伸，故素材实际总帧数必须由 {@code atlasFrameCount} 单独承载。
 */
public record EfxAttributeUVSequence(
    EfxRange sequenceNo,
    EfxRange patternNo,
    EfxRange playSpeed,
    int flags,
    @Nullable ResourceLocation resource,
    int atlasFrameCount
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 89;
    
    /**
     * 默认值：单帧贴图、无贴图资源。
     */
    public static final EfxAttributeUVSequence DEFAULT = new EfxAttributeUVSequence(
        EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO, 0, null);
    
    /**
     * 兼容构造器：不声明素材总帧数，按"图集恰好只有 {@code PatternNo} 帧"处理；参数含义见类 Javadoc。
     */
    public EfxAttributeUVSequence(EfxRange sequenceNo, EfxRange patternNo, EfxRange playSpeed,
                                  int flags, @Nullable ResourceLocation resource) {
        this(sequenceNo, patternNo, playSpeed, flags, resource, 0);
    }
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeUVSequence";
    }
    
    /**
     * 帧总数（至少 1）。
     */
    public int frameCount() {
        return Math.max(1, Math.round(this.patternNo.s()));
    }
    
    /**
     * 序列帧的起始帧是否随机：依据 {@code PatternNo.r}，为 0 时所有实例都从第 0 帧开始播放。
     */
    public boolean randomStartFrame() {
        return this.patternNo.r() != 0.0F;
    }
    
    /**
     * 素材图集的实际总帧数（{@code 0} 时退回 {@link #frameCount()}）；读取侧推算 UV 行数一律用它。
     */
    public int atlasFrameCount() {
        return this.atlasFrameCount > 0 ? this.atlasFrameCount : this.frameCount();
    }
}
