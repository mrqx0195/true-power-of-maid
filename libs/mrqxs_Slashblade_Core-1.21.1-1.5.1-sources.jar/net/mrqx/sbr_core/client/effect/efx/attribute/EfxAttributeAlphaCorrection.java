package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * 属性 {@code EFXAttributeAlphaCorrection}：贴图 alpha 的**曲线校正**（对应 json 的 {@code type} = 99）。
 * <p>
 * 它在引擎里是**顶点流通道的输入**：顶点阶段据此算出插值量 `AlphaCorrection0 = (下界, 宽度, 两路权重, 直通权重)`，
 * 片元阶段再用它合成一条曲线。材质侧的算式是
 * {@code saturate((贴图 alpha ^ 4.84 − lowPass) ÷ highPass)}：{@code lowPass} 是曲线**起点**、
 * {@code highPass} 是**宽度**，<b>不是</b>"低于即丢弃"的硬阈值——材质侧全程没有 {@code discard}。
 * 也就是说刀光的"纤细"来自这条曲线的压制，而不是裁切。
 * <p>
 * ⚠ <b>本项目当前只做了一条近似曲线，形状与引擎的"情形 1"并<b>不</b>相同</b>（差别有三处：
 * 线性 {@code saturate} 对 {@code smoothstep}、曲线输入用贴图 alpha 对"贴图 alpha × 顶点 alpha"、
 * 以及输出是否再乘一次该乘积）。差别的逐指令依据记在改进清单的 A10 重判结论里；
 * 本项目另有的 {@code CurveConst}（曲线形态参数）与低版本的 {@code Flags}（模式）未建模，
 * 原作的另两个自由度（两路权重）来自逐顶点插值通道，本项目的顶点格式装不下。
 *
 * @param lowPass  曲线起点，定义在 {@code 贴图 alpha ^ 4.84} 的域上；等效的原始 alpha 阈值是 {@code pow(lowPass, 1/4.84)}（如 {@code 0.2 → 0.717}、{@code 0.795 → 0.953}）
 * @param highPass 曲线宽度；当 {@code lowPass >= highPass} 时该属性视为无效（不做校正）
 */
public record EfxAttributeAlphaCorrection(
    float lowPass,
    float highPass
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 99;
    
    /**
     * 默认值：不裁切。
     */
    public static final EfxAttributeAlphaCorrection DEFAULT = new EfxAttributeAlphaCorrection(0.0F, 1.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeAlphaCorrection";
    }
}
