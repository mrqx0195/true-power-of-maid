package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import org.joml.Vector3f;

/**
 * 矢量场参数属性（{@code EFXAttributeVectorFieldParameter}，{@code type = 137}）。
 * <p>
 * 它让粒子在噪声场里"被卷着走"。全文件只有 {@code 収束　炎2}（五千实例的晶尘层）用到，
 * 其参数为：{@code Parameter = (6, 1, 1.5)}、{@code Lacunarity = 0.5}、{@code Gain = 0.31}、
 * {@code Blend = 3}、{@code lfoRange = 10}、{@code Rotation = (0, 0, 1)}、
 * {@code Scale = (1, 1, 1.01)}、{@code Coefficient = 0 ± 7E-45}。
 * <p>
 * <b>场贴图</b>：数据尾部的 {@code FieldParameterValues} 给出一张场遮罩贴图，已入库为
 * {@code textures/effect/vector_field.png}；本项目的实现用<b>程序化 value noise</b> 取代它
 * （见 {@code PolygonParticle} 的矢量场扰动），因此该贴图目前只作素材保留。
 * <p>
 * <b>不参与映射的字段</b>：{@code EdgeOffset} / {@code Falloff} / {@code FieldIndex}
 * 在现有数据里都是 0；{@code Rotation} 与 {@code Scale} 描述的是"场自身的朝向与缩放"，
 * 本项目只取 {@code Scale} 的 Z 分量作为各向异性的提示（现有数据接近 1，等同各向同性）。
 *
 * @param parameter   场参数：{@code x} 解读为噪声波长（格）、{@code y} 为场强量级；
 *                    ⚠ {@code z} <b>不参与映射</b>——它曾被本项目解读为"螺旋角速度"（因为那时
 *                    找不到绕中心公转的字段），后已退役：数据里其实有专门的
 *                    {@link EfxAttributeTransform3DModifier}（飘带层与面片层都真实存在），
 *                    而给"唯一空着的分量"安解释没有依据，且与前者机制不同（一个转速度、一个转位置）
 * @param lacunarity  多倍频的波长倍率（fBm 的 lacunarity）
 * @param gain        多倍频的幅度倍率（fBm 的 gain）
 * @param blend       场的混合模式（现有数据为 3，语义未确认）
 * @param lfoRange    LFO 周期（帧），用于让场自身缓慢流动
 * @param rotation    场自身的旋转
 * @param scale       场自身的缩放（各向异性）
 * @param coefficient 场强系数；现有数据退化到浮点最小值，无法照抄
 * @param edgeOffset  边缘偏移
 * @param falloff     衰减
 * @param fieldIndex  场贴图索引
 */
public record EfxAttributeVectorFieldParameter(
    Vector3f parameter,
    float lacunarity,
    float gain,
    int blend,
    float lfoRange,
    Vector3f rotation,
    Vector3f scale,
    EfxRange coefficient,
    float edgeOffset,
    float falloff,
    int fieldIndex
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 137;
    
    /**
     * 默认值：不施加任何扰动。
     */
    public static final EfxAttributeVectorFieldParameter DEFAULT = new EfxAttributeVectorFieldParameter(
        new Vector3f(), 0.0F, 0.0F, 0, 0.0F, new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F),
        EfxRange.ZERO, 0.0F, 0.0F, 0);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeVectorFieldParameter";
    }
}
