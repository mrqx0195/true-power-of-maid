package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

import java.util.List;

/**
 * 「次元斩·絶」脚本驱动层（{@code TypeNoDraw} + {@code PtBehavior}）的 EFX 预设，本身不绘制几何。
 * <p>
 * 位置与时长必须留在 EFX 上：抄进调用点会把落点写错成相机局部位置。生命三段按 EFX 帧数原样写入
 * （60fps → 项目 20tps，1 tick = 3 帧），帧 → tick 由 {@code EfxNoDrawView} 折算。
 * <p>
 * 颜色按项目统一口径由 EFX 数据的 {@code rgba}（R 在最低字节）交换 R / B 转成 ARGB；收尾段三层即文末的 {@code TAIL_*} 常量。
 */
public final class EfxJceNoDrawPresets {
    public static final ResourceLocation LUT01 =
        MrqxSlashBladeCore.prefix("textures/effect/lut01.png");
    
    public static final ResourceLocation LUT06 =
        MrqxSlashBladeCore.prefix("textures/effect/lut06.png");
    
    /**
     * {@code 黒フィルター}：斩击瞬间的径向模糊；本层位置是世界位置，{@code LocalPosition} 指向命中点上方，<b>不是屏幕中心</b>。
     */
    public static final EfxConfig BLACK_FILTER = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 3.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(30.0F, 30.0F),
            new EfxRange(1.0F, 1.0F), EfxRange.ZERO, 0))
        .put(behavior("EffectRadialBlur",
            prop("Priority", EfxBehaviorValue.ofRaw(3, 110L, 4)),
            prop("ColorRate", EfxBehaviorValue.ofFloat(0.3F)),
            prop("BlurPower", EfxBehaviorValue.ofFloat(5.0F)),
            prop("EnableFadeDistance", EfxBehaviorValue.ofInt(1)),
            prop("FadeStartDistance", EfxBehaviorValue.ofFloat(28.0F)),
            prop("FadeEndDistance", EfxBehaviorValue.ofFloat(31.0F))))
        .build();
    
    /**
     * {@code カメラシェイク小0}：斩击瞬间的轻微镜头震动。
     */
    public static final EfxConfig CAMERA_SHAKE = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(40.0F, 40.0F),
            new EfxRange(1.0F, 1.0F), EfxRange.ZERO, 0))
        .put(behavior("EffectShakeCameraCustom",
            prop("Period", EfxBehaviorValue.ofRaw(20, 0x0000000100000000L, 8)),
            prop("TranslationXRange", EfxBehaviorValue.ofFloat2(-0.05F, 0.1F)),
            prop("TranslationYRange", EfxBehaviorValue.ofFloat2(-0.05F, 0.1F)),
            prop("TranslationZRange", EfxBehaviorValue.ofFloat2(-0.05F, 0.1F)),
            prop("RotationXRange", EfxBehaviorValue.ofFloat2(-0.1F, 0.2F)),
            prop("RotationYRange", EfxBehaviorValue.ofFloat2(-0.1F, 0.2F)),
            prop("RotationZRange", EfxBehaviorValue.ofFloat2(-0.1F, 0.2F)),
            prop("UseDistanceAttenuation", EfxBehaviorValue.ofInt(1)),
            prop("DistanceAttenuationStart", EfxBehaviorValue.ofFloat(60.0F)),
            prop("DistanceAttenuationEnd", EfxBehaviorValue.ofFloat(80.0F)),
            prop("UseAngleAttenuation", EfxBehaviorValue.ofInt(1))))
        .build();
    
    /**
     * {@code ライト2}：命中点上方 3 格的点光源。
     * <p>
     * 本层的 {@code Intensity} 与调制跳变间隔是<b>有意保留的手调值</b>，不要按 EFX 数据原值改回。
     */
    public static final EfxConfig LIGHT = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 3.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(30.0F, 30.0F),
            new EfxRange(1.0F, 1.0F), EfxRange.ZERO, 0))
        .put(behavior("EffectLight5000lm",
            prop("Intensity", EfxBehaviorValue.ofFloat(2500.0F)),
            prop("IntensityAmplitudeMin", EfxBehaviorValue.ofFloat(0.8F)),
            prop("IntensityAmplitudeMax", EfxBehaviorValue.ofFloat(1.0F)),
            prop("IntensityAmplitudeChangeFrameMin", EfxBehaviorValue.ofFloat(7.0F)),
            prop("IntensityAmplitudeChangeFrameMax", EfxBehaviorValue.ofFloat(3.0F)),
            prop("Radius", EfxBehaviorValue.ofFloat(1.9F)),
            prop("ReferenceEffectiveRange", EfxBehaviorValue.ofFloat(30.0F)),
            prop("ShadowEnable", EfxBehaviorValue.ofInt(0))))
        .build();
    
    /**
     * {@code ☆カラコレ}：斩击瞬间的 LUT 色彩校正。
     */
    public static final EfxConfig CHROMA_LUT = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(10))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), EfxRange.ZERO,
            new EfxRange(1.0F, 1.0F), EfxRange.ZERO, 1))
        .put(behavior("EffectColorCorrect",
            prop("Priority", EfxBehaviorValue.ofRaw(3, 0L, 4)),
            prop("PriorityType", EfxBehaviorValue.ofEnum(0)),
            prop("Cube2Texture", EfxBehaviorValue.ofResource(LUT01)),
            prop("Cube2BlendRateMax", EfxBehaviorValue.ofFloat(1.0F))))
        .build();
    
    /**
     * {@code カメラシェイク小}：崩解收尾的一次镜头震动。
     */
    public static final EfxConfig TAIL_CAMERA_SHAKE = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(20.0F, 20.0F),
            new EfxRange(40.0F, 40.0F), EfxRange.ZERO, 0))
        .put(behavior("EffectShakeCameraCustom",
            prop("Period", EfxBehaviorValue.ofRaw(20, 4L, 8)),
            prop("TranslationXRange", EfxBehaviorValue.ofFloat2(-0.15F, 0.3F)),
            prop("TranslationYRange", EfxBehaviorValue.ofFloat2(-0.15F, 0.3F)),
            prop("TranslationZRange", EfxBehaviorValue.ofFloat2(-0.15F, 0.3F)),
            prop("RotationXRange", EfxBehaviorValue.ofFloat2(-0.5F, 1.0F)),
            prop("RotationYRange", EfxBehaviorValue.ofFloat2(-0.5F, 1.0F)),
            prop("RotationZRange", EfxBehaviorValue.ofFloat2(-0.5F, 1.0F)),
            prop("UseDistanceAttenuation", EfxBehaviorValue.ofInt(1)),
            prop("DistanceAttenuationStart", EfxBehaviorValue.ofFloat(60.0F)),
            prop("DistanceAttenuationEnd", EfxBehaviorValue.ofFloat(80.0F)),
            prop("UseAngleAttenuation", EfxBehaviorValue.ofInt(1))))
        .build();
    
    /**
     * {@code radial_blur}：收尾段的径向模糊。
     */
    public static final EfxConfig TAIL_RADIAL_BLUR = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(0))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(10.0F, 10.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(behavior("EffectRadialBlur",
            prop("Priority", EfxBehaviorValue.ofRaw(3, 0L, 4)),
            prop("ColorRate", EfxBehaviorValue.ofFloat(2.0F)),
            prop("BlurPower", EfxBehaviorValue.ofFloat(20.0F)),
            prop("LookAtType", EfxBehaviorValue.ofEnum(0))))
        .build();
    
    /**
     * {@code カラコレ}：收尾段的 LUT 色彩校正。
     * <p>
     * 生命三段 {@code 0 / 22 / 10} 是<b>有意保留的手调值</b>，<b>不要</b>按 EFX 数据原值改回。
     */
    public static final EfxConfig TAIL_CHROMA_LUT = EfxConfigBuilder.create(EfxTypeNoDraw.DEFAULT)
        .put(spawn(2))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(22.0F, 22.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(behavior("EffectColorCorrect",
            prop("Priority", EfxBehaviorValue.ofRaw(3, 0L, 4)),
            prop("PriorityType", EfxBehaviorValue.ofEnum(0)),
            prop("Cube2Texture", EfxBehaviorValue.ofResource(LUT06)),
            prop("Cube2BlendRateMax", EfxBehaviorValue.ofFloat(1.25F))))
        .build();
    
    /**
     * 构造脚本驱动层共用的生成属性：{@code MaxParticles = 1}、单批，仅生成帧因层而异。
     */
    public static EfxAttributeSpawn spawn(int spawnFrame) {
        return new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, spawnFrame, 0, 0, 0,
            false, false, false, false, 0, false);
    }
    
    /**
     * 构造脚本属性（自动补上 {@code via.effect.script.} 前缀）。
     */
    public static EfxAttributePtBehavior behavior(String scriptName, EfxBehaviorProperty... properties) {
        return new EfxAttributePtBehavior(EfxAttributePtBehavior.SCRIPT_PREFIX + scriptName,
            List.of(properties));
    }
    
    /**
     * 构造一项脚本参数。
     */
    public static EfxBehaviorProperty prop(String behaviorProperty, EfxBehaviorValue value) {
        return new EfxBehaviorProperty(behaviorProperty, value);
    }
}
