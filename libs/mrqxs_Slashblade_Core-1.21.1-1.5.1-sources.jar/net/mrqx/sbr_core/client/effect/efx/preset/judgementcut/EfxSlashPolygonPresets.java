package net.mrqx.sbr_core.client.effect.efx.preset.judgementcut;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

/**
 * 次元斩（小技能）三套演出的<b>面片类</b>层预设：{@code TypePolygon} 与 {@code TypeBillboard3D}。
 * <p>
 * 三套演出（普通 / 完美 / BOSS）的层名高度重合但<b>数值各不相同</b>，故逐套各写一份常量，常量名以演出名作前缀。
 * <p>
 * <b>与「次元斩·绝」的两点差别</b>：①演出原点是<b>目标位置</b>、不是角色位置，故<b>不</b>叠加任何骨骼抬高；
 * ②本组演出不乘效果范围倍率（由 {@code EfxTimeline#effectRangeScale()} 默认的 {@code 1.0} 给出），
 * 层里的数值就是 EFX 原值。
 */
public final class EfxSlashPolygonPresets {
    /**
     * 拼出贴图完整路径（TextureManager 需要 {@code textures/….png} 全路径）。
     */
    public static ResourceLocation texture(String name) {
        return MrqxSlashBladeCore.prefix("textures/effect/" + name + ".png");
    }
    
    /**
     * 把 EFX 的 {@code LocalPosition} 直接搬进变换属性；本组演出的层都以目标位置为心、不做额外抬高。
     */
    public static EfxAttributeTransform3D at(Vector3f position) {
        return new EfxAttributeTransform3D(position, new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 4);
    }
    
    /**
     * 本组的层统一采用的风味随机策略：EFX 给了固定种子表的层照抄首个槽位，未给的不挂（即每次真随机）。
     */
    public static EfxAttributeFixRandomGenerator seed(int slot0) {
        return new EfxAttributeFixRandomGenerator(1, slot0, -1, -1, -1, 0, 0, 0, 0, 0);
    }
    
    /**
     * 以目标位置为中心、以半径 2 格随机散布的一圈白色弧细线刀光。
     */
    public static final EfxConfig BOSS_EMITTER1 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                1, 0xFF838297, 0xFFFFFFFF, 0.002F, 0.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(1.5707964F, 1.0471976F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 0, 14, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(7.0F, 4.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.2F, 0.1F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(0.08F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_ring_purple")))
        .put(new EfxAttributeShaderSettings(0.1F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 3.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.6108653F, 0.08726647F)))
        .build();
    
    /**
     * 中心黑、边缘黄的<b>分色</b>光晕（{@code Flags = 3} 触发分色，分界由 {@code AlphaRate = 200} 给出）。
     */
    public static final EfxConfig BOSS_MUL_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                3, 0xFF000000, 0xFFFFC231, 50.0F, 0.1F, 800.0F, 0.0F,
                new EfxRange(3.1415927F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 8, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(6.0F, 6.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(0.8F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("glow_dual")))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 蓝色连续闪光：每 4 帧一批、每批两片。
     */
    public static final EfxConfig BOSS_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                18, 0x991A35FF, 0xE50500FF, 1.0F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 4.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 4, 4, 4, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(2.3F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("glow_flash")))
        .put(new EfxAttributeShaderSettings(2.0F, -3.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 4.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 橙色光晕：无渐入段，出生即满强度并随即淡出；沿视线方向外移 0.075 格。
     */
    public static final EfxConfig BOSS_GLOW1 = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                2, 0xFFFF9143, 0xFFFFFFFF, 1.1F, 12.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 3.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                new EfxRange(0.075F, 0.0F)))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 2, 2, 7, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(EfxSlashPolygonPresets.at(new Vector3f(0.0F, 0.0F, 0.5F)))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(3.0F, 3.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("lens_soft")))
        .put(new EfxAttributeShaderSettings(0.1F, -3.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 多道暗蓝色弧形刀光：以 3.5 ± 1 格的量级随机、绕 Z 轴每帧转 0.61 弧度。
     */
    public static final EfxConfig BOSS_EMITTER6 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                4, 0xFF10101F, 0xFFFFFFFF, 1.0F, 8.0F, 1.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(3.5F, 1.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 0, 16, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(6.0F, 5.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.35F, 0.1F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_black")))
        .put(new EfxAttributeShaderSettings(0.5F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 3.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.6108653F, 0.08726647F)))
        .build();
    
    /**
     * 一层暗蓝色圆形面片：缓慢胀大、存在约 18 tick 后淡出。
     */
    public static final EfxConfig BOSS_BLUR0 = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                4, 0x6600030D, 0xFFFFFFFF, 1.0F, 3.1F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 2.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 12, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(13.0F, 13.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(0.8F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("slash_line")))
        .put(new EfxAttributeShaderSettings(2.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(6.0F, 12.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 一圈向内收拢的蓝色烟雾：半径 3 ± 3 格的球面边界上生成、沿径向以负速度收向中心，同时带轻微重力。
     */
    public static final EfxConfig BOSS_REMAIN_SMOKE = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                16, 0xFF4639FF, 0xA81411CC, 5.0F, 0.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 4.0F),
                new EfxRange(0.2F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(6, 0, 1, 1, 0, 0, 6, false, 30, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(1.5707964F, 0.0F, 0.0F),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(15.0F, 10.0F),
            new EfxRange(40.0F, 20.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(-7.5F, 1.5F), new EfxRange(0.96F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 2,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.015F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(1.5F, 1.5F), 553, texture("smoke_converge")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(3.0F, 3.0F), new EfxRange(3.0F, 3.0F), new EfxRange(3.0F, 3.0F),
            1, 10, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(4.5F, 5.5F, 100.0F, 120.0F))
        .build();
    
    /**
     * 多道蓝色弧细线刀光：带固定种子表、绕 Z 轴慢转并逐帧减速，生命末段拉得很长。
     */
    public static final EfxConfig BOSS_SLASH_TRAIL3 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                17, 0xFF1510D4, 0xFF000227, 0.001F, 0.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(-1.5707964F, 3.1415927F),
                new EfxRange(3.5F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(7, 0, 1, 1, 0, 0, 8, false, 20, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(EfxSlashPolygonPresets.seed(130))
        .put(EfxSlashPolygonPresets.at(new Vector3f(0.0F, 0.4F, 0.0F)))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(13.0F, 13.0F),
            new EfxRange(70.0F, 60.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 4, texture("crack_ring_purple")))
        // 曲线会把替代贴图的 alpha 按它自己的上下限缩放到 0~1（见 TextureAlphaRange），缩放的正是"量程"这一项，
        // 所以这里直接用 EFX 原值 0.98——它对应的原始 alpha 阈值是 0.996，即只保留贴图 alpha 最亮的那条脊。
        // 曾为替代贴图（crack_ring_purple 的 alpha 上限只有 0.81）把它折算成 0.795，自动缩放落地后该折算已多余。
        .put(new EfxAttributeAlphaCorrection(0.98F, 1.0F))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(5.0F, 6.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.17453294F, 0.0F)))
        .build();
    
    /**
     * 自身不可见、只提供弧细线折射的层：折射幅度额外乘材质 alpha，故细线中段强、边缘弱。
     */
    public static final EfxConfig BOSS_SLASH_TRAIL1 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                0, 0xFF0056FF, 0xFFFFFFFF, 1.0F, 0.0F, 5.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(3.5F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(7, 0, 1, 1, 0, 0, 8, false, 25, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(EfxSlashPolygonPresets.seed(130))
        .put(EfxSlashPolygonPresets.at(new Vector3f(0.0F, 0.4F, 0.0F)))
        .put(new EfxAttributeLife(new EfxRange(4.0F, 2.0F), new EfxRange(6.0F, 6.0F),
            new EfxRange(40.0F, 34.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 4, texture("crack_ring_purple")))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            2.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 多道亮蓝色弧细线刀光：每帧一批、绕 Z 轴较快扫动，颜色倍率 50 使其明显更亮。
     */
    public static final EfxConfig BOSS_SLASH_TRAIL5 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                0, 0xFF102FC7, 0xFFFFFFFF, 50.0F, 0.0F, 10.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(-2.0943952F, 3.1415927F),
                new EfxRange(3.5F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(7, 0, 1, 1, 1, 1, 8, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(EfxSlashPolygonPresets.seed(130))
        .put(EfxSlashPolygonPresets.at(new Vector3f(0.0F, 0.4F, 0.0F)))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 1.0F), new EfxRange(4.0F, 1.0F),
            new EfxRange(35.0F, 27.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 4, texture("crack_ring_purple")))
        .put(new EfxAttributeAlphaCorrection(1.0F, 1.0F))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 3.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.34906587F, 0.017453294F)))
        .build();
    
    /**
     * 半径 2.5 ± 2.5 格的球面边界上生成、沿径向以负速度收向中心的多片烟雾面片。
     */
    public static final EfxConfig BOSS_FOLLOW2 = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                20, 0xFF2D29FF, 0xFFD9CCFF, 2.0F, 2.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 7.0F),
                new EfxRange(0.3F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(8, 0, 2, 2, 0, 0, 5, false, 18, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3DModifier(2, 0.0F, 1.0F))
        .put(new EfxAttributeLife(new EfxRange(3.0F, 3.0F), new EfxRange(2.0F, 2.0F),
            new EfxRange(25.0F, 20.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(-4.0F, 2.0F), new EfxRange(1.01F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 2,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.01F, 0.002F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(64.0F, 0.0F),
            new EfxRange(0.8F, 1.0F), 105, texture("smoke_follow")))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(2.5F, 2.5F), new EfxRange(2.5F, 2.5F), new EfxRange(2.5F, 2.5F),
            1, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(6.0F, 8.0F, 103.0F, 120.0F))
        .build();
    
    /**
     * 完美变体：一层暗蓝圆形面片，数值与 BOSS 变体不同（用同一张刀光贴图）。
     */
    public static final EfxConfig PERFECT_BLUR0 = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                4, 0x6600090D, 0xFFFFFFFF, 1.0F, 3.1F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 2.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 12, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(13.0F, 13.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(0.8F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("slash_line")))
        .put(new EfxAttributeShaderSettings(2.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(6.0F, 12.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 完美变体：同样是分色光晕，持续段长达 30 帧、并按 {@code SizeScalarAdd = -0.2} 缓慢收缩。
     * <p>
     * 边缘色与普通变体一致补为青蓝：EFX 数据里它的两色都是纯黑（{@code FF000000}），而本层是加法混合，
     * 纯黑在加法下等于什么都不画、整层不可见（实测反馈）。分色渲染只读 {@code ColorRange} 的 RGB
     * （alpha 由材质 alpha 经分界换算），故这里给的就是"边缘呈现的颜色"。
     */
    public static final EfxConfig PERFECT_MUL_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                3, 0xFF000000, 0xB200ABFF, 100.0F, 0.1F, 200.0F, 0.0F,
                new EfxRange(3.1415927F, 5.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 8, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(30.0F, 30.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.2F, 0.0F), new EfxRange(0.93F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("glow_dual")))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 完美变体：命中处的橙色圆环，在 0.75 ± 1.25 格的球内生成两批。
     */
    public static final EfxConfig PERFECT_HIT_RING = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                2, 0xFFFF9143, 0xFFFFFFFF, 1.1F, 20.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 3.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                new EfxRange(0.075F, 0.0F)))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 2, 2, 7, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(3.0F, 3.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("lens_soft")))
        .put(new EfxAttributeEmitterShape3D(
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            0, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(0.1F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 完美变体：多道黑色弧形刀光。
     */
    public static final EfxConfig PERFECT_SLASH_BLACK = EfxConfigBuilder.create(
            new EfxTypePolygon(
                4, 0xFF10101F, 0xFFFFFFFF, 1.0F, 8.0F, 1.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(3.5F, 1.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 0, 12, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(6.0F, 5.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.35F, 0.1F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_black")))
        .put(new EfxAttributeShaderSettings(0.5F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 3.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.6108653F, 0.08726647F)))
        .build();
    
    /**
     * 完美变体：每帧一批的暗青弧细线刀光。
     */
    public static final EfxConfig PERFECT_SLASH_TRAIL2 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                0, 0xFF05171F, 0xFFFFFFFF, 10.0F, 0.0F, 1.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(-2.0943952F, 3.1415927F),
                new EfxRange(3.5F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(7, 0, 1, 1, 1, 1, 8, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(EfxSlashPolygonPresets.seed(130))
        .put(EfxSlashPolygonPresets.at(new Vector3f(0.0F, 0.4F, 0.0F)))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 1.0F), new EfxRange(4.0F, 1.0F),
            new EfxRange(35.0F, 27.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 4, texture("crack_ring_purple")))
        .put(new EfxAttributeAlphaCorrection(1.0F, 1.0F))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 3.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.34906587F, 0.017453294F)))
        .build();
    
    /**
     * 完美变体：自身不可见、只提供弧细线折射，且绕 Z 轴匀速慢转并逐帧减速。
     */
    public static final EfxConfig PERFECT_SLASH_DISTORTION = EfxConfigBuilder.create(
            new EfxTypePolygon(
                0, 0xFF0056FF, 0xFFFFFFFF, 1.0F, 0.0F, 5.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(4.0F, 1.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(3, 0, 1, 1, 0, 0, 3, false, 30, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(4.0F, 2.0F), new EfxRange(6.0F, 6.0F),
            new EfxRange(40.0F, 34.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 4, texture("crack_ring_purple")))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            2.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.5235988F, 0.0F)))
        .build();
    
    /**
     * 完美变体：一层白色模糊面片，本体的颜色不参与（RGB 全白、alpha 走顶点色），可见性来自 {@code BlurTexture} 折射。
     * <p>
     * ⚠ 该层数据的贴图是矢量场图（{@code TEX_Vector}），本项目未取得该素材，
     * 改用既有的程序化矢量场配套贴图；折射类型为 {@code 2 = BlurTexture}，与折射层不是同一条分支。
     */
    public static final EfxConfig PERFECT_BLUR = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                0, 0xFFFFFFFF, 0xFFFFFFFF, 1.0F, 0.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 5.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 20, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(5.0F, 5.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(0.95F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("vector_field")))
        .put(new EfxAttributeDistortion(2, 5.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeShaderSettings(1.0F, -1.5F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 完美变体：一圈光环，绕 X 轴慢转且亮度只有常规层的一半。
     */
    public static final EfxConfig PERFECT_RING = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                1, 0x403E69C0, 0xFFFFFFFF, 2.0F, 0.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 7.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 15, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(5.0F, 5.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.2F, 0.0F), new EfxRange(0.85F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("lens_ring")))
        // 该层数据的 RotateAnim 给了绕 X 轴的自转角速度（0.03490659 弧度 / 帧、每帧衰减 0.9），
        // 而 Billboard3D 不承载 RotationAdd*，故用附加的 EfxAttributeRotateAnim 补上
        // （⚠ 这里的每帧衰减 0.9 目前未被消费：消费侧只取基准角速度，与其它层一致）
        .put(EfxSlashPolygonPresets.attachedRotationX(0.03490659F))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 0.5F))
        .put(new EfxAttributeFadeByDepth(4.0F, 6.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 完美变体：白色弧细线刀光，与 BOSS 变体的 {@code Emitter1} 同源但寿命更短。
     */
    public static final EfxConfig PERFECT_SLASH0 = EfxConfigBuilder.create(
            new EfxTypePolygon(
                17, 0xE5838297, 0x66838297, 0.0015F, 0.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(1.5707964F, 1.0471976F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(4, 0, 1, 1, 0, 0, 12, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(7.0F, 4.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.2F, 0.1F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(0.08F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_ring_purple")))
        .put(new EfxAttributeShaderSettings(0.1F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(3.0F, 5.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.6108653F, 0.08726647F)))
        .build();
    
    /**
     * 完美变体：命中处的金色辉光，球内两批。
     */
    public static final EfxConfig PERFECT_HIT_GLOW0 = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                18, 0x40ABD4F1, 0xB200ABFF, 1.0F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 6, 6, 3, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(2.5F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("glow_flash")))
        .put(new EfxAttributeEmitterShape3D(
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            0, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(2.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 4.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 完美变体独有的一族晶体粒子（{@code 粒　1}）：在 1 ± 1 × 0.1 × 2 ± 2 格的盒内生成、沿径向缓慢外散。
     * <p>
     * {@code Life.Flags} 第 0 位为 1，故保持段要补到本场演出收尾。
     */
    public static final EfxConfig PERFECT_PARTICLE1 = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                64, 6,
                0xFF3481AC, 0xFF040808,
                3.0F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 0.15F),
                new EfxRange(0.05F, 0.0F)))
        .put(new EfxAttributeSpawn(1, 0, 8, 8, 0, 0, 5, false, 5, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(0.0F, -1.5184366F, 0.0F),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeTransform3DModifier(128, 0.0F, 1.0F))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(13.0F, 8.0F),
            new EfxRange(27.0F, 7.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(0.0F, 1.0F), new EfxRange(0.0F, 1.0F), new EfxRange(0.5F, 0.5F),
            new EfxRange(4.0F, 2.0F), new EfxRange(0.93F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(0.1F, 0.8F, 0.1F), 2,
            new EfxRange(-0.05F, 0.05F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.004F, 0.0F), new EfxRange(0.96F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(16.0F, 0.0F),
            new EfxRange(0.5F, 1.5F), 1, texture("crystal_tiny"), 16))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(1.0F, 1.0F), new EfxRange(0.0F, 0.1F), new EfxRange(2.0F, 2.0F),
            0, 10, 1, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 完美变体：{@link #PERFECT_PARTICLE1} 的高密度版本，另带矢量场扰动。
     */
    public static final EfxConfig PERFECT_PARTICLE2 = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                4900, 6,
                0xFF3481AC, 0xFF040808,
                3.0F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 0.1F),
                new EfxRange(0.05F, 0.0F)))
        .put(new EfxAttributeSpawn(1, 0, 70, 70, 0, 0, 5, false, 10, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.1F, 1.1F, 1.1F), 3))
        .put(new EfxAttributeTransform3DModifier(128, 0.0F, 1.0F))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(15.0F, 4.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(0.0F, 0.4539905F), new EfxRange(0.0F, 0.017452406F),
            new EfxRange(-0.94550323F, 0.054496735F),
            new EfxRange(16.0F, 1.0F), new EfxRange(0.86F, 0.01F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.0007F, 0.0005F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(16.0F, 0.0F),
            new EfxRange(0.0F, 0.5F), 553, texture("crystal_tiny"), 16))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(0.5F, 0.5F), EfxRange.ZERO, new EfxRange(0.0F, 1.0F),
            2, 1, 0, 3, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeVectorFieldParameter(
            new Vector3f(20.0F, -3.0F, 1.0F), 1.2F, 0.83F, 3, 10.0F,
            new Vector3f(0.0F, 0.0F, 1.0F), new Vector3f(1.0F, 1.0F, 0.99F),
            new EfxRange(0.008F, 7.0E-45F), 0.0F, 0.0F, 0))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 完美变体：{@link #PERFECT_PARTICLE2} 的更高密度版本，矢量场参数相同。
     */
    public static final EfxConfig PERFECT_PARTICLE3 = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                22500, 6,
                0xFF3481AC, 0xFF040808,
                3.0F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 0.1F),
                new EfxRange(0.05F, 0.0F)))
        .put(new EfxAttributeSpawn(1, 0, 150, 150, 0, 0, 5, false, 14, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.1F, 1.1F, 1.1F), 3))
        .put(new EfxAttributeTransform3DModifier(132, 0.0F, 1.0F))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(22.0F, 4.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(0,
            new EfxRange(0.0F, 0.4539905F), new EfxRange(0.0F, 0.017452406F),
            new EfxRange(-0.94550323F, 0.054496735F),
            new EfxRange(16.0F, 1.0F), new EfxRange(0.86F, 0.01F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F), 0,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.0F, 1.0F), EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.0007F, 0.0005F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(16.0F, 0.0F),
            new EfxRange(0.0F, 0.5F), 553, texture("crystal_tiny"), 16))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(0.5F, 0.5F), EfxRange.ZERO, new EfxRange(0.0F, 1.0F),
            2, 1, 0, 3, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeVectorFieldParameter(
            new Vector3f(20.0F, -3.0F, 1.0F), 1.2F, 0.83F, 3, 10.0F,
            new Vector3f(0.0F, 0.0F, 1.0F), new Vector3f(1.0F, 1.0F, 0.99F),
            new EfxRange(0.008F, 7.0E-45F), 0.0F, 0.0F, 0))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 普通变体：暗蓝圆形面片，保持段比完美变体短。
     */
    public static final EfxConfig NORMAL_BLUR0 = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                4, 0x6600090D, 0xFFFFFFFF, 1.0F, 3.1F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 2.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 12, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(0.8F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("slash_line")))
        .put(new EfxAttributeShaderSettings(2.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(6.0F, 12.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 普通变体：分色光晕，边缘色按本套主色调补为青蓝（EFX 数据里两色都是纯黑，加法混合下整层不可见），
     * 呈现为中央偏暗、边缘发青蓝的光晕。
     */
    public static final EfxConfig NORMAL_MUL_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                3, 0x7F000000, 0xB200ABFF, 100.0F, 0.1F, 200.0F, 0.0F,
                new EfxRange(3.1415927F, 5.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 8, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(5.0F, 5.0F), new EfxRange(30.0F, 30.0F),
            new EfxRange(10.0F, 10.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.2F, 0.0F), new EfxRange(0.93F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("glow_dual")))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 普通变体：命中圆环，亮度与散布半径都比完美变体小。
     */
    public static final EfxConfig NORMAL_HIT_RING = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                2, 0xFFFF9143, 0xFFFFFFFF, 1.1F, 12.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 3.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                new EfxRange(0.075F, 0.0F)))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 2, 2, 7, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(3.0F, 3.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("lens_soft")))
        .put(new EfxAttributeEmitterShape3D(
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            0, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(0.1F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 普通变体：只生成两条的弧细线折射。
     */
    public static final EfxConfig NORMAL_SLASH_DISTORTION = EfxConfigBuilder.create(
            new EfxTypePolygon(
                0, 0xFF0056FF, 0xFFFFFFFF, 1.0F, 0.0F, 5.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(0.0F, 3.1415927F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(4.0F, 1.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 2, 2, 2, false, 25, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(4.0F, 2.0F), new EfxRange(6.0F, 6.0F),
            new EfxRange(40.0F, 34.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 4, texture("crack_ring_purple")))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            2.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.5235988F, 0.0F)))
        .build();
    
    /**
     * 普通变体：白色弧细线刀光，只投两片。
     */
    public static final EfxConfig NORMAL_SLASH = EfxConfigBuilder.create(
            new EfxTypePolygon(
                1, 0xFF838297, 0xFFFFFFFF, 0.0012F, 0.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 3.1415927F), new EfxRange(1.5707964F, 1.0471976F),
                new EfxRange(0.0F, 3.1415927F),
                new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 0, 0, 12, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(7.0F, 4.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.2F, 0.1F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            new EfxRange(0.08F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("crack_ring_purple")))
        .put(new EfxAttributeShaderSettings(0.1F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 3.0F, 100.0F, 120.0F))
        .put(new EfxAttributeRotateAnim(EfxRange.ZERO, EfxRange.ZERO, new EfxRange(0.6108653F, 0.08726647F)))
        .build();
    
    /**
     * 普通变体：一圈光环，绕 <b>X</b> 轴慢转（其余两套的光环层只给画面内滚转，本层给的是三维自转）。
     */
    public static final EfxConfig NORMAL_RING = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                1, 0x143E69C0, 0xFFFFFFFF, 1.0F, 0.0F, 0.0F, 0.0F,
                new EfxRange(3.1415927F, 6.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 15, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(5.0F, 5.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.1F, 0.0F), new EfxRange(0.8F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 552, texture("lens_ring")))
        .put(EfxSlashPolygonPresets.attachedRotationX(0.03490659F))
        .put(new EfxAttributeShaderSettings(1.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * 普通变体：命中处的金色辉光。
     */
    public static final EfxConfig NORMAL_HIT_GLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                18, 0x4CABD4F1, 0xB200ABFF, 1.0F, 1.0F, 0.0F, 0.0F,
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 8, 8, 2, false, 2, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(1.0F, 1.0F),
            new EfxRange(2.0F, 2.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(2.5F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("glow_flash")))
        .put(new EfxAttributeEmitterShape3D(
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            0, 0, 0, 4, new Vector3f(), EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeShaderSettings(2.0F, -1.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeFadeByDepth(2.0F, 4.0F, 100.0F, 120.0F))
        .build();
    
    /**
     * 给不含类型属性的层补一个三维自转角速度。
     * <p>
     * 自转角速度由 {@link EfxAttributeRotateAnim}（{@code type} = 82）承载——它本来就是数据里那个字段的载体。
     * 此前的做法是"借类型属性不匹配时仍会查属性表"这一点，伪造一个 {@link EfxTypePolygon} 塞进去；
     * 那是权宜之计（{@code EfxTypePolygon} 里<b>并没有</b> {@code RotationAdd*} 字段，是抄写时塞进去的），现已改回。
     */
    public static EfxAttributeRotateAnim attachedRotationX(float rotationAddX) {
        return new EfxAttributeRotateAnim(new EfxRange(rotationAddX, 0.0F), EfxRange.ZERO, EfxRange.ZERO);
    }
    
    private EfxSlashPolygonPresets() {
    }
}
