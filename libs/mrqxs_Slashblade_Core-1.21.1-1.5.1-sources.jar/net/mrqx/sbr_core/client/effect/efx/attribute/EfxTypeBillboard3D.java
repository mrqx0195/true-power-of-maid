package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 类型属性 {@code EFXAttributeTypeBillboard3D}：面向相机的 3D 公告板层（对应 json 的 {@code type} = 23）。
 * <p>
 * 带此属性的 Entry（割れ系列、辉光层、两种烟雾等）其面片始终正对镜头；
 * 尺寸语义为 {@code SizeScalar × (1 + SizeX, 1 + SizeY)}，{@code Rotation.s} 是固定的画面内滚转角
 * （烟雾实测不随实例随机），{@code Offset.s} 是沿视线方向的深度偏移。
 * <p>
 * 字段与 EFX 的声明顺序一致（多出 {@code unknDD2} 与低版本才有的 {@code Offset}，本项目只取能确认语义的那些）；
 * {@code rotation} / {@code sizeScalar} / {@code sizeX} / {@code sizeY} / {@code offset} 都是
 * {@code {s, r}} 数值对，{@code color} / {@code colorRange} 由 json 的 {@code rgba} 交换 R/B 得到本项目的常规 ARGB。
 *
 * @param flags                     混合/渲染标志位（{@code Flags}）
 * @param color                     基础颜色（常规 ARGB）
 * @param colorRange                颜色随机附加范围（常规 ARGB）
 * @param colorRate                 颜色倍率
 * @param intensity                 亮度倍率
 * @param alphaRate                 透明度倍率
 * @param edgeBlendRange            边缘混合范围
 * @param rotation                  画面内滚转角（弧度；{@code s} 为基准、{@code r} 为随机幅度）
 * @param sizeScalar                尺寸量级（格）
 * @param sizeX                     额外宽度比例（相对 {@code SizeScalar}）
 * @param sizeY                     额外高度比例（相对 {@code SizeScalar}）
 * @param shadowType                阴影类型
 * @param particleIgnoreScale       是否忽略宿主缩放
 * @param enableGroupColor          是否启用组颜色
 * @param occlusionByParticleShadow 是否被粒子阴影遮挡
 * @param reserved                  保留位
 * @param offset                    沿视线方向的偏移
 */
public record EfxTypeBillboard3D(
    int flags,
    int color,
    int colorRange,
    float colorRate,
    float intensity,
    float alphaRate,
    float edgeBlendRange,
    EfxRange rotation,
    EfxRange sizeScalar,
    EfxRange sizeX,
    EfxRange sizeY,
    int shadowType,
    int particleIgnoreScale,
    boolean enableGroupColor,
    boolean occlusionByParticleShadow,
    boolean reserved,
    EfxRange offset
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 23;
    
    /**
     * 默认值：未配置该属性时的中性取值。
     */
    public static final EfxTypeBillboard3D DEFAULT = new EfxTypeBillboard3D(
        0, 0xFFFFFFFF, 0x00000000, 1.0F, 1.0F, 1.0F, 0.0F,
        EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
        0, 0, false, false, false, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeBillboard3D";
    }
    
    /**
     * 面片实际宽度（格）：{@code SizeScalar × (1 + SizeX)}，两个因子都只取区间下限 {@code s}。
     * <p>
     * 注意这是<b>区间下限</b>：消费侧的 {@link net.mrqx.sbr_core.client.effect.efx.EfxPolygonView}
     * 取的是区间<b>外缘</b> {@code s + r}，本方法当前没有调用方。
     */
    public float width() {
        return this.sizeScalar.s() * (1.0F + this.sizeX.s());
    }
    
    /**
     * 面片实际高度（格）：{@code SizeScalar × (1 + SizeY)}，两个因子都只取区间下限 {@code s}。
     * <p>
     * 同 {@link #width()}，这是区间下限而非消费侧使用的外缘值。
     */
    public float height() {
        return this.sizeScalar.s() * (1.0F + this.sizeY.s());
    }
}
