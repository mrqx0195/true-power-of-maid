package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * GPU 飘带跟随类型属性（{@code EFXAttributeTypeGpuRibbonFollow}，{@code type = 277}）。
 * <p>
 * 它是"把粒子的运动轨迹拉成一条带子"的专用类型，全文件只有 {@code 範囲　GPU} 一层用到。
 * 字段与 {@link EfxTypeGpuBillboard} 大量重合（混合位、双色、色彩倍率、强度、尺寸、拉伸距离），
 * 额外的三项 {@code particleNum} / {@code segmentNum} / {@code controlPointNum} 与末尾的
 * {@code UknDmc5} 是飘带特有的采样参数——现有数据里前三项均为 0（表示使用默认值），
 * 真正给出数值的是 {@code UknDmc5 = 8}，按"飘带分段数"取用。
 *
 * @param blendFlags       混合标志位
 * @param color            主体颜色（常规 ARGB，已交换 R/B）
 * @param colorRange       配色抖动范围（常规 ARGB，alpha 为 0 表示不抖动）
 * @param colorRate        色彩倍率
 * @param intensity        自发光强度
 * @param edgeBlendRange   边缘混合范围
 * @param alphaRate        alpha 倍率
 * @param followFlags      跟随标志位。<b>⚠ 不要按死字段处理</b>：参考实现把本组字段一起标成
 *                         "DMC5 不落盘"，但实测该类型的载荷里 {@code +4} 处 <b>100% 有值</b>
 *                         （取值域 3…20000，常见 100 / 200 / 50 / 500，量级像"长度 / 数量"
 *                         而非标志位）⇒ 至少有一个字段是真落盘的，只是名字与偏移的对应尚未钉死
 * @param particleNum      飘带粒子数（说明见 {@code followFlags}）
 * @param segmentNum       分段数。实测 {@code +8} 与 {@code +12} 是一对<b>相差 1 的计数</b>
 *                         （`+12 == +8 + 1` 在 740/740 条上恒成立，形态像"控制点数 = 段数 + 1"）
 * @param controlPointNum  控制点数（说明见 {@code segmentNum}）
 * @param sizeScalar       飘带宽度基准与随机幅度（格）
 * @param stretchDistanceX 拉伸距离 X
 * @param stretchDistanceY 拉伸距离 Y
 * @param unknDmc5         DMC5 专用字段；现有数据为 8，本视图按"飘带分段数"取用
 */
public record EfxTypeGpuRibbonFollow(
    int blendFlags,
    int color,
    int colorRange,
    float colorRate,
    float intensity,
    float edgeBlendRange,
    float alphaRate,
    int followFlags,
    int particleNum,
    int segmentNum,
    int controlPointNum,
    EfxRange sizeScalar,
    float stretchDistanceX,
    float stretchDistanceY,
    int unknDmc5
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 277;
    
    /**
     * 默认值：宽度 1 格、不加亮。
     */
    public static final EfxTypeGpuRibbonFollow DEFAULT = new EfxTypeGpuRibbonFollow(
        0, 0xFFFFFFFF, 0x00000000, 1.0F, 1.0F, 0.0F, 0.0F,
        0, 0, 0, 0, new EfxRange(1.0F, 0.0F), 0.0F, 0.0F, 0);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeGpuRibbonFollow";
    }
}
