package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 属性 {@code EFXAttributeScaleAnim}：尺寸动画（对应 json 的 {@code type} = 85）。
 * <p>
 * 每个轴有两个量：{@code *Add} 是<b>逐帧增量</b>，{@code *AddCoef} 是该增量的<b>逐帧衰减系数</b>
 * （等比数列求和，而不是倍率缩放——这一点此前理解错过）。{@code sizeScalarAdd} 作用于整体尺寸量级。
 * 缺少该属性即"尺寸恒定"，{@code sizeDelayFrame} 是尺寸动画的起始延迟。
 * <p>
 * 八个分量在数据里都是"基准值 + 随机幅度"的数值对，{@code sizeDelayFrame} 是整数对；本项目的消费侧
 * （{@code PolygonParticle} / {@code EfxMeshView}）只取 {@code s} 作为基准值，{@code r} 这一随机分量
 * 未参与映射（各预设里 {@code r} 多为 0，故影响有限）。
 *
 * @param sizeScalarAdd  整体尺寸逐帧增量（格 / 帧）
 * @param sizeScalarCoef 整体尺寸增量的逐帧衰减系数
 * @param sizeXAdd       宽度逐帧增量
 * @param sizeXAddCoef   宽度增量的逐帧衰减系数
 * @param sizeYAdd       高度逐帧增量
 * @param sizeYAddCoef   高度增量的逐帧衰减系数
 * @param sizeZAdd       深度逐帧增量
 * @param sizeZAddCoef   深度增量的逐帧衰减系数
 * @param sizeDelayFrame 尺寸动画的起始延迟（帧）
 */
public record EfxAttributeScaleAnim(
    EfxRange sizeScalarAdd,
    EfxRange sizeScalarCoef,
    EfxRange sizeXAdd,
    EfxRange sizeXAddCoef,
    EfxRange sizeYAdd,
    EfxRange sizeYAddCoef,
    EfxRange sizeZAdd,
    EfxRange sizeZAddCoef,
    EfxRange sizeDelayFrame
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 85;
    
    /**
     * 默认值：尺寸不变。
     */
    public static final EfxAttributeScaleAnim DEFAULT = new EfxAttributeScaleAnim(
        EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
        EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeScaleAnim";
    }
}
