/**
 * 次元斩（小技能）三套演出的 EFX 预设：普通 / 完美 / BOSS。
 * <p>
 * 与 {@code preset.judgementcutend}（次元斩·绝）并列，但那两套以角色为中心、按效果范围倍率放大，
 * 本包三套以<b>目标位置</b>为中心、一律按 EFX 原值。
 */
package net.mrqx.sbr_core.client.effect.efx.preset.judgementcut;
