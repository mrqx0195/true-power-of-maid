package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

import java.util.Arrays;

/**
 * 属性 {@code EFXAttributeFixRandomGenerator}：固定随机种子表（对应 json 的 {@code type} = 1）。
 * <p>
 * <b>语义</b>：这是<b>反向</b>用法——不是让效果"随机起来"，而是让同一份配置<b>每次播放都得到同一套随机分布</b>；
 * 配置里没有本属性 → 每次触发都是全新随机分布，有本属性 → 由种子表派生可复现的随机源供消费侧取用。
 * <p>
 * 字段名与类型逐字段照抄 EFX 的字段形状：8 个 int 平铺、不合并成数组。
 *
 * @param useRandomSeedTableCount 使用的种子槽位数（0 = 不使用种子表）
 * @param tableSelectionGroup     种子表分组编号（现有数据恒为 0，只承载不参与判定）
 */
public record EfxAttributeFixRandomGenerator(
    int useRandomSeedTableCount,
    int randomSeedTable0,
    int randomSeedTable1,
    int randomSeedTable2,
    int randomSeedTable3,
    int randomSeedTable4,
    int randomSeedTable5,
    int randomSeedTable6,
    int randomSeedTable7,
    int tableSelectionGroup
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 1;
    
    /**
     * 种子槽位最大个数（{@code randomSeedTable0}~{@code randomSeedTable7}）。
     */
    public static final int TABLE_SIZE = 8;
    
    /**
     * 默认值：不使用种子表，等价于每次触发都随机。
     */
    public static final EfxAttributeFixRandomGenerator DEFAULT = new EfxAttributeFixRandomGenerator(
        0, -1, -1, -1, -1, -1, -1, -1, -1, 0);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeFixRandomGenerator";
    }
    
    /**
     * 把 8 个平铺字段收成数组，顺序即槽位 0~7。
     */
    public int[] seedTable() {
        return new int[]{
            this.randomSeedTable0, this.randomSeedTable1, this.randomSeedTable2, this.randomSeedTable3,
            this.randomSeedTable4, this.randomSeedTable5, this.randomSeedTable6, this.randomSeedTable7};
    }
    
    /**
     * 取实际参与派生的有效种子：{@code -1} 是"该槽位未使用"的占位，故只保留槽位下标小于
     * {@link #useRandomSeedTableCount} 且取值非负的槽位；全无效时返回空数组，消费侧退回真随机。
     */
    public int[] validSeeds() {
        int count = Math.clamp(this.useRandomSeedTableCount, 0, TABLE_SIZE);
        int[] table = this.seedTable();
        int[] seeds = new int[count];
        int valid = 0;
        for (int i = 0; i < count; i++) {
            if (table[i] >= 0) {
                seeds[valid] = table[i];
                valid++;
            }
        }
        return Arrays.copyOf(seeds, valid);
    }
}
