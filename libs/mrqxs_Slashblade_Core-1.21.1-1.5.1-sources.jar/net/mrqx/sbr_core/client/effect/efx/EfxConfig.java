package net.mrqx.sbr_core.client.effect.efx;

import javax.annotation.Nullable;
import java.util.Map;

/**
 * 一个 EFX Entry 的完整配置：<b>一个类型属性 + 一张"属性类 → 属性实例"的表</b>。
 * <ul>
 *   <li>{@code type} 是决定渲染方式的类型属性（{@code EfxTypeBillboard3D} / {@code EfxTypePolygon} /
 *       {@code EfxTypeMesh} / {@code EfxTypeNoDraw} 等），每个 Entry 必有其一；</li>
 *   <li>{@code attributes} 以<b>属性类的 Class 为键</b>存放其余修饰属性
 *       （{@code EfxAttributeSpawn} / {@code EfxAttributeLife} / {@code EfxAttributeVelocity3D} …）。</li>
 * </ul>
 * 读取方按需取用：{@link #get(Class)} 返回 {@code null} 表示该层没有这类属性，
 * 此时应<b>跳过对应逻辑或使用该类属性的 {@code DEFAULT} 常量</b>。
 * <p>
 * 实例通过 {@link EfxConfigBuilder} 构建，避免直接书写泛型 Map。
 */
public record EfxConfig(EfxAttribute type, Map<Class<? extends EfxAttribute>, EfxAttribute> attributes) {
    /**
     * 紧凑构造器：复制为不可变表，保证配置在运行期不被意外修改。
     */
    public EfxConfig {
        attributes = Map.copyOf(attributes);
    }
    
    /**
     * 取指定类别的属性。
     *
     * @param attributeClass 属性类（如 {@code EfxAttributeLife.class}）
     * @param <T>            属性类型
     * @return 属性实例；该层未配置这类属性时返回 {@code null}
     */
    @Nullable
    public <T extends EfxAttribute> T get(Class<T> attributeClass) {
        if (attributeClass.isInstance(type)) {
            return attributeClass.cast(type);
        }
        EfxAttribute attribute = this.attributes.get(attributeClass);
        return attributeClass.isInstance(attribute) ? attributeClass.cast(attribute) : null;
    }
    
    /**
     * 取指定类别的属性，缺失时返回给定的兜底实例（通常是该类的 {@code DEFAULT}）。
     *
     * @param attributeClass 属性类
     * @param fallback       缺失时使用的兜底实例
     * @param <T>            属性类型
     * @return 属性实例（保证非空）
     */
    public <T extends EfxAttribute> T getOrDefault(Class<T> attributeClass, T fallback) {
        T attribute = this.get(attributeClass);
        return attribute != null ? attribute : fallback;
    }
    
    /**
     * 是否配置了该类属性（用于"有这个属性才走这条分支"的判断）。
     */
    public boolean has(Class<? extends EfxAttribute> attributeClass) {
        return this.attributes.containsKey(attributeClass);
    }
    
    /**
     * 是否属于某个类型属性（例如判断这是不是一个 Billboard3D 层）。
     */
    public boolean isType(Class<? extends EfxAttribute> typeClass) {
        return typeClass.isInstance(this.type);
    }
}
