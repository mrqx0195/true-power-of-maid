package net.mrqx.sbr_core.client.effect.efx.attribute;

/**
 * EFX 脚本参数的一项：<b>参数名 + 值</b>（{@code EFXAttributePtBehavior} 的 {@code properties[]} 一条）。
 * <p>
 * json 里每项是 {@code {Version, varSize, dataType, variable, varHash, behaviorProperty}}，
 * 其中两个字段经实测判定为冗余、不承载，故不进入本 record：
 * <ul>
 *   <li>{@code varSize}——实测恒等于 {@code 17 + 参数名长度}
 *       （{@code BlurPower} 9 字符 → 26、{@code MaskRate} 8 字符 → 25、
 *       {@code EnableFadeDistance} 18 字符 → 35、{@code Priority} 8 字符 → 25），
 *       是序列化记录的长度，可由参数名直接算出；</li>
 *   <li>{@code varHash}——现有数据恒为 0（只在 MHWilds 版本启用该字段）。</li>
 * </ul>
 * 本类是<b>纯数据承载 record</b>：不含任何行为、没有消费点，只由属性表读取。
 *
 * @param behaviorProperty 参数名（json 的 {@code behaviorProperty}，如 {@code BlurPower}）
 * @param value            参数值（json 的 {@code variable}）
 */
public record EfxBehaviorProperty(String behaviorProperty, EfxBehaviorValue value) {
}
