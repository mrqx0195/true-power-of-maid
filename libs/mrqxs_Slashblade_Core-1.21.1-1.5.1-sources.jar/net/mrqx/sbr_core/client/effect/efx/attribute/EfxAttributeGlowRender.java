package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.post.GlowSpec;

/**
 * <b>本项目扩展属性</b>：把一层"全屏辉光"交给屏幕空间辉光后端（{@code GlowPostEffect}）所需的参数。
 * <p>
 * <b>为什么这些值不能从 EFX 直接算出来</b>：这一族层是公告板面片，其尺寸 / 强度写的是
 * {@code SizeScalar} 与 {@code Intensity × ColorRate}；把这两个量与本项目已验收的屏幕空间观感值对照，
 * 会发现<b>两者之间没有一致的换算关系</b>：同一批层里比值相差三十余倍，说明这里缺一个
 * <b>引擎级的全局缩放系数</b>（EFX 的粒子尺寸并不是直接以"格"为单位），而那个系数的证据目前不足——
 * {@code EfxPolygonView.SIZE_SCALE = 3.0} 只是面片路径按"半径 10 格 → 30 格"标定的另一个量级，
 * 套到这一族层上同样对不上。
 * <p>
 * 因此本属性承载的是<b>本项目的观感标定值</b>，而不是从 EFX 换算出来的值；
 * 各层预设会逐项注出哪些数来自 EFX、哪些是标定值。一旦将来取得那个全局系数的证据，本属性即可整体退役。
 * <p>
 * {@code color} 不在此列——它直接取类型属性的 {@code Color}（白纸黑字写在 EFX 里，无歧义）。
 *
 * @param radius    光斑的世界半径（格）
 * @param strength  满强度时的有效增益（已含本项目的整体强度倍率，调用方不再另乘）
 * @param mode      叠加模式，取 {@link GlowSpec#MODE_ADD} / {@link GlowSpec#MODE_SCREEN} /
 *                  {@link GlowSpec#MODE_DARKEN}
 * @param softness  边缘柔和度（0~1）：越大过渡带越宽、光斑越像光晕
 * @param sceneBlur 场景整体模糊半径（像素），0 表示不模糊
 */
public record EfxAttributeGlowRender(
    float radius,
    float strength,
    int mode,
    float softness,
    float sceneBlur
) implements EfxAttribute {
    /**
     * 扩展属性无 EFX 编号。
     */
    public static final int TYPE = -11;
    
    /**
     * 默认值：一个半径 1 格、增益 0.1 的加法光斑。
     * <p>
     * 没有实际层会用到它——它只是让"某层漏配了本属性"时退化成可见但不刺眼的小光斑，
     * 而不是抛异常或什么都不画。
     */
    public static final EfxAttributeGlowRender DEFAULT =
        new EfxAttributeGlowRender(1.0F, 0.1F, GlowSpec.MODE_ADD, 0.9F, 0.0F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeGlowRender";
    }
}
