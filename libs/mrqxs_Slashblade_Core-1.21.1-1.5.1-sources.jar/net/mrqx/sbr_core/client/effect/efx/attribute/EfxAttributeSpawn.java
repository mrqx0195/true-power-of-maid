package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * 属性 {@code EFXAttributeSpawn}：生成数量与节奏（对应 json 的 {@code type} = 15）。
 * <p>
 * EFX 的区间字段在此摊平成标量：现有数据各区间上下限相等，故一律取 {@code s} 分量（无损）；
 * 仅 {@code IntervalFrame} 保留上下限、采样取上限（见 {@link #intervalFrames()}），{@code EmitterDelayFrame} 保留但无人取用。
 * <p>
 * 关键语义：{@code loopNumDmc5 > 0} 时即该层的批数，{@code = 0} 表示不用它分批（改由实例数估算批数）；
 * {@code useSpawnFrame = false} 时生成时机交由视图/时间轴自行决定；{@code intervalFrame}、{@code emitterDelayFrame} 的单位是 EFX 帧（1 tick = 3 帧）；
 * {@code trySpawnAllParticles} 置位时 {@code EfxPolygonView} 跳过"铺满演出时长"的摊批兜底、触发瞬间一次生成全部分片（当前无任何层置位）。
 * <p>
 * （未映射）本项目无取用：{@code particleInterval}、{@code spawnNumY}、{@code ringBufferMode}、{@code useLoopNumRatio}、
 * {@code interpolate}、{@code spawnChanceFrame}、{@code initializeFull}。
 */
public record EfxAttributeSpawn(
    int maxParticles,
    int particleInterval,
    int spawnNumX,
    int spawnNumY,
    int intervalFrameX,
    int intervalFrameY,
    int loopNumDmc5,
    boolean useSpawnFrame,
    int spawnFrame,
    int loopNum,
    int emitterDelayFrameX,
    int emitterDelayFrameY,
    boolean ringBufferMode,
    boolean useLoopNumRatio,
    boolean interpolate,
    boolean trySpawnAllParticles,
    int spawnChanceFrame,
    boolean initializeFull
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 15;
    
    /**
     * 默认值：一次性生成 1 个、无间隔、不循环。
     */
    public static final EfxAttributeSpawn DEFAULT = new EfxAttributeSpawn(
        1, 0, 1, 1, 0, 0, 0, false, 0, 0, 0, 0,
        false, false, false, false, 0, false);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeSpawn";
    }
    
    /**
     * EFX 一次演出的<b>总生成量</b>（每次数量 × 循环次数，含已消亡实例，至少 1）；本项目适配器实取 {@link #maxParticles()}，本方法保留供对照。
     */
    public int totalCount() {
        int perSpawn = Math.max(1, this.spawnNumY);
        int loops = this.loopNumDmc5 > 0 ? this.loopNumDmc5 : Math.max(1, this.loopNum);
        return Math.max(1, perSpawn * loops);
    }
    
    /**
     * 批次间隔（EFX 帧，1 tick = 3 帧）：取区间上限 {@code y}，0 表示同帧生成（EFX 的 x~y 随机在此简化为固定值）。
     */
    public int intervalFrames() {
        return Math.max(0, this.intervalFrameY);
    }
    
    /**
     * 分批次数：取 {@code loopNumDmc5}；0 表示"不循环"，即本字段给不出批数，由调用方按单批处理。
     */
    public int batchCount() {
        return Math.max(0, this.loopNumDmc5);
    }
    
    /**
     * 实际分批次数（至少 1）：{@code loopNumDmc5 = 0} 时按 {@code ⌈MaxParticles ÷ SpawnNum.x⌉} 兜底估算；
     * 不兜底则这些层的 {@code SpawnNum} 与间隔被整体丢弃，粒子会挤在同一 tick。
     */
    public int effectiveBatchCount() {
        if (this.loopNumDmc5 > 0) {
            return this.loopNumDmc5;
        }
        int perBatch = Math.max(1, this.spawnNumX);
        return Math.max(1, (this.maxParticles() + perBatch - 1) / perBatch);
    }
    
    /**
     * 同上，但实例数由调用方给出：GPU billboard 的 {@code maxParticles} 恒为 1，真实实例数在类型属性的 {@code instanceCount}
     * （如 {@code 収束　炎2} 为 1 与 5000），用前者会退化成"单批"。
     */
    public int effectiveBatchCount(int instanceCount) {
        if (this.loopNumDmc5 > 0) {
            return this.loopNumDmc5;
        }
        int perBatch = Math.max(1, this.spawnNumX);
        return Math.max(1, (Math.max(1, instanceCount) + perBatch - 1) / perBatch);
    }
    
    /**
     * 同时存在的实例上限 {@code MaxParticles}（至少 1）；EFX 实际生成量是 {@code spawnNum.y × loopNumDmc5}（分批出生），落到"一次性生成全部面片"的本项目里取上限才不会让粒子数翻几倍。
     */
    public int maxParticles() {
        return Math.max(1, this.maxParticles);
    }
}
