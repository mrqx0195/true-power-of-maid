package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 类型属性 {@code EFXAttributeTypePolygon}（json 的 {@code type} = 61）：朝向自定的面片层。
 * <p>
 * 与 {@link EfxTypeBillboard3D} 的差别是朝向由本属性的 {@code rotationX/Y/Z} 决定，而非面向相机。
 * <p>
 * ⚠ 本属性<b>只给初始朝向</b>，<b>不承载自转角速度</b>：数据里的 {@code RotationAdd*} 属于
 * {@link EfxAttributeRotateAnim}（{@code type} = 82）。早年照抄时把角速度塞进了本类，
 * 导致"给不含类型属性的层补自转"还得先伪造一个本属性；现已归还给它真正的载体。
 * <p>
 * <b>不建模的字段：{@code Flags2}</b>。参考实现的本类型声明里，{@code AlphaRate} 之后还有一个
 * {@code uint Flags2}（第二个标志字）。它带版本门——那条标记同时覆盖 {@code AlphaRate} 与
 * {@code Flags2}（{@code EndAt} 指到 {@code Flags2}），而 <b>DMC5 早于该门</b>，
 * 所以两者在 DMC5 的载荷里<b>都不写</b>、导出恒为 {@code 0}。既然只可能是 0，本类就不承载它
 * （承载它要在几十处构造点上多写一个恒为 0 的实参）。
 * <p>
 * ⚠ <b>该门还决定其后所有字段的偏移</b>：{@code Flags2} 既然不落盘，它后面的字段就整体前移 4 字节——
 * {@code RotationOrder} 在 {@code +24}、{@code AlphaRateLegacy} 在 {@code +84}，
 * 而不是"先把 {@code Flags2} 算进去"得到的 {@code +28} / {@code +88}。
 * 按后者去读二进制会把整段偏移错开一个 4 字节的 {@code uint}。
 *
 * @param flags          混合 / 渲染标志位掩码
 * @param color          颜色 1（常规 ARGB，由 json 的 rgba 交换 R/B 得到）
 * @param colorRange     颜色 2（常规 ARGB；与 {@code color} 一起构成颜色抖动区间）
 * @param colorRate      <b>颜色倍率</b>。⚠ 本项目**当前不消费**它（见 `PolygonParticle` 里的说明）：原型引擎里
 *                       与它数值吻合的自发光倍率在 mode 0/2/4 是整体乘进颜色的，而本项目此前把它猜成
 *                       "颜色随时序的变化速率"——该猜测无证据，是否改为消费属待裁决项。
 *                       数据里的取值跨度极大（`0.001` ~ `500`），乘进颜色会同时造成"过曝"与"几乎全黑"两种后果，
 *                       故不宜凭直觉打开。
 * @param intensity      亮度倍率
 * @param alphaRate      <b>分色分界</b>（千分制：分界 = {@code 1 − alphaRate / 1000}，见 {@code EfxPolygonView}）。
 *                       ⚠ 本版本（DMC5）的导出里，本类型属性内的 {@code AlphaRate} 是个<b>死字段</b>——它只在
 *                       RE4 及以后的数据格式里存在，本版本导出的取值恒为 {@code 0}；真正被反序列化的是
 *                       <b>同义的 {@code AlphaRateLegacy}</b>（两者在数据格式里互斥，随版本改名）。
 *                       所以抄写预设时必须取 {@code AlphaRateLegacy}：抄 {@code AlphaRate} 只会拿到 {@code 0}、
 *                       分界恒为 1（整层都走 ColorRange）。
 *                       <p>
 *                       ⚠ 不要与面片粒子 PS 里的 {@code cbAlphaRate} 混为一谈：后者是顶点（生命）alpha 的<b>幂指数</b>，
 *                       来自材质侧、与本字段取值集合不吻合，二者不是同一个量。
 * @param edgeBlendRange 边缘混合范围
 * @param rotationX      初始朝向 X
 * @param rotationY      初始朝向 Y
 * @param rotationZ      初始朝向 Z
 * @param sizeScalar     尺寸量级（格）,最终尺寸还要乘以 {@link #width()}/{@link #height()}
 * @param height         长宽比之高
 * @param offset         沿视线方向的偏移
 */
public record EfxTypePolygon(
    int flags,
    int color,
    int colorRange,
    float colorRate,
    float intensity,
    float alphaRate,
    float edgeBlendRange,
    EfxRange rotationX,
    EfxRange rotationY,
    EfxRange rotationZ,
    EfxRange sizeScalar,
    EfxRange width,
    EfxRange height,
    EfxRange offset
) implements EfxAttribute {
    
    /**
     * EFX 属性类型编号（json 中 {@code EFXAttributeTypePolygon} 的 {@code type}）。
     */
    public static final int TYPE = 61;
    
    /**
     * 默认值：单面片、无旋转、1 格见方。
     * <p>
     * 约定：EFX 层未配置本属性时<b>并不</b>整体跳过——视图按"缺省即取中性值"回退到此处
     * （{@code EfxPolygonView} 的 {@code getOrDefault}）；是否走面片路径另由
     * {@code PolygonEfxManager.handles()} 判定。
     */
    public static final EfxTypePolygon DEFAULT = new EfxTypePolygon(
        0, 0xFFFFFFFF, 0x00000000, 1.0F, 1.0F, 1.0F, 0.0F,
        EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
        new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
        EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypePolygon";
    }
}
