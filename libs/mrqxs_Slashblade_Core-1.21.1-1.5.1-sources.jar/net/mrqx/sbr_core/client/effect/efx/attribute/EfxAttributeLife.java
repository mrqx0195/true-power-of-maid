package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 属性 {@code EFXAttributeLife}：生命三段（对应 json 的 {@code type} = 87）。
 * <p>
 * 段意为"出现（渐显）→ 保持（满亮）→ 消散（渐隐）"，单位均为 EFX 帧；
 * {@code keepHoldFrame} 用于延长保持段。缺少该属性时按"立即出现、立即消散"处理。
 * <p>
 * 四段在数据里都是<b>整数</b>帧对（json 写作 {@code {"r": …, "s": …}}），本项目统一用
 * {@link EfxRange} 承载，因此这里是浮点字段（数值本身仍是整数）。
 * {@code flags} 的语义是"消散由谁触发"，本属性只承载不使用；时停会把消散段推迟到时停结束，
 * 这属于时间轴侧的处理，不在此属性内。
 *
 * @param appearFrame   出现段长度（帧）
 * @param keepFrame     保持段长度（帧）
 * @param vanishFrame   消散段长度（帧）
 * @param keepHoldFrame 保持段的额外延长（帧；是否与 {@code keepFrame} 累加取决于 {@code flags}）
 * @param flags         生命标志位（消散触发方式，只承载不使用）
 */
public record EfxAttributeLife(
    EfxRange appearFrame,
    EfxRange keepFrame,
    EfxRange vanishFrame,
    EfxRange keepHoldFrame,
    int flags) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 87;
    
    /**
     * 默认值：无出现、无保持、1 帧消散。
     */
    public static final EfxAttributeLife DEFAULT = new EfxAttributeLife(
        EfxRange.ZERO, EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO, 0);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeLife";
    }
    
    /**
     * 生命总帧数（含保持延长；是否累加 {@code keepHoldFrame} 由 {@code flags} 决定，此处按累加取上界）。
     */
    public float totalFrames() {
        return this.appearFrame.s() + this.keepFrame.s() + this.keepHoldFrame.s() + this.vanishFrame.s();
    }
}
