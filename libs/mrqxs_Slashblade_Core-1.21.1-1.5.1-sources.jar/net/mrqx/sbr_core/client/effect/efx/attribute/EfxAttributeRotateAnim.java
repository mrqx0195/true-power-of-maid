package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 属性 {@code EFXAttributeRotateAnim}：自转动画（对应 json 的 {@code type} = 82）。
 * <p>
 * 与 {@link EfxAttributeScaleAnim}（{@code type} = 85）是同一族、同一个写法：每个轴有一个<b>逐帧增量</b>
 * （{@code RotationAdd*}）与一个<b>逐帧衰减系数</b>（{@code RotationCoef*}），
 * {@code rotationDelayFrame} 是自转动画的起始延迟。
 * <p>
 * <b>为什么要有这个类</b>：自转角速度原本被"寄存"在 {@link EfxTypePolygon} 里
 * （后者的数据里<b>并没有</b> {@code RotationAdd*} 字段，是照抄时塞进去的），
 * 于是给不含类型属性的层补角速度还得先造一个假的 Polygon 属性。
 * 现在角速度回到它真正的载体上：视图从本属性读，任何层只要配上它就有自转。
 * <p>
 * 八个分量在数据里都是"基准值 + 随机幅度"的数值对；消费侧目前只取 {@code s} 作基准值
 * （各预设里 {@code r} 多为 0，故影响有限），{@code r} 这一随机分量与
 * {@link #rotationCoefX()} / {@link #rotationCoefY()} / {@link #rotationCoefZ()} 的复利语义
 * 都还<b>没有被消费</b>——现有层里后者恒为 {@code 1}（不衰减），故不消费与消费等价。
 *
 * @param flags          开关位；现有数据只取 {@code 0} 与 {@code 1}，语义未确证
 * @param rotationAddX   绕 X 轴的自转角速度（弧度 / 帧）
 * @param rotationAddY   绕 Y 轴的自转角速度（弧度 / 帧）
 * @param rotationAddZ   绕 Z 轴的自转角速度（弧度 / 帧）
 * @param rotationCoefX  X 轴角速度的逐帧复利系数（1 = 匀速）
 * @param rotationCoefY  Y 轴角速度的逐帧复利系数（1 = 匀速）
 * @param rotationCoefZ  Z 轴角速度的逐帧复利系数（1 = 匀速）
 * @param delayFrame     自转动画的起始延迟（帧）
 */
public record EfxAttributeRotateAnim(
    int flags,
    EfxRange rotationAddX,
    EfxRange rotationAddY,
    EfxRange rotationAddZ,
    EfxRange rotationCoefX,
    EfxRange rotationCoefY,
    EfxRange rotationCoefZ,
    EfxRange delayFrame
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 82;
    
    /**
     * 复利系数的中性值：{@code 1} 表示角速度不随帧变化（匀速自转）。
     */
    public static final EfxRange NO_COEF = new EfxRange(1.0F, 0.0F);
    
    /**
     * 默认值：三个轴都不自转、复利系数取 1（匀速）、无延迟——等价于该层没有配置本属性。
     */
    public static final EfxAttributeRotateAnim DEFAULT = new EfxAttributeRotateAnim(
        0, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
        NO_COEF, NO_COEF, NO_COEF, EfxRange.ZERO);
    
    /**
     * 便捷构造器：给一个绕 Z 轴的自转角速度（画面内滚转），其余轴为 0、匀速、无延迟。
     * <p>
     * 这是数据里最常见的一种用法，也是"给不含类型属性的层补一个画面内自转"时要写的那种。
     *
     * @param rotationAddZ 画面内滚转角速度（弧度 / 帧）
     */
    public EfxAttributeRotateAnim(float rotationAddZ) {
        this(0, EfxRange.ZERO, EfxRange.ZERO, new EfxRange(rotationAddZ, 0.0F),
            NO_COEF, NO_COEF, NO_COEF, EfxRange.ZERO);
    }
    
    /**
     * 便捷构造器：只给三个轴的自转角速度（三轴各自"基准值 + 随机幅度"），开关与复利系数取默认。
     *
     * @param rotationAddX 绕 X 轴的自转角速度
     * @param rotationAddY 绕 Y 轴的自转角速度
     * @param rotationAddZ 绕 Z 轴的自转角速度
     */
    public EfxAttributeRotateAnim(EfxRange rotationAddX, EfxRange rotationAddY, EfxRange rotationAddZ) {
        this(0, rotationAddX, rotationAddY, rotationAddZ, NO_COEF, NO_COEF, NO_COEF, EfxRange.ZERO);
    }
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeRotateAnim";
    }
}
