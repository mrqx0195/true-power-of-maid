package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：云层球壳（{@code ドーム} / {@code ドーム0}）的 mdf2 材质运行时覆写参数；
 * 语义属材质而非网格，故不并入 {@link EfxTypeMesh} 的构造器。
 * <p>
 * <b>坑</b>：{@code EmissiveColor} 此前只有 {@code mesh_dissolve.json} 的默认值、没有 Java 侧写入点
 * （改 EFX 数据不生效），搬入本属性后才真正由 EFX 数据驱动；未覆写的 {@code Mask02_Tiling}、
 * {@code LayerScroll_LoopNum} 仍沿 mdf2 默认（见 {@code mesh_dissolve.fsh} 的 {@code cloudDensity}）。
 *
 * @param tilingU        {@code Mask01_Tiling} 的 U 方向平铺次数；它配 {@code LoopNum.y} 与 {@code Layer02} 方向
 * @param tilingV        {@code Mask01_Tiling} 的 V 方向平铺次数；同上
 * @param alphaPow       {@code AlphaFade_Pow} 的按层覆写值（数据里 {@code ドーム = 5}、{@code ドーム0 = 1}）。
 *                       ⚠ <b>本通道 {@code [unused]}，这里只承载不消费</b>：材质侧那条"密度 → 不透明度"的幂曲线
 *                       在本项目实现的那个通道里根本不参与运算（它只在带棋盘格的另一个通道里生效，
 *                       且那里的读法是 {@code pow(saturate(N·V), AlphaFade_Pow)}，即视角幂）。
 *                       之所以仍保留该字段，是为了不丢失 EFX 数据本身
 * @param mieMax         {@code Mie_Max} 的按层覆写值；名字里带 "Mie" 但实际是<b>云量/对比度控制器</b>：
 *                       云量 {@code I = saturate(两路遮罩合成 ÷ Mie_Max)}。mdf2 静态默认 {@code 0.25}
 * @param emissiveColor 云块本体的自发光色（常规 ARGB；{@code EmissiveColor}）
 */
public record EfxAttributeCloudLayer(
    float tilingU,
    float tilingV,
    float alphaPow,
    float mieMax,
    int emissiveColor
) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -5;
    
    /**
     * 默认值：该层没有覆写这几项时的行为，取 mdf2 静态默认（{@code Mask01_Tiling = (8, 4)}、
     * {@code AlphaFade_Pow = 1.5}、{@code Mie_Max = 0.25}、{@code EmissiveColor = (0.094, 0.212, 0.780)}）。
     */
    public static final EfxAttributeCloudLayer DEFAULT =
        new EfxAttributeCloudLayer(8.0F, 4.0F, 1.5F, 0.25F, 0xFF1836C7);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeCloudLayer";
    }
}
