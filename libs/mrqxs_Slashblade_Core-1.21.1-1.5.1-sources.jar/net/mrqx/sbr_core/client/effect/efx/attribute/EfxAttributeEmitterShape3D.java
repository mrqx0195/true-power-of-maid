package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 属性 {@code EFXAttributeEmitterShape3D}：发射器形状（对应 json 的 {@code type} = 97）。
 * <p>
 * 形状 2 是<b>圆柱</b>（不是"锥"）；配合三轴 {@code Range}，形状 1 表现为椭球。三轴范围的
 * {@code s} 为内端、{@code s + r} 为外端，本项目统一取 {@code s + r} 作为该轴的散布外缘半径。
 * <p>
 * {@code rangeDivideNum}（环向分割数）、{@code scaleHorizontal}（圆柱角向扫掠角）、
 * {@code scaleVertical} 与采样分布的换算公式未知，只承载不参与采样；
 * {@code rotationOrder} / {@code localRotation} 本项目亦未映射。
 *
 * @param rangeX          X 轴范围（{@code s} 为内端、{@code s + r} 为外端）
 * @param rangeY          Y 轴范围
 * @param rangeZ          Z 轴范围
 * @param shapeType       形状类型（0 = 盒、1 = 球/椭球、2 = 圆柱）
 * @param rangeDivideNum  环向分割数（只承载）
 * @param rangeDivideAxis 分割轴（只承载）
 * @param rotationOrder   旋转顺序
 * @param localRotation   发射器局部旋转
 * @param scaleHorizontal 圆柱角向扫掠角（只承载）
 * @param scaleVertical   圆柱轴向扫掠角（只承载）
 */
public record EfxAttributeEmitterShape3D(
    EfxRange rangeX,
    EfxRange rangeY,
    EfxRange rangeZ,
    int shapeType,
    int rangeDivideNum,
    int rangeDivideAxis,
    int rotationOrder,
    org.joml.Vector3f localRotation,
    EfxRange scaleHorizontal,
    EfxRange scaleVertical
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 97;
    
    /**
     * 默认值：原点处的点发射。
     */
    public static final EfxAttributeEmitterShape3D DEFAULT = new EfxAttributeEmitterShape3D(
        EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, 0, 0, 0, 0,
        new org.joml.Vector3f(), EfxRange.ZERO, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeEmitterShape3D";
    }
}
