package net.mrqx.sbr_core.client.effect.efx;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.polygon.PolygonBlendMode;
import net.mrqx.sbr_core.client.effect.polygon.PolygonOrientation;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import net.mrqx.sbr_core.client.effect.util.TextureAlphaRange;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * 面片类（{@link EfxTypePolygon} / {@link EfxTypeBillboard3D}）EFX 配置的<b>只读派生视图</b>：构造时把"类型属性 + 属性表"
 * 一次性摊平成扁平字段，缺属性即落到其 {@code DEFAULT}；仅"存在性"本身有语义的项（{@code snapToGround}、{@code randomSeed}）
 * 才用 {@link EfxConfig#has(Class)} 判断。
 * <p>
 * 总口径：帧 → tick 为 {@code 1 tick = 3 帧}（{@link #FRAMES_PER_TICK}）；生命三段取 {@code {s, r}} 中值（{@link #rangeMean(EfxRange)}）；
 * 尺寸与发射范围一律取区间外缘 {@code s + r}（见 {@link #rangeXYZ} 的"双半幅"口径）；EFX 的 {@code rgba} 需交换 R/B。
 */
public final class EfxPolygonView {
    /**
     * EFX 帧（60fps）→ tick（20tps）的换算：1 tick = 3 帧。
     */
    public static final float FRAMES_PER_TICK = 3.0F;
    
    /**
     * EFX 着色器"时间"的换算：每多少个 tick 记 1 个时间单位。<b>不能取秒</b>——某层的 {@code LayerScroll_LoopNum = 20}
     * 在秒口径下相位 {@code fract(age)} 恒为整数、两层云完全静止；{@code 1200} 由飘带参考图反推，与 {@link EfxRibbonView#SPEED_SCALE} 同口径。
     */
    public static final float SHADER_TIME_TICKS_PER_UNIT = 1200.0F;
    
    public static final float VELOCITY_SCALE = 0.1F;
    
    /**
     * "以角色为中心、按水平效果范围 = 半径 10 格标定"的那两套演出使用的效果范围倍率：把该口径下的尺寸与发射范围
     * 统一放大到 30 格。只作用于发射范围（{@link #rangeXYZ} / {@link #rangeInner}）、粒子与网格最终尺寸、速度与重力、
     * 飘带宽度；位置偏移（{@code LocalPosition}）相对角色骨骼、角色并没有变大，故<b>不</b>参与缩放。
     * <p>
     * 倍率本身由 {@code EfxTimeline#effectRangeScale()} 逐演出给出、经触发链传到视图；本常量只作"未指定倍率"时的
     * 兼容默认值，<b>新演出应显式声明自己的口径</b>——以目标位置为中心的局部效果不乘它。
     */
    public static final float SIZE_SCALE = 3.0F;
    
    /**
     * 分色的启用掩码：{@code Flags} 的低两位同时置位即按材质 alpha 分色。
     */
    public static final int DUAL_COLOR_FLAG_MASK = 3;
    
    /**
     * 分色分界的基准值：分界 = {@code 1 − AlphaRate / 本值}，即 {@code AlphaRate} 为 0 时全取
     * {@code ColorRange}、为本值时全取 {@code Color}。
     */
    public static final float DUAL_COLOR_ALPHA_RATE_FULL = 1000.0F;
    
    /**
     * 矢量场的基准扰动强度（格 / tick²）：EFX 的 {@code Coefficient} 在现有数据里退化到 {@code 7E-45}（浮点最小非零量），
     * 照抄等于没有扰动，故改以 {@code Parameter.y} 的量级乘本基准。
     */
    public static final float VECTOR_FIELD_BASE_STRENGTH = 0.02F;
    
    /**
     * 矢量场的兜底噪声频率（格⁻¹）：{@code Parameter.x} 缺失时按"波长 6 格"处理。
     */
    public static final float DEFAULT_VECTOR_FIELD_FREQUENCY = 1.0F / 6.0F;
    
    /**
     * 素材约定：序列帧贴图每行 8 帧。
     */
    public static final int FRAME_COLUMNS = 8;
    
    /**
     * 生命属性 {@code Flags} 中"持续到演出结束"的位：{@code Flags = 1} 的十层（各种持续型层）实测都"维持约 2 秒"，
     * 而按其 {@code Appear/Keep/Vanish} 原值只有十几个 tick，故据此把保持段补足到演出收尾。
     */
    public static final int SUSTAINED_FLAG_BIT = 1;
    
    /**
     * EFX {@code VelocityType} 中"径向（由原点向外）"的取值 2（0 = Direction、1 = Normal、3 = Spread、4 = ScreenSpace）。
     */
    public static final int RADIAL_VELOCITY_TYPE = 2;
    
    /**
     * 弧度 → 度的换算系数（{@code 1 rad = 57.295776°}）。
     */
    public static final float DEGREES_PER_RADIAN = 57.295776F;
    
    /**
     * 兜底贴图：配置既没有 {@link EfxAttributeSbrRender}、也没有在其中给出贴图时使用。
     */
    public static final ResourceLocation FALLBACK_TEXTURE =
        MrqxSlashBladeCore.prefix("textures/effect/glow_soft.png");
    
    public final ResourceLocation texture;
    
    public final int frameCount;
    
    public final int frameColumns;
    
    /**
     * 序列帧贴图行数 = <b>素材实际帧数</b>（{@link EfxAttributeUVSequence#atlasFrameCount()}）÷ {@link #frameColumns}，<b>不等于</b>
     * {@code ceil(frameCount / frameColumns)}：{@code PatternNo} 说的是"播多少帧"、这里要的是"图集切几行"，某层图集 64 帧却只播前 32 帧，按播放帧数推行会把每帧采样高度算成两倍、整层贴图错位。
     */
    public final int frameRows;
    
    public final int atlasFrameCount;
    
    public final float framePlaySpeed;
    
    public final PolygonBlendMode blendMode;
    
    public final boolean depthWrite;
    
    public final PolygonOrientation orientation;
    
    public final float distortionStrength;
    
    /**
     * 该层是否<b>只写折射、不写颜色</b>：构成为"配置了折射"且 {@code Intensity} 不大于 0。
     * <p>
     * EFX 用它区分两类层——{@code 割れ　Dis　1}（{@code Intensity = 1}）本体是可见的半透明面片、折射只是叠加其上；
     * 而 {@code 剣軌跡_歪み} / {@code blur} / {@code 剣軌跡1} 一族的 {@code Intensity} 都是 0，本体不出现，
     * 画面上的观感全部来自折射。不区分时这一族会同时显示成一块带颜色的面片（实测反馈：应"自身不可见"的
     * 细弧线折射变成了可见的蓝色弧线）。
     */
    public final boolean distortionOnly;
    
    public final boolean randomStartFrame;
    
    /**
     * 固定的画面内滚转初相（弧度，面向相机模式生效）；{@code Float.NaN} 表示每片随机。<b>不可直接取 EFX {@code Rotation} 的基准值</b>
     * ——它是"起点 + 随机幅度"，只取基准会把随机误判成固定。
     */
    public final float rollRadians;
    
    /**
     * 滚转初相的随机幅度（弧度）：实际初相为 {@code rollRadians ± 该值的一半}；只取基准会让整团烟被统一旋转到同一角度。
     */
    public final float rollRadiansVariation;
    
    public final float anchorU;
    
    public final float anchorV;
    
    public final float uvScrollV;
    
    public final float vectorFieldStrength;
    
    public final float vectorFieldFrequency;
    
    public final float vectorFieldFlow;
    
    /**
     * 螺旋运动的切向角速度（弧度 / tick），来自数据里真实存在的
     * {@link EfxAttributeTransform3DModifier#spinRadiansPerTick()}——与飘带路径
     * （{@code EfxRibbonView}）共用同一口径：0 表示该层不螺旋、非 0 时位置绕演出原点旋转。
     * <p>
     * ⚠ 这里曾经还有第二条通路（把 {@link EfxAttributeVectorFieldParameter#parameter()} 的 {@code z}
     * 分量解读成"螺旋角速度"），**已退役**：那个解读是本项目为"唯一空着的分量"安的解释、没有数据依据，
     * 且它旋转的是速度；而本字段有数据依据（{@code EFXAttributeTransform3DModifier}
     * 在飘带层与面片层都真实存在）、旋转的是位置。两条并存会让同一个属性在两条路径上机制不同。
     */
    public final double spinRadiansPerTick;
    
    /**
     * 螺旋角速度的每 tick 复利系数（{@link EfxAttributeTransform3DModifier#spinAcceleration()}）：
     * 大于 1 越来越快、小于 1 越来越慢、1 为匀速；同样与飘带路径共用。
     */
    public final float spinAcceleration;
    
    public final float depthOffset;
    
    public final float depthOffsetVariation;
    
    public final float width;
    
    public final float height;
    
    public final float sizeRandom;
    
    /**
     * 宽度自身的随机浮动比例（±）：刀光"每片宽窄不一"的手感来自这组随机（如 {@code Width = {1.5, 0.03}}）。
     */
    public final float widthRandom;
    
    public final float heightRandom;
    
    /**
     * 第二个颜色（常规 ARGB，预设已把 EFX 的 {@code rgba} 换过 R/B）。<b>语义由实机测试确定</b>：不是"逐通道随机附加"，
     * 而是与 {@code color} 一起按材质 alpha 分段分工（高 alpha 区用 {@code Color}、低 alpha 区用 {@code ColorRange}）；未启用分段（{@link #dualColorSplit} 为 0）时本项目沿用近似：逐片粒子在两者之间插值。
     */
    public final int colorRange;
    
    public final float dualColorSplit;
    
    public final int frameStartRandom;
    
    public final float framePlaySpeedRandom;
    
    /**
     * 整体尺寸增量（格 / EFX 帧）：同时作用于宽与高（等比膨胀）。<b>勿与 {@link #sizeAddX} / {@link #sizeAddY} 混用</b>——本字段作用在
     * "尺寸量级"上、宽高<b>同步</b>增长，后两者是逐轴附加增量；现有两种烟雾的"团状扩散"完全依赖本字段，误写进 {@link #sizeAddX} 会让宽度每帧涨得远多于高度、烟被压扁成一条横带。
     */
    public final float sizeScalarAdd;
    
    public final float sizeScalarAddCoef;
    
    public final float sizeAddX;
    
    public final float sizeAddY;
    
    public final float sizeAddCoefX;
    
    public final float sizeAddCoefY;
    
    /**
     * 初始朝向 X 轴随机范围（度，360 表示完全随机；消费侧按"±该值的一半"取值）。EFX 的 {@code Rotation.s}（基准朝向）未参与映射，
     * 故部分层的 Y 轴基准朝向会被丢弃（已知偏差）。
     */
    public final float rotationRandomX;
    
    public final float rotationRandomY;
    
    public final float rotationRandomZ;
    
    /**
     * 自转角速度 X（<b>度 / EFX 帧</b>）的基准值：{@link EfxAttributeRotateAnim#rotationAddX()} 的 {@code s}。
     * <p>
     * ⚠ 与 {@link #rotationSpeedXVariation} 一起构成"每片各自的角速度"：消费侧逐片抽
     * {@code s + (rnd − 0.5) · r}（与初始朝向同一读法，`r` 是<b>随机全宽</b>）。这是"碎屑 / 水晶类层
     * 每片转速不同"的来源；只取 {@code s} 会让"基准为 0、抖动才是本体"的层看上去完全不转。
     */
    public final float rotationSpeedX;
    
    public final float rotationSpeedY;
    
    public final float rotationSpeedZ;
    
    /**
     * 自转角速度 X 的随机全宽（度 / EFX 帧）：{@link EfxAttributeRotateAnim#rotationAddX()} 的 {@code r}。
     * 消费侧按 {@code ±该值的一半} 取值，故 {@code r = 30°} 表示"每片在 ±15° 内各转各的"。
     */
    public final float rotationSpeedXVariation;
    
    /**
     * 自转角速度 Y 的随机全宽（度 / EFX 帧）。
     */
    public final float rotationSpeedYVariation;
    
    /**
     * 自转角速度 Z 的随机全宽（度 / EFX 帧）。
     */
    public final float rotationSpeedZVariation;
    
    /**
     * 基础颜色（常规 ARGB；减法层用高亮度色表示"压暗强度"）。消费侧按 {@code FastColor.ARGB32} 的通道顺序读取，
     * 故预设字面量必须已按"EFX 的 {@code rgba} 交换 R/B"换算过。
     */
    public final int color;
    
    public final float intensity;
    
    public final float colorRate;
    
    /**
     * <b>仅作对照记录，当前不参与渲染</b>：按"饱和度倍率"处理会把某纯蓝层的颜色洗成灰白，与实际观察冲突，
     * 故暂不消费（待裁决）。
     */
    public final float saturation;
    
    public final float shaderBrightness;
    
    public final float alphaLowPass;
    
    /**
     * alpha 曲线的宽度（{@code AlphaCorrection.highPass}）：与 {@link #alphaLowPass} 一起构成
     * 材质侧的 {@code saturate((贴图 alpha ^ 4.84 − lowPass) ÷ highPass)} 曲线，见 {@code polygon_particle.fsh}。
     * <p>
     * ⚠ 当 {@code lowPass >= highPass} 时该属性视为无效（{@link #alphaLowPass} 被置 0、曲线整段跳过），
     * 此时本字段的取值不会被使用。
     */
    public final float alphaHighPass;
    
    /**
     * 该层贴图的 alpha 下限（一次性预处理得到，见 {@link TextureAlphaRange}）。
     * <p>
     * 着色器先用 {@code (贴图 alpha − min) ÷ (max − min)} 把替代贴图的 alpha 缩放到 0~1 再进 alpha 曲线；
     * 这样按材质自带贴图标定的 {@code lowPass} 就恢复了原义。
     */
    public final float alphaRangeMin;
    
    /**
     * 该层贴图的 alpha 上限（同 {@link #alphaRangeMin}）。替代贴图的这个值常低于 1.0，
     * 不缩放会让照抄的 {@code lowPass} 把整层压成全透明。
     */
    public final float alphaRangeMax;
    
    public final float appearTicks;
    
    /**
     * 保持阶段（满亮，tick）：{@code KeepFrame} 与 {@code KeepHoldFrame}（额外延长）各自取中值后<b>相加</b>。
     */
    public float keepTicks;
    
    /**
     * 生命属性的 {@code Flags} 原值：第 0 位（{@link #SUSTAINED_FLAG_BIT}）取 1 的层实际都"维持约 2 秒"，故据此把保持段拉长到演出收尾。
     * <b>只消费这一位已核实是完备的</b>：数据侧统计（脚本 {@code efx_field_histogram.py}）显示 101 处
     * {@code Life.Flags} 只取过 {@code 0}（74 次）与 {@code 1}（27 次），其余位从未出现。
     */
    public final int lifeFlags;
    
    public final float vanishTicks;
    
    public final float fadeNearStart;
    /**
     * 锥角淡出属性（缺失即"关闭"）。
     * <p>
     * 与 {@link #fadeNearStart} 那一族是<b>两条并列</b>的淡出属性：面片顶点着色器里读到的那组
     * 角度常量（锥内 / 外边界、锥轴、边界 alpha、启用权重）就来自本属性，而区间端点来自深度淡出。
     * 本属性的默认值是"关闭"，且当前六份 EFX 导出里没有任何层覆写它 ⇒ 不改变现有行为。
     * 算式与两处 D 级近似见 {@link EfxAttributeFadeByAngle} 的类注释。
     */
    public final EfxAttributeFadeByAngle fadeByAngle;
    
    public final float fadeNearEnd;
    
    /**
     * 近端淡出段（开始变淡 / 完全消失）的统一上限（格），实际取值取 EFX 原值与它的较小者。<b>为第一人称贴脸而设</b>：本项目"演出原点 =
     * 施法者位置"，第一人称自施法时相机几乎与原点重合，胸口 / 腰部层距相机仅约 0.6 格，而 EFX 原值的 2.5 ~ 4 格会让它们整层消失；0.3 / 0.8 格下胸口保有不透明度 0.6，同时保留"贴到脸上才淡出"的行为。
     */
    public static final float MIN_FADE_NEAR_START = 0.3F;
    
    public static final float MIN_FADE_NEAR_END = 0.8F;
    
    public final float fadeFarStart;
    
    public final float fadeFarEnd;
    
    public final int count;
    
    /**
     * 本层的长度 / 速度口径系数：由本场演出的效果范围倍率（构造参数 {@code effectRangeScale}）与逐层的
     * {@link EfxAttributeCharacterSpace} 共同决定——后者声明"按角色尺寸标定"时取 {@code 1.0}，
     * 该层把范围、速度、重力、粒子尺寸全部按 EFX 原值使用，因为它们的数值本来就贴着角色、而角色并没有跟着放大。
     */
    public final float sizeScale;
    
    public final int batches;
    
    /**
     * <b>每批生成的数量</b>（{@code SpawnNum} 折算到"每 tick"之后的值）。本项目逐 tick 驱动（1 tick = 3 帧），把"一 tick 内的 3 帧"
     * 合并成一批：{@code tick 间隔 = max(1, round(IntervalFrame / 3))}、{@code 每批数量 = SpawnNum × max(1, round(3 / max(IntervalFrame, 1)))}，
     * 于是 {@code IntervalFrame = 0} 的层每批恰为 {@code SpawnNum × 3}。<b>只对持续生成的层折算</b>：{@code LoopNumDmc5 > 0} 的层 EFX 已写明批数，再乘 3 会把总量放大成三倍。
     */
    public final int spawnPerBatch;
    
    public final float intervalTicks;
    
    public final Vector3f centerOffset;
    
    /**
     * 发射范围的椭球半轴（格）：各轴取 {@code s + r}，即 {@link EfxRange} 所定义区间的<b>外缘</b>。
     * <p>
     * <b>取外缘而非期望 {@code s + r / 2}</b>：本项目的基线是"水平效果范围 = 半径 10 格"，而 {@code RangeX = {9, 1}}
     * 的期望只有 9.5 格、外缘恰好 10 格；既有预设都是照着这个口径标定的，改回期望会让这些层一起缩水。
     */
    public final Vector3f rangeXYZ;
    
    /**
     * 发射范围的内半径（格）：各轴取 {@code max(0, Range.s − Range.r / 2)}。实测部分层是"大量出现在水平效果范围
     * <b>边界</b>的小火焰"，若一律从圆心 0 开始采样，圆盘中心也会长满火焰；取 0 的层（{@code s ≤ r/2} 的绝大多数）采样行为与不加本字段时完全一致。
     */
    public final Vector3f rangeInner;
    
    public final int shapeType;
    
    /**
     * 发射形状的<b>环向分割数</b>（{@code RangeDivideNum}）：0 表示不分割（方位角完全随机），大于 0 时把一圈均分成该数目的扇区。
     * <b>它决定"一圈火焰"</b>：某地面层该值是 <b>12</b>——不分割时粒子全靠随机方位角、很容易全挤在一侧，分成 12 个扇区后无论取多少片，圆周上都会有粒子。
     */
    public final int rangeDivideNum;
    
    public final float speed;
    
    public final float speedRandom;
    
    /**
     * 是否径向发射（true = 由原点向外，false = 沿随机方向或沿 {@link #direction}）。<b>不能用"方向向量是否为零"推断</b>：
     * 大量层是 {@code radial=false} + 零方向（= 完全随机方向），若按"无方向即径向"判定，这些层会从"四散"变成"由原点向外"。
     */
    public final boolean radial;
    
    public final float gravityRate;
    
    public final float speedDecay;
    
    /**
     * 是否<b>不</b>移动；判断依据为速度<b>恰为 0</b>——负速度表示沿反方向运动而非静止。
     */
    public final boolean noMove;
    
    /**
     * 是否把发射点贴到地面（简化版 {@link EfxAttributePtCollision}）：配置中<b>是否存在</b>该属性即语义，缺失即不与地面交互。
     */
    public final boolean snapToGround;
    
    /**
     * 贴地吸附时的碰撞半径（格）：吸附时在该半径范围内取最高的可立足顶面；只把 {@link #snapToGround} 当开关而不读半径，烟层跨台阶会出现"一半沉进方块"的接缝。
     */
    public final float collisionRadius;
    
    /**
     * 速度主方向（会归一化）；零向量表示不使用方向模式。
     */
    public final Vector3f direction;
    
    public final Vector3f directionSpread;
    
    public final Vector3f velocityOffset;
    
    /**
     * 配置里给出的固定随机种子；{@code null} 表示该层<b>没有</b> {@link EfxAttributeFixRandomGenerator}，即"每次触发都要全新的随机分布"。
     */
    @Nullable
    public final Long randomSeed;
    
    /**
     * 配置里的固定随机种子表属性（缺失时为 {@code null}）。"存在性"本身就是语义，绝不能用 {@code DEFAULT} 兜底，否则又变回"同一层每次触发都用同一条随机序列"。
     */
    @Nullable
    public final EfxAttributeFixRandomGenerator fixRandomGenerator;
    
    /**
     * 取"面向相机的面片"这一组类型属性，并把 GPU 实例化 billboard 折算成等价的 Billboard3D：两个 record 在颜色 /
     * 配色抖动范围 / 色彩倍率 / 强度 / alpha 倍率 / 边缘混合范围 / 旋转 / 尺寸量级八个字段上一一对应，
     * 差异只有实例数（{@code instanceCount} 对 {@code Spawn.MaxParticles}）与混合位（{@code BlendFlags} 对 {@code Flags}）。
     * <p>
     * <b>宽高倍率与偏移一律传中性值</b>：本类型没有这三个字段——DMC5 的载荷到 {@code SizeScalar} 为止
     * （见 {@link EfxTypeGpuBillboard} 的类注释"载荷边界"）。{@code sizeX} / {@code sizeY} 取
     * {@link EfxRange#ZERO} 使 {@code 1 + 0} 成为恒等因子，{@code offset} 取 {@link EfxRange#ZERO} 表示不偏移。
     */
    public static EfxTypeBillboard3D effectiveBillboardType(EfxConfig config) {
        EfxTypeGpuBillboard gpu = config.get(EfxTypeGpuBillboard.class);
        if (gpu != null) {
            return new EfxTypeBillboard3D(
                gpu.blendFlags(), gpu.color(), gpu.colorRange(), gpu.colorRate(), gpu.intensity(),
                gpu.alphaRate(), gpu.edgeBlendRange(),
                gpu.rotation(), gpu.sizeScalar(), EfxRange.ZERO, EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO);
        }
        return config.getOrDefault(EfxTypeBillboard3D.class, EfxTypeBillboard3D.DEFAULT);
    }
    
    /**
     * 使用兜底贴图与全局默认的收尾时刻构造视图。
     */
    public EfxPolygonView(EfxConfig config) {
        this(config, FALLBACK_TEXTURE, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 使用兜底贴图构造视图，并指定本场演出的收尾时刻（tick）。
     */
    public EfxPolygonView(EfxConfig config, int sustainedKeepTicks) {
        this(config, FALLBACK_TEXTURE, sustainedKeepTicks);
    }
    
    /**
     * 逐项解析配置，构造只读视图，兜底贴图由调用方给出。
     */
    public EfxPolygonView(EfxConfig config, ResourceLocation fallbackTexture) {
        this(config, fallbackTexture, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 完整形态：逐项解析配置，构造只读视图；效果范围倍率取全局默认 {@link #SIZE_SCALE}。
     */
    public EfxPolygonView(EfxConfig config, ResourceLocation fallbackTexture, int sustainedKeepTicks) {
        this(config, fallbackTexture, sustainedKeepTicks, SIZE_SCALE);
    }
    
    /**
     * 完整形态：逐项解析配置，构造只读视图，并指定本场演出的<b>效果范围倍率</b>。
     * <p>
     * 该倍率只作用于"按效果范围标定"的层；逐层的 {@link EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}。
     */
    public EfxPolygonView(EfxConfig config, ResourceLocation fallbackTexture, int sustainedKeepTicks,
                          float effectRangeScale) {
        // 调用方未指定收尾时刻时回退到按范围效果标定的全局默认值
        float sustainedKeep = sustainedKeepTicks >= 0 ? sustainedKeepTicks : EfxTimeline.SUSTAINED_KEEP_TICKS;
        // Billboard3D 与 GPU 实例化 billboard 都算"面向相机"，后者在摊平前已被折算成等价形式
        boolean billboard = config.isType(EfxTypeBillboard3D.class) || config.isType(EfxTypeGpuBillboard.class);
        EfxTypeBillboard3D billboardType = effectiveBillboardType(config);
        EfxTypePolygon polygonType = config.getOrDefault(EfxTypePolygon.class, EfxTypePolygon.DEFAULT);
        EfxAttributeSpawn spawn = config.getOrDefault(EfxAttributeSpawn.class, EfxAttributeSpawn.DEFAULT);
        EfxAttributeLife life = config.getOrDefault(EfxAttributeLife.class, EfxAttributeLife.DEFAULT);
        EfxAttributeScaleAnim scale = config.getOrDefault(EfxAttributeScaleAnim.class, EfxAttributeScaleAnim.DEFAULT);
        EfxAttributeUVSequence uv = config.getOrDefault(EfxAttributeUVSequence.class, EfxAttributeUVSequence.DEFAULT);
        EfxAttributeEmitterShape3D shape = config.getOrDefault(EfxAttributeEmitterShape3D.class, EfxAttributeEmitterShape3D.DEFAULT);
        EfxAttributeFadeByDepth fade = config.getOrDefault(EfxAttributeFadeByDepth.class, EfxAttributeFadeByDepth.DEFAULT);
        EfxAttributeAlphaCorrection alpha = config.getOrDefault(EfxAttributeAlphaCorrection.class, EfxAttributeAlphaCorrection.DEFAULT);
        EfxAttributeTransform3D transform = config.getOrDefault(EfxAttributeTransform3D.class, EfxAttributeTransform3D.DEFAULT);
        EfxAttributeSbrRender render = config.getOrDefault(EfxAttributeSbrRender.class, EfxAttributeSbrRender.DEFAULT);
        EfxAttributeDistortion distortion =
            config.getOrDefault(EfxAttributeDistortion.class, EfxAttributeDistortion.DEFAULT);
        EfxAttributeUVScroll uvScroll =
            config.getOrDefault(EfxAttributeUVScroll.class, EfxAttributeUVScroll.DEFAULT);
        // Velocity3D 用 DEFAULT 兜底与"跳过该属性"完全等价
        EfxAttributeVelocity3D velocity = config.getOrDefault(EfxAttributeVelocity3D.class, EfxAttributeVelocity3D.DEFAULT);
        
        // ---------- 贴图与外观 ----------
        this.texture = uv.resource() != null ? uv.resource() : fallbackTexture;
        this.frameCount = uv.frameCount();
        this.frameColumns = FRAME_COLUMNS;
        this.atlasFrameCount = uv.atlasFrameCount();
        // 行数按素材实际帧数算，而不是按播放帧数
        this.frameRows = Math.max(1, this.atlasFrameCount / FRAME_COLUMNS);
        this.framePlaySpeed = uv.playSpeed().s() * FRAMES_PER_TICK;
        this.framePlaySpeedRandom = uv.playSpeed().s() != 0.0F
            ? Math.abs(uv.playSpeed().r() / uv.playSpeed().s())
            : 0.0F;
        this.frameStartRandom = Math.max(0, Math.round(uv.patternNo().r()));
        // Polygon / Billboard3D 的混合与分色共用同一个 Flags 位掩码；GPU 实例化的 BlendFlags 是另一套语义，故先判类型
        int colorFlags = billboard ? billboardType.flags() : polygonType.flags();
        EfxTypeGpuBillboard gpuBlendType = config.get(EfxTypeGpuBillboard.class);
        this.blendMode = gpuBlendType != null
            ? gpuBlendMode(gpuBlendType.blendFlags())
            : blendMode(colorFlags);
        this.depthWrite = render.depthWrite();
        this.orientation = render.groundPlane()
            ? PolygonOrientation.GROUND
            : (billboard ? PolygonOrientation.BILLBOARD : PolygonOrientation.FREE);
        this.distortionStrength = distortion.enabled() ? distortion.influence() : 0.0F;
        this.randomStartFrame = uv.randomStartFrame()
            || (this.framePlaySpeed <= 0.0F && this.frameCount > 1);
        // 自由朝向层不使用画面内滚转（其朝向由 Polygon.RotationX/Y/Z 决定），故取 NaN
        this.rollRadians = billboard ? billboardType.rotation().s() : Float.NaN;
        this.rollRadiansVariation = billboard ? billboardType.rotation().r() : 0.0F;
        this.anchorU = render.anchorU();
        this.anchorV = render.anchorV();
        this.uvScrollV = uvScroll.vScrollPerTick();
        // Parameter.x 解读为"噪声波长（格）"、Parameter.y 作为场强量级，LFO 周期换算成流动速度
        EfxAttributeVectorFieldParameter vectorField =
            config.getOrDefault(EfxAttributeVectorFieldParameter.class, EfxAttributeVectorFieldParameter.DEFAULT);
        this.vectorFieldStrength = VECTOR_FIELD_BASE_STRENGTH * Math.abs(vectorField.parameter().y());
        this.vectorFieldFrequency = vectorField.parameter().x() > 0.0F
            ? 1.0F / vectorField.parameter().x()
            : DEFAULT_VECTOR_FIELD_FREQUENCY;
        this.vectorFieldFlow = vectorField.lfoRange() > 0.0F
            ? FRAMES_PER_TICK / vectorField.lfoRange()
            : 0.0F;
        // 螺旋角速度：只认数据里真实存在的 EFXAttributeTransform3DModifier（下面几行）。
        // 注意 vectorField.parameter() 的 z 分量**不参与映射**：它曾被解读为"螺旋角速度"，
        // 但那是为"唯一空着的分量"安的解释、且转的是速度，已退役（见 spinRadiansPerTick 的注释）。
        EfxAttributeTransform3DModifier modifier =
            config.getOrDefault(EfxAttributeTransform3DModifier.class, EfxAttributeTransform3DModifier.DEFAULT);
        this.spinRadiansPerTick = modifier.spinRadiansPerTick();
        this.spinAcceleration = Math.max(0.0F, modifier.spinAcceleration());
        EfxRange offset = billboard ? billboardType.offset() : polygonType.offset();
        this.depthOffset = offset.s();
        this.depthOffsetVariation = offset.r();
        
        // ---------- 尺寸 ----------
        EfxRange sizeScalar = billboard ? billboardType.sizeScalar() : polygonType.sizeScalar();
        // 尺寸取区间<b>外缘</b> {@code s + r}，与发射范围（{@link #rangeXYZ}）同一"双半幅"口径：{@code {s, r}}
        // 是"基准 + 随机全宽"，本项目各处都按"外缘 = s + r"读；只取基准 s 会让每片面片都小一截（实测反馈
        // "面片尺寸都偏小"）。{@code {0, 1}} 这类基准为 0 的层因此自然得到 1 而不是 0，原先为它们单设的兜底随之取消。
        float scalarBase = sizeScalar.s() + sizeScalar.r();
        this.width = billboard
            ? scalarBase * (1.0F + billboardType.sizeX().s())
            : scalarBase * polygonType.width().s();
        this.height = billboard
            ? scalarBase * (1.0F + billboardType.sizeY().s())
            : scalarBase * polygonType.height().s();
        this.sizeRandom = scalarBase != 0.0F ? Math.abs(sizeScalar.r() * 0.5F / scalarBase) : 0.0F;
        this.widthRandom = relativeVariation(billboard ? billboardType.sizeX() : polygonType.width());
        this.heightRandom = relativeVariation(billboard ? billboardType.sizeY() : polygonType.height());
        this.sizeScalarAdd = scale.sizeScalarAdd().s();
        this.sizeScalarAddCoef = scale.sizeScalarCoef().s();
        this.sizeAddX = scale.sizeXAdd().s();
        this.sizeAddY = scale.sizeYAdd().s();
        this.sizeAddCoefX = scale.sizeXAddCoef().s();
        this.sizeAddCoefY = scale.sizeYAddCoef().s();
        
        // ---------- 朝向与自转 ----------
        // Polygon 的 Rotation* 是初始朝向的随机半幅（弧度）
        this.rotationRandomX = toDegrees(polygonType.rotationX().r());
        this.rotationRandomY = toDegrees(polygonType.rotationY().r());
        this.rotationRandomZ = toDegrees(polygonType.rotationZ().r());
        // 自转角速度来自它自己的属性 EFXAttributeRotateAnim（type 82），**不再**取自 TypePolygon：
        // 后者的数据里根本没有 RotationAdd* 字段，那是"寄存"（详见 EfxAttributeRotateAnim 的类注释）。
        // 这样任何层（含不含类型属性的层）只要配上该属性就有自转，不必再造一个假的 Polygon 属性。
        EfxAttributeRotateAnim rotateAnim =
            config.getOrDefault(EfxAttributeRotateAnim.class, EfxAttributeRotateAnim.DEFAULT);
        this.rotationSpeedX = toDegrees(rotateAnim.rotationAddX().s());
        this.rotationSpeedY = toDegrees(rotateAnim.rotationAddY().s());
        this.rotationSpeedZ = toDegrees(rotateAnim.rotationAddZ().s());
        // 随机全宽同源：消费侧逐片抽 s ± r/2，让"基准为 0、抖动才是本体"的层也能转起来
        this.rotationSpeedXVariation = toDegrees(rotateAnim.rotationAddX().r());
        this.rotationSpeedYVariation = toDegrees(rotateAnim.rotationAddY().r());
        this.rotationSpeedZVariation = toDegrees(rotateAnim.rotationAddZ().r());
        
        // ---------- 颜色与亮度 ----------
        this.color = billboard ? billboardType.color() : polygonType.color();
        this.colorRange = billboard ? billboardType.colorRange() : polygonType.colorRange();
        // 分色：Flags 低两位同时置位才启用，分界由 AlphaRate 给出（0 = 全取 ColorRange、1000 = 全取 Color）
        float alphaRate = billboard ? billboardType.alphaRate() : polygonType.alphaRate();
        this.dualColorSplit = (colorFlags & DUAL_COLOR_FLAG_MASK) == DUAL_COLOR_FLAG_MASK
            ? Math.clamp(1.0F - alphaRate / DUAL_COLOR_ALPHA_RATE_FULL, 0.0F, 1.0F)
            : 0.0F;
        this.intensity = billboard ? billboardType.intensity() : polygonType.intensity();
        this.colorRate = billboard ? billboardType.colorRate() : polygonType.colorRate();
        // 只写折射的层：Intensity 不大于 0 即该层不向颜色通道输出（见 distortionOnly）
        this.distortionOnly = this.distortionStrength > 0.0F && this.intensity <= 0.0F;
        EfxAttributeShaderSettings shader =
            config.getOrDefault(EfxAttributeShaderSettings.class, EfxAttributeShaderSettings.DEFAULT);
        this.saturation = shader.saturation();
        this.shaderBrightness = shader.colorBrightness();
        // AlphaCorrection 的 lowPass 是曲线的起点、highPass 是宽度；lowPass 不小于 highPass 时该属性视为无效
        // （数据里 剣軌跡2 与 剣軌跡5 都是 1.0 : 1.0），此时不做任何 alpha 校正、直接用原版粒子着色器
        this.alphaLowPass = alpha.lowPass() < alpha.highPass() ? alpha.lowPass() : 0.0F;
        this.alphaHighPass = alpha.highPass();
        // 替代贴图的 alpha 量程常与原图不同，先把它的上下限测出来交给着色器缩放；
        // 不需要校正的层不测（省掉一次读图），直接给恒等区间。
        TextureAlphaRange.Range alphaRange = this.alphaLowPass > 0.0F
            ? TextureAlphaRange.of(this.texture)
            : TextureAlphaRange.Range.IDENTITY;
        this.alphaRangeMin = alphaRange.min();
        this.alphaRangeMax = alphaRange.max();
        
        // ---------- 生命与距离淡出 ----------
        this.appearTicks = rangeMean(life.appearFrame()) / FRAMES_PER_TICK;
        // 保持段由 KeepFrame 与 KeepHoldFrame（额外的保持延长）各自取中值后相加
        this.keepTicks = (rangeMean(life.keepFrame()) + rangeMean(life.keepHoldFrame())) / FRAMES_PER_TICK;
        this.vanishTicks = rangeMean(life.vanishFrame()) / FRAMES_PER_TICK;
        // 生命 Flags 第 0 位：取 1 的层都是"生成后一直 Keep 至效果结束"，但它们的 Appear/Keep/Vanish 三段原值只有十几个 tick，故补足到演出收尾
        this.lifeFlags = life.flags();
        if ((this.lifeFlags & SUSTAINED_FLAG_BIT) != 0) {
            this.keepTicks = Math.max(this.keepTicks,
                Math.max(0.0F, sustainedKeep - this.appearTicks));
        }
        // 近端淡出下限：EFX 原值的 2.5 ~ 4 格是第三人称下"贴脸才淡出"的设定，照抄会让第一人称自施法时的胸口 / 腰部层整层 alpha = 0
        this.fadeNearStart = Math.min(fade.nearStart(), MIN_FADE_NEAR_START);
        this.fadeByAngle = config.getOrDefault(EfxAttributeFadeByAngle.class, EfxAttributeFadeByAngle.DEFAULT);
        this.fadeNearEnd = Math.min(fade.nearEnd(), MIN_FADE_NEAR_END);
        this.fadeFarStart = fade.farStart();
        this.fadeFarEnd = fade.farEnd();
        
        // ---------- 生成 ----------
        // GPU 实例化 billboard 自带的 instanceCount 才是"同时存在的实例数"（其 Spawn.MaxParticles 恒为 1，照抄会只生成一片）
        EfxTypeGpuBillboard gpuBillboardType =
            config.getOrDefault(EfxTypeGpuBillboard.class, EfxTypeGpuBillboard.DEFAULT);
        this.count = gpuBillboardType.instanceCount() > 0
            ? gpuBillboardType.instanceCount()
            : spawn.maxParticles();
        this.sizeScale = config
            .getOrDefault(EfxAttributeCharacterSpace.class, EfxAttributeCharacterSpace.DEFAULT)
            .characterSized() ? 1.0F : effectRangeScale;
        // LoopNumDmc5 = 0 表示"不限制循环"：每隔 IntervalFrame 生成一批、一直持续到演出收尾（IntervalFrame = 0 视为"每 tick 一批"）
        // 若把 0 一律按"单批"处理又让所有批次落在同一 tick，这些层就会全变成"瞬间一大团"
        int loop = spawn.batchCount();
        // 一 tick 内的 3 帧合并成一批，故 IntervalFrame = 0 的层每批恰为 SpawnNum × 3（数据以 60 帧逐帧生成，故每帧生成量需乘 3）
        int frameInterval = Math.max(1, spawn.intervalFrames());
        float interval = Math.max(1.0F, Math.round(frameInterval / FRAMES_PER_TICK));
        // 能铺满演出时长的最大批数：批数 × 间隔不能超过演出长度，否则尾批永远不会出生
        int maxBatches = Math.max(1, Math.round(sustainedKeep / interval) + 1);
        // "单批"这件事 EFX 数据本身决定不了，只能由预设显式给出：GPU 胸 上昇青炎 与 収束 炎2 的原值完全一样而实测节奏相反
        // 故把 TrySpawnAllParticles 当作"瞬间一整团"的扩展语义；反过来用 IntervalFrame = 0 判单批会把 収束 炎2 也压成一团
        boolean singleBatch = spawn.trySpawnAllParticles();
        boolean sustainedSpawn = loop == 0 && !singleBatch;
        int perBatchMultiplier = sustainedSpawn
            ? Math.max(1, Math.round(FRAMES_PER_TICK / (float) frameInterval))
            : 1;
        this.spawnPerBatch = singleBatch
            ? this.count
            : Math.max(1, spawn.spawnNumX()) * perBatchMultiplier;
        // 分批总量：优先用数据明确写出的 LoopNumDmc5，否则按演出时长铺满（见 EfxAttributeSpawn）
        this.batches = singleBatch
            ? 1
            : Math.min(loop > 0 ? loop : spawn.effectiveBatchCount(this.count), maxBatches);
        this.intervalTicks = interval;
        this.centerOffset = new Vector3f(transform.localPosition());
        // 范围取"基准 + 随机幅度"作为散布外缘（见 rangeXYZ 的"双半幅"口径），再乘 sizeScale
        this.rangeXYZ = new Vector3f(
            (shape.rangeX().s() + shape.rangeX().r()) * this.sizeScale,
            (shape.rangeY().s() + shape.rangeY().r()) * this.sizeScale,
            (shape.rangeZ().s() + shape.rangeZ().r()) * this.sizeScale);
        // 内半径 = 区间下界 s − r/2（夹到 0）：让"只出现在范围边界"的层形成环带
        this.rangeInner = new Vector3f(
            Math.max(0.0F, shape.rangeX().s() - shape.rangeX().r() * 0.5F) * this.sizeScale,
            Math.max(0.0F, shape.rangeY().s() - shape.rangeY().r() * 0.5F) * this.sizeScale,
            Math.max(0.0F, shape.rangeZ().s() - shape.rangeZ().r() * 0.5F) * this.sizeScale);
        this.shapeType = shape.shapeType();
        this.rangeDivideNum = Math.max(0, shape.rangeDivideNum());
        
        // ---------- 运动 ----------
        // 速度同样跟 sizeScale 走，收缩 / 上升的时间比例才与放大前一致
        this.speed = velocity.speed().s() * VELOCITY_SCALE * this.sizeScale;
        this.speedRandom = velocity.speed().s() != 0.0F
            ? Math.abs(velocity.speed().r() / velocity.speed().s())
            : 0.0F;
        this.radial = velocity.velocityType() == RADIAL_VELOCITY_TYPE;
        this.gravityRate = velocity.gravityRate().s() * VELOCITY_SCALE * this.sizeScale;
        this.speedDecay = perFrameToPerTick(velocity.speedCoef().s());
        // "不移动"只对速度恰为 0 的层成立；负速度表示反向运动，不能一并当作静止
        this.noMove = velocity.speed().s() == 0.0F;
        // 只有配置里真的存在 PtCollision 才做贴地吸附——"存在性"本身就是语义，故用 has 判断
        EfxAttributePtCollision collision = config.get(EfxAttributePtCollision.class);
        this.snapToGround = collision != null;
        this.collisionRadius = collision != null ? Math.max(0.0F, collision.radius().s()) : 0.0F;
        // 三个向量都复制一份：视图是只读快照，不持有属性 record 内部的 Vector3f 实例
        this.direction = new Vector3f(velocity.direction());
        this.directionSpread = new Vector3f(velocity.size());
        this.velocityOffset = new Vector3f(velocity.offset());
        
        // ---------- 随机种子 ----------
        // 只有配置真的写了 FixRandomGenerator 才是"可复现"；没有该属性的层必须每次触发都随机，故保留 null 语义而绝不用 DEFAULT 兜底
        this.fixRandomGenerator = config.get(EfxAttributeFixRandomGenerator.class);
        int[] seeds = this.fixRandomGenerator != null ? this.fixRandomGenerator.validSeeds() : new int[0];
        this.randomSeed = seeds.length > 0 ? (long) seeds[0] : null;
    }
    
    /**
     * 生命总时长（tick）：{@code appear + keep + vanish}。
     */
    public float totalLifeTicks() {
        return this.appearTicks + this.keepTicks + this.vanishTicks;
    }
    
    /**
     * 把 GPU 实例化 billboard 的 {@code BlendFlags} 映射成混合模式。<b>不能直接复用 {@link #blendMode(int)}</b>：后者是给 {@code TypePolygon} /
     * {@code Billboard3D} 的 {@code Flags} <b>位掩码</b>写的（bit2 ⇒ 反减），而 {@link EfxTypeGpuBillboard} 的 {@code BlendFlags} 取 3 ~ 6 这样的
     * <b>连续小整数</b>、语义更接近"模式编号"。同构直传后 4 / 5 / 6 都命中 bit2 被判成反减，亮蓝色的几层因此被"从画面里减去蓝色"、呈补色的红 / 黄
     * 乃至几乎看不出（实测报出的现象）；这几层的原意都是发亮的蓝色，故 3 ~ 6 一律按加法处理。
     */
    public static PolygonBlendMode gpuBlendMode(int blendFlags) {
        if (blendFlags == 3 || blendFlags == 4 || blendFlags == 5 || blendFlags == 6) {
            return PolygonBlendMode.ADDITIVE;
        }
        return blendMode(blendFlags);
    }
    
    /**
     * EFX 的混合标志位 → 本项目的混合模式（规则依现有数据的实测对应关系反推）：{@code bit2}（值 4）非零 → 反向减法；否则 {@code bit0}（1）或
     * {@code bit1}（2）任一非零 → 加法（{@code Flags = 2 / 3 / 17} 的层都是加法层）；其余（{@code 0} / {@code 16}）→ 普通半透明。
     * 只看 bit2 / bit1 会把 {@code Flags = 17} 的层误判成半透明，这是"大部分特效观感变淡"的主要原因之一。<b>本方法只适用于 {@code TypePolygon} / {@code Billboard3D} 的位掩码。</b>
     */
    public static PolygonBlendMode blendMode(int flags) {
        if ((flags & 4) != 0) {
            return PolygonBlendMode.REVERSE_SUBTRACT;
        }
        if ((flags & 3) != 0) {
            return PolygonBlendMode.ADDITIVE;
        }
        return PolygonBlendMode.TRANSLUCENT;
    }
    
    /**
     * 把 EFX 的"每 EFX 帧倍率"折算成"每 tick 倍率"（1 tick = 3 帧，故取三次方）。<b>为什么必须折算</b>：尺寸增量用的是等比级数的极限
     * {@code perTick / (1 − coefficient)}，系数差一点点、极限就差很多——某层的 {@code 0.1 / 0.9} 本该收敛到 1 格，不折算会算成 3 格，
     * 再乘全局尺寸倍率后单个面片宽达 8 格以上（实测的"效果过大"）。
     */
    public static float perTickCoefficient(float frameCoefficient) {
        if (frameCoefficient <= 0.0F) {
            return 0.0F;
        }
        return frameCoefficient * frameCoefficient * frameCoefficient;
    }
    
    /**
     * 把"每 EFX 帧的增量"折算成"每 tick 的等效增量"的权重。<b>不能简单乘 {@link #FRAMES_PER_TICK}</b>——增量本身按系数逐帧衰减，一 tick 内的
     * 三次增量之和是 {@code add × (1 + c + c²)} 而不是 {@code add × 3}（{@code c = 0.9} 时是 2.71 而非 3，极限尺寸差约 11%）；配合
     * {@link #perTickCoefficient(float)} 可做到<b>与逐帧模拟完全等价</b>，{@code c = 1}（不衰减）时退化为 {@link #FRAMES_PER_TICK}。
     */
    public static float framesPerTickWeight(float frameCoefficient) {
        float coefficient = Math.max(0.0F, frameCoefficient);
        return 1.0F + coefficient + coefficient * coefficient;
    }
    
    /**
     * 把 EFX 的 {@code {s, r}} 数值对折算成"相对基准的随机比例"（±），即 {@code |r / 2 ÷ s|}；{@code s} 为 0 时返回 0。
     */
    public static float relativeVariation(EfxRange range) {
        return range.s() != 0.0F ? Math.abs(range.r() * 0.5F / range.s()) : 0.0F;
    }
    
    /**
     * 取 EFX 数值区间的中值 {@code s + r / 2}：本项目的生命字段是单值，而 EFX 的四个生命字段是"基准 + 随机幅度"，取中值即"随机在两个端点间
     * 均匀取值"的期望，是当前结构下最接近的近似，面片 / 网格 / 碎片三个视图统一采用。
     */
    public static float rangeMean(EfxRange range) {
        return range.s() + range.r() * 0.5F;
    }
    
    /**
     * 弧度 → 度。
     */
    public static float toDegrees(float radians) {
        return radians * DEGREES_PER_RADIAN;
    }
    
    /**
     * 把"每帧衰减系数"换算成"每 tick 衰减系数"（1 tick = 3 帧，如 {@code 0.9³ ≈ 0.729}）。
     */
    public static float perFrameToPerTick(float perFrame) {
        return perFrame * perFrame * perFrame;
    }
}
