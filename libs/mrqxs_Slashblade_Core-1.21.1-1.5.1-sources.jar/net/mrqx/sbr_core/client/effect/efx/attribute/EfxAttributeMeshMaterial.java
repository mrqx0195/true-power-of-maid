package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * <b>本项目扩展属性</b>：光环类网格材质（{@code mesh_03_pl0300_aura} 系列）的逐层材质参数覆写，
 * 即 EFX 的 {@code EFXAttributeTypeMesh} 的 {@code properties} 表；
 * 12 个字段全部由渲染侧作为 uniform 消费（{@code mesh_dissolve.json} 的 {@code Ripple*} 系列），
 * 无"仅作记录"的字段。
 * <p>
 * <b>必须逐层承载</b>：护盾与収束オーラ两层共用同一材质、只有本类的值不同（如 {@code Green_Scale2} 为 2 / 3），
 * 内联成着色器常量就会丢掉差异。
 * <p>
 * <b>不落在这里</b>：{@code Red_Offset}/{@code Green_Offset}/{@code EmissiveRate} 随生命期成曲线，由 {@link EfxAttributeMeshClip} 承载；
 * {@code UVFade_Enable}、{@code VolumeBlend*}、{@code FlowIntensity}、{@code Morph_*} 取静态默认、恒等值或标 {@code [unused]}，故不设字段。
 * <p>
 * <b>两端色是材质参数（{@code cb3}）</b>：本层只覆写 {@code ColorHigh}、{@code ColorParam} 仍是 mdf2 默认，
 * 照类型属性的 {@code color2}（纯白）染色会与实际不符；纹波层一律以材质参数为准。
 *
 * @param colorParam           低色端（常规 ARGB）；本层 EFX 未覆写 ⇒ 取 mdf2 默认纯白 {@code 0xFFFFFFFF}
 * @param colorHigh            高色端（常规 ARGB）；由 EFX 覆写，两层均近黑的深蓝，缺省 {@link #DEFAULT_COLOR_HIGH}
 * @param redScaleU            红路基础 UV 的 U 分量缩放（{@code Red_Scale}）；采样 UV 为 {@code (1 − UV0) × (scaleU, scaleV)}
 * @param redScaleV            红路基础 UV 的 V 分量缩放（{@code Red_Scale2}）；缺省 1
 * @param greenScaleU          绿路基础 UV 的 U 分量缩放（{@code Green_Scale}）；缺省 1
 * @param greenScaleV          绿路基础 UV 的 V 分量缩放（{@code Green_Scale2}）：两层"纹理疏密不同"的直接来源；缺省 1
 * @param redPower             红通道遮罩的幂次（{@code Red_Power}）；缺省 1
 * @param greenPower           绿通道遮罩的幂次（{@code Green_Power}）；缺省 1
 * @param uvFadeLow            半径遮罩 {@code smoothstep} 的下界（{@code UVFade_Low}）；缺省 {@code 0.2}
 * @param uvFadeHigh           半径遮罩 {@code smoothstep} 的上界（{@code UVFade_High}）；未被覆写时 1
 * @param edgeSmoothingOutside 菲涅尔归一化的下界（{@code EdgeSmoothing_OutsideAngle}）；缺省 0
 * @param edgeSmoothingInside  菲涅尔归一化的上界（{@code EdgeSmoothing_InsideAngle}）：对平面圆盘即"俯视到何种程度气浪才成形"；缺省 {@code 0.2}
 */
public record EfxAttributeMeshMaterial(
    int colorParam,
    int colorHigh,
    float redScaleU,
    float redScaleV,
    float greenScaleU,
    float greenScaleV,
    float redPower,
    float greenPower,
    float uvFadeLow,
    float uvFadeHigh,
    float edgeSmoothingOutside,
    float edgeSmoothingInside
) implements EfxAttribute {
    /**
     * 扩展属性编号。
     */
    public static final int TYPE = -7;
    
    /**
     * {@code ColorHigh} 的材质静态默认值（mdf2 里的 {@code 0xFF2E0D8F} 蓝紫）。
     * <b>声明位置必须在 {@link #DEFAULT} 之前</b>：静态字段按文本顺序初始化，写在下面会让 {@code DEFAULT} 读到 {@code 0}（透明黑）。
     */
    public static final int DEFAULT_COLOR_HIGH = 0xFF2E0D8F;
    
    /**
     * 默认值：全部取 mdf2 静态默认，即"该层没有覆写任何材质参数"时的行为（纯白 + {@link #DEFAULT_COLOR_HIGH} +
     * 四个缩放与两个幂次 1 + {@code UVFade 0.2/1} + {@code EdgeSmoothing 0/0.2}）。
     */
    public static final EfxAttributeMeshMaterial DEFAULT = new EfxAttributeMeshMaterial(
        0xFFFFFFFF, DEFAULT_COLOR_HIGH,
        1.0F, 1.0F, 1.0F, 1.0F,
        1.0F, 1.0F,
        0.2F, 1.0F,
        0.0F, 0.2F);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "SbrAttributeMeshMaterial";
    }
}
