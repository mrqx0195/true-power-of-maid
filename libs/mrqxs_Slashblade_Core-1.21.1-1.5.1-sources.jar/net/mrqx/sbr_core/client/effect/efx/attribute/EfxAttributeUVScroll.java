package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 属性 {@code EFXAttributeUVScroll}：UV 滚动（对应 json 的 {@code type} = 98）。
 * <p>
 * EFX 数据里<b>没有任何一层配置它</b>，因此现有数值（割れ　青　1 的 {@code 0.15}）是早期手调的观感值，
 * 而非从 EFX 数据还原——它在本项目里承担"雾状裂纹内的能量流动"这一表现。
 * 本项目此前把它写成了自定义字段（{@code SbrRender.uvScrollV}），现已按 EFX 的归属迁回本类。
 * <p>
 * <b>数值语义</b>：{@code *Add} 是"每帧的 UV 偏移增量"，{@code *AddCoef} 是该增量的逐帧衰减系数，
 * {@code *Offset} 是初始 UV 偏移；本项目当前只消费 {@code vScrollAdd}（U 轴的滚动暂无对应表现），
 * 其余字段原样承载以便后续补全。
 *
 * @param flags          滚动标志位（{@code Flags}，本项目不消费）
 * @param uScrollAdd     U 轴每帧偏移增量
 * @param vScrollAdd     V 轴每帧偏移增量
 * @param uScrollAddCoef U 轴增量的逐帧衰减系数
 * @param vScrollAddCoef V 轴增量的逐帧衰减系数
 * @param uScrollOffset  U 轴初始偏移
 * @param vScrollOffset  V 轴初始偏移
 */
public record EfxAttributeUVScroll(
    int flags,
    EfxRange uScrollAdd,
    EfxRange vScrollAdd,
    EfxRange uScrollAddCoef,
    EfxRange vScrollAddCoef,
    EfxRange uScrollOffset,
    EfxRange vScrollOffset
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 98;
    
    /**
     * 默认值：不滚动。
     */
    public static final EfxAttributeUVScroll DEFAULT = new EfxAttributeUVScroll(
        0, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeUVScroll";
    }
    
    /**
     * 构造一个"只沿 V 轴匀速滚动"的配置。
     * <p>
     * 本项目实际需要的就是这一个自由度（贴图内的能量沿刀身方向流动），
     * 因此提供一个便捷工厂，避免每个预设都写七个参数。
     *
     * @param vScrollPerTick V 轴每 tick 的偏移增量
     * @return 只滚动 V 轴、各轴增量均不衰减的配置
     */
    public static EfxAttributeUVScroll vScrollPerTick(float vScrollPerTick) {
        return new EfxAttributeUVScroll(0,
            EfxRange.ZERO, new EfxRange(vScrollPerTick, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO);
    }
    
    /**
     * V 轴每 tick 的滚动增量（{@code vScrollAdd} 的基准值）。
     */
    public float vScrollPerTick() {
        return this.vScrollAdd.s();
    }
}
