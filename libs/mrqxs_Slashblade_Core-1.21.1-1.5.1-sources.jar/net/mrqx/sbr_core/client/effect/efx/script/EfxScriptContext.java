package net.mrqx.sbr_core.client.effect.efx.script;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxNoDrawView;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributePtBehavior;
import org.joml.Vector3f;

/**
 * 一次脚本执行的上下文：<b>哪个世界、从哪里起算、哪一层的配置</b>。
 * <p>
 * 三样东西缺一不可：
 * <ul>
 *   <li>{@link #level}——执行者要往世界里放东西（贴地面片）时需要；</li>
 *   <li>{@link #origin}——本次演出的原点（例如斩击命中点），是<b>世界坐标</b>而非相机局部坐标；</li>
 *   <li>{@link #view}——该层的 EFX 配置视图，位置偏移、时长、尺寸、参数全在里面。</li>
 * </ul>
 * <p>
 * 坐标加法只做一次且收在 {@link #position()} 里：执行者只拿到最终的世界坐标，
 * 就没有再算错的机会。
 *
 * @param level  客户端世界
 * @param origin 演出原点（世界坐标）
 * @param view   该 NoDraw 层的 EFX 配置视图
 */
public record EfxScriptContext(ClientLevel level, Vec3 origin, EfxNoDrawView view) {
    /**
     * 本次效果的世界落点：演出原点 + 层的局部位置偏移。
     *
     * @return 世界坐标
     */
    public Vec3 position() {
        Vector3f offset = this.view.localPosition;
        return this.origin.add(offset.x, offset.y, offset.z);
    }
    
    /**
     * 该层的脚本属性（脚本名 + 完整参数表）。
     *
     * @return 脚本属性；该层没配 {@code PtBehavior} 时是空脚本的默认实例
     */
    public EfxAttributePtBehavior behavior() {
        return this.view.behavior;
    }
    
    /**
     * 出现（渐显）段长度（tick）。
     */
    public int appearTicks() {
        return this.view.appearTicks;
    }
    
    /**
     * 保持（满强度）段长度（tick）。
     */
    public int keepTicks() {
        return this.view.keepTicks;
    }
    
    /**
     * 消散（渐隐）段长度（tick）。
     */
    public int vanishTicks() {
        return this.view.vanishTicks;
    }
    
    /**
     * 生命总长（tick），即三段之和；执行者的默认作用时长。
     */
    public int totalLifeTicks() {
        return this.view.totalLifeTicks;
    }
}
