package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * GPU 实例化 billboard 类型属性（{@code EFXAttributeTypeGpuBillboard}，{@code type = 265}）。
 * <p>
 * 与 {@link EfxTypeBillboard3D} 的差别只有两处命名：本类型用 {@code instanceCount} 表示
 * <b>同时存在的实例数</b>（Billboard3D 走的是 {@code Spawn.MaxParticles}），
 * 用 {@code BlendFlags} 表示混合位（Billboard3D 叫 {@code Flags}）。
 * 颜色 / 配色幅度 / 色彩倍率 / 强度 / 边缘混合 / alpha 倍率 / 旋转 / 尺寸这些字段两者同构，
 * 因此 {@link net.mrqx.sbr_core.client.effect.efx.EfxPolygonView} 会把本类型<b>折算成一个等价的
 * Billboard3D</b> 之后再摊平，整条面片渲染管线得以共用。
 * <p>
 * <b>载荷边界：48 字节</b>。本类型在 DMC5 的载荷恰好就是本 record 的 10 个字段
 * （{@code 8 × 4 + 8 + 8 = 48}）。参考实现对该类型的声明里还有
 * {@code unkn3} / {@code ParticleNum} / {@code Flags} / {@code re4Ukn} /
 * {@code SizeX} / {@code SizeY} / {@code Offset} 七个字段，但它们各自带版本门：
 * {@code ParticleNum} 与 {@code Flags} 需 {@code >= RE4}，{@code SizeX} / {@code SizeY} /
 * {@code Offset} 需 {@code >= RERT}，而 DMC5 的版本早于 RE4 —— 所以
 * <b>DMC5 的载荷里根本不写它们</b>（这也解释了 JSON 导出里它们恒为默认值 0，
 * 那是"没读到就填 0"，不是"读到 0"）。
 * <p>
 * <b>因此不要把上述字段补进来。</b>本项目曾一度按参考实现的声明建过
 * {@code sizeX} / {@code sizeY} / {@code offsetX} / {@code offsetY} 四个字段，
 * 而全部预设里它们在语义上都只能是 0（{@code 1 + 0} 是恒等因子），
 * 属于纯粹的死字段 —— 已随载荷边界的确证一并删除。
 *
 * @param instanceCount  同时存在的实例数
 * @param blendFlags     混合标志位
 * @param color          主体颜色（常规 ARGB，已交换 R/B）
 * @param colorRange     配色抖动范围（常规 ARGB，alpha 为 0 表示不抖动）
 * @param colorRate      色彩倍率
 * @param intensity      自发光强度
 * @param edgeBlendRange 边缘混合范围
 * @param alphaRate      alpha 倍率
 * @param rotation       画面内滚转：{@code s} 为基准、{@code r} 为随机幅度（弧度）
 * @param sizeScalar     尺寸基准与随机幅度（格）
 */
public record EfxTypeGpuBillboard(
    int instanceCount,
    int blendFlags,
    int color,
    int colorRange,
    float colorRate,
    float intensity,
    float edgeBlendRange,
    float alphaRate,
    EfxRange rotation,
    EfxRange sizeScalar
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 265;
    
    /**
     * 默认值：不生成实例、加法外的一切取中性值。
     */
    public static final EfxTypeGpuBillboard DEFAULT = new EfxTypeGpuBillboard(
        0, 0, 0xFFFFFFFF, 0x00000000, 1.0F, 1.0F, 0.0F, 0.0F,
        EfxRange.ZERO, new EfxRange(1.0F, 0.0F));
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeGpuBillboard";
    }
}
