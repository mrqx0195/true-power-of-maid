package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.minecraft.resources.ResourceLocation;

/**
 * EFX 脚本参数的值（{@code EFXAttributePtBehavior} 里的 {@code properties[].variable}）。
 * <p>
 * 类型以 json 的 {@code dataType} 为准，{@code $type} 只在 {@code RszSwitch} 注册过该编号时才写得出来。
 * 参考实现里这组编号（{@code EFX PtBehaviorPropType}）是
 * {@code 4 = PropUint} / {@code 9 PropFloat} / {@code 10 PropRange} / {@code 11 PropFloat3} / {@code 14 PropInt} /
 * {@code 15 PropColor} / {@code 16 PropWstringName} / {@code 17 PropPrefabpath} / {@code 18 PropEnum} /
 * {@code 19 PropFloat2} / {@code 21 PropWstring2}。
 * <p>
 * <b>本接口未覆盖的编号</b>：{@code 3} 与 {@code 20}——数据里各出现 8 / 5 次（集中在 {@code カメラシェイク小}、
 * {@code radial_blur}、{@code 黒フィルター}、{@code カラコレ} 这几个脚本层），但<b>枚举里根本没有</b>这两个编号，
 * 故落进"原始字节"分支、按 {@link RawValue} 承载，不猜名字。另有 {@code 4 = PropUint} 属枚举有名字、
 * 本项目未建模，同样落原始字节（现有数据里一次都没出现过）。
 * <p>
 * 本接口 {@code sealed}：参数类型是封闭集合，读取侧可放心穷举；各变体都是<b>纯数据承载 record</b>，
 * 不含任何行为、没有消费点。
 */
public sealed interface EfxBehaviorValue {
    /**
     * 参数类型编号（json 的 {@code dataType}，即 EFX {@code PtBehaviorPropType} 的编号）。
     */
    int dataType();
    
    /**
     * 单浮点（EFX {@code PropFloat}）。
     */
    int PROP_FLOAT = 9;
    
    /**
     * 浮点区间（EFX {@code PropRange}）。
     */
    int PROP_RANGE = 10;
    
    /**
     * 三分量浮点（EFX {@code PropFloat3}）。
     */
    int PROP_FLOAT3 = 11;
    
    /**
     * 整数（EFX {@code PropInt}）。
     */
    int PROP_INT = 14;
    
    /**
     * 颜色（EFX {@code PropColor}）。
     */
    int PROP_COLOR = 15;
    
    /**
     * 名称字符串（EFX {@code PropWstringName}）。
     */
    int PROP_WSTRING_NAME = 16;
    
    /**
     * 预制体路径（EFX {@code PropPrefabpath}）。
     */
    int PROP_PREFAB_PATH = 17;
    
    /**
     * 枚举（EFX {@code PropEnum}）。
     */
    int PROP_ENUM = 18;
    
    /**
     * 双分量浮点（EFX {@code PropFloat2}）。
     */
    int PROP_FLOAT2 = 19;
    
    /**
     * 宽字符串 2（EFX {@code PropWstring2}）。
     */
    int PROP_WSTRING2 = 21;
    
    /**
     * 单浮点。
     */
    record FloatValue(float value) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_FLOAT;
        }
    }
    
    /**
     * 整数。
     */
    record IntValue(int value) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_INT;
        }
    }
    
    /**
     * 枚举项；与 {@link IntValue} 同为整数，只靠类型编号区分"这个整数是选项索引"。
     */
    record EnumValue(int value) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_ENUM;
        }
    }
    
    /**
     * 浮点区间（{@code via.Range}，字段名沿用 EFX 的 {@code s} / {@code r}）。
     */
    record RangeValue(float s, float r) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_RANGE;
        }
    }
    
    /**
     * 双分量浮点。
     */
    record Float2Value(float x, float y) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_FLOAT2;
        }
    }
    
    /**
     * 三分量浮点。
     */
    record Float3Value(float x, float y, float z) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_FLOAT3;
        }
    }
    
    /**
     * 颜色。
     * <p>
     * 约定常规 ARGB；json 里按"R 在最低字节"书写，转换规则与 {@code EfxTypePolygon} 的 {@code Color} 一致（交换 R/B）。
     */
    record ColorValue(int argb) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_COLOR;
        }
    }
    
    /**
     * 字符串，涵盖三种字符串编号（名称 16 / 预制体路径 17 / 宽字符串 2 21）：内存里都是 UTF-16，
     * 差别只在用途，故合成一个变体并保留 {@code dataType}。
     *
     * @param value 字符串内容（已去掉结尾的 NUL）
     */
    record StringValue(int dataType, String value) implements EfxBehaviorValue {
    }
    
    /**
     * 本项目实际使用的资源路径。
     * <p>
     * 字符串参数原本承载的是引擎侧资源路径，本项目里无意义，要加载的是本项目贴图；
     * 用 {@link ResourceLocation} 承载可杜绝"字符串拼路径"，写错在加载时立刻暴露。编号沿用
     * {@link #PROP_WSTRING2}——现有数据里该编号只出现于 LUT 校正层的 {@code Cube2Texture}。
     */
    record ResourceValue(ResourceLocation resource) implements EfxBehaviorValue {
        
        @Override
        public int dataType() {
            return PROP_WSTRING2;
        }
    }
    
    /**
     * 原始字节：编号不在类型枚举里、或类型无法确证的项。
     * <p>
     * 紧凑承载约定：小端，仅前 {@code byteLength} 个字节有效；来源数据出现超过 8 字节的项时
     * {@link #ofRaw(int, long, int)} 直接抛异常，宁可当场暴露也不静默截断。
     * <p>
     * 已知偏差（待裁决）：编号 {@code 3}（径向模糊的 {@code Priority}）类型枚举里没有，故不猜其名；
     * 编号 {@code 20}（相机震动的 {@code Period}）8 字节，按整数读作 {@code (0, 1)}、按浮点读第二分量是次正规数，
     * 更可能是两个整数，但同样无从确证分量名。
     *
     * @param bits       原始字节按小端拼成的整数（仅前 {@code byteLength} 字节有效）
     * @param byteLength 原始字节数（1~8）
     */
    record RawValue(int dataType, long bits, int byteLength) implements EfxBehaviorValue {
        
        /**
         * 校验长度，避免出现"高字节是脏数据"的实例。
         */
        public RawValue {
            if (byteLength < 1 || byteLength > Long.BYTES) {
                throw new IllegalArgumentException(
                    "EFX 原始参数只支持 1~8 字节，收到 " + byteLength + " 字节");
            }
        }
        
        /**
         * 把原始字节按小端读作整数（用于 {@code Priority} 这类"编号未确证、长度与整数相同"的项）。
         */
        public int littleEndianInt() {
            return (int) this.bits;
        }
    }
    
    static EfxBehaviorValue ofFloat(float value) {
        return new FloatValue(value);
    }
    
    static EfxBehaviorValue ofInt(int value) {
        return new IntValue(value);
    }
    
    static EfxBehaviorValue ofEnum(int value) {
        return new EnumValue(value);
    }
    
    static EfxBehaviorValue ofRange(float s, float r) {
        return new RangeValue(s, r);
    }
    
    static EfxBehaviorValue ofFloat2(float x, float y) {
        return new Float2Value(x, y);
    }
    
    static EfxBehaviorValue ofFloat3(float x, float y, float z) {
        return new Float3Value(x, y, z);
    }
    
    static EfxBehaviorValue ofColor(int argb) {
        return new ColorValue(argb);
    }
    
    /**
     * 构造"名称"类字符串参数。
     */
    static EfxBehaviorValue ofName(String value) {
        return new StringValue(PROP_WSTRING_NAME, value);
    }
    
    /**
     * 构造"预制体路径"类字符串参数。
     */
    static EfxBehaviorValue ofPrefabPath(String value) {
        return new StringValue(PROP_PREFAB_PATH, value);
    }
    
    /**
     * 构造"宽字符串 2"类字符串参数。
     */
    static EfxBehaviorValue ofWString2(String value) {
        return new StringValue(PROP_WSTRING2, value);
    }
    
    /**
     * 构造"本项目资源路径"类参数。
     */
    static EfxBehaviorValue ofResource(ResourceLocation resource) {
        return new ResourceValue(resource);
    }
    
    /**
     * 构造原始字节参数。
     *
     * @param byteLength 原始字节数（1~8）
     */
    static EfxBehaviorValue ofRaw(int dataType, long bits, int byteLength) {
        return new RawValue(dataType, bits, byteLength);
    }
}
