package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack.EfxJcePolygonPresets;
import org.joml.Vector3f;

/**
 * 「次元斩·絶」<b>范围效果</b>中<b>面片类</b>层的 EFX 预设，结构与 {@link EfxJcePolygonPresets}（斩绝本体）
 * 完全一致，通用换算见其类注释。本类特有约定：
 * <ul>
 *   <li>绑定到 {@code Waist} / {@code Chest} 的层其固定偏移由 {@code BoneOffset} 在时间轴侧施加，本类只承载
 *       数据自身的 {@code LocalPosition}；分批生成折叠为一次性生成，故 {@code loopNumDmc5} 只作记录；</li>
 *   <li>效果范围口径为半径约 10 格的水平圆，发射范围与扩散速度均按它标定；{@code ColorRange} 与
 *       {@code Saturation} 未测出真实效果、暂不消费，各常量仍照原值记录以作对照。</li>
 * </ul>
 * TODO(P10)：逐字段精细校对（各 {@code {s, r}} 随机幅度、混合模式位），实机验收后按观感回填。
 */
public final class EfxJceRangePolygonPresets {
    /**
     * 拼出贴图完整路径（TextureManager 需要 {@code textures/….png} 全路径，参数为不含扩展名的贴图名）。
     */
    public static ResourceLocation texture(String name) {
        return MrqxSlashBladeCore.prefix("textures/effect/" + name + ".png");
    }
    
    /**
     * {@code 地面　収束　炎}：在角色身边小范围内持续出现、向角色收拢的蓝色火焰，持续生成。
     * ⚠ 勿与 {@link #RANGE_CONVERGE_BURST}（{@code 範囲　収束　炎}，向外扩大的两次爆发）混淆。
     * <p>
     * <b>方向取向心是有意偏离数据原值的手调值，不要按数据原值改回</b>：数据原值为 {@code VelocityType = 1}（Normal）
     * 配 {@code Speed = +8}，实测方向取向心，故写 {@code VelocityType = 2}（Radial）、速度取负向。
     * 生成偏移写 {@code -0.1}，与数据的 {@code -1.2} 不一致（待复核）。
     */
    public static final EfxConfig GROUND_CONVERGE_FIRE = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                3, 0xFF393039, 0x801D1D61, 1.5F, 0, 800.0F, 0.0F,
                new EfxRange(3.1415927F, 1.5F),
                new EfxRange(0.2F, 3.0F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(160, 0, 5, 5, 7, 7, 0, false, 5, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 0.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 3))
        .put(EfxAttributeCharacterSpace.CHARACTER_SIZED)
        .put(new EfxAttributeLife(new EfxRange(6.0F, 5.0F), EfxRange.ZERO,
            new EfxRange(24.0F, 18.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new EfxRange(-1.2F, 0.0F), new EfxRange(0.96F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(0.1F, 1.0F, 0.1F),
            2,
            new EfxRange(-0.1F, 0.0F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(2.0F, 3.0F), new EfxRange(-0.2F, -0.2F), new EfxRange(2.0F, 3.0F),
            2, 12, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(1.6F, 1.8F), 553, EfxJceRangePolygonPresets.texture("fire_generic")))
        .put(new EfxAttributeFadeByDepth(2.5F, 5.0F, 100.0F, 120.0F))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * {@code 歪み_head2}：在角色脚底出现、持续向上升腾的黑色 / 深蓝色火焰，不宽于角色、不高于腰部，持续生成。
     */
    public static final EfxConfig WARP_BUBBLE = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                // 实测 flag=4 效果更接近
                4, 0xFF01125C, 0xFFFF616F, 1.0F, 1.0F, 1.0F, 0.0F,
                new EfxRange(3.1415927F, 0.4F),
                new EfxRange(0.01F, 0.1F),
                new EfxRange(1, 0),
                new EfxRange(1, 0),
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(120, 0, 1, 1, 2, 2, 0, false, 60, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(12.0F, 12.0F), EfxRange.ZERO,
            new EfxRange(25.0F, 25.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            EfxRange.ZERO, new EfxRange(1, 0.0F), EfxRange.ZERO,
            new EfxRange(0.1F, 0), new EfxRange(0.8F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F),
            0,
            new EfxRange(-1.2F, 0.0F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(0.0F, 0.2F), new EfxRange(0.0F, 0.3F), new EfxRange(0.0F, 0.2F),
            1, 3, 1, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(0.0F, 1.5707964F)))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.1F, 0.02F), new EfxRange(0.9F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(0.5F, 0.6F), 553, EfxJceRangePolygonPresets.texture("fire_generic")))
        .put(new EfxAttributeFadeByDepth(2.5F, 5.0F, 100.0F, 120.0F))
        .put(EfxAttributeCharacterSpace.CHARACTER_SIZED)
        .put(new EfxAttributeSbrRender(false, 0.5F, 0.5F, false))
        .put(new EfxAttributeShaderSettings(0.3F, -0.4F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * {@code 範囲　収束　炎1}：范围效果主力——大量出现在水平效果范围边界上的小火焰，持续生成。
     * <p>
     * 序列帧必须是同族的 32 帧，否则整张贴图会被当成单帧渲染；
     * 近似点：只借用 {@code PtCollision} 的贴地语义，反弹物理未实现。
     */
    public static final EfxConfig RANGE_CONVERGE_FIRE_DENSE = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                18, 0xFF0009FF, 0xFF000D7B, 55.0F, 1.0F, 1.0F, 0.0F,
                new EfxRange(3.1415927F, 1.0F),
                new EfxRange(0.5F, 1.5F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1000, 0, 50, 50, 0, 0, 90, false, 40, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 0.5F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(3.0F, 3.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(25.0F, 15.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.35F, 0.0F), new EfxRange(0.95F, 0.01F), EfxRange.ZERO,
            new Vector3f(0.0F, 0.3F, 0.0F), new Vector3f(1.5F, 1.0F, 1.5F),
            0,
            new EfxRange(-0.3F, 0.0F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(9.0F, 1.0F), EfxRange.ZERO, new EfxRange(9.0F, 1.0F),
            2, 0, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        // 尺寸动画取 EFX 原值（整体尺寸逐帧增量 0.07、增量衰减系数 0.98）。它是本层与
        // RANGE_CONVERGE_FIRE_FLOW 之间"火焰大小不同"的**唯一**来源：两层的 SizeScalar / SizeX 完全相同。
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.07F, 0.02F), new EfxRange(0.98F, 0.01F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(1.0F, 1.0F), 1, texture("fire_generic")))
        .put(new EfxAttributeFadeByDepth(3.0F, 4.0F, 100.0F, 120.0F))
        .put(new EfxAttributeShaderSettings(0.05F, -0.1F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributePtCollision(16, new EfxRange(0.1F, 0.1F), new EfxRange(3.0F, 3.0F),
            new EfxRange(0.7F, 0.7F), 1, 1, 0, 3.0F, 4.5F, 0.0F, EfxRange.ZERO))
        .build();
    
    /**
     * {@code 範囲　収束　炎2}：与 {@link #RANGE_CONVERGE_FIRE_DENSE} 同位置、同运动的稀疏叠层，量更少、单片火焰更大，持续生成。
     * <p>
     * "火焰更大"由尺寸动画增量（{@code SizeScalarAdd}）承担，两层的基准尺寸其实完全相同。
     */
    public static final EfxConfig RANGE_CONVERGE_FIRE_FLOW = EfxConfigBuilder.create(
            new EfxTypeBillboard3D(
                18, 0xFF0009FF, 0xFF00031D, 30.0F, 0.5F, 1.0F, 0.0F,
                new EfxRange(3.1415927F, 2.0F),
                new EfxRange(0.5F, 1.5F),
                new EfxRange(0.0F, 1.0F),
                EfxRange.ZERO,
                0, 0, false, false, false,
                EfxRange.ZERO))
        .put(new EfxAttributeSpawn(50, 0, 4, 4, 0, 0, 90, false, 40, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 0.5F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(3.0F, 3.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(25.0F, 15.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.35F, 0.0F), new EfxRange(0.95F, 0.01F), EfxRange.ZERO,
            new Vector3f(0.0F, 0.3F, 0.0F), new Vector3f(1.5F, 1.0F, 1.5F),
            0,
            new EfxRange(-0.3F, 0.0F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(9.0F, 1.0F), EfxRange.ZERO, new EfxRange(9.0F, 1.0F),
            2, 0, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        // 与 RANGE_CONVERGE_FIRE_DENSE 同参数，只有整体尺寸逐帧增量不同（0.3 对 0.07，EFX 原值）
        // ——这就是"本层单片火焰更大"的全部来源。
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.3F, 0.02F), new EfxRange(0.98F, 0.01F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(0.25F, 0.25F), 1, texture("fire_generic")))
        .put(new EfxAttributeFadeByDepth(3.0F, 4.0F, 100.0F, 120.0F))
        .put(new EfxAttributeShaderSettings(0.05F, -0.1F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributePtCollision(16, new EfxRange(0.1F, 0.1F), new EfxRange(3.0F, 3.0F),
            new EfxRange(0.7F, 0.7F), 1, 1, 0, 3.0F, 4.5F, 0.0F, EfxRange.ZERO))
        .build();
    
    /**
     * {@code GPU　胸　上昇青炎}：笼罩角色全身的蓝青色火焰 / 烟雾，由大量粒子在小范围内聚集而成；
     * 从腿部出现、主要聚集于上半身，最多略高于头顶；只触发一次，随后靠粒子不断重生成维持。
     */
    public static final EfxConfig CHEST_RISING_FLAME = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                // ⚠ 实例数**有意取 84**：数据 `instanceCount = 42`，这里放大约 2×。
                // 与 OPENING_GPU_SMOKE 同口径：作者裁决"保持现值 + 记明"。
                84, 5,
                0xFF0E218A, 0xFF0E218A,
                120.0F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 0.9F),
                new EfxRange(1.8F, 0.0F)))
        .put(new EfxAttributeSpawn(1, 0, 3, 3, 0, 0, 0, false, 40, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(EfxAttributeCharacterSpace.CHARACTER_SIZED)
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.03F, 0.01F), new EfxRange(0.98F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeLife(new EfxRange(6.0F, 6.0F), EfxRange.ZERO,
            new EfxRange(15.0F, 1.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            EfxRange.ZERO, new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new EfxRange(0.4F, 0.1F), new EfxRange(0.96F, 0.0F), EfxRange.ZERO,
            new Vector3f(0.0F, 0.5F, 0.0F), new Vector3f(2.0F, 1.5F, 2.0F),
            0,
            new EfxRange(-0.8F, 0.05F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(0.0F, 0.7F), new EfxRange(0.0F, 0.7F), new EfxRange(0.0F, 0.7F),
            1, 5, 1, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(0.6F, 1.0F), 9, EfxJceRangePolygonPresets.texture("smoke_chest_flame"), 64))
        .put(new EfxAttributeFadeByDepth(2.5F, 5.0F, 100.0F, 120.0F))
        .put(new EfxAttributeShaderSettings(0.3F, -0.2F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * {@code 開始 GPU煙}：从角色位置快速扩大至效果范围、并在扩散过程中减淡消失的蓝黑色烟雾，只生成一次。
     * 增益与尺寸均取数据原值——全局尺寸倍率已统一放大整段演出，预设里再手调一次就是双重放大。
     */
    public static final EfxConfig OPENING_GPU_SMOKE = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                // ⚠ 实例数**有意取 400**：数据 `instanceCount = 40`，这里放大约 10× 以补烟雾密度。
                // 作者裁决"保持现值 + 记明"——**不是抄错**，改回数据值会让本层粒子数掉到十分之一。
                400, 17,
                0xB3000DFF, 0xFF02003B,
                1.0F, 2.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 2.0F),
                new EfxRange(0.5F, 1.0F)))
        // ⚠ `SpawnNum` **有意写 (100, 100)**：数据是 `(10, 10)`，这里按"生成量"口径放大了
        //（同族的 `OPENING_GPU_SMOKE_WATER` 对数据 `(20, 20)` 是照抄，故本层属**有意偏离**）。
        // 作者裁决"保持现值 + 记明"。
        .put(new EfxAttributeSpawn(1, 0, 100, 100, 0, 0, 4, false, 1, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(15.0F, 15.0F),
            new EfxRange(12.0F, 12.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(6.0F, 1.0F), new EfxRange(0.98F, 0.0F), EfxRange.ZERO,
            new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(5.0F, 3.0F, 5.0F),
            0,
            EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        // 尺寸动画取数据原值（逐帧增量 0.3、不衰减）——"快速扩大至效果范围"这一行为全靠它：
        // 类型属性里的 SizeScalar 是静态的，缺了本属性这层只会平移不会长大。
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.3F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(1.5F, 1.5F), new EfxRange(1.5F, 1.5F), new EfxRange(1.5F, 1.5F),
            1, 10, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(0.0F, 1.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(1.5F, 2.0F), 553, texture("fire_generic")))
        .put(new EfxAttributeFadeByDepth(4.0F, 6.0F, 50.0F, 70.0F))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        // 自转：数据这条的 `RotationAddX = (0, 0.017453294)`（基准 0、随机半幅 1°）
        // ——即每片随机取 ±1°/帧 的 X 轴自转，`RotationCoefX = 0.95` 让它逐帧衰减。
        // 本层朝向是自由朝向（无 SbrRender、非 groundPlane），故 X 轴自转会被消费。
        // ⚠ `RotationCoef*` 目前**未被消费**（消费侧只取基准角速度），故这里忠实抄下以便日后接上。
        .put(new EfxAttributeRotateAnim(1,
            new EfxRange(0.0F, 0.017453294F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(0.95F, 0.01F), EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .build();
    
    /**
     * {@code 範囲　収束　炎}：从角色位置快速扩大至水平效果范围的一圈蓝色火焰 / 烟雾，先后生成两次。
     * 名字里的"収束"不描述它的运动——实测并没有收束效果。
     */
    public static final EfxConfig RANGE_CONVERGE_BURST = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                130, 5,
                0xFF030BFF, 0x5200168F,
                0.01F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 1.8F),
                new EfxRange(0.5F, 0.0F)))
        .put(new EfxAttributeSpawn(1, 0, 65, 65, 7, 7, 2, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 0.2F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 3))
        .put(new EfxAttributeLife(new EfxRange(8.0F, 4.0F), new EfxRange(4.0F, 4.0F),
            new EfxRange(30.0F, 18.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(5.0F, 0.0F), new EfxRange(0.95F, 0.01F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(20.0F, 1.0F, 20.0F),
            1,
            new EfxRange(-0.7F, 0.0F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.2F, 0.02F), new EfxRange(0.99F, 0.01F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(1.0F, 1.0F), EfxRange.ZERO, new EfxRange(1.0F, 1.0F),
            2, 0, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(0.6F, 1.0F), 553, texture("fire_generic")))
        .put(new EfxAttributeFadeByDepth(3.0F, 4.0F, 100.0F, 120.0F))
        .put(new EfxAttributeShaderSettings(2.0F, -0.5F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * {@code 開始 GPU煙0}：从角色位置扩大至效果范围后迅速减淡消失的大量蓝色水纹粒子（始终面向镜头），只生成一次；
     * 绑定骨骼 {@code Chest}，其固定偏移由时间轴侧的 {@code BoneOffset.CHEST} 施加。
     */
    public static final EfxConfig OPENING_GPU_SMOKE_WATER = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                40, 4,
                0xFF0038FF, 0xFF3533D2,
                0.02F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 3.0F),
                new EfxRange(0.5F, 1.0F)))
        .put(new EfxAttributeSpawn(1, 0, 20, 20, 0, 0, 4, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1.0F, 1.0F), new EfxRange(15.0F, 15.0F),
            new EfxRange(12.0F, 12.0F), EfxRange.ZERO, 0))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(6.0F, 1.0F), new EfxRange(0.98F, 0.0F), EfxRange.ZERO,
            new Vector3f(0.0F, 1.5F, 0.0F), new Vector3f(5.0F, 5.0F, 5.0F),
            1,
            EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.3F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(1.0F, 1.0F), new EfxRange(1.0F, 1.0F), new EfxRange(1.0F, 1.0F),
            1, 10, 0, 4, new Vector3f(),
            new EfxRange(0.0F, 6.2831855F), new EfxRange(-0.5235988F, 2.0943952F)))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(32.0F, 0.0F),
            new EfxRange(0.5F, 0.5F), 553, texture("water_caustics")))
        .put(new EfxAttributeFadeByDepth(3.0F, 6.0F, 100.0F, 120.0F))
        .put(new EfxAttributeShaderSettings(1.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .build();
    
    /**
     * {@code 収束　炎2}：<b>不是火焰</b>，而是角色周围一圈大量螺旋上升的水晶粒子，全文件实例数最多、寿命最长。
     * <p>
     * 矢量场扰动强度由 {@code EfxPolygonView.VECTOR_FIELD_BASE_STRENGTH} 按观感取值，场贴图用程序化噪声取代；
     * 水晶素材共 16 帧，本层只取前 8 帧。
     */
    public static final EfxConfig CRYSTAL_DUST = EfxConfigBuilder.create(
            new EfxTypeGpuBillboard(
                5000, 3,
                0xFF5A6EB4, 0xFF0B0706,
                32.0F, 0.0F,
                0.0F, 0.0F,
                new EfxRange(3.1415927F, 0.06F),
                new EfxRange(0.06F, 0.0F)))
        .put(new EfxAttributeSpawn(1, 0, 70, 70, 0, 0, 0, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0.0F, 0.1F, 0.0F), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 3))
        .put(new EfxAttributeLife(new EfxRange(2.0F, 2.0F), new EfxRange(70.0F, 60.0F),
            new EfxRange(5.0F, 1.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeVelocity3D(
            0,
            new EfxRange(0.0F, 0.86602545F), new EfxRange(0.75F, 0.25F), new EfxRange(0.0F, 0.86602545F),
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO,
            new Vector3f(), new Vector3f(0.0F, 1.0F, 0.0F),
            2,
            new EfxRange(-0.7F, 0.2F), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(-0.001F, 0.0005F), new EfxRange(0.98F, 0.01F),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeEmitterShape3D(
            new EfxRange(3.0F, 7.0F), EfxRange.ZERO, new EfxRange(3.0F, 7.0F),
            2, 0, 0, 4, new Vector3f(),
            EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(8.0F, 0.0F),
            new EfxRange(1.0F, 1.2F), 552, texture("crystal_tiny"), 16))
        .put(new EfxAttributeShaderSettings(0.0F, 0.0F, 4.0F, 0xFF000000, 1.0F))
        .put(new EfxAttributeVectorFieldParameter(
            new Vector3f(6.0F, 1.0F, 1.5F), 0.5F, 0.31F, 3, 10.0F,
            new Vector3f(0.0F, 0.0F, 1.0F), new Vector3f(1.0F, 1.0F, 1.01F),
            EfxRange.ZERO, 0.0F, 0.0F, 0))
        // 自转：数据这条的 `RotationAddX = (0.052359883, 0.03490659)`（3°/帧 ± 2°），不衰减。
        // 本层是自由朝向（无 SbrRender、非 groundPlane），故 X 轴自转会被消费——
        // 这层"水晶粒子绕自身 X 轴翻腾"的观感此前完全没有，本轮补上。
        // ⚠ 数据的 `RotationCoefY/Z` 是 0（那两轴本就不动），忠实抄下。
        .put(new EfxAttributeRotateAnim(1,
            new EfxRange(0.052359883F, 0.03490659F), EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(1.0F, 0.0F), EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .build();
    
    /**
     * {@code デカール}：从数据看是约第 3 tick 落在角色上方、再贴到地面的 20×20 单位圆形印记（实测无明显可见的特性）；
     * 表现原由脚本 {@code via.effect.script.EffectDecal} 承担，本实现用"贴地大面片"近似。
     * <p>
     * <b>本方法是这张贴花唯一的一份面片数据</b>：脚本那九项参数（{@code Extent}、{@code RandomRollRange}、
     * {@code SearchTerrainDistance}、{@code BaseColorMod} 等）由脚本层的 {@link EfxAttributePtBehavior} 传入，
     * 不再另抄一份常量——参数改了不需要两处同步；<b>落点</b>只由 EFX 层的位置给出，故这里写零偏移。
     * <p>
     * 各参数的用法与<b>推断等级</b>：
     * <ul>
     *   <li>{@code Extent.x} / {@code Extent.z} → 地面上的两个边长（当前数据两者都是 20，与旧值一致，有据）；
     *       两者不等时把 {@code z/x} 的差值作为另一轴的比例，但<b>哪一轴是"宽"未确证</b>；
     *       {@code Extent.y} 是贴花盒的高度，本项目的面片没有体积，暂只记录（{@code TODO}）；</li>
     *   <li>{@code RandomRollRange} → 画面内滚转的<b>随机幅度</b>（度）。基准角写 0：数据只给了"范围"，
     *       旧值把 180° 同时写进基准角与幅度，属转写偏差，此处按语义只留幅度；</li>
     *   <li>{@code SearchTerrainDistance} → 贴地吸附的搜索半径（<b>推断</b>：旧值 0.1 格跨台阶时贴不上）；</li>
     *   <li>{@code BaseColorMod} → 面片基础色（<b>推断</b>：名字即"基础色"，且它是不透明暗色，
     *       而乘数类参数通常以白色为中性，故按颜色而非乘数用）；</li>
     *   <li>{@code EmissiveMod} → <b>暂未消费</b>：本项目面片只有一路自发光颜色，没有"基础色 + 自发光"
     *       两路的载体，要接它得先有第二个颜色通道；</li>
     *   <li>{@code ScaleXY} / {@code DecalDirection} / {@code DecalUpDirection} → <b>暂未消费</b>
     *       （语义未确证：{@code ScaleXY} 直接当尺寸比例会让边长翻倍；朝向两项在本项目"固定贴地"的近似下
     *       没有对应量，而数据给的朝向枚举也确实与"贴地"一致）；</li>
     *   <li>{@code DecalPrefab} → 贴花资源未入库，留空即不生成图案，本实现用 {@code glow_soft} 占位。</li>
     * </ul>
     * <p>
     * 坑：{@code glow_soft.png} 是单帧大图，故这里<b>不</b>声明 {@code atlasFrameCount}——声明成 64 只会显示整张图的左上角 1/64。
     *
     * @param behavior {@code デカール} 层的脚本参数表；某项缺失时该字段落到数据本身的取值
     */
    public static EfxConfig groundDecal(EfxAttributePtBehavior behavior) {
        Vector3f extent = behavior.vector3Value("Extent", new Vector3f(20.0F, 3.0F, 20.0F));
        float rollDegrees = behavior.floatValue("RandomRollRange", 180.0F);
        float searchDistance = behavior.floatValue("SearchTerrainDistance", 6.0F);
        int baseColor = behavior.colorValue("BaseColorMod", 0xFF373315);
        // 两个边长不等时，把 z/x 的差值作为"另一轴"的比例；Extent.x 为 0 属数据异常，此时退化为正方形
        float otherAxisRatio = extent.x != 0.0F ? extent.z / extent.x - 1.0F : 0.0F;
        return EfxConfigBuilder.create(
                new EfxTypeBillboard3D(
                    0, baseColor, 0xFF0C0B2F, 1.0F, 1.0F, 1.0F, 0.0F,
                    new EfxRange(0.0F, (float) Math.toRadians(rollDegrees)),
                    new EfxRange(extent.x, 0.0F),
                    EfxRange.ZERO, new EfxRange(otherAxisRatio, 0.0F),
                    0, 0, false, false, false,
                    EfxRange.ZERO))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 10, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(), new Vector3f(),
            new Vector3f(1.0F, 1.0F, 1.0F), 4))
        .put(new EfxAttributeLife(new EfxRange(50.0F, 50.0F), new EfxRange(5.0F, 5.0F),
            new EfxRange(20.0F, 20.0F), EfxRange.ZERO, 1))
        .put(new EfxAttributeUVSequence(new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F),
            EfxRange.ZERO, 0, texture("glow_soft")))
        .put(new EfxAttributePtCollision(16, new EfxRange(searchDistance, 0.0F), EfxRange.ZERO, EfxRange.ZERO,
            0, 0, 0, 0.0F, 0.0F, 0.0F, EfxRange.ZERO))
        .put(new EfxAttributeSbrRender(false, 0.5F, 0.5F, true))
        .put(new EfxAttributePtBehavior("via.effect.script.EffectDecal"))
        .build();
    }
}
