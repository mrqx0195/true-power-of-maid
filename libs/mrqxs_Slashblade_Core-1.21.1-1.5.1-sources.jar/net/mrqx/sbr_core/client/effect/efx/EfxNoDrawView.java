package net.mrqx.sbr_core.client.effect.efx;

import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import org.joml.Vector3f;

/**
 * 脚本驱动层（{@link EfxTypeNoDraw}）EFX 配置的<b>只读派生视图</b>，思路与 {@link EfxPolygonView}
 * 等视图一致：构造时把 {@link EfxConfig} 的稀疏属性表一次性摊平成扁平数值。
 * <p>
 * 本层的根本差别是<b>不产生任何绘制</b>——位置、时长、范围、参数都交给脚本执行者。
 * 故 {@link #localPosition} 按<b>相对演出原点的世界偏移</b>解读，而不是相机局部位置。
 * <p>
 * 换算口径：每 tick 记 {@link #FRAMES_PER_TICK} 帧，生命三段先取 {@link #rangeMean(EfxRange)} 中值再折 tick 并四舍五入。
 * <p>
 * 只承载、当前无消费方的字段：{@link EfxTypeNoDraw} 的 {@code Flags} / {@code unkn14} / {@code unkn15}
 * （后两者在现有数据里恒为 0）与 {@link EfxAttributeTransform3D} 的 {@code LocalRotation} / {@code LocalScale}。
 */
public final class EfxNoDrawView {
    /**
     * 1 tick 对应的 EFX 帧数（EFX 60fps、本项目 20tps）。
     */
    public static final float FRAMES_PER_TICK = 3.0F;
    
    /**
     * 生命 {@code Flags}（{@code VanishEvent}）里"保持到演出收尾"的那一位。
     */
    public static final int KEEP_HOLD_FLAG = 1;
    
    /**
     * 脚本属性（{@link EfxAttributePtBehavior}），承载脚本名与完整参数表。
     * 本视图唯一整体保留的属性 record：摊平会丢失"该层给了哪些参数"这一信息，
     * 故交由脚本适配器按名读取（{@link EfxAttributePtBehavior#floatValue(String, float)} 等）。
     */
    public final EfxAttributePtBehavior behavior;
    
    /**
     * 脚本短名（去掉 {@code via.effect.script.} 前缀），即派发键；为空表示该层没挂脚本（纯占位层），不应派发执行者。
     */
    public final String scriptName;
    
    /**
     * 相对演出原点的位置偏移（格），来源 {@code EFXAttributeTransform3D.LocalPosition}：本层的落点写在这里，而不是相机空间。
     */
    public final Vector3f localPosition;
    
    /**
     * 尺寸基准（格，XYZ），来源 {@link EfxTypeNoDraw#size()}。
     */
    public final Vector3f size;
    
    /**
     * 尺寸的随机全宽（格，XYZ），来源 {@link EfxTypeNoDraw#sizeRandom()}。
     */
    public final Vector3f sizeRandom;
    
    /**
     * 颜色 1（常规 ARGB），来源 {@link EfxTypeNoDraw#color()}。
     */
    public final int color;
    
    /**
     * 颜色 2（常规 ARGB），来源 {@link EfxTypeNoDraw#colorRange()}。
     */
    public final int colorRange;
    
    /**
     * 旋转基准（弧度，XYZ），来源 {@link EfxTypeNoDraw#rotation()}。
     */
    public final Vector3f rotation;
    
    /**
     * 旋转的随机全宽（弧度，XYZ），来源 {@link EfxTypeNoDraw#rotationRandom()}。
     */
    public final Vector3f rotationRandom;
    
    /**
     * 出现（渐显）段长度（tick），来源 {@code EFXAttributeLife.AppearFrame}。
     */
    public final int appearTicks;
    
    /**
     * 保持段长度（tick，含 {@code KeepHoldFrame} 的延长），来源 {@code EFXAttributeLife}。
     */
    public final int keepTicks;
    
    /**
     * 消散（渐隐）段长度（tick），来源 {@code EFXAttributeLife.VanishFrame}。
     */
    public final int vanishTicks;
    
    /**
     * 生命总长（tick）：三段之和，即脚本执行者的默认作用时长。
     */
    public final int totalLifeTicks;
    
    /**
     * 生命属性的 {@code Flags} 原值（{@code EFXAttributeLife.Flags}，语义为 {@code VanishEvent}）：第 0 位置 1 表示"保持到演出收尾"，见 {@link #isKeepHold()}。
     */
    public final int lifeFlags;
    
    /**
     * 同时存在的实例上限（{@code MaxParticles}），来源 {@code EFXAttributeSpawn}。
     */
    public final int spawnTotal;
    
    /**
     * 分批出生次数，来源 {@code EFXAttributeSpawn.LoopNumDmc5}；为 0 时按实例数与 {@code SpawnNum} 估算（{@link EfxAttributeSpawn#effectiveBatchCount()}）。
     */
    public final int spawnBatches;
    
    /**
     * 批次间隔（tick），来源 {@code EFXAttributeSpawn.IntervalFrame}（帧 ÷ 3，至少 1）。
     */
    public final int spawnIntervalTicks;
    
    /**
     * EFX 标注的生成帧（帧），来源 {@code EFXAttributeSpawn.SpawnFrame}。
     */
    public final int spawnFrame;
    
    /**
     * EFX 是否启用 {@link #spawnFrame}（来源 {@code EFXAttributeSpawn.UseSpawnFrame}）。
     */
    public final boolean useSpawnFrame;
    
    /**
     * 逐项解析配置，构造只读视图（{@code config} 的类型属性应为 {@link EfxTypeNoDraw}）。
     */
    public EfxNoDrawView(EfxConfig config) {
        this(config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 逐项解析配置，构造只读视图，并指定本场演出的收尾时刻。{@code sustainedKeepTicks} 为
     * {@link EfxTimeline#USE_DEFAULT_SUSTAINED_KEEP} 时回退到 {@link EfxTimeline#SUSTAINED_KEEP_TICKS}
     * （按范围效果标定的值，长时演出的层应由时间轴传入真实值）。
     */
    public EfxNoDrawView(EfxConfig config, int sustainedKeepTicks) {
        float sustainedKeep = sustainedKeepTicks >= 0
            ? sustainedKeepTicks
            : EfxTimeline.SUSTAINED_KEEP_TICKS;
        EfxTypeNoDraw noDrawType = config.getOrDefault(EfxTypeNoDraw.class, EfxTypeNoDraw.DEFAULT);
        EfxAttributeSpawn spawn = config.getOrDefault(EfxAttributeSpawn.class, EfxAttributeSpawn.DEFAULT);
        EfxAttributeLife life = config.getOrDefault(EfxAttributeLife.class, EfxAttributeLife.DEFAULT);
        EfxAttributeTransform3D transform =
            config.getOrDefault(EfxAttributeTransform3D.class, EfxAttributeTransform3D.DEFAULT);
        
        // 没有 PtBehavior 属性即"该层不驱动任何脚本"，脚本名留空、参数表为空
        this.behavior = config.getOrDefault(EfxAttributePtBehavior.class, EfxAttributePtBehavior.DEFAULT);
        this.scriptName = this.behavior.scriptName();
        
        this.localPosition = new Vector3f(transform.localPosition());
        this.size = new Vector3f(noDrawType.size());
        this.sizeRandom = new Vector3f(noDrawType.sizeRandom());
        this.color = noDrawType.color();
        this.colorRange = noDrawType.colorRange();
        this.rotation = new Vector3f(noDrawType.rotation());
        this.rotationRandom = new Vector3f(noDrawType.rotationRandom());
        
        this.appearTicks = Math.max(0, Math.round(rangeMean(life.appearFrame()) / FRAMES_PER_TICK));
        this.lifeFlags = life.flags();
        int keepTicks = Math.max(0,
            Math.round((rangeMean(life.keepFrame()) + rangeMean(life.keepHoldFrame())) / FRAMES_PER_TICK));
        // Flags 第 0 位置位即保持段至少延续到演出结束；同一份 EFX 数据落在任何类型的层上都应得到同一种解释
        if ((this.lifeFlags & KEEP_HOLD_FLAG) != 0) {
            keepTicks = Math.max(keepTicks,
                Math.max(0, Math.round(sustainedKeep) - this.appearTicks));
        }
        this.keepTicks = keepTicks;
        this.vanishTicks = Math.max(0, Math.round(rangeMean(life.vanishFrame()) / FRAMES_PER_TICK));
        this.totalLifeTicks = this.appearTicks + this.keepTicks + this.vanishTicks;
        
        this.spawnTotal = spawn.maxParticles();
        this.spawnBatches = spawn.effectiveBatchCount(this.spawnTotal);
        this.spawnIntervalTicks = Math.max(1, Math.round(spawn.intervalFrames() / FRAMES_PER_TICK));
        this.spawnFrame = spawn.spawnFrame();
        this.useSpawnFrame = spawn.useSpawnFrame();
    }
    
    /**
     * 该层是否挂了脚本；脚本名为空（纯占位层）时返回 {@code false}。
     */
    public boolean hasScript() {
        return this.behavior.hasScript();
    }
    
    /**
     * 取 EFX 数值区间的中值 {@code s + r / 2}，口径与 {@link EfxMeshView#rangeMean(EfxRange)} 一致：
     * 生命字段在本项目是单值、EFX 是"基准 + 随机幅度"，取中值即均匀取值的期望。
     */
    public static float rangeMean(EfxRange range) {
        return range.s() + range.r() * 0.5F;
    }
}
