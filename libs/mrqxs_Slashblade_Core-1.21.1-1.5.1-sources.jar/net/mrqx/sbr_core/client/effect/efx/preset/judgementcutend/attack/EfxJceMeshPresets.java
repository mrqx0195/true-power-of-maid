package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack;

import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.mesh.MeshShard;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * 网格类特效（われ 层）的 EFX 风格预设：每个常量就是一个 {@link EfxConfig}，由读取侧的
 * {@link net.mrqx.sbr_core.client.effect.efx.EfxMeshView} 在触发时摊平成渲染/发射所需的扁平字段。
 * <p>
 * 换算口径此处只留会改变结论的几条：
 * <ul>
 *   <li>生命三段帧数 ÷3 得 tick，{@code Keep} / {@code Vanish} 取区间中值（本项目的网格粒子只有"保持 + 消散"两段）；
 *       数量上 {@code MaxParticles} 是同时存在的实例上限，{@code IntervalFrame.y ÷ 3} 是批间隔；发射范围取 {@code s + r} 作外缘半轴；</li>
 *   <li>颜色：EFX 数据的 {@code Color.rgba} 是"R 在最低字节"的 32 位整数，换算成常规 ARGB 只需交换 R 与 B（不是整体反转字节序），
 *       本类的十六进制字面量一律写交换后的常规 ARGB，读取侧不再换算；</li>
 *   <li>{@code SizeScalarCoef ≤ 1}（われ 四层均为 0）表示消散期不放大，本项目的 {@code vanishScaleGrowth} 随之取 0；</li>
 *   <li>{@code rotationX/Y/Z} 在渲染侧由 {@code GenericMeshParticle} 自己三轴随机（±π），与 EFX 的"基准 90° + 随机 180°"
 *       只是同一观感的两种写法，故不进入本配置；{@code animationSpeed*} 与 {@code animationMode} 因形状只有一组而无效。</li>
 * </ul>
 * <p>
 * われ 四层的材质是一条纯屏空间管线：唯一的贴图是已渲染的画面，物体自身没有任何颜色，片元只做
 * "在屏空间偏移处重采样 → 幂次色调曲线 → 上界钳制"。因此渲染侧固定使用白底贴图 {@code nullwhite.png}
 * （颜色与亮度全由顶点色烘焙）、网格资源固定为 {@code MeshShard.MODEL_LOCATION}（{@code dimension_slashes.obj}）。
 * <p>
 * 近似：{@code EFXAttributeShaderSettings} 的饱和度 / 负层级 / 正层级是引擎材质层概念，本项目渲染层没有对应语义，不参与映射。
 */
public final class EfxJceMeshPresets {
    /**
     * 畸变折射幅度：<b>旧预设手调的"满强度"值，仅作对照记录</b>，不能由 EFX 换算得到——真正决定屏空间采样偏移的
     * 参数幅度随物体尺寸变化，无法唯一反推（两种读法相差一个数量级）。
     * <p>
     * TODO 实测定标：把 {@code FloatParam} 在 {@code 0.01 ~ 0.2} 之间实机比对，取"恰好能看出裂缝处背景被掰动"的那一档再换算回本常量；
     * 定标前保持旧值不动（改错了会让折射整体消失或炸开，实机上难以与"通道没接上"区分）。
     */
    public static final float DISTORTION_REFRACTIVE = 50;
    
    /**
     * 保持层（われ）：合并 {@code Dis空間われ4} / {@code Dis空間われ8} 两层，二者只差数量与分批。
     */
    public static final EfxConfig KEEP = buildDisWare(
        true, 132, 0,
        32, 0, 8, 8, 3, 3, 4, 37,
        new Vector3f(0, 2.5F, 0),
        new EfxRange(5, 5), new EfxRange(2.5F, 2.5F), new EfxRange(5, 5),
        2.5F, 0, 100, 0, 2.5F, 0,
        2, 0.5F,
        0xFFAF0DFF, 0xFFAE0DFF,
        151, 0);
    
    /**
     * 消散层（われ）：合并 {@code Dis空間われ9} / {@code Dis空間われ10} 两层，二者只差数量与分批。
     */
    public static final EfxConfig FADE = buildDisWare(
        true, 0, 30,
        32, 0, 32, 32, 3, 3, 1, 169,
        new Vector3f(0, 2.5F, 0),
        new EfxRange(5, 5), new EfxRange(2.5F, 2.5F), new EfxRange(5, 5),
        2.5F, 0, 100, 0, 2.5F, 0,
        2, 0.5F,
        0xFFAF0DFF, 0xFFAE0DFF,
        151, 0.12F);
    
    private EfxJceMeshPresets() {
    }
    
    /**
     * 按われ 四层共有的字段组装一个 EFX 配置（完整参数版，仅供本类的常量初始化使用）。
     *
     * @param fixRandomSeed     固定随机种子槽位 0：われ 四个 Entry 都带 {@code EFXAttributeFixRandomGenerator}，
     *                          本类两个常量各取先出现的那一个；写 {@code -1} 表示"不配置该属性"（即每次触发真随机）
     * @param vanishScaleGrowth 消散期每 tick 的放大增量（0 = 不放大），用于反算 EFX 的 {@code SizeScalarCoef}
     */
    public static EfxConfig buildDisWare(
        boolean hasDistortion,
        float keepFrames,
        float vanishFrames,
        int maxParticles,
        int particleInterval,
        int spawnNumX,
        int spawnNumY,
        int intervalFrameX,
        int intervalFrameY,
        int loopNumDmc5,
        int spawnFrame,
        @Nullable Vector3f localPosition,
        EfxRange rangeX, EfxRange rangeY, EfxRange rangeZ,
        float scaleX, float scaleXVar,
        float scaleY, float scaleYVar,
        float scaleZ, float scaleZVar,
        float multiplier, float multiplierVar,
        int color1, int color2,
        int fixRandomSeed, float vanishScaleGrowth) {
        float sizeScalarCoef = vanishScaleGrowth > 0 ? vanishScaleGrowth / 3 + 1 : 0;
        EfxConfigBuilder builder = EfxConfigBuilder.create(
                new EfxTypeMesh(
                    1, 0, 1, 1, 1, 0,
                    1.5707964F, 3.1415927F,
                    1.5707964F, 3.1415927F,
                    1.5707964F, 3.1415927F,
                    scaleX, scaleXVar,
                    scaleY, scaleYVar,
                    scaleZ, scaleZVar,
                    multiplier, multiplierVar,
                    // 本体**不绘制**：われ 的材质是一条纯屏空间管线（唯一贴图是"已渲染的画面"），EFX 的 color1/color2
                    // 是材质的 ColorParam、**不是顶点色**——当顶点色渲染会把网格染成品红，盖掉"空间被切裂"的观感
                    color1 & 0x00FFFFFF, color2 & 0x00FFFFFF,
                    MeshShard.MODEL_LOCATION))
            .put(new EfxAttributeSpawn(maxParticles, particleInterval, spawnNumX, spawnNumY,
                intervalFrameX, intervalFrameY, loopNumDmc5, false, spawnFrame, 0, 0, 0,
                false, false, false, false, 0, false))
            .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(keepFrames, 0),
                new EfxRange(vanishFrames, 0), EfxRange.ZERO, 0))
            .put(new EfxAttributeScaleAnim(
                new EfxRange(-0.0001F, 0), new EfxRange(sizeScalarCoef, 0),
                new EfxRange(-0.003F, 0.00085F), new EfxRange(1.04F, 0),
                EfxRange.ZERO, new EfxRange(1, 0),
                EfxRange.ZERO, new EfxRange(1, 0),
                EfxRange.ZERO))
            .put(new EfxAttributeEmitterShape3D(rangeX, rangeY, rangeZ,
                1, 0, 0, 4,
                new Vector3f(),
                new EfxRange(0, 6.2831855F),
                new EfxRange(0, 1.5707964F)))
            .put(new EfxAttributeTransform3D(
                localPosition != null ? localPosition : new Vector3f(),
                new Vector3f(),
                new Vector3f(1, 1, 1),
                4));
        if (hasDistortion) {
            builder.put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
                DISTORTION_REFRACTIVE, 0, 0, 0x00000000, 0, false));
        }
        if (fixRandomSeed >= 0) {
            builder.put(new EfxAttributeFixRandomGenerator(1, fixRandomSeed, -1, -1, -1, 0, 0, 0, 0, 0));
        }
        return builder.build();
    }
}
