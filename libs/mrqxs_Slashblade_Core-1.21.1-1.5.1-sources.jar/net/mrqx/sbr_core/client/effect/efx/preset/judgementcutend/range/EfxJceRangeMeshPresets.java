package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack.EfxJceMeshPresets;
import org.joml.Vector3f;

import java.util.List;

/**
 * 「次元斩·絶」<b>范围效果</b>中<b>网格类</b>层的 EFX 预设。
 * <p>
 * 结构同 {@link EfxJceMeshPresets}：每个常量是一个 {@link EfxConfig}，由 {@code EfxMeshView} 摊平成渲染所需的扁平字段。
 * <p>
 * <b>效果范围口径（实测）</b>：水平效果范围是以角色为中心、半径约 10 格的水平圆，各球壳层据此按
 * {@code 极限直径 = ScaleMultiplier + 3 × SizeScalarAdd ÷ (1 − SizeScalarCoef³)} 反解 {@code SizeScalarAdd} 标定到直径 20 格。
 * 四个球壳层共用 {@link #SPHERE_SHELL} / {@link #SPHERE_SHELL_OUTER} 两个模型；{@code SizeScalarAdd / SizeScalarCoef} 由
 * {@code GenericMeshParticle} 逐 tick 累加并衰减，{@code EfxTypeMesh.texture} 经 {@code MeshParticleRenderType.overridden(...)} 逐层覆写贴图。
 */
public final class EfxJceRangeMeshPresets {
    /**
     * 内层球壳模型。
     */
    public static final ResourceLocation SPHERE_SHELL =
        MrqxSlashBladeCore.prefix("model/effect/sphere_shell.obj");
    
    /**
     * 第二层球壳模型，比 {@link #SPHERE_SHELL} 多一层 UV / 法线数据。
     */
    public static final ResourceLocation SPHERE_SHELL_OUTER =
        MrqxSlashBladeCore.prefix("model/effect/sphere_shell_outer.obj");
    
    /**
     * 圆盘模型：护盾与收束光环共用，故两者呈圆盘状而非圆柱状；素材本身是中心带孔的平面圆盘。
     * <p>
     * 实测 V 坐标等于半径，故沿 V 平移贴图即"图案沿半径方向行进"。
     */
    public static final ResourceLocation PIPE_CYLINDER =
        MrqxSlashBladeCore.prefix("model/effect/pipe_cylinder.obj");
    
    /**
     * 光环材质的基础贴图；流动感由关键帧曲线驱动 V 轴平移近似（见 {@code EfxTypeMesh#rippleRings}）。
     */
    public static final ResourceLocation AURA_RIPPLE =
        MrqxSlashBladeCore.prefix("textures/effect/aura_ripple.png");
    
    /**
     * 穹顶的表面遮罩贴图，{@code ドーム} / {@code ドーム0} 共用，透明度也由它给出。
     */
    public static final ResourceLocation DOME_SURFACE =
        MrqxSlashBladeCore.prefix("textures/effect/dome_surface.png");
    
    /**
     * 穹顶的法线 / 粗糙度 / 金属度贴图；本项目网格着色器暂不做法线贴图，先入库备用——要补时照玻璃碎屑那条路径挂到 {@code Sampler1}。
     */
    public static final ResourceLocation DOME_NORMAL =
        MrqxSlashBladeCore.prefix("textures/effect/dome_normal.png");
    
    /**
     * {@code インバース0} 逐层覆写的火焰贴图：由 {@code EfxTypeMesh.texture} 承载，运行时经
     * {@code MeshParticleRenderType.overridden(...)} 变成该层专用的渲染类型。
     */
    public static final ResourceLocation MAGIC_FIRE =
        MrqxSlashBladeCore.prefix("textures/effect/magic_fire.png");
    
    /**
     * {@code ドーム}：从角色位置<b>扩大至效果范围</b>的蓝黑色极淡球壳，只生成一次并 Keep 至结束，表面是不断流动的类云层。
     */
    public static final EfxConfig DOME = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, Mth.PI, 0, 0, 0,
                1, 0, 0.7F, 0, 1, 0,
                1, 0,
                0xFF000000, 0xFF030308, SPHERE_SHELL, DOME_SURFACE, false, true))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 0, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(30, 30), new EfxRange(1, 1),
            new EfxRange(30, 30), EfxRange.ZERO, 1))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.22F, 0), new EfxRange(0.9313F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeFadeByDepth(1, 3, 100, 120))
        .put(new EfxAttributeCloudLayer(8.0F, 4.0F, 5.0F, 0.25F, 0xFF283A8F))
        .build();
    
    /**
     * {@code 白黒}：从角色位置扩大至效果范围后<b>迅速减淡消失</b>的透明球，带<b>凸透镜</b>折射与<b>黑白滤镜</b>，只生成一次。
     * <p>
     * <b>本体不绘制、只做折射与滤镜</b>：两个顶点色 alpha 均为 0，可见性全部来自 {@link EfxAttributeDistortion} 的折射通道与 {@link EfxAttributeColorFilter} 的滤镜通道——二者共用同一批四边形与同一个透镜空间权重。
     */
    public static final EfxConfig MONOCHROME = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                0.4F, 0,
                0x00000000, 0x00FFFFFF, SPHERE_SHELL))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 0, false, 1, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(30, 30),
            new EfxRange(30, 30), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.28F, 0), new EfxRange(0.93F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeTransform3D(new Vector3f(0, 1.5F, 0), new Vector3f(),
            new Vector3f(1, 1, 1), 4))
        // 屏幕空间折射（凸透镜）：强度取满强度；本层顶点色 alpha 全为 0，缺了这条属性该层就完全不可见
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            15.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        // 材质色彩滤镜（黑白）：strength 与 tint；透镜空间权重已由逐顶点遮罩给出，此处不再叠"球缘淡出"
        // toneLevel 取 EFX 覆写区间中值；emissiveIntensity 折算到 LDR 后不额外压暗；detoneRate 取默认恒等
        .put(new EfxAttributeColorFilter(1.0F, 0xFFFFFFFF, 1.15F, 2000.0F, 0.0F))
        .build();
    
    /**
     * {@code インバース0}：从角色位置快速扩大至效果范围的<b>不可见椭球壳</b>，只在它与场景中其它物体<b>相交的那一圈</b>烧起蓝色火焰。
     * <p>
     * 可见性全部交给相交发光属性与场景深度：本体只写顶点色（alpha 供判断这一片还在不在），火焰颜色由 {@link EfxAttributeIntersectGlow#color()} 给出、形状取自 {@link #MAGIC_FIRE}。
     */
    public static final EfxConfig INVERSE_IMPACT = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 0.4F, 0, 1, 0,
                1, 0,
                0xFF0612FF, 0xFF9A7575, SPHERE_SHELL, MAGIC_FIRE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 5, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(1, 1), new EfxRange(1, 1),
            new EfxRange(10, 10), EfxRange.ZERO, 1))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.40F, 0), new EfxRange(0.92F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeIntersectGlow(
            true,
            36.0F, 0.0F, 0xFF002BFF,
            7.0F, 1.0F,
            200.0F, 1.55F,
            100.0F, 5.0F,
            8.0F, 2.0F, 0.05F, 0.2F))
        // 自转：数据这条的 `RotationAddY = -0.002617994` 弧度/帧（约 -0.15°/帧）。
        // ⚠ 数值极小、本层寿命又只有 12 帧（4 tick），累计不到 2° ⇒ 观感上等于不转；
        // 补它只是让"数据里有的东西代码里也有"，不要指望看到变化。
        .put(new EfxAttributeRotateAnim(0,
            EfxRange.ZERO, new EfxRange(-0.002617994F, 0.0F), EfxRange.ZERO,
            new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F), EfxRange.ZERO))
        .build();
    
    /**
     * {@code ドーム0}：{@link #DOME} 的第二层（外皮），模型换成 {@link #SPHERE_SHELL_OUTER}（两帧切换动画），与内层叠加让蓝色罩子更厚实。
     */
    public static final EfxConfig DOME_OUTER = EfxConfigBuilder.create(
            new EfxTypeMesh(
                2, 1, 2, 1, 1, 0,
                0, 0, 0, Mth.PI, 0, 0,
                1, 0, 0.7F, 0, 1, 0,
                1, 0,
                0xFF000000, 0xFF030308, SPHERE_SHELL_OUTER, DOME_SURFACE, false, true))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 0, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(new EfxRange(30, 30), new EfxRange(1, 1),
            new EfxRange(30, 30), EfxRange.ZERO, 1))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(1.22F, 0), new EfxRange(0.9315F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeFadeByDepth(1, 3, 100, 120))
        .put(new EfxAttributeCloudLayer(4.0F, 3.0F, 1.0F, 0.25F, 0xFF283A8F))
        .build();
    
    /**
     * 构造一条"两端关键帧"的材质曲线（起点在帧 0、终点在 {@code duration}）——本效果集的 {@code TypeMeshClip} 轨道都是这种形状，需要多关键帧时直接构造 {@link EfxAttributeMeshClip.Track}。
     */
    public static EfxAttributeMeshClip.Track track(float duration, float startValue, float endValue) {
        return new EfxAttributeMeshClip.Track(duration, List.of(
            new EfxAttributeMeshClip.Keyframe(0, startValue),
            new EfxAttributeMeshClip.Keyframe(duration, endValue)));
    }
    
    /**
     * {@code メッシュ　シールド2}：范围技起手时在角色所在<b>水平面</b>上出现的一圈<b>扩大</b>的蓝色火焰 / 气浪，扩大到最大时消失、只生成一次（随后向角色收缩的稀薄波纹来自 {@link #CONVERGING_AURA}）。
     */
    public static final EfxConfig SHIELD = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                5.0F, 0,
                0xFF0632B6, 0xFFFFFFFF, PIPE_CYLINDER, AURA_RIPPLE, true))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0, -0.25F, 0), new Vector3f(),
            new Vector3f(1, 1, 1), 4))
        .put(new EfxAttributeLife(EfxRange.ZERO, EfxRange.ZERO,
            new EfxRange(60, 60), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.29F, 0), new EfxRange(0.98F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeMeshMaterial(
            0xFFFFFFFF, 0xFF000648,
            4.0F, 1.3F, 2.0F, 2.0F,
            2.0F, 1.6F,
            0.0F, 1.0F,
            0.0F, 0.1F))
        .put(new EfxAttributeMeshClip(List.of(
            track(60, 10, 0),
            track(60, -0.3F, 0.35F),
            track(60, -0.3F, 0.35F),
            track(40, 0.35F, 0.7F))))
        .put(new EfxAttributeVelocity3D(
            0,
            EfxRange.ZERO, new EfxRange(1, 0), EfxRange.ZERO,
            EfxRange.ZERO, new EfxRange(1, 0), EfxRange.ZERO,
            new Vector3f(), new Vector3f(),
            0,
            new EfxRange(-0.2F, 0), EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .build();
    
    /**
     * {@code 開始　青}：从角色位置快速扩大至效果范围、并在扩散中减淡消失的<b>透明球</b>，带<b>凹透镜</b>折射与淡淡的青色滤镜。
     * <p>
     * 青色须挂在滤镜通道 tint 而非球壳顶点色：该颜色在屏幕上盖住的是<b>背景画面</b>，顶点色只能盖住"球壳在角色身前那一层"。
     */
    public static final EfxConfig OPENING_BLUE = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                1, 0,
                0x0022D8FF, 0x0022D8FF, SPHERE_SHELL))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 0, 0, 1, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(15, 15),
            new EfxRange(30, 30), EfxRange.ZERO, 0))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0.7F, 0), new EfxRange(0.96F, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeDistortion(EfxAttributeDistortion.DISTORTION_TYPE_REFRACT,
            -100.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false))
        .put(new EfxAttributeColorFilter(0.10F, 0xFF22D8FF, 5.0F, 10.0F, 0.001F))
        .put(new EfxAttributeMeshClip(List.of(
            track(30, -100, -40))))
        .build();
    
    /**
     * {@code メッシュ　収束オーラ0}：在角色所在<b>水平面上</b>、向角色<b>不断收缩</b>的青灰色波浪气浪，是收束感的第一主力；圆环模型 ⇒ 角色脚底留有一块不受气浪影响的区域。
     */
    public static final EfxConfig CONVERGING_AURA = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 3.1415927F, 0, 0,
                1, 0.1F, 1, 0.5F, 1, 0.1F,
                20.0F, 1,
                0xFF333C5C, 0xFFFFFFFF, EfxJceRangeMeshPresets.PIPE_CYLINDER, EfxJceRangeMeshPresets.AURA_RIPPLE, true))
        .put(new EfxAttributeSpawn(2, 0, 1, 1, 25, 25, 0, false, 30, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeTransform3D(new Vector3f(0, 0.2F, 0), new Vector3f(),
            new Vector3f(1, 1, 1), 4))
        .put(new EfxAttributeLife(new EfxRange(16, 16), EfxRange.ZERO,
            new EfxRange(34, 34), EfxRange.ZERO, 1))
        .put(new EfxAttributeScaleAnim(
            new EfxRange(0, 0), new EfxRange(1, 0),
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO,
            EfxRange.ZERO, EfxRange.ZERO, EfxRange.ZERO))
        .put(new EfxAttributeMeshMaterial(
            0xFFFFFFFF, 0xFF000315,
            4.0F, 1.3F, 2.0F, 3.0F,
            1.0F, 1.0F,
            0.0F, 1.0F,
            0.0F, 0.2F))
        // 四条轨道的时长统一 60 帧、幅值直接取原值：旧写法把首条写成「时长 1、末值 3」、
        // 把后三条写成「时长 600、幅值 ×16」，三处都与原数据不符（对照记录见文档 §实现对照）
        .put(new EfxAttributeMeshClip(List.of(
            EfxJceRangeMeshPresets.track(60, 3.0F, 0.0F),
            EfxJceRangeMeshPresets.track(60, 0.35F, -0.3F),
            EfxJceRangeMeshPresets.track(60, 0.35F, -0.3F),
            EfxJceRangeMeshPresets.track(60, 0.55F, 0.25F))))
        .build();
}
