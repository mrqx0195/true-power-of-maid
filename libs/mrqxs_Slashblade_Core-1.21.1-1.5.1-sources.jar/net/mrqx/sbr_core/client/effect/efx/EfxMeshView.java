package net.mrqx.sbr_core.client.effect.efx;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import net.mrqx.sbr_core.client.effect.mesh.MeshShard;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * 网格类（{@link EfxTypeMesh}）EFX 配置的<b>只读派生视图</b>：构造时按属性逐项解析、摊平成扁平字段，此后读取侧不再触碰任何属性 record；解析一律经
 * {@link EfxConfig#getOrDefault(Class, EfxAttribute)}（未配置时落到该属性的 {@code DEFAULT}）；
 * {@code animationSpeed*} / {@code animationMode} / {@code meshPath} 仅作对照记录、不参与映射。
 */
public final class EfxMeshView {
    /**
     * EFX 帧（60fps）→ tick（20tps）的换算：1 tick = 3 帧。
     */
    public static final float FRAMES_PER_TICK = 3.0F;
    
    /**
     * 自发光强度兜底值（对应材质 {@code EmissiveIntensity}）；EFX 属性表无此参数，当前渲染路径尚未消费它（仅作对照记录）。
     */
    public static final float DEFAULT_EMISSIVE_INTENSITY = 3000.0F;
    
    /**
     * 菲涅尔指数兜底值（对应材质 {@code FresnelPower}）；性质同 {@link #DEFAULT_EMISSIVE_INTENSITY}。
     * 指数越大，权重越集中在正对相机的球心（各层消费点见 {@link #fresnelPower}）。
     */
    public static final float DEFAULT_FRESNEL_POWER = 5.0F;
    
    /**
     * 折射强度的归一化基准：{@link EfxAttributeSbrRender#distortionStrength()} 取 1（满强度）时对应的折射幅度，必须与消费侧 {@code GenericMeshParticle} 除以的值一致。
     */
    public static final float REFRACTIVE_FULL_STRENGTH = 15.0F;
    
    /**
     * 畸变内容的放大倍率兜底值（{@code >1} 放大画面、向屏幕中心收缩采样以预留边缘余量）；EFX 属性表无此字段。
     */
    public static final float DEFAULT_DISTORTION_ZOOM = 1.1F;
    
    /**
     * 网格资源路径：本项目实际加载的 obj（{@link EfxTypeMesh#resource()}）；缺失时回退到 {@code MeshShard.MODEL_LOCATION}。
     */
    public final ResourceLocation resource;
    
    /**
     * 逐层贴图覆写（{@code TypeMesh.texPaths}）：覆盖在 {@link #resource} 模型上的<b>贴图</b>；为 {@code null} 时用渲染类型的默认贴图。
     */
    @Nullable
    public final ResourceLocation texture;
    
    /**
     * 材质关键帧曲线（{@code TypeMeshClip}）；{@code null} 表示该层未配置、溶解进度恒为 0。读取侧按层选择解读方式：{@link #rippleRings} 层三条轨道全消费，
     * {@link #enableDistortion} 层第一条轨道作折射率曲线，其余层第一条轨道作"溶解曲线"（材质属性已由哈希反查确证）。
     */
    @Nullable
    public final EfxAttributeMeshClip meshClip;
    
    /**
     * 初始旋转 X（弧度；消费侧按"基准 ± 随机幅度/2"使用）；EFX 里这三对字段就是网格出生朝向的全部依据，Y / Z 两对同构、不再另述。
     */
    public final float rotationX;
    
    /**
     * 初始旋转 X 的随机幅度（弧度，随机全宽）。
     */
    public final float rotationXVariation;
    
    public final float rotationY;
    
    public final float rotationYVariation;
    
    public final float rotationZ;
    
    public final float rotationZVariation;
    
    /**
     * 自转角速度 X（<b>度 / EFX 帧</b>）：来自 {@link EfxAttributeRotateAnim#rotationAddX()}。
     * 与面片视图（{@code EfxPolygonView}）同一口径——两者都只取区间的下限 {@code s}（随机幅度 {@code r} 未消费）。
     * <p>
     * 网格路径过去<b>完全不读</b>这个属性，故配上它的层（如范围效果的 {@code インバース0}）此前朝向是死的。
     */
    public final float rotationSpeedX;
    
    /**
     * 自转角速度 Y（度 / EFX 帧）。
     */
    public final float rotationSpeedY;
    
    /**
     * 自转角速度 Z（度 / EFX 帧）。
     */
    public final float rotationSpeedZ;
    
    /**
     * 自转角速度 X 的随机全宽（度 / EFX 帧）：{@link EfxAttributeRotateAnim#rotationAddX()} 的 {@code r}。
     * 消费侧逐粒子抽 {@code s + (rnd − 0.5) · r}（实际范围 {@code ±r/2}），与面片路径同一读法。
     */
    public final float rotationSpeedXVariation;
    
    /**
     * 自转角速度 Y 的随机全宽（度 / EFX 帧）。
     */
    public final float rotationSpeedYVariation;
    
    /**
     * 自转角速度 Z 的随机全宽（度 / EFX 帧）。
     */
    public final float rotationSpeedZVariation;
    
    /**
     * 生命属性的 {@code Flags} 原值；第 0 位置 1 时表示"保持到演出收尾"，见 {@link EfxTimeline#SUSTAINED_KEEP_TICKS}。
     */
    public final int lifeFlags;
    
    /**
     * 是否把材质关键帧曲线解读为<b>纹波相位</b>（该圆盘网格的 V 坐标恰等于半径，平移 V 即"图案沿半径行进"）；为 {@code true} 时不做噪声溶解，改为沿 V 轴平移贴图。
     */
    public final boolean rippleRings;
    
    /**
     * 是否按<b>云层球壳</b>渲染：贴图只当 R / G 双通道的云层密度用、颜色全取顶点色——这类层的材质把遮罩图挂在 {@code AlphaTranslucentOcclusionMetalMap} 槽位（蓝通道恒为 0），当成颜色贴图渲染会得到黄绿色"彩色球壳"（实测反馈）。
     */
    public final boolean cloudShell;
    
    /**
     * 第一路云遮罩（{@code Mask01}）的 U / V 方向平铺次数（{@link EfxAttributeCloudLayer#tilingU()}）；两层云纹的疏密差异即来自此处的覆写与否。
     */
    public final float cloudTilingU;
    
    public final float cloudTilingV;
    
    /**
     * 云量归一化的除数（材质参数 {@code Mie_Max}，{@link EfxAttributeCloudLayer#mieMax()}）。
     * <p>
     * 名字里带 "Mie"（大气散射），但在云层材质里它实际充当<b>云量 / 对比度控制器</b>：
     * 云量 {@code I = saturate(两路遮罩的合成 ÷ Mie_Max)}，再经 {@code 1 − I²(3 − 2I)} 整形，
     * 得到"云薄处接近 1"的密度量（自发光就按它加权）。mdf2 静态默认 {@code 0.25}。
     */
    public final float cloudMieMax;
    
    /**
     * 云块本体的自发光色（常规 ARGB；{@link EfxAttributeCloudLayer#emissiveColor()}）：该 uniform 原先锁死在 {@code mesh_dissolve.json} 的默认值里、改 EFX 数据不生效，现在改由本字段驱动。
     */
    public final int cloudEmissive;
    
    /**
     * 颜色低 / 高色端（常规 ARGB；材质参数 {@code ColorParam} / {@code ColorHigh}）：低色端两层均未覆写、取材质默认纯白 {@code 0xFFFFFFFF}；混合权重 {@code mask} 只由贴图与半径遮罩决定，<b>不含视角项</b>，与顶点色无关。
     */
    public final int rippleColorParam;
    
    public final int rippleColorHigh;
    
    /**
     * 红 / 绿路基础 UV 的 U / V 分量缩放（{@code Red_Scale} / {@code Red_Scale2} / {@code Green_Scale} / {@code Green_Scale2}）：采样 UV 是 {@code (1 − UV0) × 缩放}，即"先翻转再平铺"；这一族参数是两层光环"纹理疏密不同"的直接来源，<b>必须逐层承载</b>。
     */
    public final float rippleRedScaleU;
    
    public final float rippleRedScaleV;
    
    public final float rippleGreenScaleU;
    
    public final float rippleGreenScaleV;
    
    /**
     * 红 / 绿通道遮罩的幂次（{@code Red_Power} / {@code Green_Power}）。
     */
    public final float rippleRedPower;
    
    public final float rippleGreenPower;
    
    /**
     * 半径遮罩 smoothstep 的下界 / 上界（{@code UVFade_Low} / {@code UVFade_High}）。
     */
    public final float rippleUvFadeLow;
    
    public final float rippleUvFadeHigh;
    
    /**
     * 菲涅尔归一化的下界（{@code EdgeSmoothing_OutsideAngle}）。
     */
    public final float rippleEdgeOutside;
    
    /**
     * 菲涅尔归一化的上界（{@code EdgeSmoothing_InsideAngle}）：对一块<b>平面圆盘</b>而言 {@code N·V} 就是相机俯仰角的余弦，故本值决定"要俯视到什么程度气浪才成形"；注意它与既有顶点侧 {@code pow(1 − N·V, p)} 的"边缘权重"方向恰好相反，不可混用。
     */
    public final float rippleEdgeInside;
    
    /**
     * 近端开始淡出的距离（格，0 表示不淡出）：取 EFX 原值与 {@link EfxPolygonView#MIN_FADE_NEAR_START} 的<b>较小者</b>（理由见该常量）；完全消失距离取 {@code MIN_FADE_NEAR_END} 同口径。
     */
    public final float fadeNearStart;
    
    public final float fadeNearEnd;
    
    /**
     * 远端开始淡出的距离（0 表示不做远端淡出；{@link EfxAttributeFadeByDepth#farStart()}）；完全消失距离取 {@link EfxAttributeFadeByDepth#farEnd()}。
     */
    public final float fadeFarStart;
    
    public final float fadeFarEnd;
    
    /**
     * 是否启用<b>相交发光</b>：表面只在"与场景中其它物体相交处"亮起；启用后改走 {@code mesh_intersect} 着色器，逐像素比较自身深度与场景深度副本。
     */
    public final boolean intersectGlow;
    
    /**
     * 交线带宽（世界单位，{@code Width_Top}）：片元在场景<b>之前</b>的距离达到该值时带剖面归零，再经 {@link #intersectVolumePower} 次幂收窄。
     */
    public final float intersectWidth;
    
    /**
     * 片元在场景<b>之后</b>一侧的带宽（{@code Width_Bottom}）；为 0 即"只朝可见的一侧展开"——球体被地面挡住的那半边不会烧起来。
     */
    public final float intersectWidthBottom;
    
    /**
     * 交线颜色（常规 ARGB）：<b>边缘通道</b> {@code LimColor}；最终颜色是 {@code max(base, lim)} 两路取大，蓝色由这一路给出。
     */
    public final int intersectColor;
    
    /**
     * 体积项与带剖面共用的幂次（{@code Volume_Power}）：越大则火焰从交线向外衰减越快，"贴着交线"而不是糊开。
     */
    public final float intersectVolumePower;
    
    /**
     * 朝向项的幂次（{@code AlphaFade_Power}）：用 {@code pow(|N·V|, ·)}，即<b>正对镜头最亮、掠射变暗</b>，注意方向。
     */
    public final float intersectAlphaFadePower;
    
    /**
     * 基础通道的亮度增益与幂次整形（{@code Base_Intensity} / {@code Base_Power}）：把火焰贴图整体推亮到过曝，形成白心。
     */
    public final float intersectBaseIntensity;
    
    public final float intersectBasePower;
    
    /**
     * 边缘通道的亮度增益与幂次（{@code Lim_Intensity} / {@code Lim_Power}）：越大蓝边越窄、只在最正对镜头处出现。
     */
    public final float intersectLimIntensity;
    
    public final float intersectLimPower;
    
    /**
     * 火焰贴图在网格表面的 U / V 方向平铺次数（材质参数 {@code VAR_UVscale.x / .y}）；缺了它，球面自身的 UV 只会把火焰图案画在球壳的一小块上。
     */
    public final float intersectUvScaleU;
    
    public final float intersectUvScaleV;
    
    /**
     * 相位的 U / V 方向滚动速度（{@code VAR_UVSpeed.x / .y}）：相位是 {@code frac(round(UVSpeed * 600) * time)}，故单位是"乘 600 取整后每时间单位滚多少圈"。
     */
    public final float intersectUvSpeedU;
    
    public final float intersectUvSpeedV;
    
    /**
     * 溶解渲染类型的分组标识：溶解阈值是逐批写入的 uniform，故<b>同一个渲染桶里只能有同一层、同一批的粒子</b>；这里取配置对象的身份散列——各层预设都是 {@code public static final} 常量，同一层每次触发拿到的都是同一实例，标识因而稳定。
     */
    public final int dissolveLayerKey;
    
    /**
     * 形状组数量（单一形状为 1）；来源：{@link EfxTypeMesh#frameCount()}。
     */
    public final int frameCount;
    
    /**
     * 随机起始形状的下限 / 上限（含）与可选形状组数量；来源：{@link EfxTypeMesh#startingFrameMin()} / {@link EfxTypeMesh#startingFrameMax()} / {@link EfxTypeMesh#selectableFrameCount()}。
     */
    public final int startingFrameMin;
    
    public final int startingFrameMax;
    
    public final int selectableFrameCount;
    
    /**
     * 形状切换速度的下限 / 上限与动画模式（0 = 不播放、仅用起始形状）；三项均仅作对照记录，来源：{@link EfxTypeMesh#animationSpeedMin()} 等。
     */
    public final float animationSpeedMin;
    
    public final float animationSpeedMax;
    
    public final int animationMode;
    
    /**
     * 每实例 X / Y / Z 轴缩放（作用于归一化几何）；来源：{@link EfxTypeMesh#scaleX()} 等。
     */
    public final float scaleX;
    
    public final float scaleY;
    
    public final float scaleZ;
    
    /**
     * 整体尺寸系数的基准与随机波动幅度（±）；来源：{@link EfxTypeMesh#scaleMultiplier()} / {@link EfxTypeMesh#scaleMultiplierVariation()}。
     */
    public final float scaleMultiplierBase;
    
    public final float scaleMultiplierVar;
    
    /**
     * 本层的长度口径系数：由本场演出的效果范围倍率与逐层的 {@link EfxAttributeCharacterSpace} 共同决定
     * （后者声明"按角色尺寸标定"时取 {@code 1.0}）；网格的最终尺寸与尺寸增量都乘它。
     */
    public final float sizeScale;
    
    /**
     * 消散期每 tick 的放大增量（0 表示不放大）：{@link EfxAttributeScaleAnim#sizeScalarCoef()} 经 {@link #vanishScaleGrowth(EfxAttributeScaleAnim)} 折算。
     */
    public final float vanishScaleGrowth;
    
    /**
     * 生命期尺寸增量（每 tick）：EFX 的 {@code SizeScalarAdd}（每帧的加法增量）按"1 tick = 3 帧"折算，自出生起逐 tick 累积。
     */
    public final float sizeAddPerTick;
    
    /**
     * 尺寸增量自身的每 tick 衰减系数：{@code SizeScalarCoef} 是<b>每帧</b>倍率，每 tick 等价值即其三次方；逐 tick 衰减使胀大速度渐缓，最终收敛到 {@code 增量 / (1 - 衰减)}。
     */
    public final float sizeAddCoefPerTick;
    
    /**
     * 材质颜色 1（常规 ARGB）；来源：{@link EfxTypeMesh#color1()}。
     */
    public final int color1;
    
    /**
     * 材质颜色 2（常规 ARGB）：参与渲染，作为 Fresnel 边缘色（见 {@code GenericMeshParticle} 的顶点着色）。来源：{@link EfxTypeMesh#color2()}。
     */
    public final int color2;
    
    /**
     * 自发光强度；来源：EFX 属性表无此参数，取 {@link #DEFAULT_EMISSIVE_INTENSITY}。
     */
    public final float emissiveIntensity;
    
    /**
     * 菲涅尔指数（材质 {@code FresnelPower}）；来源：EFX 属性表无此参数，取 {@link #DEFAULT_FRESNEL_POWER}。
     * 消费侧口径为 {@code pow(|N·V|, p)}（<b>正对相机处最亮</b>），见 {@code GenericMeshParticle#vertexColor}。
     */
    public final float fresnelPower;
    
    /**
     * 出现阶段（渐显，tick）：{@link EfxAttributeLife#appearFrame()} 的中值 {@code s + r/2} ÷ {@link #FRAMES_PER_TICK} 后四舍五入。
     */
    public final int appearTicks;
    
    /**
     * 保持阶段（满亮，tick）：{@link EfxAttributeLife#keepFrame()} 与 {@link EfxAttributeLife#keepHoldFrame()}（保持段的额外延长）各自取中值 {@code s + r/2} 后<b>相加</b>，再 ÷ {@link #FRAMES_PER_TICK} 四舍五入；这是面片 / 网格 / 碎片三个视图统一的口径。
     */
    public int lifeKeepTicks;
    
    /**
     * 消散阶段（渐隐，tick）：{@link EfxAttributeLife#vanishFrame()} 的中值 {@code s + r/2} ÷ {@link #FRAMES_PER_TICK} 后四舍五入。
     */
    public final int lifeVanishTicks;
    
    /**
     * 该层一次演出的粒子总数；来源：{@link EfxAttributeSpawn#maxParticles()}（同时存在上限，至少 1）。
     */
    public final int spawnTotal;
    
    /**
     * 分批次数与相邻两批之间的出生间隔（tick，至少 1）：前者取 {@link EfxAttributeSpawn#effectiveBatchCount()}（{@code LoopNumDmc5}；该值为 0 时按"不限制循环、持续到演出收尾"估算），后者为 {@link EfxAttributeSpawn#intervalFrames()} ÷ {@link #FRAMES_PER_TICK} 后四舍五入，{@code IntervalFrame = 0} 视为每 tick 一批。
     */
    public final int spawnBatches;
    
    public final int spawnIntervalTicks;
    
    /**
     * 发射中心相对演出原点的固定偏移（格）；来源：{@link EfxAttributeTransform3D#localPosition()}，缺失时为零向量。
     */
    public final Vector3f localOffset;
    
    /**
     * 发射范围半轴（格）：取 {@link EfxAttributeEmitterShape3D} 的 {@code RangeX/Y/Z} 的 {@code s + r}（区间外端，散布外缘），按 {@link #shapeType} 采样。
     */
    public final Vector3f rangeXYZ;
    
    /**
     * 发射器形状：0 = 盒/点，1 = 球（三轴半径不等时呈椭球），2 = 圆柱；来源：{@link EfxAttributeEmitterShape3D#shapeType()}，缺失时为 0。
     */
    public final int shapeType;
    
    /**
     * 折射幅度（0 表示不参与畸变，负值即凹透镜；{@link #enableDistortion} 即本值非零）：{@link EfxAttributeDistortion#influence()} 原样保留、未归一化，归一化到遮罩 0~1 的除法由 {@code GenericMeshParticle#buildDistortionQuads} 按 {@link #REFRACTIVE_FULL_STRENGTH} 完成。
     */
    public final float distortionRefractive;
    
    /**
     * 畸变内容的放大倍率；来源：EFX 属性表无此参数，取 {@link #DEFAULT_DISTORTION_ZOOM}。球壳层与薄片层都生效：本项目位移幅度远大于 EFX 原值，
     * 放大承担"预留屏幕边缘余量、避免把屏外尚未渲染的内容拉进画面"的职责，<b>薄片层关掉放大实机立刻拉丝</b>；又因放大只有乘上<b>逐顶点变化</b>的权重时才把采样 UV 变成非线性映射，
     * 本项目薄片层权重是整片常量，故缩放与平移一样是仿射变换，不会破坏"整块滑动"的观感。
     */
    public final float distortionZoom;
    
    /**
     * 是否参与真实屏幕空间畸变；来源：{@link #distortionRefractive} 非零（配置里给出了畸变强度，负值即凹透镜）。
     */
    public final boolean enableDistortion;
    
    /**
     * 滤镜总强度（0 = 不滤镜）：它是<b>滤镜遮罩 A 通道</b>的乘数（A = 透镜空间权重 × 本值 × 生命不透明度），与折射强度完全独立。
     */
    public final float colorFilterStrength;
    
    /**
     * 滤镜目标色（常规 ARGB）：{@code 0xFFFFFFFF} 即"向灰收敛"＝去色，淡青即"青色滤镜"；由 {@code GenericMeshParticle#buildFilterQuads} 写进滤镜遮罩的 RGB 通道。
     */
    public final int colorFilterTint;
    
    /**
     * 材质 {@code Emit_ToneLevel}：色阶指数 k（1 = 恒等），与 {@link #colorFilterDetoneRate} 一起构成后处理里的 {@code mix(f, pow(f, k), detone)}。
     */
    public final float colorFilterToneLevel;
    
    /**
     * 材质 {@code EmissiveIntensity} 折算到 LDR 的<b>上限钳制值</b>（0~1），即 {@code clamp(EmissiveIntensity / HDR_WHITE_POINT, 0, 1)}；LDR 下两层实际取值都是 1.0（不压暗）。
     */
    public final float colorFilterEmissiveClamp;
    
    /**
     * 材质 {@code DetoneRate}：0 = 纯滤镜、1 = 纯色调曲线；来源：{@link EfxAttributeColorFilter#detoneRate()}。
     */
    public final float colorFilterDetoneRate;
    
    /**
     * 屏幕空间逐通道增益的目标色（常规 ARGB）：{@code rgb} 即 {@code ColorParam.rgb}、{@code a} 即与画面的融合权重；取 {@code 0xFFFFFFFF} 即增益恒等——现有数据正是"只有色散、没有色偏"（实测确认该层会受 {@code Color} 影响）。
     */
    public final int screenGradingGain;
    
    /**
     * 屏幕空间色散幅度（屏幕 UV 单位，0 = 不色散）：EFX 做三次采样，但 {@code .r} 路的偏移量在 {@code mov r1.x, r2.x} 处被丢弃，故实际只有 {@code .g} / {@code .b} 两条偏移有效。
     */
    public final float screenGradingDispersion;
    
    /**
     * 球面权重指数（{@code FresnelPower}）：权重口径是 {@code (N·V)^p}、<b>球心方向最大</b>，与本项目顶点侧既有的 {@code pow(1 − N·V, p)} <b>方向相反</b>，不可混用。
     */
    public final float screenGradingSpherePower;
    
    /**
     * 屏幕边缘遮罩的缩放 / 渐变（{@code Edge_Scale} / {@code Edge_Gradation}）：把屏幕四边外侧约 10% 平滑压到 0，避免球把画面染成硬边。
     */
    public final float screenGradingEdgeScale;
    
    public final float screenGradingEdgeGradation;
    
    /**
     * 本层的网格是否为<b>封闭球壳</b>：它决定遮罩写入时要不要做<b>半球面过滤</b>（见 {@code GenericMeshParticle#facesCamera}）——球壳视点常落在壳体内部，
     * 前后两半球面投影到同一批像素，必须只写朝向相机的那半边，否则折射通道两份反向法线互相抵消、滤镜通道按绘制顺序覆盖写，观感上就是"撕裂"；
     * 而<b>单面薄片乱堆簇</b>硬套过滤会剔掉近一半薄片（表现为"折射方向正确、幅度偏小"，实测）。
     */
    public final boolean closedShell;
    
    /**
     * 是否参与屏幕空间逐通道增益 / 色散通道（{@link EfxAttributeScreenGrading#enabled()}：增益非恒等或色散非零）；与 {@link #enableDistortion}、{@link #enableColorFilter} 三者相互独立。
     */
    public final boolean enableScreenGrading;
    
    /**
     * 是否参与材质色彩滤镜遮罩（{@link EfxAttributeColorFilter#enabled()}：强度非零即参与）；与 {@link #enableDistortion} 相互独立，{@code MeshEmitterManager} 会跟踪"需要任一遮罩"的粒子。
     */
    public final boolean enableColorFilter;
    
    /**
     * 配置里给出的固定随机种子（{@link EfxAttributeFixRandomGenerator} 的第一个有效槽位）；{@code null} 表示该层<b>没有</b>本属性，即"每次触发都要全新的随机分布"——按"存在性即语义"显式判定，不写死某个种子。
     */
    @Nullable
    public final Long randomSeed;
    
    /**
     * 配置里的固定随机种子表属性（缺失时为 {@code null}）：只在配置真的写了该属性时才非空，"存在性"本身就是语义，故不做 {@code DEFAULT} 兜底。
     */
    @Nullable
    public final EfxAttributeFixRandomGenerator fixRandomGenerator;
    
    /**
     * 逐项解析配置，构造只读视图（类型属性应为 {@link EfxTypeMesh}）；本场演出的收尾时刻取默认值。
     */
    public EfxMeshView(EfxConfig config) {
        this(config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 逐项解析配置，构造只读视图，并指定本场演出的收尾时刻：{@code sustainedKeepTicks} 为从本层触发时刻到本段演出收尾的 tick 数，{@link EfxTimeline#USE_DEFAULT_SUSTAINED_KEEP} 表示未指定（回退到 {@link EfxTimeline#SUSTAINED_KEEP_TICKS}）。
     */
    public EfxMeshView(EfxConfig config, int sustainedKeepTicks) {
        this(config, sustainedKeepTicks, EfxPolygonView.SIZE_SCALE);
    }
    
    /**
     * 逐项解析配置，构造只读视图，并指定本场演出的收尾时刻与<b>效果范围倍率</b>。
     * <p>
     * 该倍率只作用于"按效果范围标定"的层；逐层的 {@link EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}。
     */
    public EfxMeshView(EfxConfig config, int sustainedKeepTicks, float effectRangeScale) {
        float sustainedKeep = sustainedKeepTicks >= 0
            ? sustainedKeepTicks
            : EfxTimeline.SUSTAINED_KEEP_TICKS;
        EfxTypeMesh meshType = config.getOrDefault(EfxTypeMesh.class, EfxTypeMesh.DEFAULT);
        EfxAttributeSpawn spawn = config.getOrDefault(EfxAttributeSpawn.class, EfxAttributeSpawn.DEFAULT);
        EfxAttributeLife life = config.getOrDefault(EfxAttributeLife.class, EfxAttributeLife.DEFAULT);
        EfxAttributeScaleAnim scaleAnim =
            config.getOrDefault(EfxAttributeScaleAnim.class, EfxAttributeScaleAnim.DEFAULT);
        EfxAttributeTransform3D transform =
            config.getOrDefault(EfxAttributeTransform3D.class, EfxAttributeTransform3D.DEFAULT);
        EfxAttributeEmitterShape3D shape =
            config.getOrDefault(EfxAttributeEmitterShape3D.class, EfxAttributeEmitterShape3D.DEFAULT);
        EfxAttributeDistortion distortion =
            config.getOrDefault(EfxAttributeDistortion.class, EfxAttributeDistortion.DEFAULT);
        
        // ---------- 网格与形状序列 ----------
        this.resource = meshType.resource() != null ? meshType.resource() : MeshShard.MODEL_LOCATION;
        this.texture = meshType.texture();
        this.meshClip = config.get(EfxAttributeMeshClip.class);
        this.rippleRings = meshType.rippleRings();
        this.cloudShell = meshType.cloudShell();
        EfxAttributeCloudLayer cloudLayer =
            config.getOrDefault(EfxAttributeCloudLayer.class, EfxAttributeCloudLayer.DEFAULT);
        this.cloudTilingU = cloudLayer.tilingU();
        this.cloudTilingV = cloudLayer.tilingV();
        this.cloudMieMax = cloudLayer.mieMax();
        this.cloudEmissive = cloudLayer.emissiveColor();
        EfxAttributeMeshMaterial meshMaterial =
            config.getOrDefault(EfxAttributeMeshMaterial.class, EfxAttributeMeshMaterial.DEFAULT);
        this.rippleColorParam = meshMaterial.colorParam();
        this.rippleColorHigh = meshMaterial.colorHigh();
        this.rippleRedScaleU = meshMaterial.redScaleU();
        this.rippleRedScaleV = meshMaterial.redScaleV();
        this.rippleGreenScaleU = meshMaterial.greenScaleU();
        this.rippleGreenScaleV = meshMaterial.greenScaleV();
        this.rippleRedPower = meshMaterial.redPower();
        this.rippleGreenPower = meshMaterial.greenPower();
        this.rippleUvFadeLow = meshMaterial.uvFadeLow();
        this.rippleUvFadeHigh = meshMaterial.uvFadeHigh();
        this.rippleEdgeOutside = meshMaterial.edgeSmoothingOutside();
        this.rippleEdgeInside = meshMaterial.edgeSmoothingInside();
        EfxAttributeFadeByDepth fadeByDepth =
            config.getOrDefault(EfxAttributeFadeByDepth.class, EfxAttributeFadeByDepth.DEFAULT);
        this.fadeNearStart = Math.min(fadeByDepth.nearStart(), EfxPolygonView.MIN_FADE_NEAR_START);
        this.fadeNearEnd = Math.min(fadeByDepth.nearEnd(), EfxPolygonView.MIN_FADE_NEAR_END);
        this.fadeFarStart = fadeByDepth.farStart();
        this.fadeFarEnd = fadeByDepth.farEnd();
        EfxAttributeIntersectGlow intersectGlowAttr =
            config.getOrDefault(EfxAttributeIntersectGlow.class, EfxAttributeIntersectGlow.DEFAULT);
        this.intersectGlow = intersectGlowAttr.enabled();
        this.intersectWidth = intersectGlowAttr.widthTop();
        this.intersectWidthBottom = intersectGlowAttr.widthBottom();
        this.intersectColor = intersectGlowAttr.limColor();
        this.intersectVolumePower = intersectGlowAttr.volumePower();
        this.intersectAlphaFadePower = intersectGlowAttr.alphaFadePower();
        this.intersectBaseIntensity = intersectGlowAttr.baseIntensity();
        this.intersectBasePower = intersectGlowAttr.basePower();
        this.intersectLimIntensity = intersectGlowAttr.limIntensity();
        this.intersectLimPower = intersectGlowAttr.limPower();
        this.intersectUvScaleU = intersectGlowAttr.uvScaleU();
        this.intersectUvScaleV = intersectGlowAttr.uvScaleV();
        this.intersectUvSpeedU = intersectGlowAttr.uvSpeedU();
        this.intersectUvSpeedV = intersectGlowAttr.uvSpeedV();
        this.dissolveLayerKey = System.identityHashCode(config);
        this.frameCount = meshType.frameCount();
        this.startingFrameMin = meshType.startingFrameMin();
        this.startingFrameMax = meshType.startingFrameMax();
        this.selectableFrameCount = meshType.selectableFrameCount();
        this.animationSpeedMin = meshType.animationSpeedMin();
        this.animationSpeedMax = meshType.animationSpeedMax();
        this.animationMode = meshType.animationMode();
        this.rotationX = meshType.rotationX();
        this.rotationXVariation = meshType.rotationXVariation();
        this.rotationY = meshType.rotationY();
        this.rotationYVariation = meshType.rotationYVariation();
        this.rotationZ = meshType.rotationZ();
        this.rotationZVariation = meshType.rotationZVariation();
        // 自转角速度来自它自己的属性 EFXAttributeRotateAnim（type 82）——与面片路径同一属性、同一口径。
        // 网格路径原先不读它，所以"数据里有 RotateAnim 的网格层"一直是不转的。
        EfxAttributeRotateAnim rotateAnim =
            config.getOrDefault(EfxAttributeRotateAnim.class, EfxAttributeRotateAnim.DEFAULT);
        this.rotationSpeedX = (float) Math.toDegrees(rotateAnim.rotationAddX().s());
        this.rotationSpeedY = (float) Math.toDegrees(rotateAnim.rotationAddY().s());
        this.rotationSpeedZ = (float) Math.toDegrees(rotateAnim.rotationAddZ().s());
        // 随机全宽同源：消费侧逐粒子抽 s ± r/2
        this.rotationSpeedXVariation = (float) Math.toDegrees(rotateAnim.rotationAddX().r());
        this.rotationSpeedYVariation = (float) Math.toDegrees(rotateAnim.rotationAddY().r());
        this.rotationSpeedZVariation = (float) Math.toDegrees(rotateAnim.rotationAddZ().r());
        
        // ---------- 尺寸与倍率 ----------
        this.scaleX = meshType.scaleX();
        this.scaleY = meshType.scaleY();
        this.scaleZ = meshType.scaleZ();
        this.scaleMultiplierBase = meshType.scaleMultiplier();
        this.scaleMultiplierVar = meshType.scaleMultiplierVariation();
        this.sizeScale = config
            .getOrDefault(EfxAttributeCharacterSpace.class, EfxAttributeCharacterSpace.DEFAULT)
            .characterSized() ? 1.0F : effectRangeScale;
        this.vanishScaleGrowth = vanishScaleGrowth(scaleAnim);
        float addCoef = scaleAnim.sizeScalarCoef().s();
        this.sizeAddPerTick = scaleAnim.sizeScalarAdd().s() * EfxPolygonView.framesPerTickWeight(addCoef);
        this.sizeAddCoefPerTick = EfxPolygonView.perTickCoefficient(addCoef);
        
        // ---------- 颜色与亮度 ----------
        this.color1 = meshType.color1();
        this.color2 = meshType.color2();
        this.emissiveIntensity = DEFAULT_EMISSIVE_INTENSITY;
        this.fresnelPower = DEFAULT_FRESNEL_POWER;
        
        // ---------- 生命 ----------
        this.appearTicks = Math.max(0, Math.round(rangeMean(life.appearFrame()) / FRAMES_PER_TICK));
        this.lifeKeepTicks = Math.max(0, Math.round(
            (rangeMean(life.keepFrame()) + rangeMean(life.keepHoldFrame())) / FRAMES_PER_TICK));
        this.lifeVanishTicks = Math.max(0, Math.round(rangeMean(life.vanishFrame()) / FRAMES_PER_TICK));
        this.lifeFlags = life.flags();
        if ((this.lifeFlags & EfxPolygonView.SUSTAINED_FLAG_BIT) != 0) {
            this.lifeKeepTicks = Math.max(this.lifeKeepTicks, Math.max(0,
                Math.round(sustainedKeep) - this.appearTicks));
        }
        
        // ---------- 生成 ----------
        this.spawnTotal = spawn.maxParticles();
        int loop = spawn.batchCount();
        float interval = Math.max(spawn.intervalFrames() / FRAMES_PER_TICK, 1.0F);
        this.spawnBatches = loop > 0
            ? loop
            : Math.max(1, Math.round(sustainedKeep / interval) + 1);
        this.spawnIntervalTicks = Math.max(1, Math.round(interval));
        // 复制一份：视图是只读快照，不持有属性 record 内部的 Vector3f 实例
        this.localOffset = new Vector3f(transform.localPosition());
        this.rangeXYZ = new Vector3f(
            shape.rangeX().s() + shape.rangeX().r(),
            shape.rangeY().s() + shape.rangeY().r(),
            shape.rangeZ().s() + shape.rangeZ().r());
        this.shapeType = shape.shapeType();
        
        // ---------- 畸变 ----------
        this.distortionRefractive = distortion.enabled() ? distortion.influence() : 0.0F;
        this.distortionZoom = DEFAULT_DISTORTION_ZOOM;
        this.enableDistortion = this.distortionRefractive != 0.0F;
        // 材质色彩滤镜是与折射并列的第二条屏幕空间遮罩通道：白黒 / 開始　青 的滤镜走这条链，而不是外部后处理效果
        EfxAttributeColorFilter colorFilter =
            config.getOrDefault(EfxAttributeColorFilter.class, EfxAttributeColorFilter.DEFAULT);
        this.colorFilterStrength = colorFilter.strength();
        this.colorFilterTint = colorFilter.tintColor();
        this.colorFilterToneLevel = colorFilter.toneLevel();
        this.colorFilterEmissiveClamp = colorFilter.emissiveClamp();
        this.colorFilterDetoneRate = colorFilter.detoneRate();
        this.enableColorFilter = colorFilter.enabled();
        // 屏幕空间逐通道增益 + 色散（TYPE = -10）是第三条屏空间通道，专为 カラコレ 那种"逐通道乘性增益 + 色散"而设，与"向目标色收敛"的代数形式不同，故另立语义、由后处理的模式位区分
        EfxAttributeScreenGrading screenGrading =
            config.getOrDefault(EfxAttributeScreenGrading.class, EfxAttributeScreenGrading.DEFAULT);
        this.screenGradingGain = screenGrading.gainColor();
        this.screenGradingDispersion = screenGrading.dispersion();
        this.screenGradingSpherePower = screenGrading.sphereWeightPower();
        this.screenGradingEdgeScale = screenGrading.edgeScale();
        this.screenGradingEdgeGradation = screenGrading.edgeGradation();
        // 判据是"<b>配置了</b>本属性"而非"增益非恒等或色散非零"：カラコレ 一族声明这条通道的用意是让本体
        // 完全不画（顶点色 alpha 承载的是 ColorParam.w，见 GenericMeshParticle#vertexColor），而它们的增益恰恰
        // 可能恒等——次元斩三套的色散系数由 RefractiveIndex 折算而来、当前就是 0，按 enabled() 判会让球壳以
        // color1 的 alpha 实画出来（实测反馈"颜色过重"），而它本该只作为极淡的叠加存在
        this.enableScreenGrading = config.has(EfxAttributeScreenGrading.class);
        // 球壳判据用资源路径是权宜：EFX 里没有"这个网格是不是封闭体"这一字段，而它决定"逐顶点球面权重
        // 是否生效"；漏判 color_sphere 会让滤镜在整个球面上均匀铺满（实测"滤镜没有按弦长减弱"）。
        // 判据取"路径含 sphere"而非逐个列举：本项目的球体资产有 color_sphere / sphere_shell / refract_sphere
        // 三种命名，漏掉其中任何一个都会让该层的折射被前后半球互相抵消而完全看不出效果（实测反馈）
        ResourceLocation shellLocation = meshType.resource();
        this.closedShell = shellLocation != null && shellLocation.getPath().contains("sphere");
        
        // ---------- 随机种子 ----------
        this.fixRandomGenerator = config.get(EfxAttributeFixRandomGenerator.class);
        int[] seeds = this.fixRandomGenerator != null ? this.fixRandomGenerator.validSeeds() : new int[0];
        this.randomSeed = seeds.length > 0 ? (long) seeds[0] : null;
    }
    
    /**
     * 取 EFX 数值区间的中值 {@code s + r / 2}：本项目的生命字段是单值，而 EFX 是"基准 + 随机幅度"，取中值即"随机在两端点间均匀取值"的期望值，是当前结构下最接近的近似；口径与 {@link EfxPolygonView#rangeMean(EfxRange)} 是同一实现，面片 / 网格 / 碎片三个视图必须一致。
     */
    public static float rangeMean(EfxRange range) {
        return range.s() + range.r() * 0.5F;
    }
    
    /**
     * 当前的溶解进度（0~1），由材质关键帧曲线的第一条轨道驱动：EFX 曲线以<b>帧</b>为单位，故把已经过的 tick 乘 {@link #FRAMES_PER_TICK} 后取进度。 <b>畸变层除外</b>：同时配置畸变与材质关键帧时，第一条轨道按"折射率曲线"解读（见 {@link #refractionScaleAt(int)}），此时恒返回 0；未配置材质关键帧时同样恒为 0。
     */
    public float dissolveAt(int ticks) {
        EfxAttributeMeshClip clip = this.meshClip;
        if (clip == null || this.enableDistortion) {
            return 0.0F;
        }
        EfxAttributeMeshClip.Track track = clip.primary();
        if (track == null) {
            return 0.0F;
        }
        return track.progressAt(ticks * FRAMES_PER_TICK);
    }
    
    /**
     * 当前的折射强度系数（1.0 表示直接采用 {@link #distortionRefractive} 的固定强度）：{@code 開始　青} 的 {@code TypeMeshClip} 只有一条轨道 {@code -100 → -40}，哈希反查确认它驱动的正是 {@code RefractiveIndex}
     * （实测该层"带凹透镜效果"），故一层同时配置畸变与材质关键帧时，第一条轨道按"折射率曲线"解读，用 {@code |当前值| ÷ |首值|} 归一化成随时间衰减的强度系数；无材质关键帧时恒为 1.0。
     */
    public float refractionScaleAt(int ticks) {
        EfxAttributeMeshClip clip = this.meshClip;
        if (clip == null || !this.enableDistortion) {
            return 1.0F;
        }
        EfxAttributeMeshClip.Track track = clip.primary();
        if (track == null || track.keyframes().isEmpty()) {
            return 1.0F;
        }
        float start = Math.abs(track.keyframes().getFirst().value());
        if (start <= 0.0F) {
            return 1.0F;
        }
        float current = Math.abs(track.valueAt(ticks * FRAMES_PER_TICK));
        return Math.clamp(current / start, 0.0F, 1.0F);
    }
    
    /**
     * 红路（{@code BaseMap.R} 通道）的纹波相位：返回 V 轴 UV 平移量，{@code ticks} 为自粒子出生已经过的 tick。
     */
    public float rippleRedAt(int ticks) {
        return this.rippleScrollAt(EfxAttributeMeshClip.RED_OFFSET_TRACK_INDEX, ticks);
    }
    
    /**
     * 绿路（{@code BaseMap.G} 通道）的纹波相位：返回 V 轴 UV 平移量，{@code ticks} 为自粒子出生已经过的 tick。与红路<b>各走各的曲线</b>（{@code Green_Offset}）—— 只读红路的话，绿路那条曲线建了却没有被任何代码引用，两路扰动就退化成了一层。
     */
    public float rippleGreenAt(int ticks) {
        return this.rippleScrollAt(EfxAttributeMeshClip.GREEN_OFFSET_TRACK_INDEX, ticks);
    }
    
    /**
     * 按轨道下标取该路的纹波相位（内部辅助，两路共用）：返回 V 轴 UV 平移量，缺少配置或该轨道时返回 0。
     */
    public float rippleScrollAt(int trackIndex, int ticks) {
        EfxAttributeMeshClip clip = this.meshClip;
        if (clip == null) {
            return 0.0F;
        }
        EfxAttributeMeshClip.Track track = clip.at(trackIndex);
        if (track == null || track.keyframes().isEmpty()) {
            return 0.0F;
        }
        return track.valueAt(ticks * FRAMES_PER_TICK);
    }
    
    /**
     * 当前的 {@code EmissiveRate}（材质参数，自发光强度）：它<b>平方后乘到颜色上</b>（{@code blendedColor *= EmissiveRate²}）；两层的曲线都是"从初始值衰减到 0"，即该层亮度本就该衰减到全黑——此前没被任何代码读取，亮度衰减只能由 {@code lifeAlpha} 的线性淡出与着色器里固定的 {@code mask × 4} 增益近似。缺少该属性或首条轨道时返回 1.0。
     */
    public float emissiveRateAt(int ticks) {
        EfxAttributeMeshClip clip = this.meshClip;
        if (clip == null) {
            return 1.0F;
        }
        EfxAttributeMeshClip.Track track = clip.at(EfxAttributeMeshClip.EMISSIVE_RATE_TRACK_INDEX);
        if (track == null || track.keyframes().isEmpty()) {
            return 1.0F;
        }
        return Math.max(0.0F, track.valueAt(ticks * FRAMES_PER_TICK));
    }
    
    /**
     * 把 EFX 的尺寸动画折算成"消散期每 tick 的放大增量"：{@code GenericMeshParticle} 在消散期按 {@code scaleNow *= 1 + 增量} 逐 tick 累乘，而 EFX 的 {@code SizeScalarCoef} 是<b>逐帧倍率</b>，
     * 要与之等价，每 tick 倍率必须是它的三次方（1 tick = 3 帧），故返回 {@code coef³ − 1}，复用 {@link EfxPolygonView#perTickCoefficient(float)}；线性近似 {@code (coef − 1) × 3} 在 {@code c = 1.1} 时偏小（0.300 vs 0.331），不可用。
     * 系数不大于 1 时返回 0（われ 四个 Entry 都属这种情况）；{@code SizeXAdd} 这类逐轴动画没有对应字段，不映射。
     */
    public static float vanishScaleGrowth(EfxAttributeScaleAnim scaleAnim) {
        float coefficient = scaleAnim.sizeScalarCoef().s();
        if (coefficient <= 1.0F) {
            return 0.0F;
        }
        return EfxPolygonView.perTickCoefficient(coefficient) - 1.0F;
    }
}
