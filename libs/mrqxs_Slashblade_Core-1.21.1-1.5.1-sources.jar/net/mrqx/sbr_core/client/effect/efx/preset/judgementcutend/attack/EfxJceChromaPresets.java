package net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxConfigBuilder;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeLife;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeScreenGrading;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeSpawn;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeMesh;

/**
 * 「次元斩·絶」里<b>屏幕空间调色类</b>层的 EFX 预设（{@code カラコレ} 一族）。
 * <p>
 * 这些层走"屏空间逐通道增益 + 色散"路径，与 {@code EfxJceMeshPresets} 的"われ 四层"
 * （屏空间偏移采样 + 幂次色调）不同，故单独成类。
 */
public final class EfxJceChromaPresets {
    /**
     * 屏幕空间调色用的球体模型（由数据里的球状网格转换成本项目的 {@code .obj}）。
     */
    public static final ResourceLocation COLOR_SPHERE =
        MrqxSlashBladeCore.prefix("model/effect/color_sphere.obj");
    
    /**
     * {@code カラコレ} 的色散幅度系数。
     */
    public static final float CHROMA_DISPERSION = (5.0F - 1.0F) * 1.0E-4F;
    
    /**
     * {@code カラコレ}：在起手一瞬间包裹摄像机的<b>屏幕空间调色球</b>。
     */
    public static final EfxConfig CHROMA_BALL = EfxConfigBuilder.create(
            new EfxTypeMesh(
                1, 0, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0,
                1, 0, 1, 0, 1, 0,
                20, 0,
                0xCCFFFFFF, 0xFFFFFFFF, COLOR_SPHERE))
        .put(new EfxAttributeSpawn(1, 0, 1, 1, 5, 5, 3, false, 0, 0, 0, 0,
            false, false, false, false, 0, false))
        .put(new EfxAttributeLife(EfxRange.ZERO, new EfxRange(5, 5),
            new EfxRange(5, 5), EfxRange.ZERO, 0))
        .put(new EfxAttributeScreenGrading(0xCCFFFFFF, CHROMA_DISPERSION, 1.0F, 0.0F, 0.0F))
        .build();
}
