package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

/**
 * 属性 {@code EFXAttributeDistortion}：屏幕空间畸变（对应 json 的 {@code type} = 106）。
 * <p>
 * 现有数据里只有「割れ　Dis　1」配置了它：
 * {@code DistortionType=1}（Refract）、{@code Influence=1}、
 * {@code SpecularPower/SpecularIntensity=0}、{@code SpecularColor=0}、
 * {@code AlphaBlend=0}、{@code FadeScreenEdge=false}。
 * 本项目此前把"是否参与畸变"简化成了一个自定义字段（{@code SbrRender.distortionStrength}），
 * 现已按 EFX 的归属迁回本类。
 * <p>
 * 字段与顺序与 EFX 一致；{@code DistortionType} 的取值为 0 = Blur、1 = Refract、2 = BlurTexture。
 *
 * @param distortionType    畸变类型（0 = Blur、1 = Refract、2 = BlurTexture）
 * @param influence         畸变强度（{@code Influence}）
 * @param specularPower     高光锐度（本项目当前不映射）
 * @param specularIntensity 高光强度（本项目当前不映射）
 * @param specularColor     高光颜色（常规 ARGB；本项目当前不映射）
 * @param alphaBlend        透明度混合（仅 DD2 版本有；本项目当前不映射）
 * @param fadeScreenEdge    是否让屏幕边缘淡出（仅 DD2 版本有；本项目当前不映射）
 */
public record EfxAttributeDistortion(
    int distortionType,
    float influence,
    float specularPower,
    float specularIntensity,
    int specularColor,
    float alphaBlend,
    boolean fadeScreenEdge
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 106;
    
    /**
     * 畸变类型：折射。
     */
    public static final int DISTORTION_TYPE_REFRACT = 1;
    
    /**
     * 默认值：不参与畸变（强度为 0）。
     */
    public static final EfxAttributeDistortion DEFAULT = new EfxAttributeDistortion(
        DISTORTION_TYPE_REFRACT, 0.0F, 0.0F, 0.0F, 0x00000000, 0.0F, false);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeDistortion";
    }
    
    /**
     * 该层是否真的参与屏幕空间畸变：强度非零即参与。
     * <p>
     * 读取侧用本方法代替"该属性是否存在"的判断——EFX 允许配置一个强度为 0 的
     * {@code Distortion}（等价于关闭），因此不能只看存在性。
     * <p>
     * <b>负强度表示凹透镜</b>：{@code 開始　青} 的材质 {@code RefractiveIndex = -100}
     * （实测该层"带凹透镜效果"），负值即"把采样方向整体反过来"——
     * 凸透镜向外放大背景，凹透镜向内收缩背景。
     */
    public boolean enabled() {
        return this.influence != 0.0F;
    }
}
