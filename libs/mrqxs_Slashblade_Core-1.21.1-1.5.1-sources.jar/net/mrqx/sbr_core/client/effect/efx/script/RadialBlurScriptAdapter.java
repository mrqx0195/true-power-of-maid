package net.mrqx.sbr_core.client.effect.efx.script;

import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributePtBehavior;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxBehaviorValue;
import net.mrqx.sbr_core.client.effect.post.RadialBlurPostEffect;

/**
 * 脚本 {@code via.effect.script.EffectRadialBlur}（径向模糊）的执行者：把该层 EFX 配置
 * 落地成一次全屏径向模糊后处理。
 * <p>
 * <b>参数映射</b>：
 * <ul>
 *   <li>中心取 {@link EfxScriptContext#position()}——径向模糊以<b>特效发射点</b>为中心，
 *       而不是屏幕中心，这一点由 {@code RadialBlurPostEffect} 的 {@code origin} 承担；</li>
 *   <li>时长取生命三段（{@link EfxScriptContext#appearTicks()} 等）；</li>
 *   <li>{@code BlurPower} / {@code ColorRate} 原样进 uniform；</li>
 *   <li>遮罩：{@code MaskRate} 大于 0 时按 {@code MaskSmoothstep}（过渡带起止）与
 *       {@code ScreenPosition}（遮罩中心）构造 {@link RadialBlurPostEffect.BlurMask}。</li>
 * </ul>
 * <p>
 * <b>明确不消费的参数</b>（记录而非静默丢弃）：{@code EnableFadeDistance} /
 * {@code FadeStartDistance} / {@code FadeEndDistance}（径向模糊跑在<b>后处理全屏 quad</b> 上，
 * 拿不到逐像素的场景深度，无法按深度淡出，改以持续时间近似）、{@code LookAtType}（语义未确证）、
 * {@code Priority}（屏幕空间路径上没有渲染优先级的对应语义）。
 */
public final class RadialBlurScriptAdapter implements EfxScriptAdapter {
    /**
     * 本执行者对应的脚本短名，即派发键。
     */
    public static final String SCRIPT_NAME = "EffectRadialBlur";
    
    @Override
    public String scriptName() {
        return SCRIPT_NAME;
    }
    
    @Override
    public void execute(EfxScriptContext context) {
        EfxAttributePtBehavior behavior = context.behavior();
        RadialBlurPostEffect.trigger(
            context.position(),
            context.appearTicks(),
            context.keepTicks(),
            context.vanishTicks(),
            behavior.floatValue("BlurPower", RadialBlurPostEffect.DEFAULT_BLUR_POWER),
            behavior.floatValue("ColorRate", 0.0F),
            mask(behavior));
    }
    
    /**
     * 按参数表构造模糊遮罩。
     * <p>
     * 缺项一律取"不遮罩"一侧的取值（{@code MaskRate} 为 0 即整屏均匀模糊），
     * 因此没配遮罩参数的层行为与引入遮罩之前完全一致。
     *
     * @param behavior 该层的脚本属性
     * @return 遮罩参数
     */
    public static RadialBlurPostEffect.BlurMask mask(EfxAttributePtBehavior behavior) {
        float rate = behavior.floatValue("MaskRate", 0.0F);
        if (rate <= 0.0F) {
            return RadialBlurPostEffect.BlurMask.NONE;
        }
        EfxBehaviorValue.Float2Value smoothstep =
            behavior.value("MaskSmoothstep", EfxBehaviorValue.Float2Value.class);
        EfxBehaviorValue.RangeValue screenPosition =
            behavior.value("ScreenPosition", EfxBehaviorValue.RangeValue.class);
        return new RadialBlurPostEffect.BlurMask(
            rate,
            smoothstep != null ? smoothstep.x() : 0.0F,
            smoothstep != null ? smoothstep.y() : 1.0F,
            screenPosition != null ? screenPosition.s() : 0.5F,
            screenPosition != null ? screenPosition.r() : 0.5F);
    }
}
