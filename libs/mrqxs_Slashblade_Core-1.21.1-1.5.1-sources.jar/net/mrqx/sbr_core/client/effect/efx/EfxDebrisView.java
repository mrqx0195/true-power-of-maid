package net.mrqx.sbr_core.client.effect.efx;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.effect.debris.DebrisMesh;
import net.mrqx.sbr_core.client.effect.efx.attribute.*;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * 网格类（{@link EfxTypeMesh}）EFX 配置的<b>只读派生视图</b>，服务玻璃大碎片层（{@code ガラス} 系列）。
 * <p>
 * 碎片是可见实体，需要速度 / 重力 / 翻滚与三段生命，故与 {@link EfxMeshView} 分开成类；构造后读取侧
 * 不再触碰任何属性 record，解析一律走 {@link EfxConfig#getOrDefault(Class, EfxAttribute)}（各属性的
 * DEFAULT 等价于"跳过该属性"）。
 */
public final class EfxDebrisView {
    /**
     * EFX 帧（60fps）→ tick（20tps）的换算：1 tick = 3 帧。
     */
    public static final float FRAMES_PER_TICK = 3.0F;
    
    /**
     * 速度 / 重力类的缩放折中系数（同 {@link EfxPolygonView#VELOCITY_SCALE}）：EFX 数值按此折算后再由渲染侧 ×3 换 tick。
     */
    public static final float VELOCITY_SCALE = 0.1F;
    
    /**
     * 亮度倍率默认值：EFX 属性表无此参数，取 1.0。
     */
    public static final float DEFAULT_INTENSITY = 1.0F;
    
    /**
     * 碎片总数：{@link EfxAttributeSpawn#maxParticles()}（同时存在的上限）。
     */
    public final int count;
    
    /**
     * 分批次数（至少 1）：{@link EfxAttributeSpawn#batchCount()}。
     */
    public final int batches;
    
    /**
     * 相邻两批之间的出生间隔（tick）：{@link EfxAttributeSpawn#intervalFrames()} ÷ {@link #FRAMES_PER_TICK}。
     */
    public final float intervalTicks;
    
    /**
     * 发射范围半轴（格）：{@link EfxAttributeEmitterShape3D} 各轴 {@code Range} 的 {@code s + r}（区间外端）。
     */
    public final Vector3f rangeXYZ;
    
    /**
     * 发射器形状：0 = 盒 / 点，1 = 球（三轴半径不等时呈椭球），2 = 圆柱；缺失时为 0。
     */
    public final int shapeType;
    
    /**
     * 初速度（格 / EFX 帧）：{@link EfxAttributeVelocity3D#speed()} 的基准值 × {@link #VELOCITY_SCALE}；缺失该属性时为 0。
     */
    public final float speed;
    
    /**
     * 初速度随机浮动比例（±）：{@code |Speed.r ÷ Speed.s|}（同 {@link EfxPolygonView#speedRandom}）；速度为 0 时为 0。
     */
    public final float speedRandom;
    
    /**
     * 是否径向发射（true = 由原点向外）：缺失该属性时为 true；本项目按"方向向量有无水平分量"推断，属启发式近似。
     */
    public final boolean radial;
    
    /**
     * 屏幕空间折射幅度（{@link EfxAttributeDistortion#influence()}）：缺失时为 0；玻璃碎片的折射来自材质而非 EFX 属性，此处接进折射遮罩通道。
     */
    public final float distortionRefractive;
    
    /**
     * 是否参与屏幕空间折射遮罩：{@link #distortionRefractive} 非零即为 true（强度 0 等价于关闭，不能只看属性存在与否）。
     */
    public final boolean enableDistortion;
    
    /**
     * 碎片网格资产位置（{@link EfxTypeMesh#mesh()}，由 EFX {@code meshPath} 决定）：玻璃与小石共用渲染路径、仅 OBJ 不同，不再是硬编码。
     */
    @Nullable
    public final ResourceLocation meshLocation;
    
    /**
     * 近端开始变淡的距离（格）：EFX 原值与 {@link EfxPolygonView#MIN_FADE_NEAR_START} 取<b>较小者</b>；照搬 EFX 的 3 会让第一人称下贴脸的碎片整片消失。
     */
    public final float fadeNearStart;
    
    /**
     * 近端完全透明（消失）的距离（格）；取法同 {@link #fadeNearStart}。
     */
    public final float fadeNearEnd;
    
    /**
     * 远端开始淡出的距离（格）：{@link EfxAttributeFadeByDepth#farStart()}；缺失时为 0。
     */
    public final float fadeFarStart;
    
    /**
     * 远端完全消失的距离（格）：{@link EfxAttributeFadeByDepth#farEnd()}；缺失时为 0。
     */
    public final float fadeFarEnd;
    
    /**
     * 尺寸的逐 <b>tick</b> 增量基准（EFX 为逐帧量，此处直取作逐 tick，与 {@code PolygonParticle} 同口径，总变化量因此为 3 倍——已知偏差）。
     */
    public final float sizeAddPerTick;
    
    /**
     * {@link #sizeAddPerTick} 的随机幅度（同为单位已折算的逐 tick 值），用于逐实例随机化。
     */
    public final float sizeAddRandomPerTick;
    
    /**
     * 尺寸增量的逐 tick 衰减系数（1 表示不衰减）：{@link EfxAttributeScaleAnim#sizeScalarCoef()}，已按 1 tick = 3 帧折算。
     */
    public final float sizeAddCoefPerTick;
    
    /**
     * 重力系数（每 tick 速度递减量，格 / tick²）：{@link EfxAttributeVelocity3D#gravityRate()} 的基准值 × {@link #VELOCITY_SCALE}；缺失该属性时为 0。
     */
    public final float gravityRate;
    
    /**
     * 速度的逐 tick 衰减系数（1 表示不衰减，即"空气阻力"）：{@link EfxAttributeVelocity3D#speedCoef()} 经 {@link EfxPolygonView#perFrameToPerTick(float)} 折算。
     */
    public final float speedDecay;
    
    /**
     * 碎片基准尺寸（格，作用于归一化网格）：{@link EfxTypeMesh#scaleMultiplier()} × {@link EfxTypeMesh#scaleX()}。
     */
    public final float scale;
    
    /**
     * Y 轴相对 X 轴的比例（{@code scaleY ÷ scaleX}）；不压扁的话薄片会被渲染成立方体。
     */
    public final float scaleYAspect;
    
    /**
     * Z 轴相对 X 轴的比例（{@code scaleZ ÷ scaleX}），语义同 {@link #scaleYAspect}。
     */
    public final float scaleZAspect;
    
    /**
     * 尺寸随机浮动比例（±）：{@link EfxTypeMesh#scaleXVariation()} 相对 {@code scaleX} 的比值再取半（见 {@link #scaleRandom(EfxTypeMesh)}）。
     */
    public final float scaleRandom;
    
    /**
     * 绕 X 轴翻滚角速度（度 / EFX 帧）的<b>基准值</b>：{@link EfxAttributeRotateAnim#rotationAddX()} 的 {@code s}。
     * <p>
     * ⚠ 从前这里是整层共用的常量 `30`，而数据（`ガラス　大0`）的 `s` 其实是 <b>0</b>、
     * 角速度整段在随机全宽里（`±30°`）——那个常量是把 `r` 当成 `s` 抄来的结果。
     */
    public final float spinX;
    
    /**
     * 绕 Y 轴翻滚角速度（度 / EFX 帧）的基准值。
     */
    public final float spinY;
    
    /**
     * 绕 Z 轴翻滚角速度（度 / EFX 帧）的基准值。
     */
    public final float spinZ;
    
    /**
     * 绕 X 轴翻滚角速度的随机全宽（度 / EFX 帧）：{@link EfxAttributeRotateAnim#rotationAddX()} 的 {@code r}。
     * 消费侧逐片抽 {@code s + (rnd − 0.5) · r}（实际范围 {@code ±r/2}）。
     */
    public final float spinXVariation;
    
    /**
     * 绕 Y 轴翻滚角速度的随机全宽（度 / EFX 帧）。
     */
    public final float spinYVariation;
    
    /**
     * 绕 Z 轴翻滚角速度的随机全宽（度 / EFX 帧）。
     */
    public final float spinZVariation;
    
    /**
     * 翻滚角速度每 tick 的衰减系数（1 表示不衰减）：{@link EfxAttributeRotateAnim#rotationCoefX()}
     * 经 {@link #perFrameToPerTick(float)} 折算。数据里三轴可以不同（`ガラス　大0` 是 X/Z `0.95`、Y `1`），
     * 故三轴各存一份。
     */
    public final float spinDecayX;
    
    /**
     * 绕 Y 轴翻滚角速度每 tick 的衰减系数。
     */
    public final float spinDecayY;
    
    /**
     * 绕 Z 轴翻滚角速度每 tick 的衰减系数。
     */
    public final float spinDecayZ;
    
    /**
     * 出现阶段（tick，渐显）：{@link EfxAttributeLife#appearFrame()} 的中值 {@code s + r/2} ÷ {@link #FRAMES_PER_TICK}。
     */
    public final float appearTicks;
    
    /**
     * 保持阶段（tick，碎片留存）：{@link EfxAttributeLife#keepFrame()} 与 {@link EfxAttributeLife#keepHoldFrame()}（保持段的额外延长）各自取中值后<b>相加</b>再 ÷ {@link #FRAMES_PER_TICK}，为面片 / 网格 / 碎片三视图统一口径。
     */
    public final float keepTicks;
    
    /**
     * 消散阶段（tick，渐隐）：{@link EfxAttributeLife#vanishFrame()} 的中值 {@code s + r/2} ÷ {@link #FRAMES_PER_TICK}。
     */
    public final float vanishTicks;
    
    /**
     * 基础颜色（常规 ARGB）：{@link EfxTypeMesh#color1()}，预设书写时已完成"EFX {@code rgba} → ARGB"（交换 R / B 通道）。
     */
    public final int color;
    
    /**
     * 亮度倍率：EFX 属性表无此参数，取 {@link #DEFAULT_INTENSITY}。
     */
    public final float intensity;
    
    /**
     * 每个碎片实例随机取起始形状的下限（含）：{@link EfxTypeMesh#startingFrameMin()}。
     */
    public final int startingFrameMin;
    
    /**
     * 每个碎片实例随机取起始形状的上限（含）：{@link EfxTypeMesh#startingFrameMax()}。
     */
    public final int startingFrameMax;
    
    /**
     * 形状组数量：仅作对照记录，本项目形状组数由 {@code glass_debris.obj} 决定，与 EFX 同源。
     */
    public final int frameCount;
    
    /**
     * 可用于随机取形的形状组数量（{@link EfxTypeMesh#selectableFrameCount()}）。
     */
    public final int selectableFrameCount;
    
    /**
     * 网格资源路径（{@link EfxTypeMesh#resource()}，仅作对照记录）；缺失时回退到 {@code DebrisMesh.MODEL_LOCATION}。
     */
    public final ResourceLocation resource;
    
    /**
     * 配置给出的固定随机种子（{@link EfxAttributeFixRandomGenerator} 的首个有效槽位）：{@code null} 表示本层没有该属性，即每次触发都用全新的随机分布。
     */
    @Nullable
    public final Long randomSeed;
    
    /**
     * 固定随机种子表属性（缺失为 {@code null}）："存在性"本身就是语义，故不做 {@code DEFAULT} 兜底。
     */
    @Nullable
    public final EfxAttributeFixRandomGenerator fixRandomGenerator;
    
    /**
     * 逐项解析配置，构造只读视图（{@code config} 的类型属性应为 {@link EfxTypeMesh}）。
     */
    public EfxDebrisView(EfxConfig config) {
        EfxTypeMesh meshType = config.getOrDefault(EfxTypeMesh.class, EfxTypeMesh.DEFAULT);
        EfxAttributeSpawn spawn = config.getOrDefault(EfxAttributeSpawn.class, EfxAttributeSpawn.DEFAULT);
        EfxAttributeLife life = config.getOrDefault(EfxAttributeLife.class, EfxAttributeLife.DEFAULT);
        EfxAttributeEmitterShape3D shape =
            config.getOrDefault(EfxAttributeEmitterShape3D.class, EfxAttributeEmitterShape3D.DEFAULT);
        // Velocity3D 用 DEFAULT 兜底与"跳过该属性"完全等价（速度、重力为 0 且无主方向）
        EfxAttributeVelocity3D velocity =
            config.getOrDefault(EfxAttributeVelocity3D.class, EfxAttributeVelocity3D.DEFAULT);
        EfxAttributeDistortion distortion =
            config.getOrDefault(EfxAttributeDistortion.class, EfxAttributeDistortion.DEFAULT);
        this.distortionRefractive = distortion.enabled() ? distortion.influence() : 0.0F;
        this.enableDistortion = this.distortionRefractive != 0.0F;
        this.meshLocation = meshType.resource();
        EfxAttributeFadeByDepth fadeByDepth =
            config.getOrDefault(EfxAttributeFadeByDepth.class, EfxAttributeFadeByDepth.DEFAULT);
        this.fadeNearStart = Math.min(fadeByDepth.nearStart(), EfxPolygonView.MIN_FADE_NEAR_START);
        this.fadeNearEnd = Math.min(fadeByDepth.nearEnd(), EfxPolygonView.MIN_FADE_NEAR_END);
        this.fadeFarStart = fadeByDepth.farStart();
        this.fadeFarEnd = fadeByDepth.farEnd();
        EfxAttributeScaleAnim scaleAnim =
            config.getOrDefault(EfxAttributeScaleAnim.class, EfxAttributeScaleAnim.DEFAULT);
        this.sizeAddPerTick = EfxPolygonView.perFrameToPerTick(scaleAnim.sizeScalarAdd().s());
        this.sizeAddRandomPerTick = EfxPolygonView.perFrameToPerTick(scaleAnim.sizeScalarAdd().r());
        this.sizeAddCoefPerTick = EfxPolygonView.perTickCoefficient(scaleAnim.sizeScalarCoef().s());
        
        // ---------- 分批节奏 ----------
        this.count = spawn.maxParticles();
        this.batches = Math.max(1, spawn.batchCount());
        // IntervalFrame = 0 时结果为 0，即"同帧生成全部批次"
        this.intervalTicks = spawn.intervalFrames() / FRAMES_PER_TICK;
        
        // ---------- 发射范围与形状 ----------
        this.rangeXYZ = new Vector3f(
            shape.rangeX().s() + shape.rangeX().r(),
            shape.rangeY().s() + shape.rangeY().r(),
            shape.rangeZ().s() + shape.rangeZ().r());
        this.shapeType = shape.shapeType();
        
        // ---------- 运动 ----------
        this.speed = toProjectSpeed(velocity.speed().s());
        this.speedRandom = speedRandom(velocity);
        this.radial = isRadial(velocity);
        this.gravityRate = toProjectSpeed(velocity.gravityRate().s());
        this.speedDecay = EfxPolygonView.perFrameToPerTick(velocity.speedCoef().s());
        
        // ---------- 尺寸与翻滚 ----------
        float sx = meshType.scaleX();
        float sy = meshType.scaleY();
        float sz = meshType.scaleZ();
        this.scale = meshType.scaleMultiplier() * sx;
        this.scaleYAspect = sx != 0.0F ? sy / sx : 1.0F;
        this.scaleZAspect = sx != 0.0F ? sz / sx : 1.0F;
        this.scaleRandom = scaleRandom(meshType);
        // 翻滚：基准 + 随机全宽 + 逐轴衰减，一律取自 EfxAttributeRotateAnim（不再用常量）
        EfxAttributeRotateAnim rotateAnim =
            config.getOrDefault(EfxAttributeRotateAnim.class, EfxAttributeRotateAnim.DEFAULT);
        this.spinX = (float) Math.toDegrees(rotateAnim.rotationAddX().s());
        this.spinY = (float) Math.toDegrees(rotateAnim.rotationAddY().s());
        this.spinZ = (float) Math.toDegrees(rotateAnim.rotationAddZ().s());
        this.spinXVariation = (float) Math.toDegrees(rotateAnim.rotationAddX().r());
        this.spinYVariation = (float) Math.toDegrees(rotateAnim.rotationAddY().r());
        this.spinZVariation = (float) Math.toDegrees(rotateAnim.rotationAddZ().r());
        this.spinDecayX = perFrameToPerTick(rotateAnim.rotationCoefX().s());
        this.spinDecayY = perFrameToPerTick(rotateAnim.rotationCoefY().s());
        this.spinDecayZ = perFrameToPerTick(rotateAnim.rotationCoefZ().s());
        
        // ---------- 生命与外观 ----------
        this.appearTicks = EfxMeshView.rangeMean(life.appearFrame()) / FRAMES_PER_TICK;
        this.keepTicks = (EfxMeshView.rangeMean(life.keepFrame())
            + EfxMeshView.rangeMean(life.keepHoldFrame())) / FRAMES_PER_TICK;
        this.vanishTicks = EfxMeshView.rangeMean(life.vanishFrame()) / FRAMES_PER_TICK;
        this.color = meshType.color1();
        this.intensity = DEFAULT_INTENSITY;
        
        // ---------- 形状序列 ----------
        this.startingFrameMin = meshType.startingFrameMin();
        this.startingFrameMax = meshType.startingFrameMax();
        this.frameCount = meshType.frameCount();
        this.selectableFrameCount = meshType.selectableFrameCount();
        this.resource = meshType.resource() != null ? meshType.resource() : DebrisMesh.MODEL_LOCATION;
        
        // ---------- 随机种子 ----------
        this.fixRandomGenerator = config.get(EfxAttributeFixRandomGenerator.class);
        int[] seeds = this.fixRandomGenerator != null ? this.fixRandomGenerator.validSeeds() : new int[0];
        this.randomSeed = seeds.length > 0 ? (long) seeds[0] : null;
    }
    
    /**
     * 生命总时长（tick）：{@code appear + keep + vanish}。
     */
    public float totalTicks() {
        return this.appearTicks + this.keepTicks + this.vanishTicks;
    }
    
    /**
     * 取 EFX 速度并折算成本项目的速度量级（× {@link #VELOCITY_SCALE}）。
     */
    public static float toProjectSpeed(float speed) {
        return speed * VELOCITY_SCALE;
    }
    
    /**
     * 把初速度的随机幅度折算成相对随机比例 {@code |Speed.r ÷ Speed.s|}（{@code Speed} 才是速度区间，{@code Size} 是方向椭球半径）。
     */
    public static float speedRandom(EfxAttributeVelocity3D velocity) {
        float base = velocity.speed().s();
        return base != 0.0F ? Math.abs(velocity.speed().r() / base) : 0.0F;
    }
    
    /**
     * 把尺寸随机幅度折算成相对浮动比例：{@code scaleXVariation} 是"随机全宽"，本项目用"基准 ± 比例"，故除以轴向基准再取半幅。
     */
    public static float scaleRandom(EfxTypeMesh meshType) {
        return meshType.scaleX() != 0.0F
            ? Math.abs(meshType.scaleXVariation() / meshType.scaleX() * 0.5F)
            : 0.0F;
    }
    
    /**
     * 判断是否"由原点向外"的径向发射：无主方向或主方向纯竖直时为 true；属启发式近似（EFX 由 {@code VelocityType} 给出，本项目暂未读取）。
     */
    public static boolean isRadial(EfxAttributeVelocity3D velocity) {
        if (!velocity.hasDirection()) {
            return true;
        }
        Vector3f direction = velocity.direction();
        return Math.abs(direction.x) < 1.0E-6F && Math.abs(direction.z) < 1.0E-6F;
    }
    
    /**
     * 把"每帧衰减系数"换算成"每 tick 衰减系数"（1 tick = 3 帧，即取三次方）。
     */
    public static float perFrameToPerTick(float perFrame) {
        return perFrame * perFrame * perFrame;
    }
}
