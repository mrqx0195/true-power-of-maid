package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;
import net.mrqx.sbr_core.client.effect.efx.EfxRange;

/**
 * 飘带跟随类型属性（{@code EFXAttributeTypeRibbonFollow}，{@code type = 28}）。
 * <p>
 * 与 {@link EfxTypeGpuRibbonFollow}（{@code type = 277}）是<b>两套不同的字段集</b>：本类型的参数明显更多，
 * 多出的是"沿带长分段"的一组——{@code ColorPlace1/2} 与 {@code ScalePlace1/2} 各给出两个中间位置的
 * 颜色与宽度、{@code HeadColor} / {@code HeadScale} 给出头端、{@code *Ratio} 给出这两个位置在带长上的比例；
 * 另有 {@code FadeSide} / {@code FadeByTwistMin/Max} / {@code GhostStretch} 这类外观项。
 * <p>
 * <b>现有数据里这些分段参数全是默认值</b>（{@code ColorPlace* = 0xFFFFFFFF}、{@code ScalePlace* = 1}、
 * {@code Ratio = 0.5 / 1}），因此本项目<b>只有 {@code sizeScalar} / {@code color} / {@code colorRange}
 * 三项进了消费侧</b>，其余仅作字段承载——不要因为它们"看起来没被用"就把字段删掉，
 * 那是"数据里恰好取默认值"，不是"引擎里没有这项能力"。
 * <p>
 * 颜色字段由 json 的 {@code rgba} 交换 R/B 得到本项目的常规 ARGB。
 *
 * @param blendFlags         混合标志位；现有数据取 1152，位语义与面片的 {@code Flags} 不同，尚未确证
 * @param color              主体颜色（常规 ARGB）
 * @param colorRange         配色抖动范围（常规 ARGB，alpha 为 0 表示不抖动）
 * @param colorRate          色彩倍率
 * @param intensity          自发光强度
 * @param edgeBlendRange     边缘混合范围
 * @param alphaRate          alpha 倍率
 * @param flags              跟随标志位（与 {@code FollowFlags} 配套，语义未确证）
 * @param sizeScalar         带宽基准与随机幅度（格）——<b>实测这一项才是带宽</b>，{@code width} 不是
 * @param width              宽度字段；实测不影响带宽，仅作承载
 * @param textureRepeatNum   贴图沿带长的重复次数
 * @param unkn14Re2          未确证字段，现有数据取 1
 * @param shadowMultiplier   阴影倍率
 * @param fadeSide           侧面淡出参数
 * @param followFlags        跟随标志位
 * @param stretchDistanceX   拉伸距离 X。<b>整数语义</b>：参考数据里这 8 字节按 {@code u32} 读是 `2/3/10/20/60`
 *                           这类小整数、按 {@code float} 读则是非规格化数（`5.6e-45` 之类），
 *                           所以参考实现虽然声明成 `Vector2`，实际承载的是两个整数。
 * @param stretchDistanceY   拉伸距离 Y（整数语义，同上）
 * @param unkn               未确证字段
 * @param shapeDivision      形状分段数；现有数据为 0（即未指定）
 * @param splineDivision     样条分段数；现有数据为 0（即未指定）
 * @param unknRe7            未确证字段
 * @param unknRe7_2          未确证字段
 * @param headColor          头端颜色（常规 ARGB）
 * @param colorPlace1        带长上第一个中间位置的颜色（常规 ARGB）
 * @param colorPlace2        带长上第二个中间位置的颜色（常规 ARGB）
 * @param colorPlace1Ratio   第一个中间位置在带长上的比例
 * @param colorPlace2Ratio   第二个中间位置在带长上的比例
 * @param headScale          头端宽度倍率
 * @param scalePlace1        带长上第一个中间位置的宽度倍率
 * @param scalePlace2        带长上第二个中间位置的宽度倍率
 * @param scalePlace1Ratio   第一个宽度中间位置在带长上的比例
 * @param scalePlace2Ratio   第二个宽度中间位置在带长上的比例
 * @param fadeByTwistMin     扭转淡出下限
 * @param fadeByTwistMax     扭转淡出上限
 * @param ghostStretch       残影拉伸
 */
public record EfxTypeRibbonFollow(
    int blendFlags,
    int color,
    int colorRange,
    float colorRate,
    float intensity,
    float edgeBlendRange,
    float alphaRate,
    int flags,
    EfxRange sizeScalar,
    EfxRange width,
    float textureRepeatNum,
    float unkn14Re2,
    float shadowMultiplier,
    float fadeSide,
    int followFlags,
    int stretchDistanceX,
    int stretchDistanceY,
    int unkn,
    int shapeDivision,
    int splineDivision,
    int unknRe7,
    int unknRe7_2,
    int headColor,
    int colorPlace1,
    int colorPlace2,
    float colorPlace1Ratio,
    float colorPlace2Ratio,
    float headScale,
    float scalePlace1,
    float scalePlace2,
    float scalePlace1Ratio,
    float scalePlace2Ratio,
    float fadeByTwistMin,
    float fadeByTwistMax,
    EfxRange ghostStretch
) implements EfxAttribute {
    /**
     * EFX 属性类型编号。
     */
    public static final int TYPE = 28;
    
    /**
     * 默认值：宽度 1 格、分段参数取中性（三个位置同色同宽、比例 0.5 / 1）。
     */
    public static final EfxTypeRibbonFollow DEFAULT = new EfxTypeRibbonFollow(
        0, 0xFFFFFFFF, 0x00000000, 1.0F, 1.0F, 0.0F, 0.0F, 0,
        new EfxRange(1.0F, 0.0F), new EfxRange(1.0F, 0.0F), 0.0F, 0.0F, 0.0F, 0.0F, 0,
        0, 0, 0, 0, 0, 0, 0,
        0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0.5F, 1.0F,
        1.0F, 1.0F, 1.0F, 0.5F, 1.0F,
        0.0F, 0.0F, EfxRange.ZERO);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeRibbonFollow";
    }
}
