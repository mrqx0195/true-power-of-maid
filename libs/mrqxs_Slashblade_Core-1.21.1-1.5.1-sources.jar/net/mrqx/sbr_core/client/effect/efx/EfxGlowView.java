package net.mrqx.sbr_core.client.effect.efx;

import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeGlowRender;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxAttributeLife;
import net.mrqx.sbr_core.client.effect.efx.attribute.EfxTypeBillboard3D;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;

/**
 * "全屏辉光"层（{@link EfxTypeBillboard3D} + {@link EfxAttributeGlowRender}）EFX 配置的只读派生视图，
 * 服务屏幕空间辉光后端（{@code GlowPostEffect}）。
 * <p>
 * {@link #color} 与生命三段来自 EFX，其余数值是 {@link EfxAttributeGlowRender} 承载的本项目观感标定值。
 * <p>
 * 生命三段先取 {@link #rangeMean(EfxRange)} 中值（与其余视图一致）再 ÷ {@link #FRAMES_PER_TICK} 并四舍五入。
 */
public final class EfxGlowView {
    /**
     * 1 tick 对应的 EFX 帧数（EFX 60fps、本项目 20tps）。
     */
    public static final float FRAMES_PER_TICK = 3.0F;
    
    /**
     * 生命 {@code Flags}（{@code VanishEvent}）里"保持到演出收尾"的那一位。
     */
    public static final int KEEP_HOLD_FLAG = 1;
    
    /**
     * 光斑的世界半径（格），本项目的观感标定值。
     */
    public final float radius;
    
    /**
     * 光斑颜色（常规 ARGB），来自 EFX 类型属性的 {@code Color}。
     */
    public final int color;
    
    /**
     * 满强度增益，已含整体强度倍率（本项目的观感标定值）。
     */
    public final float strength;
    
    /**
     * 叠加模式（{@code GlowSpec.MODE_*}）。
     */
    public final int mode;
    
    /**
     * 边缘柔和度（EFX 里没有对应字段）。
     */
    public final float softness;
    
    /**
     * 场景整体模糊半径（像素）。
     */
    public final float sceneBlur;
    
    /**
     * 渐入段（tick），由 EFX 生命换算。
     */
    public final int appearTicks;
    
    /**
     * 满强度段（tick）；{@code Flags} 置位时延长到演出收尾。
     */
    public final int keepTicks;
    
    /**
     * 渐出段（tick），由 EFX 生命换算。
     */
    public final int vanishTicks;
    
    /**
     * 逐项解析配置，构造只读视图（{@code config} 的类型属性应为 {@link EfxTypeBillboard3D}）。
     */
    public EfxGlowView(EfxConfig config) {
        this(config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 逐项解析配置，构造只读视图，并指定本场演出的收尾时刻；{@code sustainedKeepTicks} 为
     * {@link EfxTimeline#USE_DEFAULT_SUSTAINED_KEEP} 时回退到 {@link EfxTimeline#SUSTAINED_KEEP_TICKS}。
     */
    public EfxGlowView(EfxConfig config, int sustainedKeepTicks) {
        float sustainedKeep = sustainedKeepTicks >= 0
            ? sustainedKeepTicks
            : EfxTimeline.SUSTAINED_KEEP_TICKS;
        EfxTypeBillboard3D type = config.getOrDefault(EfxTypeBillboard3D.class, EfxTypeBillboard3D.DEFAULT);
        EfxAttributeLife life = config.getOrDefault(EfxAttributeLife.class, EfxAttributeLife.DEFAULT);
        EfxAttributeGlowRender glow =
            config.getOrDefault(EfxAttributeGlowRender.class, EfxAttributeGlowRender.DEFAULT);
        
        this.radius = glow.radius();
        this.color = type.color();
        this.strength = glow.strength();
        this.mode = glow.mode();
        this.softness = glow.softness();
        this.sceneBlur = glow.sceneBlur();
        
        // 每段至少 1 tick：这一族层的生命本来只有 1~2 帧量级，四舍五入会把某段算成 0、效果完全不显示
        this.appearTicks = Math.max(1, Math.round(rangeMean(life.appearFrame()) / FRAMES_PER_TICK));
        int keepTicks = Math.max(1,
            Math.round((rangeMean(life.keepFrame())
                + rangeMean(life.keepHoldFrame())) / FRAMES_PER_TICK));
        // Flags 第 0 位置位即保持段延长到演出收尾，口径与 EfxNoDrawView 及三个粒子视图一致
        if ((life.flags() & KEEP_HOLD_FLAG) != 0) {
            keepTicks = Math.max(keepTicks,
                Math.max(1, Math.round(sustainedKeep) - this.appearTicks));
        }
        this.keepTicks = keepTicks;
        this.vanishTicks = Math.max(1, Math.round(rangeMean(life.vanishFrame()) / FRAMES_PER_TICK));
    }
    
    /**
     * 取 EFX 数值区间的中值 {@code s + r / 2}：本项目的生命字段是单值，而 EFX 是"基准 + 随机幅度"，
     * 中值即均匀取值的期望；口径与 {@link EfxMeshView#rangeMean(EfxRange)} 等视图完全一致。
     */
    public static float rangeMean(EfxRange range) {
        return range.s() + range.r() * 0.5F;
    }
}
