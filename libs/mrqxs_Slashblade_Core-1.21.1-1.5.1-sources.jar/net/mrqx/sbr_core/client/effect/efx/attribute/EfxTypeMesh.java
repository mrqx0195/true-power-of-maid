package net.mrqx.sbr_core.client.effect.efx.attribute;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.effect.efx.EfxAttribute;

import javax.annotation.Nullable;

/**
 * 类型属性 {@code EFXAttributeTypeMesh}：真实网格层（われ 与 玻璃大碎片，对应 json 的 {@code type} = 25）。
 * <p>
 * {@code frameCount} 是网格内的形状组数量，{@code startingFrameMin/Max} 限定<b>随机取起始形状</b>的范围；
 * {@code rotation*Variation} 只描述"出生时朝向随机多少"（弧度），角速度在 {@code EFXAttributeRotateAnim}。
 * <p>
 * <b>{@code animationMode} / {@code animationSpeed*} 不映射，且已核实这样是完备的</b>（数据侧分布，
 * 脚本 {@code efx_field_histogram.py}）：全部 27 处 {@code TypeMesh} 里 {@code animationMode} 恒为 {@code 0}
 * （不逐帧切换形状）、{@code animationSpeedMin/Max} 恒为 {@code 1}（乘 1，中性）；本版本的 {@code TypeMesh}
 * 里连 {@code PlayType} / {@code PlayOrder} 字段都没有（那是参考实现里别的结构体才有的），
 * 故原先"枚举含义无从对照"这条其实不成立。
 * ⚠ {@code frameCount} 并<b>不</b>恒为 1：实测分布是 {@code 1}×20 / {@code 2}×3 / {@code 3}×3 / {@code 8}×1，
 * 多形状组的层靠 {@link #startingFrameMin()} / {@link #startingFrameMax()} 选起始形状（本项目已消费）。
 * <p>
 * 不显然的坑：{@code color1/color2} 是材质的 {@code ColorParam} 两端色、不是顶点色，json 的 rgba 需交换 R/B；
 * {@code rotation*Variation}/{@code scale*Variation} 是随机全宽，消费侧按 {@code 基准 ± Variation/2} 使用。
 * <p>
 * 口径：{@code startingFrameMax} 按"含"解读会指向不存在的形状组（现有数据 Max = 1 而只有 1 组形状），
 * 故 {@link #selectableFrameCount()} 先夹到 {@code frameCount - 1} 再按"含"计算，对现有数据等价于半开区间。
 * <p>
 * 缺省即跳过：{@code resource} 为 {@code null} 时回退到该碎片自己的默认模型——本字段直接承载真正加载的
 * 模型资源；{@code texture} 为 {@code null} 时用渲染类型的默认贴图（{@code MeshParticleRenderType}
 * 原本只带固定贴图，而材质可逐层覆写贴图，故独立成字段）。
 * <p>
 * {@code rippleRings} 为 {@code true} 时该层走纹波片元管线（贴图只取 R/G 当遮罩、颜色由
 * {@code ColorParam}/{@code ColorHigh} 插值），不做噪声溶解；{@code cloudShell} 把贴图 R/G 当云层密度、
 * 颜色取顶点色——该遮罩图蓝通道恒为 0，当颜色渲染会得到黄绿色球壳（实测）。材质参数由
 * {@link EfxAttributeMeshMaterial} 逐层承载。
 */
public record EfxTypeMesh(
    int frameCount,
    int startingFrameMin,
    int startingFrameMax,
    float animationSpeedMin,
    float animationSpeedMax,
    int animationMode,
    float rotationX,
    float rotationXVariation,
    float rotationY,
    float rotationYVariation,
    float rotationZ,
    float rotationZVariation,
    float scaleX,
    float scaleXVariation,
    float scaleY,
    float scaleYVariation,
    float scaleZ,
    float scaleZVariation,
    float scaleMultiplier,
    float scaleMultiplierVariation,
    int color1,
    int color2,
    @Nullable ResourceLocation resource,
    @Nullable ResourceLocation texture,
    boolean rippleRings,
    boolean cloudShell
) implements EfxAttribute {
    
    /**
     * 兼容构造器：带贴图覆写但采用默认"溶解"语义（不启用纹波），使 インバース0 这类层无需改动。
     */
    public EfxTypeMesh(
        int frameCount,
        int startingFrameMin,
        int startingFrameMax,
        float animationSpeedMin,
        float animationSpeedMax,
        int animationMode,
        float rotationX,
        float rotationXVariation,
        float rotationY,
        float rotationYVariation,
        float rotationZ,
        float rotationZVariation,
        float scaleX,
        float scaleXVariation,
        float scaleY,
        float scaleYVariation,
        float scaleZ,
        float scaleZVariation,
        float scaleMultiplier,
        float scaleMultiplierVariation,
        int color1,
        int color2,
        @Nullable ResourceLocation resource,
        @Nullable ResourceLocation texture
    ) {
        this(frameCount, startingFrameMin, startingFrameMax,
            animationSpeedMin, animationSpeedMax, animationMode,
            rotationX, rotationXVariation, rotationY, rotationYVariation,
            rotationZ, rotationZVariation,
            scaleX, scaleXVariation, scaleY, scaleYVariation,
            scaleZ, scaleZVariation,
            scaleMultiplier, scaleMultiplierVariation,
            color1, color2, resource, texture, false, false);
    }
    
    /**
     * 兼容构造器：带纹波开关但不带云层开关，供 メッシュ　シールド2 与 メッシュ　収束オーラ0 使用。
     * {@link #cloudShell} 是后加的组件，补此条以保住原先 25 参数的调用。
     */
    public EfxTypeMesh(
        int frameCount,
        int startingFrameMin,
        int startingFrameMax,
        float animationSpeedMin,
        float animationSpeedMax,
        int animationMode,
        float rotationX,
        float rotationXVariation,
        float rotationY,
        float rotationYVariation,
        float rotationZ,
        float rotationZVariation,
        float scaleX,
        float scaleXVariation,
        float scaleY,
        float scaleYVariation,
        float scaleZ,
        float scaleZVariation,
        float scaleMultiplier,
        float scaleMultiplierVariation,
        int color1,
        int color2,
        @Nullable ResourceLocation resource,
        @Nullable ResourceLocation texture,
        boolean rippleRings
    ) {
        this(frameCount, startingFrameMin, startingFrameMax,
            animationSpeedMin, animationSpeedMax, animationMode,
            rotationX, rotationXVariation, rotationY, rotationYVariation,
            rotationZ, rotationZVariation,
            scaleX, scaleXVariation, scaleY, scaleYVariation,
            scaleZ, scaleZVariation,
            scaleMultiplier, scaleMultiplierVariation,
            color1, color2, resource, texture, rippleRings, false);
    }
    
    /**
     * 兼容构造器：不带贴图覆写（用渲染类型的默认贴图），使现有各层预设一行都不用改。
     */
    public EfxTypeMesh(
        int frameCount,
        int startingFrameMin,
        int startingFrameMax,
        float animationSpeedMin,
        float animationSpeedMax,
        int animationMode,
        float rotationX,
        float rotationXVariation,
        float rotationY,
        float rotationYVariation,
        float rotationZ,
        float rotationZVariation,
        float scaleX,
        float scaleXVariation,
        float scaleY,
        float scaleYVariation,
        float scaleZ,
        float scaleZVariation,
        float scaleMultiplier,
        float scaleMultiplierVariation,
        int color1,
        int color2,
        @Nullable ResourceLocation resource
    ) {
        this(frameCount, startingFrameMin, startingFrameMax,
            animationSpeedMin, animationSpeedMax, animationMode,
            rotationX, rotationXVariation, rotationY, rotationYVariation,
            rotationZ, rotationZVariation,
            scaleX, scaleXVariation, scaleY, scaleYVariation,
            scaleZ, scaleZVariation,
            scaleMultiplier, scaleMultiplierVariation,
            color1, color2, resource, null);
    }
    
    /**
     * EFX 属性类型编号（json 中 {@code EFXAttributeTypeMesh} 的 {@code type}）。
     */
    public static final int TYPE = 25;
    
    /**
     * 默认值：单形状、不随机、1 格尺寸、白色。
     */
    public static final EfxTypeMesh DEFAULT = new EfxTypeMesh(
        1, 0, 0, 1.0F, 1.0F, 0,
        0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
        1.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F,
        1.0F, 0.0F,
        0xFFFFFFFF, 0xFFFFFFFF, null);
    
    @Override
    public int type() {
        return TYPE;
    }
    
    @Override
    public String attributeName() {
        return "EFXAttributeTypeMesh";
    }
    
    /**
     * 可用于随机取形的形状组数量（把两端夹到 {@code frameCount} 内后按"含"计算）。
     * 现有数据 {@code frameCount = 1、Min = 0、Max = 1} 说明 {@code Max} 更像半开区间上界，
     * 故先夹到 {@code frameCount - 1}；无有效区间时返回 0。
     */
    public int selectableFrameCount() {
        int min = Math.max(0, Math.min(this.startingFrameMin, this.startingFrameMax));
        int max = Math.min(this.frameCount - 1, Math.max(this.startingFrameMin, this.startingFrameMax));
        return max >= min ? max - min + 1 : 0;
    }
}
