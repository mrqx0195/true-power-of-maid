package net.mrqx.sbr_core.client.effect.timeline;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.debris.DebrisManager;
import net.mrqx.sbr_core.client.effect.efx.EfxPolygonView;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * 「次元斩·絶」本体的演出时间轴。
 * <p>
 * 各层的触发时刻写在 {@code TICK_*} 常量里，括号内是 EFX 的 {@code SpawnFrame} 原值。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class JudgementCutEndTimeline extends EfxTimeline {
    /**
     * 单例：本类持有"本次演出"的运行态。
     */
    public static final JudgementCutEndTimeline INSTANCE = new JudgementCutEndTimeline();
    
    /**
     * 演出总帧数（实测 169 帧）。
     */
    public static final int TOTAL_FRAMES = 169;
    
    /**
     * 演出总 tick 数。
     */
    public static final int TOTAL_TICKS = framesToTicks(TOTAL_FRAMES);
    
    public static final int LAYER_BLACK_FILTER = 0;
    public static final int LAYER_CAMERA_SHAKE = 1;
    public static final int LAYER_LIGHT = 2;
    public static final int LAYER_CHROMA_BALL = 3;
    public static final int LAYER_GLOW_SUBTRACT = 4;
    /**
     * 闪光连击，占用 {@link #BLUR_FLASH_COUNT} 个连续编号。
     */
    public static final int LAYER_BLUR_FLASH = 5;
    public static final int LAYER_CRACK_BLACK = 8;
    public static final int LAYER_CRACK_PURPLE_GLOW = 9;
    public static final int LAYER_CRACK_PURPLE = 10;
    public static final int LAYER_SLASH_WIDE = 11;
    public static final int LAYER_CRACK_BLUE = 12;
    public static final int LAYER_SLASH_LINE = 13;
    /**
     * 背部加法辉光连击，占用 {@link #BACK_ADD_GLOW_COUNT} 个连续编号。
     */
    public static final int LAYER_BACK_ADD_GLOW = 14;
    public static final int LAYER_CHROMA_LUT = 17;
    public static final int LAYER_KEEP = 18;
    /**
     * 崩解段：碎片与尾段镜头 / 模糊同刻触发。
     */
    public static final int LAYER_DEBRIS = 19;
    public static final int LAYER_TAIL_CHROMA_LUT = 20;
    public static final int LAYER_BURST = 21;
    
    /**
     * 紫色裂纹（{@code SpawnFrame = 6}）。
     */
    public static final int TICK_CRACK_PURPLE = framesToTicks(6);
    
    /**
     * 宽斩击（{@code SpawnFrame = 7}）。
     */
    public static final int TICK_SLASH_WIDE = framesToTicks(7);
    
    /**
     * 蓝色裂纹。
     */
    public static final int TICK_CRACK_BLUE = 3;
    
    /**
     * 细斩线（{@code SpawnFrame = 9}）。
     */
    public static final int TICK_SLASH_LINE = framesToTicks(9);
    
    /**
     * 背部加法辉光首批（{@code SpawnFrame = 10}）。
     */
    public static final int TICK_BACK_ADD = framesToTicks(10);
    
    /**
     * LUT 色彩校正（{@code SpawnFrame = 10}）。
     */
    public static final int TICK_LUT_COLOR = framesToTicks(10);
    
    /**
     * 保持层（{@code SpawnFrame = 37}）。
     */
    public static final int TICK_KEEP = framesToTicks(37);
    
    /**
     * 崩解段（{@code SpawnFrame = 164}）。
     */
    public static final int TICK_DEBRIS = framesToTicks(164);
    
    /**
     * 爆发段（{@code SpawnFrame = 169}）。
     */
    public static final int TICK_BURST = framesToTicks(169);
    
    /**
     * 闪光连击的批量数与间隔（tick）。
     */
    public static final int BLUR_FLASH_COUNT = 3;
    public static final int BLUR_FLASH_INTERVAL = 2;
    
    /**
     * 背部加法辉光的批量数与间隔（tick）。
     */
    public static final int BACK_ADD_GLOW_COUNT = 3;
    public static final int BACK_ADD_INTERVAL = 3;
    
    private JudgementCutEndTimeline() {
    }
    
    /**
     * 播放一次完整的演出。
     *
     * @param level  客户端世界
     * @param origin 演出原点
     */
    public static void play(ClientLevel level, Vec3 origin) {
        INSTANCE.start(level, origin);
    }
    
    /**
     * 每个客户端 tick 推进一步演出。
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        INSTANCE.tick(Minecraft.getInstance().level);
    }
    
    /**
     * 同 {@code JudgementCutEndRangeTimeline}：本场演出也按"半径 10 格 → 30 格"的效果范围口径标定。
     */
    @Override
    public float effectRangeScale() {
        return EfxPolygonView.SIZE_SCALE;
    }
    
    @Override
    public int totalTicks() {
        return TOTAL_TICKS;
    }
    
    @Override
    protected void tickLayers(ClientLevel level, int elapsed) {
        this.tickOpening(level, elapsed);
        this.tickSlash(level, elapsed);
        this.tickTail(level, elapsed);
    }
    
    /**
     * 起手段：压暗、震屏、补光、色球、减色辉光、闪光连击、裂纹。
     *
     * @param level   客户端世界
     * @param elapsed 自演出开始已经过的 tick
     */
    public void tickOpening(ClientLevel level, int elapsed) {
        if (this.shouldFire(LAYER_BLACK_FILTER, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJceNoDrawPresets.BLACK_FILTER);
        }
        if (this.shouldFire(LAYER_CAMERA_SHAKE, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJceNoDrawPresets.CAMERA_SHAKE);
        }
        if (this.shouldFire(LAYER_LIGHT, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJceNoDrawPresets.LIGHT);
        }
        if (this.shouldFire(LAYER_CHROMA_BALL, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJceChromaPresets.CHROMA_BALL);
        }
        if (this.shouldFire(LAYER_GLOW_SUBTRACT, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJceGlowPresets.GLOW_SUBTRACT);
        }
        for (int i = 0; i < BLUR_FLASH_COUNT; i++) {
            if (this.shouldFire(LAYER_BLUR_FLASH + i, i * BLUR_FLASH_INTERVAL, elapsed)) {
                this.spawn(level, this.origin, EfxJceGlowPresets.BLUR_FLASH);
            }
        }
        if (this.shouldFire(LAYER_CRACK_BLACK, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.CRACK_BLACK);
        }
        if (this.shouldFire(LAYER_CRACK_PURPLE_GLOW, 0, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.CRACK_PURPLE_GLOW);
        }
    }
    
    /**
     * 斩击段：裂纹、斩击、背部辉光连击、LUT 色彩校正与保持层。
     *
     * @param level   客户端世界
     * @param elapsed 自演出开始已经过的 tick
     */
    public void tickSlash(ClientLevel level, int elapsed) {
        if (this.shouldFire(LAYER_CRACK_PURPLE, TICK_CRACK_PURPLE, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.CRACK_PURPLE);
        }
        if (this.shouldFire(LAYER_SLASH_WIDE, TICK_SLASH_WIDE, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.SLASH_WIDE);
        }
        if (this.shouldFire(LAYER_CRACK_BLUE, TICK_CRACK_BLUE, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.CRACK_BLUE);
        }
        if (this.shouldFire(LAYER_SLASH_LINE, TICK_SLASH_LINE, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.SLASH_LINE);
        }
        for (int i = 0; i < BACK_ADD_GLOW_COUNT; i++) {
            if (this.shouldFire(LAYER_BACK_ADD_GLOW + i, TICK_BACK_ADD + i * BACK_ADD_INTERVAL, elapsed)) {
                this.spawn(level, this.origin, EfxJceGlowPresets.BACK_ADD_GLOW);
            }
        }
        // TODO: 观感不大行，考虑后续调整或移除
//        if (this.shouldFire(LAYER_BACK_ADD_LATE, TICK_DEBRIS + 1, elapsed)) {
//            this.spawn(level, this.origin, EfxJceGlowPresets.BACK_ADD_LATE);
//        }
        if (this.shouldFire(LAYER_CHROMA_LUT, TICK_LUT_COLOR, elapsed)) {
            this.spawn(level, this.origin, EfxJceNoDrawPresets.CHROMA_LUT,
                TICK_DEBRIS - TICK_LUT_COLOR + 2);
        }
        if (this.shouldFire(LAYER_KEEP, TICK_KEEP, elapsed)) {
            this.spawn(level, this.origin, EfxJceMeshPresets.KEEP);
        }
    }
    
    /**
     * 收尾段：崩解碎片与尾段镜头 / 模糊 / 调色，随后爆发。
     *
     * @param level   客户端世界
     * @param elapsed 自演出开始已经过的 tick
     */
    public void tickTail(ClientLevel level, int elapsed) {
        // TODO: 观感不大行，考虑后续调整或移除
//        if (this.shouldFire(LAYER_GROUND_SMOKE, TICK_DEBRIS, elapsed)) {
//            this.spawn(level, this.origin, EfxJcePolygonPresets.GROUND_SMOKE);
//            this.spawn(level, this.origin, EfxJcePolygonPresets.GROUND_SMOKE_VERTICAL);
//        }
        if (this.shouldFire(LAYER_DEBRIS, TICK_DEBRIS, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.CRYSTAL_SMALL,
                TICK_BURST - TICK_DEBRIS);
            DebrisManager.spawn(level, this.origin, EfxJceDebrisPresets.GLASS_LARGE);
            DebrisManager.spawn(level, this.origin.add(0.0D, 1.0D, 0.0D), EfxJceDebrisPresets.STONE_SMALL);
            this.spawn(level, this.origin, EfxJceNoDrawPresets.TAIL_CAMERA_SHAKE);
            this.spawn(level, this.origin, EfxJceNoDrawPresets.TAIL_RADIAL_BLUR);
        }
        if (this.shouldFire(LAYER_TAIL_CHROMA_LUT, TICK_DEBRIS + 1, elapsed)) {
            this.spawn(level, this.origin, EfxJceNoDrawPresets.TAIL_CHROMA_LUT);
        }
        if (this.shouldFire(LAYER_BURST, TICK_BURST, elapsed)) {
            this.spawn(level, this.origin, EfxJcePolygonPresets.CRYSTAL_TINY, 0);
            this.spawn(level, this.origin, EfxJceMeshPresets.FADE);
        }
    }
}
