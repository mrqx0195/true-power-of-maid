package net.mrqx.sbr_core.client.effect.timeline;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashMeshPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashNoDrawPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashPolygonPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashRibbonPresets;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * 次元斩（小技能）<b>普通变体</b>的演出时间轴。
 * <p>
 * 演出原点是<b>目标位置</b>，故与另两套一样<b>不</b>覆写 {@link EfxTimeline#effectRangeScale()}。
 * <p>
 * 三套里有五个层的数据<b>与完美变体逐字段相同</b>（{@code 斬り_黒}、{@code 剣軌跡2}、{@code 歪み開始}、
 * {@code 歪み}、{@code blur}），为免同一条数据抄两遍，本类直接引用完美变体的常量——
 * 这是"同一份数据被两次引用"，不是"普通变体沿用了别人的参数"。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class DimensionSlashNormalTimeline extends EfxTimeline {
    /**
     * 单例：本类持有"本次演出"的运行态。
     */
    public static final DimensionSlashNormalTimeline INSTANCE = new DimensionSlashNormalTimeline();
    
    /**
     * 演出总帧数：最长的一层（{@code 剣軌跡_歪み}）收尾于第 108.5 帧。
     */
    public static final int TOTAL_FRAMES = 109;
    
    public static final int TOTAL_TICKS = framesToTicks(TOTAL_FRAMES);
    
    public static final int LAYER_SLASH_BLACK = 0;
    public static final int LAYER_SLASH = 1;
    public static final int LAYER_HIT_LIGHT = 2;
    public static final int LAYER_HIT_RING = 3;
    public static final int LAYER_SLASH_TRAIL2 = 4;
    public static final int LAYER_HIT_GLOW = 5;
    public static final int LAYER_CHROMA = 6;
    public static final int LAYER_DISTORTION_START = 7;
    public static final int LAYER_MUL_GLOW = 8;
    public static final int LAYER_BLUR0 = 9;
    public static final int LAYER_CAMERA_SHAKE = 10;
    public static final int LAYER_DISTORTION = 11;
    public static final int LAYER_RING = 12;
    public static final int LAYER_REMAIN_RIBBON = 13;
    public static final int LAYER_BLUR = 14;
    public static final int LAYER_SLASH_DISTORTION = 15;
    
    public static final int TICK_OPENING = framesToTicks(0);
    public static final int TICK_HIT = framesToTicks(3);
    public static final int TICK_CHROMA_AND_DISTORTION_START = framesToTicks(5);
    public static final int TICK_MUL_GLOW = framesToTicks(12);
    public static final int TICK_BLUR0 = framesToTicks(18);
    public static final int TICK_CAMERA_SHAKE_ONWARDS = framesToTicks(23);
    public static final int TICK_REMAIN_RIBBON_AND_BLUR = framesToTicks(30);
    public static final int TICK_SLASH_DISTORTION = framesToTicks(38);
    
    private DimensionSlashNormalTimeline() {
    }
    
    /**
     * 播放一次完整演出；重复调用会重新计时（不叠加）。
     */
    public static void play(ClientLevel level, Vec3 target) {
        INSTANCE.start(level, target);
    }
    
    /**
     * 每个客户端 tick 推进一步演出。
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        INSTANCE.tick(Minecraft.getInstance().level);
    }
    
    @Override
    public int totalTicks() {
        return TOTAL_TICKS;
    }
    
    @Override
    protected void tickLayers(ClientLevel level, int elapsed) {
        // 起手瞬间：黑色弧形刀光、白色弧细线、命中补光
        if (this.shouldFire(LAYER_SLASH_BLACK, TICK_OPENING, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_SLASH_BLACK);
        }
        if (this.shouldFire(LAYER_SLASH, TICK_OPENING, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_SLASH);
        }
        if (this.shouldFire(LAYER_HIT_LIGHT, TICK_OPENING, elapsed)) {
            this.spawn(level, this.origin, EfxSlashNoDrawPresets.NORMAL_HIT_LIGHT);
        }
//        // 命中反馈三件套
        if (this.shouldFire(LAYER_HIT_RING, TICK_HIT, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_HIT_RING);
        }
        if (this.shouldFire(LAYER_SLASH_TRAIL2, TICK_HIT, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_SLASH_TRAIL2);
        }
        if (this.shouldFire(LAYER_HIT_GLOW, TICK_HIT, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_HIT_GLOW);
        }
//        // 屏幕空间调色球与一瞬间的折射球
        if (this.shouldFire(LAYER_CHROMA, TICK_CHROMA_AND_DISTORTION_START, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.NORMAL_CHROMA);
        }
        if (this.shouldFire(LAYER_DISTORTION_START, TICK_CHROMA_AND_DISTORTION_START, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.PERFECT_DISTORTION_START);
        }
        // 分色光晕与暗蓝圆形面片
        if (this.shouldFire(LAYER_MUL_GLOW, TICK_MUL_GLOW, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_MUL_GLOW);
        }
        if (this.shouldFire(LAYER_BLUR0, TICK_BLUR0, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_BLUR0);
        }
//        // 收束段同刻四层
        if (this.shouldFire(LAYER_CAMERA_SHAKE, TICK_CAMERA_SHAKE_ONWARDS, elapsed)) {
            this.spawn(level, this.origin, EfxSlashNoDrawPresets.NORMAL_CAMERA_SHAKE);
        }
        if (this.shouldFire(LAYER_DISTORTION, TICK_CAMERA_SHAKE_ONWARDS, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.PERFECT_DISTORTION);
        }
        if (this.shouldFire(LAYER_RING, TICK_CAMERA_SHAKE_ONWARDS, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_RING);
        }
        if (this.shouldFire(LAYER_REMAIN_RIBBON, TICK_REMAIN_RIBBON_AND_BLUR, elapsed)) {
            this.spawn(level, this.origin, EfxSlashRibbonPresets.NORMAL_REMAIN_RIBBON);
        }
        if (this.shouldFire(LAYER_BLUR, TICK_REMAIN_RIBBON_AND_BLUR, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_BLUR);
        }
//        // 收尾的弧细线折射
        if (this.shouldFire(LAYER_SLASH_DISTORTION, TICK_SLASH_DISTORTION, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.NORMAL_SLASH_DISTORTION);
        }
    }
}
