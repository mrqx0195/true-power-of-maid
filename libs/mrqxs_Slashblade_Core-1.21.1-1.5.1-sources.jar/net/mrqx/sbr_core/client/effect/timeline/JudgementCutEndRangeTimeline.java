package net.mrqx.sbr_core.client.effect.timeline;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxPolygonView;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.attack.EfxJceGlowPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range.EfxJceRangeMeshPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range.EfxJceRangeNoDrawPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range.EfxJceRangePolygonPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcutend.range.EfxJceRangeRibbonPresets;
import net.mrqx.sbr_core.client.effect.post.GlowPostEffect;
import net.mrqx.sbr_core.client.effect.post.GlowPresets;
import net.mrqx.sbr_core.client.effect.util.BoneOffset;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * 「次元斩·絶」范围效果的演出时间轴。
 * <p>
 * 全部层的触发与先后顺序都集中在本类，与 EFX 各 Entry 的 {@code SpawnFrame} 逐条对照。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class JudgementCutEndRangeTimeline extends EfxTimeline {
    /**
     * 单例：本类持有"本次演出"的运行态。
     */
    public static final JudgementCutEndRangeTimeline INSTANCE = new JudgementCutEndRangeTimeline();
    
    /**
     * 演出总帧数（实测 130 帧 / 2 秒）；带 {@code Life.Flags} 第 0 位的层都以该时刻收尾。
     */
    public static final int TOTAL_FRAMES = 130;
    
    /**
     * 演出总 tick 数。
     */
    public static final int TOTAL_TICKS = framesToTicks(TOTAL_FRAMES);
    
    public static final int LAYER_CAMERA_SHAKE = 0;
    public static final int LAYER_RADIAL_BLUR = 1;
    public static final int LAYER_RADIAL_BLUR_LOCAL = 2;
    public static final int LAYER_GROUND_CONVERGE_FIRE = 3;
    public static final int LAYER_WARP_BUBBLE = 4;
    public static final int LAYER_BODY_ADD_GLOW = 5;
    public static final int LAYER_RANGE_CONVERGE_FIRE_DENSE = 6;
    public static final int LAYER_RANGE_CONVERGE_FIRE_FLOW = 7;
    public static final int LAYER_DOME = 8;
    public static final int LAYER_MONOCHROME = 9;
    public static final int LAYER_INVERSE_IMPACT = 10;
    public static final int LAYER_DOME_OUTER = 11;
    public static final int LAYER_CHEST_RISING_FLAME = 12;
    public static final int LAYER_OPENING_GPU_SMOKE = 13;
    public static final int LAYER_RANGE_CONVERGE_BURST = 14;
    public static final int LAYER_OPENING_GPU_SMOKE_WATER = 15;
    public static final int LAYER_RANGE_RIBBON = 16;
    public static final int LAYER_SHIELD = 17;
    public static final int LAYER_OPENING_BLUE = 18;
    public static final int LAYER_CONVERGING_AURA = 19;
    public static final int LAYER_CRYSTAL_DUST = 20;
    public static final int LAYER_LIGHT_SCRIPT = 21;
    public static final int LAYER_GROUND_DECAL = 22;
    
    public static final int TICK_CAMERA_SHAKE = framesToTicks(5);
    public static final int TICK_RADIAL_BLUR = 0;
    public static final int TICK_RADIAL_BLUR_LOCAL = framesToTicks(30);
    public static final int TICK_GROUND_CONVERGE_FIRE = framesToTicks(5);
    public static final int TICK_WARP_BUBBLE = framesToTicks(60);
    public static final int TICK_BODY_ADD_GLOW = framesToTicks(0);
    public static final int TICK_RANGE_CONVERGE_FIRE = framesToTicks(40);
    public static final int TICK_DOME = framesToTicks(0);
    public static final int TICK_MONOCHROME = framesToTicks(1);
    public static final int TICK_INVERSE_IMPACT = framesToTicks(5);
    public static final int TICK_CHEST_RISING_FLAME = framesToTicks(40);
    public static final int TICK_OPENING_GPU_SMOKE = framesToTicks(1);
    public static final int TICK_RANGE_CONVERGE_BURST = framesToTicks(0);
    public static final int TICK_OPENING_GPU_SMOKE_WATER = framesToTicks(0);
    public static final int TICK_RANGE_RIBBON = framesToTicks(35);
    public static final int TICK_SHIELD = framesToTicks(0);
    public static final int TICK_OPENING_BLUE = framesToTicks(0);
    public static final int TICK_CONVERGING_AURA = framesToTicks(30);
    public static final int TICK_CRYSTAL_DUST = framesToTicks(0);
    public static final int TICK_LIGHT_SCRIPT = framesToTicks(0);
    public static final int TICK_GROUND_DECAL = framesToTicks(10);
    
    /**
     * {@code 範囲　GPU} 的重复生成间隔（tick）。
     * <p>
     * EFX 这一层是"不限循环 + 每帧一批"，照字面做会每 tick 生成 3 条、远超单条飘带的轨迹容量，
     * 只是不断互相挤掉。取 3 tick 一批时稳态同时存在约 9 条。
     */
    public static final int RANGE_RIBBON_INTERVAL_TICKS = 3;
    
    private JudgementCutEndRangeTimeline() {
    }
    
    /**
     * 播放一次完整的范围效果演出；重复调用会重新计时（不叠加）。
     *
     * @param level  客户端世界
     * @param origin 演出原点（施法者位置，等同命中点）
     */
    public static void play(ClientLevel level, Vec3 origin) {
        INSTANCE.start(level, origin);
    }
    
    /**
     * 每个客户端 tick 推进一步演出。
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        INSTANCE.tick(Minecraft.getInstance().level);
    }
    
    /**
     * 本场演出把"半径 10 格的效果范围"整体放大到 30 格口径，故各层的范围 / 速度 / 尺寸都乘
     * {@link EfxPolygonView#SIZE_SCALE}。
     */
    @Override
    public float effectRangeScale() {
        return EfxPolygonView.SIZE_SCALE;
    }
    
    @Override
    public int totalTicks() {
        return TOTAL_TICKS;
    }
    
    @Override
    protected void tickLayers(ClientLevel level, int elapsed) {
        this.tickCameraShake(level, elapsed);
        this.tickRadialBlur(level, elapsed);
        this.tickRadialBlurLocal(level, elapsed);
        this.tickBodyAddGlow(level, elapsed);
        this.tickGroundConvergeFire(level, elapsed);
        this.tickRangeConvergeFire(level, elapsed);
        this.tickWarpBubble(level, elapsed);
        this.tickDome(level, elapsed);
        this.tickMonochrome(level, elapsed);
        this.tickInverseImpact(level, elapsed);
        this.tickOpeningGpuSmoke(level, elapsed);
        this.tickChestRisingFlame(level, elapsed);
        this.tickOpeningGpuSmokeWater(level, elapsed);
        this.tickRangeConvergeBurst(level, elapsed);
        this.tickRangeRibbon(level, elapsed);
        this.tickShield(level, elapsed);
        this.tickOpeningBlue(level, elapsed);
        this.tickConvergingAura(level, elapsed);
        this.tickCrystalDust(level, elapsed);
        // TODO: 观感不大行，考虑后续调整或移除
//        this.tickLightScript(level, elapsed);
//        this.tickGroundDecal(level, elapsed);
    }
    
    @Override
    protected void onFinished(ClientLevel level) {
        // TODO: test，未来在触发侧控制
//        JudgementCutEndTimeline.play(level, this.origin);
    }
    
    /**
     * カメラシェイク小：起手时的一次轻微镜头晃动（{@code Flags = 1}，保持到演出收尾）。
     */
    public void tickCameraShake(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_CAMERA_SHAKE, TICK_CAMERA_SHAKE, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeNoDrawPresets.CAMERA_SHAKE,
            TOTAL_TICKS - TICK_CAMERA_SHAKE);
    }
    
    /**
     * radial_blur：开场的一记强径向模糊。
     */
    public void tickRadialBlur(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_RADIAL_BLUR, TICK_RADIAL_BLUR, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeNoDrawPresets.RADIAL_BLUR);
    }
    
    /**
     * radial_blur0：收束阶段的局部淡模糊，并伴随全屏压暗。
     * <p>
     * 压暗不在 EFX 属性表里（是脚本作用于画面的附带效果），故由
     * {@link GlowPresets#RADIAL_BLUR_DARKEN} 承担——那是"铺满画面的压暗光斑"。
     */
    public void tickRadialBlurLocal(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_RADIAL_BLUR_LOCAL, TICK_RADIAL_BLUR_LOCAL, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeNoDrawPresets.RADIAL_BLUR_LOCAL,
            TOTAL_TICKS - TICK_RADIAL_BLUR_LOCAL);
        GlowPostEffect.trigger(this.origin, GlowPresets.RADIAL_BLUR_DARKEN);
    }
    
    /**
     * 体 Add グロー：起手时从腰部炸开的过曝蓝光。
     * <p>
     * 本项目改用屏幕空间辉光表现——它本质是"全身发光"这类全屏效果，用面片做会被视角拉伸。
     */
    public void tickBodyAddGlow(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_BODY_ADD_GLOW, TICK_BODY_ADD_GLOW, elapsed)) {
            return;
        }
        this.spawn(level, this.origin.add(BoneOffset.WAIST), EfxJceGlowPresets.BODY_ADD_GLOW,
            TOTAL_TICKS - TICK_BODY_ADD_GLOW);
    }
    
    /**
     * 地面　収束　炎：地面窜起的一簇深紫灰色细长火舌。
     */
    public void tickGroundConvergeFire(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_GROUND_CONVERGE_FIRE, TICK_GROUND_CONVERGE_FIRE, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangePolygonPresets.GROUND_CONVERGE_FIRE);
    }
    
    /**
     * 範囲　収束　炎1 / 炎2：主力收束火粒，两层同刻触发，差异只在数量与贴图播放方式。
     */
    public void tickRangeConvergeFire(ClientLevel level, int elapsed) {
        if (this.shouldFire(LAYER_RANGE_CONVERGE_FIRE_DENSE, TICK_RANGE_CONVERGE_FIRE, elapsed)) {
            this.spawn(level, this.origin, EfxJceRangePolygonPresets.RANGE_CONVERGE_FIRE_DENSE);
        }
        if (this.shouldFire(LAYER_RANGE_CONVERGE_FIRE_FLOW, TICK_RANGE_CONVERGE_FIRE, elapsed)) {
            this.spawn(level, this.origin, EfxJceRangePolygonPresets.RANGE_CONVERGE_FIRE_FLOW);
        }
    }
    
    /**
     * 歪み_head2：角色脚底向上持续升腾的黑 / 深蓝火焰。
     * <p>
     * <b>位置以实测为准</b>：EFX 绑的是 {@code Waist} 骨，而实测它起于脚底，
     * 故直接用演出原点、不叠加骨骼偏移。
     */
    public void tickWarpBubble(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_WARP_BUBBLE, TICK_WARP_BUBBLE, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangePolygonPresets.WARP_BUBBLE);
    }
    
    /**
     * ドーム / ドーム0：罩住角色的双层扁平深蓝球壳，两层同时在演出开始胀起。
     */
    public void tickDome(ClientLevel level, int elapsed) {
        if (this.shouldFire(LAYER_DOME, TICK_DOME, elapsed)) {
            this.spawn(level, this.origin, EfxJceRangeMeshPresets.DOME);
        }
        if (this.shouldFire(LAYER_DOME_OUTER, TICK_DOME, elapsed)) {
            this.spawn(level, this.origin, EfxJceRangeMeshPresets.DOME_OUTER);
        }
    }
    
    /**
     * 白黒：扩大至效果范围的透明球，带凸透镜折射与"越靠近球心掉色越多"的黑白滤镜。
     * <p>
     * 三者全部由 {@code MONOCHROME} 那一个 {@code EfxConfig} 表达：球体本体顶点色 alpha 为 0，
     * 可见性来自两条屏幕空间遮罩。滤镜的球心 / 半径 / 生命期就是该层粒子自己的曲线，不会错位。
     */
    public void tickMonochrome(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_MONOCHROME, TICK_MONOCHROME, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeMeshPresets.MONOCHROME);
    }
    
    /**
     * インバース0：不可见椭球壳，只在与场景物体相交的那一圈烧起蓝色火焰。
     */
    public void tickInverseImpact(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_INVERSE_IMPACT, TICK_INVERSE_IMPACT, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeMeshPresets.INVERSE_IMPACT);
    }
    
    /**
     * 開始 GPU煙：快速扩散并减淡消失的蓝黑色烟雾。
     * <p>
     * EFX 这一层是 GPU 实例化 billboard，本项目在摊平阶段折算成等价的 Billboard3D，
     * 沿用与面片层相同的渲染路径（真正的 GPU 实例化绘制属性能优化，暂不实现）。
     */
    public void tickOpeningGpuSmoke(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_OPENING_GPU_SMOKE, TICK_OPENING_GPU_SMOKE, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangePolygonPresets.OPENING_GPU_SMOKE);
    }
    
    /**
     * GPU　胸　上昇青炎：胸口窜起的一排暗蓝到近黑的细长火苗。
     * <p>
     * 该层<b>没有骨骼绑定</b>，"胸口"的高度完全由 {@code LocalPosition} 给出，故不叠加骨骼偏移。
     */
    public void tickChestRisingFlame(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_CHEST_RISING_FLAME, TICK_CHEST_RISING_FLAME, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangePolygonPresets.CHEST_RISING_FLAME);
    }
    
    /**
     * 開始 GPU煙0：扩散后迅速减淡消失的大量蓝色水纹粒子。
     */
    public void tickOpeningGpuSmokeWater(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_OPENING_GPU_SMOKE_WATER, TICK_OPENING_GPU_SMOKE_WATER, elapsed)) {
            return;
        }
        this.spawn(level, this.origin.add(BoneOffset.CHEST),
            EfxJceRangePolygonPresets.OPENING_GPU_SMOKE_WATER);
    }
    
    /**
     * 範囲　収束　炎：快速扩大的一圈蓝色火焰 / 烟雾，先后生成两批。
     * <p>
     * 名字里的"収束"不描述它的运动——实测<b>并没有</b>收束效果。
     */
    public void tickRangeConvergeBurst(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_RANGE_CONVERGE_BURST, TICK_RANGE_CONVERGE_BURST, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangePolygonPresets.RANGE_CONVERGE_BURST);
    }
    
    /**
     * 範囲　GPU：在效果范围边缘出现、逆时针螺旋向角色收拢的黑 / 蓝黑烟雾飘带。
     * <p>
     * EFX 不限循环，实测"首次生成后在持续时间内不断生成"，故本方法自 {@link #TICK_RANGE_RIBBON}
     * 起每隔 {@link #RANGE_RIBBON_INTERVAL_TICKS} 个 tick 重投一批，不使用一次性的 {@code shouldFire}。
     */
    public void tickRangeRibbon(ClientLevel level, int elapsed) {
        if (elapsed < TICK_RANGE_RIBBON) {
            return;
        }
        if ((elapsed - TICK_RANGE_RIBBON) % RANGE_RIBBON_INTERVAL_TICKS != 0) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeRibbonPresets.RANGE_RIBBON);
    }
    
    /**
     * メッシュ　シールド2：起手瞬间在水平面上出现的一圈扩大的气浪。
     */
    public void tickShield(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_SHIELD, TICK_SHIELD, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeMeshPresets.SHIELD);
    }
    
    /**
     * 開始　青：演出开始时在头顶炸开的亮天蓝畸变球。
     */
    public void tickOpeningBlue(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_OPENING_BLUE, TICK_OPENING_BLUE, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeMeshPresets.OPENING_BLUE);
    }
    
    /**
     * メッシュ　収束オーラ0：套住角色、持续收缩的暗蓝灰光环。
     */
    public void tickConvergingAura(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_CONVERGING_AURA, TICK_CONVERGING_AURA, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeMeshPresets.CONVERGING_AURA);
    }
    
    /**
     * 収束　炎2：角色周围一圈大量螺旋上升的水晶粒子（不是火焰），寿命最长。
     */
    public void tickCrystalDust(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_CRYSTAL_DUST, TICK_CRYSTAL_DUST, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangePolygonPresets.CRYSTAL_DUST);
    }
    
    /**
     * ライト：起手瞬间点亮的一盏 50000 流明蓝白补光（用屏幕空间辉光表现，不做真实光注入）。
     */
    public void tickLightScript(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_LIGHT_SCRIPT, TICK_LIGHT_SCRIPT, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeNoDrawPresets.LIGHT,
            TOTAL_TICKS - TICK_LIGHT_SCRIPT);
    }
    
    /**
     * デカール：烙在地面上的 20×20 巨大圆形印记。落点由预设的 {@code PtCollision} 吸附到地面。
     */
    public void tickGroundDecal(ClientLevel level, int elapsed) {
        if (!this.shouldFire(LAYER_GROUND_DECAL, TICK_GROUND_DECAL, elapsed)) {
            return;
        }
        this.spawn(level, this.origin, EfxJceRangeNoDrawPresets.DECAL,
            TOTAL_TICKS - TICK_GROUND_DECAL);
    }
}
