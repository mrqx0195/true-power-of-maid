package net.mrqx.sbr_core.client.effect.timeline;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.manager.EfxEffectManager;

import javax.annotation.Nullable;

/**
 * EFX 演出时间轴的基类：记录起始游戏刻，每 tick 用
 * {@code elapsed = level.getGameTime() - startGameTime} 与各层的触及时刻比较。
 * <p>
 * 不用"触发时排一批延迟任务"的相对写法：卡顿造成 tick 跳变时相对写法会整层漏掉，
 * 绝对写法只需把判定改成"越过触发时刻且尚未触发过"，缺口会自动补上。
 */
public abstract class EfxTimeline {
    /**
     * 1 tick 对应的 EFX 帧数（EFX 帧率是本项目的 3 倍）。
     */
    public static final int TICK_TO_FRAME = 3;
    
    /**
     * 未处于演出中的哨兵值。
     */
    public static final long NEVER_STARTED = Long.MIN_VALUE;
    
    /**
     * "保持到演出收尾"的层默认铺到的时长（tick），按范围效果的 130 帧标定。
     * 两场演出长度不同（范围 130 帧、「次元斩·絶」169 帧），故时间轴必须逐层传入<b>自己那一段</b>的收尾时刻，
     * 否则较长的演出会提前十几 tick 熄灭。
     */
    public static final float SUSTAINED_KEEP_TICKS = 43.0F;
    
    /**
     * {@code sustainedKeepTicks} 的"未指定"取值：视图回退到 {@link #SUSTAINED_KEEP_TICKS}。
     */
    public static final int USE_DEFAULT_SUSTAINED_KEEP = -1;
    
    /**
     * 本次演出的起始游戏刻；{@link #NEVER_STARTED} 表示当前没有演出。
     */
    public long startGameTime = NEVER_STARTED;
    
    /**
     * 本次演出的原点。
     */
    public Vec3 origin = Vec3.ZERO;
    
    /**
     * 已经触发过的层，每层占一个 bit。
     */
    public long firedLayers;
    
    /**
     * 把 EFX 帧数换算成 tick（四舍五入）；各层的帧数口径集中在此，避免各处各写一次除法。
     */
    public static int framesToTicks(int frames) {
        return (frames * 2 + TICK_TO_FRAME) / (TICK_TO_FRAME * 2);
    }
    
    /**
     * 开始一次演出；重复调用会重新计时（不叠加）。
     */
    public void start(ClientLevel level, Vec3 origin) {
        this.startGameTime = level.getGameTime();
        this.origin = origin;
        this.firedLayers = 0L;
    }
    
    /**
     * 结束本次演出。子类覆盖时须调用 {@code super.stop()}。
     */
    public void stop() {
        this.startGameTime = NEVER_STARTED;
    }
    
    /**
     * 演出总 tick 数，越过即结束。
     */
    public abstract int totalTicks();
    
    /**
     * 分发本 tick 各层的触发。
     */
    protected abstract void tickLayers(ClientLevel level, int elapsed);
    
    /**
     * 演出自然结束时的收尾动作，默认什么都不做。
     */
    protected void onFinished(ClientLevel level) {
    }
    
    /**
     * 推进一步演出；{@code level} 为 null 时结束演出。
     */
    public void tick(@Nullable ClientLevel level) {
        if (level == null) {
            this.stop();
            return;
        }
        if (this.startGameTime == NEVER_STARTED) {
            return;
        }
        long elapsed = level.getGameTime() - this.startGameTime;
        if (elapsed < 0L || elapsed > this.totalTicks()) {
            this.stop();
            this.onFinished(level);
            return;
        }
        this.tickLayers(level, (int) elapsed);
    }
    
    /**
     * 判断某一层本 tick 是否应当触发，并记下"已触发"；越过触发时刻且尚未触发过就补触发。
     *
     * @param layerIndex 层编号，须互不相同且小于 64
     */
    public boolean shouldFire(int layerIndex, int triggerTick, int elapsed) {
        if (elapsed < triggerTick) {
            return false;
        }
        long bit = 1L << layerIndex;
        if ((this.firedLayers & bit) != 0L) {
            return false;
        }
        this.firedLayers = this.firedLayers | bit;
        return true;
    }
    
    /**
     * 本场演出的<b>效果范围倍率</b>：决定各层的范围 / 速度 / 尺寸是否被放大。
     * <p>
     * 默认 {@code 1.0}，即层里的数值就是 EFX 原值。需要把"半径 10 格的效果范围"整体放大到
     * 30 格口径的演出（以角色为中心的那两套）覆写它；以目标位置为中心的局部效果保持默认。
     * 逐层的 {@code EfxAttributeCharacterSpace} 仍可把某一层单独压回 {@code 1.0}。
     */
    public float effectRangeScale() {
        return 1.0F;
    }
    
    /**
     * 触发一层效果，收尾时刻取默认值；效果范围倍率取本场演出的 {@link #effectRangeScale()}。
     */
    protected boolean spawn(ClientLevel level, Vec3 origin, EfxConfig config) {
        return EfxEffectManager.spawn(level, origin, config, USE_DEFAULT_SUSTAINED_KEEP,
            this.effectRangeScale());
    }
    
    /**
     * 触发一层效果，并显式给出本段演出的收尾时刻（从本层触发时刻到本段演出收尾的 tick 数）；
     * 效果范围倍率取本场演出的 {@link #effectRangeScale()}。
     */
    protected boolean spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks) {
        return EfxEffectManager.spawn(level, origin, config, sustainedKeepTicks, this.effectRangeScale());
    }
}
