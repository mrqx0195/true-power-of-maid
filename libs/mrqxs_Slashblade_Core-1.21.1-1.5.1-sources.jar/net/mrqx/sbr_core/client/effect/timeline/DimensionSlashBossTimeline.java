package net.mrqx.sbr_core.client.effect.timeline;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashMeshPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashNoDrawPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashPolygonPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashRibbonPresets;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * 次元斩（小技能）<b>BOSS 变体</b>的演出时间轴。
 * <p>
 * 演出原点是<b>目标位置</b>（命中点），与角色位置无关，故本类<b>不</b>覆写
 * {@link EfxTimeline#effectRangeScale()}——各层按 EFX 原值播放，不做范围型放大。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class DimensionSlashBossTimeline extends EfxTimeline {
    /**
     * 单例：本类持有"本次演出"的运行态。
     */
    public static final DimensionSlashBossTimeline INSTANCE = new DimensionSlashBossTimeline();
    
    /**
     * 演出总帧数：最长的一层（{@code 剣軌跡3}）收尾于第 152.5 帧。
     */
    public static final int TOTAL_FRAMES = 153;
    
    public static final int TOTAL_TICKS = framesToTicks(TOTAL_FRAMES);
    
    public static final int LAYER_EMITTER1 = 0;
    public static final int LAYER_EMITTER6 = 1;
    public static final int LAYER_SLASH_TRAIL5 = 2;
    public static final int LAYER_GLOW = 3;
    public static final int LAYER_GLOW1 = 4;
    public static final int LAYER_CHROMA0 = 5;
    public static final int LAYER_CAMERA_SHAKE = 6;
    public static final int LAYER_MONOCHROME_START = 7;
    public static final int LAYER_MUL_GLOW = 8;
    public static final int LAYER_BLUR0 = 9;
    public static final int LAYER_MONOCHROME = 10;
    public static final int LAYER_FOLLOW0 = 11;
    public static final int LAYER_FOLLOW2 = 12;
    public static final int LAYER_SLASH_TRAIL3 = 13;
    public static final int LAYER_SLASH_TRAIL1 = 14;
    public static final int LAYER_REMAIN_SMOKE = 15;
    
    public static final int TICK_EMITTER1_AND_6 = framesToTicks(0);
    public static final int TICK_GLOW = framesToTicks(3);
    public static final int TICK_CHROMA0 = framesToTicks(5);
    public static final int TICK_CAMERA_SHAKE = framesToTicks(6);
    public static final int TICK_MONOCHROME_START = framesToTicks(9);
    public static final int TICK_MUL_GLOW = framesToTicks(12);
    public static final int TICK_BLUR0 = framesToTicks(18);
    public static final int TICK_MONOCHROME_AND_FOLLOW0 = framesToTicks(20);
    public static final int TICK_FOLLOW2 = framesToTicks(27);
    public static final int TICK_SLASH_TRAIL3 = framesToTicks(30);
    public static final int TICK_SLASH_TRAIL1 = framesToTicks(38);
    public static final int TICK_REMAIN_SMOKE = framesToTicks(45);
    
    private DimensionSlashBossTimeline() {
    }
    
    /**
     * 播放一次完整演出；重复调用会重新计时（不叠加）。
     */
    public static void play(ClientLevel level, Vec3 target) {
        INSTANCE.start(level, target);
    }
    
    /**
     * 每个客户端 tick 推进一步演出。
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        INSTANCE.tick(Minecraft.getInstance().level);
    }
    
    @Override
    public int totalTicks() {
        return TOTAL_TICKS;
    }
    
    @Override
    protected void tickLayers(ClientLevel level, int elapsed) {
        // 目标位置处同时炸开的三层：白弧细线刀光、暗蓝弧刀光、亮蓝弧细线
        if (this.shouldFire(LAYER_EMITTER1, TICK_EMITTER1_AND_6, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_EMITTER1);
        }
        if (this.shouldFire(LAYER_EMITTER6, TICK_EMITTER1_AND_6, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_EMITTER6);
        }
        if (this.shouldFire(LAYER_SLASH_TRAIL5, TICK_EMITTER1_AND_6, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_SLASH_TRAIL5);
        }
        // 起手的两道闪光
        if (this.shouldFire(LAYER_GLOW, TICK_GLOW, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_GLOW);
        }
        if (this.shouldFire(LAYER_GLOW1, TICK_GLOW, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_GLOW1);
        }
        // 屏幕空间调色球与镜头晃动
        if (this.shouldFire(LAYER_CHROMA0, TICK_CHROMA0, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.BOSS_CHROMA0);
        }
        if (this.shouldFire(LAYER_CAMERA_SHAKE, TICK_CAMERA_SHAKE, elapsed)) {
            this.spawn(level, this.origin, EfxSlashNoDrawPresets.BOSS_CAMERA_SHAKE);
        }
        // 一瞬间的折射脉冲
        if (this.shouldFire(LAYER_MONOCHROME_START, TICK_MONOCHROME_START, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.BOSS_MONOCHROME_START);
        }
        // 中心黑、边缘黄的分色光晕
        if (this.shouldFire(LAYER_MUL_GLOW, TICK_MUL_GLOW, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_MUL_GLOW);
        }
        // 一层暗蓝圆形面片
        if (this.shouldFire(LAYER_BLUR0, TICK_BLUR0, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_BLUR0);
        }
        // 折射球与向心收拢的烟雾条带同刻登场
        if (this.shouldFire(LAYER_MONOCHROME, TICK_MONOCHROME_AND_FOLLOW0, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.BOSS_MONOCHROME);
        }
        if (this.shouldFire(LAYER_FOLLOW0, TICK_MONOCHROME_AND_FOLLOW0, elapsed)) {
            this.spawn(level, this.origin, EfxSlashRibbonPresets.BOSS_FOLLOW0);
        }
        // 向心收拢的烟雾面片
        if (this.shouldFire(LAYER_FOLLOW2, TICK_FOLLOW2, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_FOLLOW2);
        }
        // 收尾段的三层：残留刀光、不可见的弧细线折射、向内收拢的烟雾
        if (this.shouldFire(LAYER_SLASH_TRAIL3, TICK_SLASH_TRAIL3, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_SLASH_TRAIL3);
        }
        if (this.shouldFire(LAYER_SLASH_TRAIL1, TICK_SLASH_TRAIL1, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_SLASH_TRAIL1);
        }
        if (this.shouldFire(LAYER_REMAIN_SMOKE, TICK_REMAIN_SMOKE, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.BOSS_REMAIN_SMOKE);
        }
    }
}
