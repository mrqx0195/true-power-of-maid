package net.mrqx.sbr_core.client.effect.timeline;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashMeshPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashNoDrawPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashPolygonPresets;
import net.mrqx.sbr_core.client.effect.efx.preset.judgementcut.EfxSlashRibbonPresets;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * 次元斩（小技能）<b>完美变体</b>的演出时间轴。
 * <p>
 * 演出原点是<b>目标位置</b>，故与 BOSS 变体一样<b>不</b>覆写 {@link EfxTimeline#effectRangeScale()}。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class DimensionSlashPerfectTimeline extends EfxTimeline {
    /**
     * 单例：本类持有"本次演出"的运行态。
     */
    public static final DimensionSlashPerfectTimeline INSTANCE = new DimensionSlashPerfectTimeline();
    
    /**
     * 演出总帧数：最长的一层（{@code 剣軌跡_歪み}）收尾于第 116 帧。
     */
    public static final int TOTAL_FRAMES = 116;
    
    public static final int TOTAL_TICKS = framesToTicks(TOTAL_FRAMES);
    
    public static final int LAYER_SLASH_BLACK = 0;
    public static final int LAYER_SLASH0 = 1;
    public static final int LAYER_HIT_LIGHT = 2;
    public static final int LAYER_HIT_RING = 3;
    public static final int LAYER_SLASH_TRAIL2 = 4;
    public static final int LAYER_HIT_GLOW0 = 5;
    public static final int LAYER_CHROMA = 6;
    public static final int LAYER_DISTORTION_START = 7;
    public static final int LAYER_PARTICLE1 = 8;
    public static final int LAYER_PARTICLE2 = 9;
    public static final int LAYER_MUL_GLOW = 10;
    public static final int LAYER_PARTICLE3 = 11;
    public static final int LAYER_BLUR0 = 12;
    public static final int LAYER_CAMERA_SHAKE = 13;
    public static final int LAYER_DISTORTION = 14;
    public static final int LAYER_RING = 15;
    public static final int LAYER_REMAIN_RIBBON = 16;
    public static final int LAYER_BLUR = 17;
    public static final int LAYER_SLASH_DISTORTION = 18;
    
    public static final int TICK_OPENING = framesToTicks(0);
    public static final int TICK_HIT = framesToTicks(3);
    public static final int TICK_CHROMA_AND_DISTORTION_START = framesToTicks(5);
    public static final int TICK_PARTICLE1_AND_2 = framesToTicks(8);
    public static final int TICK_MUL_GLOW = framesToTicks(12);
    public static final int TICK_PARTICLE3 = framesToTicks(14);
    public static final int TICK_BLUR0 = framesToTicks(18);
    public static final int TICK_CAMERA_SHAKE_ONWARDS = framesToTicks(23);
    public static final int TICK_REMAIN_RIBBON_AND_BLUR = framesToTicks(30);
    public static final int TICK_SLASH_DISTORTION = framesToTicks(45);
    
    private DimensionSlashPerfectTimeline() {
    }
    
    /**
     * 播放一次完整演出；重复调用会重新计时（不叠加）。
     */
    public static void play(ClientLevel level, Vec3 target) {
        INSTANCE.start(level, target);
    }
    
    /**
     * 每个客户端 tick 推进一步演出。
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        INSTANCE.tick(Minecraft.getInstance().level);
    }
    
    @Override
    public int totalTicks() {
        return TOTAL_TICKS;
    }
    
    @Override
    protected void tickLayers(ClientLevel level, int elapsed) {
        // 起手瞬间：黑色弧形刀光、白色弧细线、命中补光
        if (this.shouldFire(LAYER_SLASH_BLACK, TICK_OPENING, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_SLASH_BLACK);
        }
        if (this.shouldFire(LAYER_SLASH0, TICK_OPENING, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_SLASH0);
        }
        if (this.shouldFire(LAYER_HIT_LIGHT, TICK_OPENING, elapsed)) {
            this.spawn(level, this.origin, EfxSlashNoDrawPresets.PERFECT_HIT_LIGHT);
        }
        // 命中反馈三件套：橙色圆环、暗青弧细线、金色辉光
        if (this.shouldFire(LAYER_HIT_RING, TICK_HIT, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_HIT_RING);
        }
        if (this.shouldFire(LAYER_SLASH_TRAIL2, TICK_HIT, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_SLASH_TRAIL2);
        }
        if (this.shouldFire(LAYER_HIT_GLOW0, TICK_HIT, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_HIT_GLOW0);
        }
        // 屏幕空间调色球与一瞬间的折射球
        if (this.shouldFire(LAYER_CHROMA, TICK_CHROMA_AND_DISTORTION_START, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.PERFECT_CHROMA);
        }
        if (this.shouldFire(LAYER_DISTORTION_START, TICK_CHROMA_AND_DISTORTION_START, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.PERFECT_DISTORTION_START);
        }
        // 晶体粒子三批，第一批带 Life.Flags 第 0 位、要保持到收尾
        if (this.shouldFire(LAYER_PARTICLE1, TICK_PARTICLE1_AND_2, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_PARTICLE1,
                TOTAL_TICKS - TICK_PARTICLE1_AND_2);
        }
        if (this.shouldFire(LAYER_PARTICLE2, TICK_PARTICLE1_AND_2, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_PARTICLE2);
        }
        if (this.shouldFire(LAYER_MUL_GLOW, TICK_MUL_GLOW, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_MUL_GLOW);
        }
        if (this.shouldFire(LAYER_PARTICLE3, TICK_PARTICLE3, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_PARTICLE3);
        }
        // 暗蓝圆形面片
        if (this.shouldFire(LAYER_BLUR0, TICK_BLUR0, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_BLUR0);
        }
        // 收束段同刻四层：镜头晃动、折射球、光环、烟雾条带
        if (this.shouldFire(LAYER_CAMERA_SHAKE, TICK_CAMERA_SHAKE_ONWARDS, elapsed)) {
            this.spawn(level, this.origin, EfxSlashNoDrawPresets.PERFECT_CAMERA_SHAKE);
        }
        if (this.shouldFire(LAYER_DISTORTION, TICK_CAMERA_SHAKE_ONWARDS, elapsed)) {
            this.spawn(level, this.origin, EfxSlashMeshPresets.PERFECT_DISTORTION);
        }
        if (this.shouldFire(LAYER_RING, TICK_CAMERA_SHAKE_ONWARDS, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_RING);
        }
        if (this.shouldFire(LAYER_REMAIN_RIBBON, TICK_REMAIN_RIBBON_AND_BLUR, elapsed)) {
            this.spawn(level, this.origin, EfxSlashRibbonPresets.PERFECT_REMAIN_RIBBON);
        }
        // 模糊折射面片
        if (this.shouldFire(LAYER_BLUR, TICK_REMAIN_RIBBON_AND_BLUR, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_BLUR);
        }
        // 收尾的弧细线折射
        if (this.shouldFire(LAYER_SLASH_DISTORTION, TICK_SLASH_DISTORTION, elapsed)) {
            this.spawn(level, this.origin, EfxSlashPolygonPresets.PERFECT_SLASH_DISTORTION);
        }
    }
}
