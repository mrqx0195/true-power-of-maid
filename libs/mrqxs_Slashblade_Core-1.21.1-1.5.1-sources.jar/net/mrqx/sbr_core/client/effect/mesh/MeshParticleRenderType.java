package net.mrqx.sbr_core.client.effect.mesh;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.debris.DebrisShaders;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;

import java.util.HashMap;
import java.util.Map;

/**
 * 网格粒子的半透明渲染类型：以三角形绘制共享几何，顶点格式 {@code PARTICLE}，不写深度、不做阴影。
 * {@link #TRANSLUCENT} 用白色贴图 + 顶点色烘焙发光、普通 alpha 混合（加算会让深色片彻底消失）；
 * {@link #GLASS} / {@link #STONE} 用真实 ALB 贴图，并把 NRM 贴图绑到 {@code Sampler1} 做法线光照。
 * 1.21.1 的 {@link ParticleRenderType#begin} 只需设好状态并返回 {@link BufferBuilder}，提交由粒子
 * 引擎的 {@code buffer.build()} 统一完成，故此处不负责结束/上传。
 * <p>
 * <b>输出约定（预乘 / 非预乘）</b>：本族的片元着色器（{@code mesh_dissolve}、{@code glass_debris}）
 * 输出的是<b>非预乘</b> alpha，与 {@code defaultBlendFunc()} / 各自的 {@code .json} 混合状态自洽。
 * <p>
 * 为什么不像面片族（{@link net.mrqx.sbr_core.client.effect.polygon.PolygonRenderTypes}）那样补预乘开关：
 * <b>这一族在原作里根本没有 alpha 混合</b>——网格材质的通道是延迟 GBuffer（输出四个 {@code SV_TARGET}，
 * 且写入的 {@code SV_TARGET0.w = 0}），透明性是在延迟合成阶段解决的，因此"输出侧是否预乘"在原作那里
 * <b>不成立</b>。本项目没有延迟管线、只能前向仿制，而前向必须自选一套自洽配对——现在三处都自洽
 * （普通混合非预乘、加色 {@code SRC_ALPHA, ONE} 非预乘、{@code defaultBlendFunc} 非预乘），故<b>不再改动</b>。
 */
public enum MeshParticleRenderType implements ParticleRenderType {
    /**
     * われ 网格碎片：白色底图 + 顶点色烘焙发光。
     */
    TRANSLUCENT(MrqxSlashBladeCore.prefix("textures/effect/nullwhite.png"),
        MrqxSlashBladeCore.prefix("textures/effect/nullwhite.png")),
    
    /**
     * 玻璃大碎片：真实 ALB 贴图 + NRM 法线光照。
     */
    GLASS(MrqxSlashBladeCore.prefix("textures/effect/glass_debris.png"),
        MrqxSlashBladeCore.prefix("textures/effect/glass_debris_nrm.png")),
    
    /**
     * 小石碎片：真实 ALBM 贴图 + NRMR 法线光照，与 {@link #GLASS} 共用着色器与渲染状态，只换贴图。
     */
    STONE(MrqxSlashBladeCore.prefix("textures/effect/stone_debris.png"),
        MrqxSlashBladeCore.prefix("textures/effect/stone_debris_nrm.png"));
    
    /**
     * われ 网格的白底贴图，也是溶解层的默认贴图；不复用 {@link #TRANSLUCENT} 的字段——enum 常量先于静态字段初始化，反向引用只会拿到 {@code null}。
     */
    public static final ResourceLocation DEFAULT_TEXTURE =
        MrqxSlashBladeCore.prefix("textures/effect/nullwhite.png");
    
    /**
     * 逐层贴图覆写用的渲染类型缓存：同一张贴图必须复用同一实例，否则粒子引擎会把同一层拆成多批。
     */
    public static final Map<ResourceLocation, ParticleRenderType> OVERRIDES = new HashMap<>();
    
    /**
     * 溶解渲染类型的缓存：按 (层, 批) 隔离。溶解阈值 / 纹波相位 / 亮度是逐粒子写入的 uniform，
     * 而 uniform 只在 draw call 级生效（顶点先累积、{@code end()} 才绘制），混桶会让后写的覆盖先写的。
     */
    public static final Map<Long, ParticleRenderType> DISSOLVE_TYPES = new HashMap<>();
    
    /**
     * 本类型使用的基础贴图（纹理管理器不会自动补 {@code textures/} 前缀与 {@code .png} 后缀）。
     */
    public final ResourceLocation texture;
    
    /**
     * 本类型使用的法线贴图，绑定到着色器的 {@code Sampler1}；随实例走而非全局常量，否则 {@link #STONE} 会顶着玻璃的法线。
     */
    public final ResourceLocation normalTexture;
    
    MeshParticleRenderType(ResourceLocation texture, ResourceLocation normalTexture) {
        this.texture = texture;
        this.normalTexture = normalTexture;
    }
    
    @Override
    public BufferBuilder begin(Tesselator tesselator, TextureManager textureManager) {
        if (this == GLASS || this == STONE) {
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            // 显式复位混合方程：面片粒子的减法刀光会把方程残留为 REVERSE_SUBTRACT，导致本类型被"减"成黑色
            RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
            RenderSystem.defaultBlendFunc();
            // 玻璃碎片是封闭网格且持续翻滚，必须双面渲染，否则转到背面时整片消失
            RenderSystem.disableCull();
            this.applyGlassShader();
            RenderSystem.setShaderTexture(0, this.texture);
        } else {
            applyTranslucentState(this.texture);
        }
        return tesselator.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.PARTICLE);
    }
    
    /**
     * 把当前纹理单元上绑定的贴图设为 REPEAT：网格自身的 UV 铺满 0~1，而本项目的网格片元着色器会把它乘上
     * 材质的平铺参数（{@code VAR_UVscale}、{@code Mask01_Tiling}）或沿 V 轴平移；若是 CLAMP，就只有 UV 落在
     * [0,1] 的一小块显示完整贴图、其余全是边缘像素拉成的条纹。调用前须先用 {@code setShaderTexture(0, …)} 绑图。
     */
    public static void setRepeatWrap() {
        GlStateManager._activeTexture(GL13.GL_TEXTURE0);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_REPEAT);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_REPEAT);
    }
    
    /**
     * 设置"半透明网格"共用的渲染状态（われ 与逐层贴图覆写都走这一套）。
     */
    public static void applyTranslucentState(ResourceLocation texture) {
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        // 显式复位混合方程：面片粒子的减法刀光会把方程残留为 REVERSE_SUBTRACT，导致本类型被"减"成黑色
        RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
        RenderSystem.defaultBlendFunc();
        // 本项目的网格层几乎都是封闭球壳而视点常在壳内，单面渲染时从内侧看到的背面被剔除，整层会"消失"
        RenderSystem.disableCull();
        RenderSystem.setShaderTexture(0, texture);
        // 贴图必须可平铺：本类型的片元着色器会把网格 UV 乘上材质的平铺参数或沿 V 轴平移
        setRepeatWrap();
    }
    
    /**
     * 取一个"使用指定贴图"的半透明网格渲染类型，用于逐层贴图覆写。必须以渲染类型区分贴图：粒子引擎按
     * {@code ParticleRenderType} 分组，同组只认 {@code begin} 设好的那一次绑定，粒子自己换贴图只会互相覆盖。
     */
    public static ParticleRenderType overridden(ResourceLocation texture) {
        return OVERRIDES.computeIfAbsent(texture, OverriddenTranslucent::new);
    }
    
    /**
     * 取某层某一批专用的溶解渲染类型（{@code mesh_dissolve}）；键为何要含批序号见 {@link #DISSOLVE_TYPES}，层标识约定见 {@code EfxMeshView#dissolveLayerKey}。
     */
    public static ParticleRenderType dissolving(int layerKey, int batchIndex, ResourceLocation texture) {
        return DISSOLVE_TYPES.computeIfAbsent(renderKey(layerKey, batchIndex),
            key -> new DissolveTranslucent(texture));
    }
    
    /**
     * 把"层标识 + 批序号"合成可直接用作 {@code Map} 键的 64 位值。
     */
    public static long renderKey(int layerKey, int batchIndex) {
        return ((long) layerKey << 32) | (batchIndex & 0xFFFFFFFFL);
    }
    
    /**
     * 相交发光类型的缓存：同样按 (层, 批) 隔离（uniform 逐批写入，混批会互相覆盖）。
     */
    public static final Map<Long, ParticleRenderType> INTERSECT_TYPES = new HashMap<>();
    
    /**
     * 取某层某一批专用的相交发光渲染类型（{@code mesh_intersect}）：场景深度副本绑到 {@code Sampler1}，
     * 只在"片元深度 ≈ 场景深度"处加算发光。为看到球面穿入地面那一圈而关闭背面剔除与深度写入，
     * 但保留深度测试（被地面挡住的片元不该发光）；参数含义同 {@link #dissolving}。
     */
    public static ParticleRenderType intersecting(int layerKey, int batchIndex, ResourceLocation texture) {
        return INTERSECT_TYPES.computeIfAbsent(renderKey(layerKey, batchIndex),
            key -> new IntersectTranslucent(texture));
    }
    
    /**
     * 相交发光用的渲染类型：加算混合 + 场景深度比较。
     *
     * @param texture 本类型使用的火焰贴图。
     */
    public record IntersectTranslucent(ResourceLocation texture) implements ParticleRenderType {
        
        @Override
        public BufferBuilder begin(Tesselator tesselator, TextureManager textureManager) {
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
            // 加算混合：交线是要"亮起来"的火焰，不是盖住地面的贴片
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            RenderSystem.enableDepthTest();
            // 球壳是封闭网格且视点常在球内，必须双面渲染
            RenderSystem.disableCull();
            ShaderInstance shader = MeshIntersectShaders.shader();
            if (shader != null) {
                RenderSystem.setShader(() -> shader);
            } else {
                // 着色器尚未加载成功时回退到原版粒子着色器：交线不生效，但不会崩溃
                RenderSystem.setShader(GameRenderer::getParticleShader);
            }
            RenderSystem.setShaderTexture(0, this.texture);
            MeshIntersectShaders.bindSceneDepth();
            setRepeatWrap();
            return tesselator.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.PARTICLE);
        }
    }
    
    /**
     * 溶解用的渲染类型：状态与 {@link #TRANSLUCENT} 相同，只把着色器换成 {@code mesh_dissolve}。
     *
     * @param texture 本类型使用的贴图。
     */
    public record DissolveTranslucent(ResourceLocation texture) implements ParticleRenderType {
        
        @Override
        public BufferBuilder begin(Tesselator tesselator, TextureManager textureManager) {
            applyTranslucentState(this.texture);
            ShaderInstance shader = MeshDissolveShaders.shader();
            if (shader != null) {
                RenderSystem.setShader(() -> shader);
            } else {
                // 着色器尚未加载成功时回退到原版粒子着色器：溶解不生效，但不会崩溃
                RenderSystem.setShader(GameRenderer::getParticleShader);
            }
            return tesselator.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.PARTICLE);
        }
    }
    
    /**
     * 逐层贴图覆写用的渲染类型：状态与 {@link #TRANSLUCENT} 完全一致，只是把贴图换成该层指定的那一张。
     *
     * @param texture 本类型使用的贴图。
     */
    public record OverriddenTranslucent(ResourceLocation texture) implements ParticleRenderType {
        
        @Override
        public BufferBuilder begin(Tesselator tesselator, TextureManager textureManager) {
            applyTranslucentState(this.texture);
            return tesselator.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.PARTICLE);
        }
    }
    
    /**
     * 绑定玻璃碎片的 ALB/NRM 双贴图着色器；着色器未加载成功时回退原版粒子着色器（丢失法线光照但不崩溃）。
     */
    public void applyGlassShader() {
        ShaderInstance shader = DebrisShaders.shader();
        if (shader == null) {
            RenderSystem.setShader(GameRenderer::getParticleShader);
            return;
        }
        // 这里的着色器实例是全局共享缓存，绝不能用 try-with-resources 持有（close 会删除 GL program）
        RenderSystem.setShader(() -> shader);
        RenderSystem.setShaderTexture(1, this.normalTexture);
    }
}
