package net.mrqx.sbr_core.client.effect.mesh;

import mods.flammpfeil.slashblade.client.renderer.model.obj.*;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * 由 SlashBlade 自带的 {@link WavefrontObject} 解析结果"展开"后、可直接逐三角形消费的网格数据。
 * <p>
 * 之所以再做一次展开：粒子渲染需要在 CPU 侧逐面读取"顶点坐标 / 面法线 / 纹理坐标"自行算 Fresnel 与遮罩方向，
 * 而 WavefrontObject 自带的渲染路径（{@link GroupObject#render}）面向"实体"格式的 VertexConsumer，无法直接复用。
 */
public record ObjMesh(List<ObjMesh.Triangle> triangles) {
    /**
     * 单个三角形图元：局部空间下三个顶点坐标、单位面法线与逐顶点纹理坐标。
     *
     * @param p0     三角形第一个顶点（局部坐标）
     * @param p1     三角形第二个顶点（局部坐标）
     * @param p2     三角形第三个顶点（局部坐标）
     * @param normal 该面的单位法线（已归一化，供 Fresnel/畸变方向计算）
     * @param u0     p0 的 U 纹理坐标
     * @param v0     p0 的 V 纹理坐标
     * @param u1     p1 的 U 纹理坐标
     * @param v1     p1 的 V 纹理坐标
     * @param u2     p2 的 U 纹理坐标
     * @param v2     p2 的 V 纹理坐标
     */
    public record Triangle(
        Vector3f p0,
        Vector3f p1,
        Vector3f p2,
        Vector3f normal,
        float u0, float v0,
        float u1, float v1,
        float u2, float v2
    ) {
    }
    
    /**
     * 把 WavefrontObject 的全部组与面展开为三角形列表（保持 obj 原始局部坐标，不做任何变换）。
     * 三角面直接取用；四边形面按 (0,1,2)(0,2,3) 拆成两个三角形。
     *
     * @param wavefront 已解析的 OBJ 模型
     * @return 展开后的网格
     */
    public static ObjMesh fromWavefront(WavefrontObject wavefront) {
        List<Triangle> triangles = new ArrayList<>();
        for (GroupObject group : wavefront.groupObjects) {
            for (Face face : group.faces) {
                if (face.vertices.length < 3) {
                    continue;
                }
                if (face.vertices.length == 3) {
                    triangles.add(toTriangle(face, 0, 1, 2));
                } else {
                    triangles.add(toTriangle(face, 0, 1, 2));
                    triangles.add(toTriangle(face, 0, 2, 3));
                }
            }
        }
        return new ObjMesh(List.copyOf(triangles));
    }
    
    /**
     * 抽取面上三个指定顶点构成一个三角形，法线优先使用解析器算好的面法线，
     * 纹理坐标优先使用面上逐顶点 UV，缺失时回退为全幅采样的三角形默认 UV。
     */
    public static Triangle toTriangle(Face face, int i0, int i1, int i2) {
        Vector3f p0 = toVector3f(face.vertices[i0]);
        Vector3f p1 = toVector3f(face.vertices[i1]);
        Vector3f p2 = toVector3f(face.vertices[i2]);
        Vector3f normal;
        if (face.faceNormal != null) {
            normal = toVector3f(face.faceNormal).normalize();
        } else {
            normal = new Vector3f(p1).sub(p0).cross(new Vector3f(p2).sub(p0)).normalize();
        }
        TextureCoordinate[] tcs = face.textureCoordinates;
        float[] u = new float[3];
        float[] v = new float[3];
        int[] idx = {i0, i1, i2};
        for (int i = 0; i < 3; i++) {
            if (tcs != null && idx[i] < tcs.length) {
                u[i] = tcs[idx[i]].u;
                v[i] = tcs[idx[i]].v;
            } else {
                // 无 UV 时给三角形默认全幅采样坐标，避免纹理坐标越界
                u[i] = i == 0 ? 0.0F : i == 1 ? 1.0F : 0.0F;
                v[i] = i == 0 ? 0.0F : i == 1 ? 0.0F : 1.0F;
            }
        }
        return new Triangle(p0, p1, p2, normal, u[0], v[0], u[1], v[1], u[2], v[2]);
    }
    
    public static Vector3f toVector3f(Vertex vertex) {
        return new Vector3f(vertex.x, vertex.y, vertex.z);
    }
    
    /**
     * 归一化网格：把几何中心平移到原点，并把最大包围盒跨度缩放到 1，
     * 使不同来源的 OBJ（不同导出尺度）能被同一套特效配置的 scale 语义驱动。
     *
     * @return 归一化后的新网格（原始网格保持不变）
     */
    public ObjMesh normalizedToUnit() {
        if (this.triangles.isEmpty()) {
            return this;
        }
        Vector3f min = new Vector3f(Float.MAX_VALUE);
        Vector3f max = new Vector3f(Float.MIN_VALUE);
        for (Triangle triangle : this.triangles) {
            embrace(min, max, triangle.p0());
            embrace(min, max, triangle.p1());
            embrace(min, max, triangle.p2());
        }
        Vector3f center = new Vector3f(min).add(max).mul(0.5F);
        float extent = Math.max(max.x - min.x, Math.max(max.y - min.y, max.z - min.z));
        float scale = extent > 1.0E-4F ? 1.0F / extent : 1.0F;
        List<Triangle> normalized = new ArrayList<>(this.triangles.size());
        for (Triangle triangle : this.triangles) {
            normalized.add(new Triangle(
                move(triangle.p0(), center, scale),
                move(triangle.p1(), center, scale),
                move(triangle.p2(), center, scale),
                triangle.normal(),
                triangle.u0(), triangle.v0(),
                triangle.u1(), triangle.v1(),
                triangle.u2(), triangle.v2()));
        }
        return new ObjMesh(List.copyOf(normalized));
    }
    
    /**
     * 把 bbox 的角点纳入范围（内部辅助）
     */
    public static void embrace(Vector3f min, Vector3f max, Vector3f p) {
        min.x = Math.min(min.x, p.x);
        min.y = Math.min(min.y, p.y);
        min.z = Math.min(min.z, p.z);
        max.x = Math.max(max.x, p.x);
        max.y = Math.max(max.y, p.y);
        max.z = Math.max(max.z, p.z);
    }
    
    /**
     * 顶点先平移再等比缩放（内部辅助）
     */
    public static Vector3f move(Vector3f p, Vector3f center, float scale) {
        return new Vector3f(p).sub(center).mul(scale);
    }
}
