package net.mrqx.sbr_core.client.effect.mesh;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * 网格溶解的自定义着色器（{@code sbr_core:mesh_dissolve}，见 {@code shaders/core/mesh_dissolve.json/vsh/fsh}）。
 * <p>
 * 对应 {@code EFXAttributeMeshClip}：曲线被解读为"溶解进度"，由本 shader 按噪声阈值**裁掉**像素，
 * 得到"轮廓被啃出噪波状缺口 + 缺口边界有烧蚀亮边"，而非整体变淡。
 * <p>
 * 阈值走 uniform、由粒子逐帧写入：粒子顶点格式只有 {@code Position / Color / UV0 / UV2}，没有空闲通道。
 * 由此约束：<b>同一渲染桶（同层 + 同批）只能放同一层同一批的粒子</b>，混批会互相覆盖进度值，
 * 故 {@link MeshParticleRenderType} 为每个需要溶解的层缓存独立渲染类型实例。
 */
@EventBusSubscriber(modid = MrqxSlashBladeCore.MODID, value = Dist.CLIENT)
public final class MeshDissolveShaders {
    /**
     * 着色器资源 id（对应 {@code shaders/core/mesh_dissolve.json}）。
     */
    public static final ResourceLocation MESH_DISSOLVE = MrqxSlashBladeCore.prefix("mesh_dissolve");
    
    /**
     * 编译后的着色器实例；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    public static ShaderInstance dissolveShader;
    
    private MeshDissolveShaders() {
    }
    
    /**
     * 注册着色器（在资源重载时由 NeoForge 调用）。
     */
    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        try {
            event.registerShader(
                new ShaderInstance(event.getResourceProvider(), MESH_DISSOLVE, DefaultVertexFormat.PARTICLE),
                shader -> dissolveShader = shader);
        } catch (IOException e) {
            dissolveShader = null;
            MrqxSlashBladeCore.LOGGER.error("加载网格溶解着色器失败: {}", MESH_DISSOLVE, e);
        }
    }
    
    /**
     * 取得网格溶解着色器实例。
     * <p>
     * <b>调用方不得关闭该实例</b>：它是全局共享缓存（资源重载时由 NeoForge 换新、旧实例由引擎关闭），
     * 调用 {@link ShaderInstance#close()} 会删掉 GL program，使之后所有绘制失效。未加载成功时返回 null。
     */
    @Nullable
    public static ShaderInstance shader() {
        return dissolveShader;
    }
    
    /**
     * 写入当前层的溶解进度（uniform {@code Dissolve}，取值 0~1）。
     * <p>
     * 同一渲染桶（同层 + 同批）的粒子进度相同，"最后一个写入的值"即该批该用的值，无需同步。
     */
    public static void setDissolve(float dissolve) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("Dissolve").set(dissolve);
        }
    }
    
    /**
     * 写入纹波层两路 UV 的 V 轴平移量；两路曲线不同，<b>必须分别写入</b>（只写一路会让"两路异速叠加"退化成单层平推）。
     */
    public static void setRippleUv(float redScroll, float greenScroll) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("RippleUvScroll").set(redScroll, greenScroll);
        }
    }
    
    /**
     * 写入纹波层两路基础 UV 的缩放（<b>先翻转、再平铺</b>）。
     * 它与上面的平移量不在同一坐标系，混用会改变波纹行进方向。
     */
    public static void setRippleUvScale(float redScaleU, float redScaleV, float greenScaleU, float greenScaleV) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("RippleUvScale").set(redScaleU, redScaleV, greenScaleU, greenScaleV);
        }
    }
    
    /**
     * 写入纹波层两路遮罩的幂次。
     */
    public static void setRipplePower(float redPower, float greenPower) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("RipplePower").set(redPower, greenPower);
        }
    }
    
    /**
     * 写入纹波层的颜色两端色（常规 ARGB）。
     * <p>
     * <b>为什么不走顶点色</b>：混合权重 {@code mask} 由贴图与半径遮罩决定、与视角无关，
     * 而顶点色已被 {@code |N·V|} 占用；把插值权重换成菲涅尔即两端色空间分布反向的成因。
     */
    public static void setRippleColor(int colorParam, int colorHigh) {
        ShaderInstance shader = dissolveShader;
        if (shader == null) {
            return;
        }
        shader.safeGetUniform("RippleColorParam").set(
            (colorParam >> 16 & 0xFF) / 255.0F,
            (colorParam >> 8 & 0xFF) / 255.0F,
            (colorParam & 0xFF) / 255.0F,
            (colorParam >>> 24 & 0xFF) / 255.0F);
        shader.safeGetUniform("RippleColorHigh").set(
            (colorHigh >> 16 & 0xFF) / 255.0F,
            (colorHigh >> 8 & 0xFF) / 255.0F,
            (colorHigh & 0xFF) / 255.0F,
            1.0F);
    }
    
    /**
     * 写入纹波层的 {@code EmissiveRate}：着色器会把它<b>平方后乘到颜色上</b>，两层曲线都是从初值衰减到 0，
     * 故它承担"扩大到最大时熄灭"的亮度曲线，不是可选提亮旋钮；量级是个位数、不是 0~1 归一化值。
     */
    public static void setRippleEmissive(float emissiveRate) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("RippleEmissive").set(emissiveRate);
        }
    }
    
    /**
     * 写入半径遮罩的 smoothstep 区间。
     * <p>
     * <b>名为 UVFade 的这一组参数做的其实是球半径遮罩</b>：对本项目"V 即半径"的圆盘，它退化为以半径中点为峰
     * 向内外衰减的环带，<b>这正是"收束感"的来源</b>。
     */
    public static void setRippleUvFade(float low, float high) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("RippleUvFade").set(low, high);
        }
    }
    
    /**
     * 写入菲涅尔归一化的 smoothstep 区间（取值为角度）。
     * <p>
     * 着色器把 {@code N·V} 用这两个值归一化后取 smoothstep，权重是<b>"正对镜头最强、掠射为 0"</b>，
     * 对平面圆盘即"越接近俯视越亮"，符号方向不能反。
     */
    public static void setRippleEdge(float outside, float inside) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("RippleEdge").set(outside, inside);
        }
    }
    
    /**
     * 切换"光环纹波模式"。
     * <p>
     * 开启后片元着色器走 {@code rippleShade()} 独立管线：贴图只取 R / G 两通道当遮罩，
     * 颜色由 {@link #setRippleColor(int, int)} 的两端色插值，亮度由 {@link #setRippleEmissive(float)} 的平方调制。
     */
    public static void setRipple(boolean ripple) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("Ripple").set(ripple ? 1.0F : 0.0F);
        }
    }
    
    /**
     * 切换"贴图充当透明度遮罩"模式：贴图只决定"哪里亮、哪里透"，颜色仍走顶点色，
     * 供覆写了真实颜色贴图的层使用（典型是 {@code インバース0} 的火焰层）。
     * <p>
     * 与 {@link #setRipple(boolean)} <b>互斥</b>：光环材质的贴图是稀疏遮罩图，必须走完整的
     * {@code mix(ColorParam, ColorHigh, mask)} 管线，两者贴图语义不同，不能共用一条分支。
     */
    public static void setMaskAlpha(boolean maskAlpha) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("MaskAlpha").set(maskAlpha ? 1.0F : 0.0F);
        }
    }
    
    /**
     * 写入云层流动的时间（秒，非 tick）；0 表示该层不做云层流动。
     * <p>
     * 供覆写了贴图的球壳层使用：以"三组互质速度采样同一张分形贴图再取均值"近似多层异速异向的 UV 滚动叠加，
     * 见 {@code mesh_dissolve.fsh} 的 {@code cloudMask()}。
     */
    public static void setCloudTime(float cloudTime) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("CloudTime").set(cloudTime);
        }
    }
    
    /**
     * 写入第一路云遮罩（{@code Mask01}）的平铺次数；两层云纹疏密不同，必须逐层写入、不能合成一个常量。
     */
    public static void setCloudTiling(float tilingU, float tilingV) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("CloudTiling").set(tilingU, tilingV);
        }
    }
    
    /**
     * 写入云量归一化的除数（材质参数 {@code Mie_Max}）；小于等于 0 时片元着色器按 1 处理。
     */
    public static void setCloudMieMax(float mieMax) {
        ShaderInstance shader = dissolveShader;
        if (shader != null) {
            shader.safeGetUniform("CloudMieMax").set(mieMax);
        }
    }
    
    /**
     * 写入云块本体的自发光色（常规 ARGB）。
     * <p>
     * <b>本方法必须存在</b>：该颜色若只写在 {@code mesh_dissolve.json} 的默认值里，EFX 数据改了不会生效，
     * 会形成"看似已实现、实际锁死在资源文件"的假实现。
     */
    public static void setCloudEmissive(int argb) {
        ShaderInstance shader = dissolveShader;
        if (shader == null) {
            return;
        }
        shader.safeGetUniform("CloudEmissive").set(
            (argb >> 16 & 0xFF) / 255.0F,
            (argb >> 8 & 0xFF) / 255.0F,
            (argb & 0xFF) / 255.0F,
            1.0F);
    }
}
