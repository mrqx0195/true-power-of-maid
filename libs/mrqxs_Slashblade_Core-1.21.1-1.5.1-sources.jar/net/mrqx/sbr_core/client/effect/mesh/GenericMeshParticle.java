package net.mrqx.sbr_core.client.effect.mesh;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxMeshView;
import net.mrqx.sbr_core.client.effect.efx.EfxPolygonView;
import net.mrqx.sbr_core.client.effect.post.DistortionEffectManager;
import net.mrqx.sbr_core.client.effect.post.DistortionSource;
import net.mrqx.sbr_core.client.effect.util.RefractionDepthScale;
import net.mrqx.sbr_core.client.utils.ParticleUtils;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;

/**
 * 通用网格粒子：把共享的归一化几何按每实例随机的旋转 / 缩放 / 出生延迟画成一片碎片（本体通常透明），
 * 并承担折射、色彩滤镜、逐通道增益三条屏幕空间遮罩的几何输出（见 {@link #buildDistortionQuads}）。
 * 参数取自 {@link EfxMeshView}；外观为三段式生命（Appear / Keep / Vanish）+ Fresnel 掠射提亮 + full-bright。
 */
@SuppressWarnings("DuplicatedCode")
public class GenericMeshParticle extends Particle implements DistortionSource {
    /**
     * 强制全亮光照（lightmap = 15<<20 | 15<<4），使自发光不受环境光影响。
     */
    public static final int FULLBRIGHT_LIGHTMAP = 0xF000F0;
    
    /**
     * 深度还原用的近平面距离（MC 投影矩阵固定为 0.05），远平面取 {@code gameRenderer.getDepthFar()}。
     */
    public static final float NEAR_PLANE = 0.05F;
    
    /**
     * 相交火焰贴图滚动相位的时间基准：每多少个 tick 记 1 个"时间单位"。
     * 只影响滚动快慢，取值按观感标定。
     */
    public static final float INTERSECT_UV_TICKS_PER_TIME_UNIT = 12000.0F;
    
    /**
     * 尺寸标量收缩到 0 之后是否<b>重新涨回初始尺寸</b>（循环收缩），只影响负增量层。
     * 取 {@code false}：开启后两圈之间必然出现"气浪突然爆出"的空档。
     */
    public static final boolean LOOP_SHRINK = false;
    
    /**
     * EFX 帧（60fps）→ tick（20tps）的换算：1 tick = 3 帧。
     * 自转角速度按"度 / 帧"记录，消费时要用它换成"度 / tick"（与面片路径同一口径）。
     */
    public static final float TICK_TO_FRAME = 3.0F;
    
    /**
     * 本层实际使用的归一化三角形列表（按 obj 资源进程内缓存，见 {@link MeshLibrary}），由 {@link EfxMeshView#resource} 决定。
     */
    protected final List<ObjMesh.Triangle> mesh;
    
    /**
     * 该粒子所属的配置视图（构造时已把 EFX 属性摊平成生命 / 缩放 / 畸变等扁平字段）。
     */
    protected final EfxMeshView view;
    
    /**
     * 每实例的随机朝向（われ 为三轴完全随机，杜绝重复朝向）
     */
    protected final Quaternionf rotation = new Quaternionf();
    
    /**
     * 每实例的整体尺寸随机系数（scaleMultiplierBase ± scaleMultiplierVar）
     */
    protected final float scaleMultiplier;
    
    /**
     * 是否参与真实屏幕空间畸变
     */
    protected final boolean distortion;
    
    /**
     * 是否参与<b>材质色彩滤镜</b>遮罩：与 {@link #distortion} 并列的第二条通道，共用同一批四边形与 {@link #lensWeight}。
     */
    protected final boolean colorFilter;
    
    /**
     * 是否参与<b>屏幕空间逐通道增益</b>遮罩（{@code カラコレ}）：滤镜"向目标色收敛"、本通道"逐通道乘性增益"，故可同时存在。
     */
    protected final boolean screenGrading;
    
    /**
     * 当前额外缩放倍率：<b>只承担消散期</b>的指数放大（初始 1，逐 tick 累乘）
     */
    protected float scaleNow = 1.0F;
    
    /**
     * 当前的尺寸标量（格）：出生时等于 {@link #scaleMultiplier}，生命期内逐 tick 累加 {@link #sizeAdd}。
     * <b>增量是绝对尺寸增量、不能当倍率乘</b>，否则"恰好收到 0"的层两 tick 就会缩没。
     */
    protected float sizeScalar;
    
    /**
     * 当前的每 tick 尺寸增量（格），逐 tick 按 {@link EfxMeshView#sizeAddCoefPerTick} 衰减，收敛到
     * {@code 增量 / (1 - 衰减)} 的极限尺寸（球壳"胀起来后稳住"的成因）。
     */
    protected float sizeAdd;
    
    /**
     * 出生延迟（tick），用于把"分批慢出"转化为不同粒子错峰出现
     */
    protected int remainingDelay;
    
    /**
     * 该粒子所属的<b>批序号</b>（同一层内每批不同，0 起），必须参与渲染分桶：材质动画参数在 {@link #render} 里
     * 作为 <b>uniform</b> 写入，而 uniform 只在 draw call 级别生效，混批会让先出生的一批被后一批整个改写。
     */
    protected final int batchIndex;
    
    /**
     * 本实例的自转角速度（<b>度 / EFX 帧</b>）：出生时逐粒子抽
     * {@code 基准 + (随机 − 0.5) × 随机全宽}（见 {@link EfxMeshView#rotationSpeedXVariation}）。
     */
    protected final float spinX;
    protected final float spinY;
    protected final float spinZ;
    
    /**
     * 创建一片网格粒子；{@code rnd} 由发射器传入，保证同一批的种子序列连续（同批朝向 / 尺寸可复现）。
     */
    public GenericMeshParticle(ClientLevel level, double x, double y, double z,
                               EfxMeshView view, RandomSource rnd, int delayTicks, int batchIndex) {
        super(level, x, y, z);
        this.view = view;
        this.mesh = MeshLibrary.triangles(view.resource);
        this.remainingDelay = Math.max(0, delayTicks);
        this.batchIndex = batchIndex;
        // 出生朝向：按该层的 Rotation 基准 ± 幅度/2（EFX 的 Variation 是随机全宽），六个值都为 0 的层朝向恒定
        this.rotation.rotationXYZ(
            view.rotationX + (rnd.nextFloat() - 0.5F) * view.rotationXVariation,
            view.rotationY + (rnd.nextFloat() - 0.5F) * view.rotationYVariation,
            view.rotationZ + (rnd.nextFloat() - 0.5F) * view.rotationZVariation);
        // 自转角速度同样逐粒子抽一次（同一读法：基准 + 随机全宽 ×（随机 − 0.5））
        this.spinX = view.rotationSpeedX + (rnd.nextFloat() - 0.5F) * view.rotationSpeedXVariation;
        this.spinY = view.rotationSpeedY + (rnd.nextFloat() - 0.5F) * view.rotationSpeedYVariation;
        this.spinZ = view.rotationSpeedZ + (rnd.nextFloat() - 0.5F) * view.rotationSpeedZVariation;
        this.scaleMultiplier = view.scaleMultiplierBase
            + (rnd.nextFloat() - 0.5F) * view.scaleMultiplierVar;
        this.distortion = view.enableDistortion;
        this.colorFilter = view.enableColorFilter;
        this.screenGrading = view.enableScreenGrading;
        this.sizeScalar = this.scaleMultiplier;
        this.sizeAdd = view.sizeAddPerTick;
        this.lifetime = view.appearTicks + view.lifeKeepTicks + view.lifeVanishTicks;
        this.hasPhysics = false;
        this.gravity = 0.0F;
    }
    
    /**
     * 逐 tick 推进生命周期：延迟期内不计数、不渲染，之后按 Keep 维持、Vanish 淡出，寿命耗尽移除。
     */
    @Override
    public void tick() {
        if (this.remainingDelay > 0) {
            this.remainingDelay--;
            return;
        }
        this.age++;
        if (this.age > this.lifetime) {
            this.remove();
            return;
        }
        if (this.view.vanishScaleGrowth > 0.0F
            && this.age > this.view.appearTicks + this.view.lifeKeepTicks) {
            this.scaleNow *= 1.0F + this.view.vanishScaleGrowth;
        }
        if (this.view.sizeAddPerTick != 0.0F) {
            // 下限 clamp 到 0：负缩放会让网格翻转（视觉上等同于消失），故在 0 处截断
            this.sizeScalar = Math.max(0.0F, this.sizeScalar + this.sizeAdd);
            this.sizeAdd *= this.view.sizeAddCoefPerTick;
            if (LOOP_SHRINK && this.view.sizeAddPerTick < 0.0F && this.sizeScalar <= 0.0F) {
                this.sizeScalar = this.scaleMultiplier;
                this.sizeAdd = this.view.sizeAddPerTick;
            }
        }
        this.applySpin();
    }
    
    /**
     * 自转：把出生朝向按该层角速度再转一小步。
     * <p>
     * 角速度来自数据里的 {@code EFXAttributeRotateAnim}（与面片路径同一属性、同一口径），单位是<b>度 / EFX 帧</b>，
     * 故这里乘 {@link #TICK_TO_FRAME} 换成"度 / tick"。
     * <p>
     * 直接就地旋转 {@link #rotation}，而不是每帧另算一个四元数：它被顶点、法线、遮罩等十余处直接读取，
     * 逐处改签名不划算。代价是丢失"出生朝向"这个中间量（没有地方需要它）。
     * 单步角很小（`インバース0` 是 `-0.002617994` 弧度/帧 ≈ `0.45°`/tick），故按局部轴连续旋转与按世界轴旋转
     * 的差别不可见；四元数每步都是单位四元数相乘，长度不会明显漂移。
     */
    protected void applySpin() {
        // 用本实例出生时抽定的角速度（逐粒子不同），而不是整层共用一个值
        float stepX = this.spinX;
        float stepY = this.spinY;
        float stepZ = this.spinZ;
        if (stepX == 0.0F && stepY == 0.0F && stepZ == 0.0F) {
            return;
        }
        this.rotation.rotateXYZ(
            (float) Math.toRadians(stepX * TICK_TO_FRAME),
            (float) Math.toRadians(stepY * TICK_TO_FRAME),
            (float) Math.toRadians(stepZ * TICK_TO_FRAME));
    }
    
    /**
     * 当前生命阶段的不透明度：Appear 段线性升起、Keep 段恒为 1、Vanish 段线性归零。
     */
    public float lifeAlpha() {
        int appear = this.view.appearTicks;
        if (this.age < appear) {
            return appear <= 0 ? 1.0F : (float) this.age / (float) appear;
        }
        int keepEnd = appear + this.view.lifeKeepTicks;
        if (this.age <= keepEnd) {
            return 1.0F;
        }
        int vanish = this.view.lifeVanishTicks;
        if (vanish <= 0) {
            return 0.0F;
        }
        return Mth.clamp(1.0F - (this.age - keepEnd) / (float) vanish, 0.0F, 1.0F);
    }
    
    /**
     * 该粒子是否仍应参与<b>折射</b>遮罩绘制；语义是"仍活跃且启用了折射"，<b>不能</b>单独用作"是否还活着"的判据。
     */
    @Override
    public boolean hasDistortion() {
        return this.distortion && !this.removed;
    }
    
    /**
     * 该粒子是否仍应参与<b>材质色彩滤镜</b>遮罩绘制（与 {@link #hasDistortion()} 相互独立）。
     */
    @Override
    public boolean hasColorFilter() {
        return this.colorFilter && !this.removed;
    }
    
    @Override
    public boolean hasScreenGrading() {
        return this.screenGrading && !this.removed;
    }
    
    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        if (this.remainingDelay > 0) {
            return;
        }
        // 相交发光层：声明本帧需要场景深度副本，并把屏幕尺寸 / 近远平面 / 交线宽度与颜色写进 uniform（同桶最后写入者生效）
        if (this.view.intersectGlow) {
            SceneDepthCopy.request();
            MeshIntersectShaders.setScreenSize(SceneDepthCopy.textureWidth(), SceneDepthCopy.textureHeight());
            MeshIntersectShaders.setDepthRange(NEAR_PLANE, Minecraft.getInstance().gameRenderer.getDepthFar());
            MeshIntersectShaders.setGlow(this.view);
            // 火焰贴图的平铺与滚动：不做平铺的话球面 UV 只把火焰画在球壳一小块上，其余采样到透明区被 discard
            MeshIntersectShaders.setGlowUvScale(this.view.intersectUvScaleU, this.view.intersectUvScaleV);
            // 相位 frac(round(UVSpeed × 600) × time)：先乘 600 取整再乘时间取小数；时间基准见 INTERSECT_UV_TICKS_PER_TIME_UNIT
            float intersectTime = this.age / INTERSECT_UV_TICKS_PER_TIME_UNIT;
            float scrollU = Math.round(this.view.intersectUvSpeedU * 600.0F) * intersectTime;
            float scrollV = Math.round(this.view.intersectUvSpeedV * 600.0F) * intersectTime;
            MeshIntersectShaders.setGlowUvScroll(
                scrollU - (float) Math.floor(scrollU),
                scrollV - (float) Math.floor(scrollV));
        }
        // 写入本层材质动画参数（供 mesh_dissolve 使用）：同桶粒子 age 相同，"最后一个写入的值"即该桶该用的值
        if (this.view.meshClip != null || this.view.texture != null) {
            // 两种"贴图当遮罩"的语义互斥：光环材质走完整纹波管线，覆写了真实颜色贴图的层只把贴图当透明度遮罩；云层两者都不进
            MeshDissolveShaders.setRipple(this.view.rippleRings);
            MeshDissolveShaders.setMaskAlpha(!this.view.rippleRings && this.view.texture != null);
            if (this.view.rippleRings) {
                // 光环材质的整套参数：两路相位 / UV 缩放与幂次 / 两端色 / 自发光 / 半径遮罩 / 菲涅尔区间（同桶取值一致）
                MeshDissolveShaders.setRippleUv(
                    this.view.rippleRedAt(this.age), this.view.rippleGreenAt(this.age));
                MeshDissolveShaders.setRippleUvScale(
                    this.view.rippleRedScaleU, this.view.rippleRedScaleV,
                    this.view.rippleGreenScaleU, this.view.rippleGreenScaleV);
                MeshDissolveShaders.setRipplePower(this.view.rippleRedPower, this.view.rippleGreenPower);
                MeshDissolveShaders.setRippleColor(this.view.rippleColorParam, this.view.rippleColorHigh);
                MeshDissolveShaders.setRippleEmissive(this.view.emissiveRateAt(this.age));
                MeshDissolveShaders.setRippleUvFade(this.view.rippleUvFadeLow, this.view.rippleUvFadeHigh);
                MeshDissolveShaders.setRippleEdge(this.view.rippleEdgeOutside, this.view.rippleEdgeInside);
            }
            // 溶解只对"曲线被解读为溶解进度"的层生效（纹波层恒为 0，见 EfxMeshView#dissolveAt）
            MeshDissolveShaders.setDissolve(this.view.rippleRings ? 0.0F : this.view.dissolveAt(this.age));
            // 云层流动只给"云层球壳"层：贴图是 R / G 双通道遮罩，覆写了真实颜色贴图的层不能进该分支（否则火焰纹理被当成密度）。
            // 时间基准必须用 SHADER_TIME_TICKS_PER_UNIT，取"秒"会因 age 是整数 tick 而让两层云完全静止。
            // ⚠ 下面这个额外的 / 3 是**观感标定值**（与 INTERSECT_UV_TICKS_PER_TIME_UNIT 同性质，已由作者确认）：
            //   共享口径是 age/1200，本层实机调成它的 1/3。它不是 FRAMES_PER_TICK 的遗留错误，不要"顺手改对"。
            MeshDissolveShaders.setCloudTime(
                this.view.cloudShell && this.view.texture != null
                    ? this.age / EfxPolygonView.SHADER_TIME_TICKS_PER_UNIT / 3
                    : 0.0F);
            // 云层球壳的按层参数：Mask01_Tiling 是 Mask01 那一路云遮罩的平铺次数，
            // 它配 LoopNum.y + Layer02 方向（平铺/相位/方向是交叉配对的，详见 mesh_dissolve.fsh 的 cloudDensity）。
            // Mie_Max 是云量归一化的除数，见 mesh_dissolve.fsh 的 CloudMieMax 注释。
            if (this.view.cloudShell && this.view.texture != null) {
                MeshDissolveShaders.setCloudTiling(this.view.cloudTilingU, this.view.cloudTilingV);
                MeshDissolveShaders.setCloudMieMax(this.view.cloudMieMax);
                MeshDissolveShaders.setCloudEmissive(this.view.cloudEmissive);
            }
        }
        Vec3 camPos = camera.getPosition();
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - camPos.x);
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - camPos.y);
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - camPos.z);
        
        // 再乘视图的效果范围倍率：预设里的尺寸曲线按"半径 10 格"标定
        float sx = this.view.scaleX * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sy = this.view.scaleY * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sz = this.view.scaleZ * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        
        for (ObjMesh.Triangle triangle : this.mesh) {
            putVertex(buffer, triangle.p0(), triangle.u0(), triangle.v0(), sx, sy, sz, px, py, pz, triangle.normal());
            putVertex(buffer, triangle.p1(), triangle.u1(), triangle.v1(), sx, sy, sz, px, py, pz, triangle.normal());
            putVertex(buffer, triangle.p2(), triangle.u2(), triangle.v2(), sx, sy, sz, px, py, pz, triangle.normal());
        }
    }
    
    /**
     * 把单个局部坐标顶点经"缩放 → 旋转 → 世界位移"后写入粒子缓冲。<b>顶点色承载整片的外观</b>：
     * 本色取自 {@link EfxMeshView#color1} 并按 Fresnel 向 {@link EfxMeshView#color2} 靠拢，形成"暗底 + 亮边"。
     */
    protected void putVertex(VertexConsumer buffer, Vector3f p, float u, float v,
                             float sx, float sy, float sz,
                             float px, float py, float pz, Vector3f normal) {
        Vector3f world = new Vector3f(p).mul(sx, sy, sz).rotate(this.rotation).add(px, py, pz);
        int color;
        if (this.view.intersectGlow) {
            color = this.intersectVertexColor(normal, px, py, pz);
        } else if (this.view.rippleRings) {
            color = this.rippleVertexColor(normal, px, py, pz);
        } else {
            color = this.vertexColor(normal, px, py, pz);
        }
        buffer.addVertex(world.x, world.y, world.z)
            .setColor(color >> 16 & 0xFF, color >> 8 & 0xFF, color & 0xFF, color >>> 24 & 0xFF)
            .setUv(u, v)
            .setLight(FULLBRIGHT_LIGHTMAP);
    }
    
    /**
     * 该面的 {@code |N·V|}：法线与"粒子中心 → 相机"方向的夹角余弦。取绝对值是因为网格层几乎都是封闭壳、
     * 视点时常落在壳内、看到的全是背面；方向按粒子<b>中心</b>取而非逐顶点（{@code PARTICLE} 格式没有法线属性）。
     */
    protected float viewFacing(Vector3f normal, float px, float py, float pz) {
        Vector3f toCamera = new Vector3f(-px, -py, -pz);
        if (toCamera.lengthSquared() <= 1.0E-6F) {
            return 1.0F;
        }
        Vector3f rotatedNormal = new Vector3f(normal).rotate(this.rotation);
        return Math.abs(rotatedNormal.dot(toCamera.normalize()));
    }
    
    /**
     * <b>相交发光层</b>的顶点色：{@code R} 存 {@code |N·V|}（着色器要拿它取两次幂）、{@code A} 存生命期不透明度。
     * <b>不乘 {@code color1} 的 alpha</b>：着色器已乘过 {@code ColorParam.a}（由 Java 侧从 {@code color1} 写入），
     * 两处都乘会变成 alpha 的平方。
     */
    protected int intersectVertexColor(Vector3f normal, float px, float py, float pz) {
        float facing = this.viewFacing(normal, px, py, pz);
        float alpha = this.lifeAlpha() * ParticleUtils.distanceAlpha(px, py, pz, this.view.fadeNearEnd, this.view.fadeNearStart, this.view.fadeFarEnd, this.view.fadeFarStart);
        return (int) (Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F) << 24
            | (int) (Mth.clamp(facing, 0.0F, 1.0F) * 255.0F) << 16;
    }
    
    /**
     * <b>光环纹波层</b>的顶点色：{@code R} 存 {@code |N·V|}（片元着色器拿它过
     * {@code smoothstep(EdgeSmoothing_OutsideAngle, InsideAngle, N·V)}）、{@code A} 存生命期不透明度。
     * 颜色<b>不由顶点色承载</b>：两端色是 {@code mix(ColorParam, ColorHigh, mask)}，{@code mask} 只由贴图与
     * 半径遮罩决定、与视角无关，用顶点色当混合结果等于把权重偷换成菲涅尔（"两端色空间分布相反"的成因）。
     */
    protected int rippleVertexColor(Vector3f normal, float px, float py, float pz) {
        float facing = this.viewFacing(normal, px, py, pz);
        float alpha = this.lifeAlpha() * ParticleUtils.distanceAlpha(px, py, pz, this.view.fadeNearEnd, this.view.fadeNearStart, this.view.fadeFarEnd, this.view.fadeFarStart);
        return (int) (Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F) << 24
            | (int) (Mth.clamp(facing, 0.0F, 1.0F) * 255.0F) << 16;
    }
    
    /**
     * 计算某个面的顶点色（ARGB 打包）：主体色 {@code color1} 按 Fresnel 向边缘色 {@code color2} 靠拢。
     */
    protected int vertexColor(Vector3f normal, float px, float py, float pz) {
        float facing = this.viewFacing(normal, px, py, pz);
        // Fresnel：材质侧是 pow(|N·V|, FresnelPower)，**正对相机的球心最亮、掠射的边缘最暗**（09 §4.5）。
        // 它与"边缘亮"的那套直觉相反，但两者不是镜像关系：幂曲线让权重只在圆心附近接近 1、随后迅速掉下去
        //（p = 5 时 N·V = 0.8 已只剩约 0.33），所以边缘不是"稍暗"而是基本归 0、整层收缩成一个亮核。
        float fresnel = (float) Math.pow(Math.min(facing, 1.0F), this.view.fresnelPower);
        
        float baseR = (this.view.color1 >> 16 & 0xFF) / 255.0F;
        float baseG = (this.view.color1 >> 8 & 0xFF) / 255.0F;
        float baseB = (this.view.color1 & 0xFF) / 255.0F;
        float edgeR = (this.view.color2 >> 16 & 0xFF) / 255.0F;
        float edgeG = (this.view.color2 >> 8 & 0xFF) / 255.0F;
        float edgeB = (this.view.color2 & 0xFF) / 255.0F;
        
        float red = Mth.clamp(baseR + (edgeR - baseR) * fresnel, 0.0F, 1.0F);
        float green = Mth.clamp(baseG + (edgeG - baseG) * fresnel, 0.0F, 1.0F);
        float blue = Mth.clamp(baseB + (edgeB - baseB) * fresnel, 0.0F, 1.0F);
        // 屏空间载体（カラコレ 的调色球、白黒 / 歪み 一族的折射球）例外：它们的可见性全部来自屏幕空间通道，
        // 本体在数据里"基本不渲染"——color1 的 alpha 并不小（白黒 是 0xCC、歪み開始 是 0x80），照常当不透明度
        // 用会在画面上出现一个实在的球壳（实测"颜色过重"），并带上 color1 的颜色（实测"被渲染成黄色"）
        float bodyAlpha = this.view.enableScreenGrading || this.view.enableDistortion
            ? 0.0F
            : ((this.view.color1 >>> 24 & 0xFF) / 255.0F);
        float alpha = this.lifeAlpha() * bodyAlpha * ParticleUtils.distanceAlpha(px, py, pz, this.view.fadeNearEnd, this.view.fadeNearStart, this.view.fadeFarEnd, this.view.fadeFarStart);
        
        return (int) (Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F) << 24
            | (int) (red * 255.0F) << 16
            | (int) (green * 255.0F) << 8
            | (int) (blue * 255.0F);
    }
    
    /**
     * 把碎片面法线换算成"屏幕空间偏移方向 + 强度"写入畸变遮罩缓冲：RG 编码偏移方向（0~1 映射自 -1~1）、B 固定为 0、
     * A 存折射强度（折射率系数 × 生命透明度 × 视深标度）；由 {@code DistortionEffectManager} 在遮罩绘制阶段调用。
     * <p>
     * <b>视深标度</b>：该族材质的折射偏移与视深成反比，而后处理的 {@code Strength} 是逐帧常量、吸收不了
     * 逐像素的深度，故在写入侧逐顶点折进 A 通道（见 {@link RefractionDepthScale}）。
     */
    @Override
    public void buildDistortionQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
        if (this.remainingDelay > 0 || !this.distortion) {
            return;
        }
        float wx = (float) Mth.lerp(partialTicks, this.xo, this.x);
        float wy = (float) Mth.lerp(partialTicks, this.yo, this.y);
        float wz = (float) Mth.lerp(partialTicks, this.zo, this.z);
        // 相机相对坐标：粒子阶段渲染的 modelView 为单位矩阵，遮罩须与粒子渲染保持同一坐标空间
        float px = wx - (float) camPos.x;
        float py = wy - (float) camPos.y;
        float pz = wz - (float) camPos.z;
        
        float lifeAlpha = lifeAlpha();
        // 再乘视图的效果范围倍率：预设里的尺寸曲线按"半径 10 格"标定
        float sx = this.view.scaleX * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sy = this.view.scaleY * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sz = this.view.scaleZ * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        
        // 折射强度独立于 Fresnel：整片区域都折射背景，而非只在边缘；配了材质关键帧的层由 RefractiveIndex 曲线控强弱。
        float refraction = Mth.clamp(
            Math.abs(this.view.distortionRefractive) / EfxMeshView.REFRACTIVE_FULL_STRENGTH, 0.0F, 1.0F)
            * this.view.refractionScaleAt(this.age);
        // 凹透镜（折射强度为负）把采样方向整体反过来：凸透镜向外放大背景、凹透镜向内收缩
        float lensSign = this.view.distortionRefractive < 0.0F ? -1.0F : 1.0F;
        // 折进遮罩 A 通道的视深标度：球心即该层几何中心，逐顶点重算没有意义（见 RefractionDepthScale）
        float depthScale = RefractionDepthScale.factorOf(px, py, pz);
        
        // ---------- 透镜 / 滤镜的空间权重（本方法内一律相机相对坐标）----------
        // 口径见 {@link #lensWeight}（以球心投影为中心向外衰减的朝向权重）；该权重同时作用于折射偏移幅度与滤镜的厚度。
        float radius = Math.max(1.0E-4F, (sx + sy + sz) / 3.0F);
        boolean cameraInside = Mth.sqrt(px * px + py * py + pz * pz) < radius;
        
        for (ObjMesh.Triangle triangle : this.mesh) {
            // 只写朝向相机的那一半球壳（理由见 {@link #facesCamera}）；该过滤只对<b>封闭球壳</b>成立：
            // われ 是单面薄片乱堆簇、没有"背面"可言，硬套会剔掉近一半薄片、遮罩覆盖减半。
            if (this.view.closedShell && !this.facesCamera(triangle, sx, sy, sz, px, py, pz, cameraInside)) {
                continue;
            }
            // 方向编码逐顶点算（见下方封闭球壳分支）；薄片层仍按面法线取常量，故这里先算出它那两个通道
            Vector3f normal = new Vector3f(triangle.normal()).rotate(this.rotation).normalize();
            int flatR = packDirection(-normal.dot(camRight) * lensSign);
            int flatG = packDirection(-normal.dot(camUp) * lensSign);
            
            // 法线在相机"右 / 上"基向量上的投影 = 折射后背景被拉伸的屏幕方向。<b>取负号</b>：凸透镜要放大画面，
            // 球面右侧的采样点必须朝屏幕中心移动；直接用法线投影会让采样点向外移、观感恰好相反。
            // 方向编码改为逐顶点计算，见下方封闭球壳分支
            // **只有凸透镜才该写它**：shader 里 patchedCoord = (texCoord − 0.5)/zoom + 0.5 那一项永远是放大，
            // 凹透镜若也带上，R/G 的方向效果会被它整个盖过去，故写 0（zoom = 1）。
            // **薄片层（われ）同样写它**：关掉放大后实机会拉丝（偏移把屏幕外尚未渲染的内容拉进画面）。
            float zoomDelta = lensSign > 0.0F ? this.view.distortionZoom - 1.0F : 0.0F;
            int bCol = (int) (Mth.clamp(zoomDelta, 0.0F, 1.0F) * 255.0F);
            
            // ---------- alpha 的两种口径 ----------
            // 封闭球壳：逐顶点算球面权重（法线朝向随位置变化，球心方向最厚、切向最薄）。
            // 薄片层：<b>整个面片统一取满权重</b>——われ 是单面薄片乱堆簇、没有"球心"，
            // 径向权重 {@link #lensWeight} 对它没有物理含义；逐顶点加权会让位移在面片内部渐变、直线被弯成弧。
            // 顶点色：R/G 是方向编码、B 是放大增量、A 是强度。混合为覆盖式（见 DistortionRenderHook#drawMask），
            // 后处理里的 zoom = 1 + b·a 取到的是单层值，不随重叠层数叠加。
            if (this.view.closedShell) {
                // 封闭球壳：<b>方向与强度都逐顶点</b>。方向若按面法线算、三个顶点共用一个值，相邻三角形之间会直接
                // 跳变——球面上每一片三角形各朝一个方向拽一次，画面就被切成一格格台阶（实测"观感变得很奇怪"）；
                // 强度本来就是逐顶点插值的，方向同样插值才谈得上连续的位移场。
                // 顶点法线取"顶点相对球心的方向"：网格以局部原点为球心，等比缩放下它与真实法线等价，而球面网格
                // 本就是该形状。
                Vector3f[] sphereCorners = {triangle.p0(), triangle.p1(), triangle.p2()};
                int[] sphereAlpha = {
                    distortionAlpha(sphereCorners[0], sx, sy, sz, px, py, pz, refraction, lifeAlpha, cameraInside, depthScale),
                    distortionAlpha(sphereCorners[1], sx, sy, sz, px, py, pz, refraction, lifeAlpha, cameraInside, depthScale),
                    distortionAlpha(sphereCorners[2], sx, sy, sz, px, py, pz, refraction, lifeAlpha, cameraInside, depthScale)};
                for (int i = 0; i < 3; i++) {
                    Vector3f vertexNormal =
                        new Vector3f(sphereCorners[i].x * sx, sphereCorners[i].y * sy, sphereCorners[i].z * sz)
                            .rotate(this.rotation).normalize();
                    putMaskVertex(buffer, sphereCorners[i], sx, sy, sz, px, py, pz,
                        packDirection(-vertexNormal.dot(camRight) * lensSign),
                        packDirection(-vertexNormal.dot(camUp) * lensSign),
                        bCol, sphereAlpha[i]);
                }
            } else {
                // 薄片层：<b>整个面片统一取满权重</b>——われ 是单面薄片乱堆簇、没有"球心"，径向权重
                // {@link #lensWeight} 对它没有物理含义；逐顶点加权会让位移在面片内部渐变、直线被弯成弧。
                // 方向同样按面法线取常量：单片极小，跳变看不出来。
                int flat = toMaskAlpha(refraction * lifeAlpha * depthScale, 1.0F);
                putMaskVertex(buffer, triangle.p0(), sx, sy, sz, px, py, pz, flatR, flatG, bCol, flat);
                putMaskVertex(buffer, triangle.p1(), sx, sy, sz, px, py, pz, flatR, flatG, bCol, flat);
                putMaskVertex(buffer, triangle.p2(), sx, sy, sz, px, py, pz, flatR, flatG, bCol, flat);
            }
        }
    }
    
    /**
     * 把本层的几何写进<b>材质色彩滤镜遮罩</b>：RGB = 该层的滤镜目标色（{@link EfxMeshView#colorFilterTint}），
     * A = 透镜空间权重 × 滤镜强度 × 生命不透明度；由 {@code DistortionRenderHook} 在 {@code AFTER_PARTICLES} 阶段调用。
     * <b>不与折射合进一次绘制</b>：两条通道的顶点色含义完全不同，而 MC 的 {@code RenderTarget} 不支持多颜色附件；
     * 两次绘制复用同一批四边形与同一个 {@link #lensWeight}，故"滤镜的作用范围与折射严丝合缝"是几何上保证的。
     */
    @Override
    public void buildFilterQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
        if (this.remainingDelay > 0 || !this.colorFilter) {
            return;
        }
        // 逐层 uniform：色调三项是材质参数、与几何无关，写一次即可（同层取值相同）。
        DistortionEffectManager.setFilterProfile(
            this.view.colorFilterToneLevel,
            this.view.colorFilterEmissiveClamp,
            this.view.colorFilterDetoneRate);
        
        float wx = (float) Mth.lerp(partialTicks, this.xo, this.x);
        float wy = (float) Mth.lerp(partialTicks, this.yo, this.y);
        float wz = (float) Mth.lerp(partialTicks, this.zo, this.z);
        float px = wx - (float) camPos.x;
        float py = wy - (float) camPos.y;
        float pz = wz - (float) camPos.z;
        
        float lifeAlpha = lifeAlpha();
        float sx = this.view.scaleX * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sy = this.view.scaleY * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sz = this.view.scaleZ * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        
        // 滤镜强度与折射强度完全独立：只做滤镜的层 distortionRefractive 为 0，也能正常出效果
        float strength = Mth.clamp(this.view.colorFilterStrength, 0.0F, 1.0F) * lifeAlpha;
        int tint = this.view.colorFilterTint;
        int rCol = tint >> 16 & 0xFF;
        int gCol = tint >> 8 & 0xFF;
        int bCol = tint & 0xFF;
        
        float radius = Math.max(1.0E-4F, (sx + sy + sz) / 3.0F);
        boolean cameraInside = Mth.sqrt(px * px + py * py + pz * pz) < radius;
        
        for (ObjMesh.Triangle triangle : this.mesh) {
            // 与折射通道用同一个朝向过滤：两条通道写的是同一批四边形，任一通道少写一半都会让作用范围对不上。
            if (this.view.closedShell && !this.facesCamera(triangle, sx, sy, sz, px, py, pz, cameraInside)) {
                continue;
            }
            // 权重口径与折射通道一致（见 buildDistortionQuads 的"alpha 的两种口径"）
            int a0;
            int a1;
            int a2;
            if (this.view.closedShell) {
                a0 = toMaskAlpha(strength, this.lensWeight(triangle.p0(), sx, sy, sz, px, py, pz,
                    cameraInside));
                a1 = toMaskAlpha(strength, this.lensWeight(triangle.p1(), sx, sy, sz, px, py, pz,
                    cameraInside));
                a2 = toMaskAlpha(strength, this.lensWeight(triangle.p2(), sx, sy, sz, px, py, pz,
                    cameraInside));
            } else {
                int flat = toMaskAlpha(strength, 1.0F);
                a0 = flat;
                a1 = flat;
                a2 = flat;
            }
            putMaskVertex(buffer, triangle.p0(), sx, sy, sz, px, py, pz, rCol, gCol, bCol, a0);
            putMaskVertex(buffer, triangle.p1(), sx, sy, sz, px, py, pz, rCol, gCol, bCol, a1);
            putMaskVertex(buffer, triangle.p2(), sx, sy, sz, px, py, pz, rCol, gCol, bCol, a2);
        }
    }
    
    /**
     * 把本层的几何写进<b>屏幕空间逐通道增益遮罩</b>（{@code カラコレ}）：RGB = 该层的增益目标色
     * （{@link EfxMeshView#screenGradingGain} 的 RGB），A = {@code ColorParam.w × (N·V)^p × 生命不透明度}；
     * 后处理侧据此做 {@code scene *= 1 + A × (rgb − 1)}。
     * <b>权重口径与其它两条通道不同</b>：本通道用球面权重 {@code (N·V)^p}（球心方向最大），而 {@link #lensWeight}
     * 是"朝向"权重，两者球外视角下相关但不等价，故另算一份（见 {@link #sphereWeight}）。
     */
    @Override
    public void buildScreenGradingQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
        if (this.remainingDelay > 0 || !this.screenGrading) {
            return;
        }
        float wx = (float) Mth.lerp(partialTicks, this.xo, this.x);
        float wy = (float) Mth.lerp(partialTicks, this.yo, this.y);
        float wz = (float) Mth.lerp(partialTicks, this.zo, this.z);
        float px = wx - (float) camPos.x;
        float py = wy - (float) camPos.y;
        float pz = wz - (float) camPos.z;
        float sqrt = Mth.sqrt(px * px + py * py + pz * pz);
        // 本通道跑在<b>后处理全屏 quad</b> 上（{@code gl_FragCoord.w ≡ 1}）、拿不到逐像素视深，
        // 故用"粒子到相机的距离"近似代表视深。
        float centerDistance = Math.max(1.0F, sqrt);
        // 屏幕边缘淡出：即使 Edge_Scale / Edge_Gradation 覆写为 0，屏幕外侧仍会被压平，属<b>内建</b>行为。
        // ⚠ corner 的确切定义未能唯一确定，这里取其量级作为渐变宽度。
        float edgeBase = 0.55F * this.view.screenGradingEdgeScale - 0.1F;
        float edgeWidth = Math.abs(edgeBase * (1.0F - this.view.screenGradingEdgeGradation));
        DistortionEffectManager.setGradingProfile(
            this.view.screenGradingDispersion / centerDistance, edgeWidth);
        float lifeAlpha = lifeAlpha();
        float sx = this.view.scaleX * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sy = this.view.scaleY * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float sz = this.view.scaleZ * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        float radius = Math.max(1.0E-4F, (sx + sy + sz) / 3.0F);
        boolean cameraInside = sqrt < radius;
        int tint = this.view.screenGradingGain;
        int rCol = tint >> 16 & 0xFF;
        int gCol = tint >> 8 & 0xFF;
        int bCol = tint & 0xFF;
        float strength = Mth.clamp((tint >>> 24 & 0xFF) / 255.0F, 0.0F, 1.0F) * lifeAlpha;
        float power = Math.max(0.0F, this.view.screenGradingSpherePower);
        for (ObjMesh.Triangle triangle : this.mesh) {
            // 与另两条通道用同一个朝向过滤，保证三条通道的作用范围严丝合缝（见 {@link #facesCamera}）。
            if (this.view.closedShell && !this.facesCamera(triangle, sx, sy, sz, px, py, pz, cameraInside)) {
                continue;
            }
            // 权重口径与另两条通道一致（见 buildDistortionQuads 的"alpha 的两种口径"）
            int a0;
            int a1;
            int a2;
            if (this.view.closedShell) {
                a0 = toMaskAlpha(strength, this.sphereWeight(triangle.p0(), sx, sy, sz, px, py, pz, power, cameraInside));
                a1 = toMaskAlpha(strength, this.sphereWeight(triangle.p1(), sx, sy, sz, px, py, pz, power, cameraInside));
                a2 = toMaskAlpha(strength, this.sphereWeight(triangle.p2(), sx, sy, sz, px, py, pz, power, cameraInside));
            } else {
                int flat = toMaskAlpha(strength, 1.0F);
                a0 = flat;
                a1 = flat;
                a2 = flat;
            }
            putMaskVertex(buffer, triangle.p0(), sx, sy, sz, px, py, pz, rCol, gCol, bCol, a0);
            putMaskVertex(buffer, triangle.p1(), sx, sy, sz, px, py, pz, rCol, gCol, bCol, a1);
            putMaskVertex(buffer, triangle.p2(), sx, sy, sz, px, py, pz, rCol, gCol, bCol, a2);
        }
    }
    
    /**
     * 按<b>球面权重</b>算出某个网格顶点处的权重（0~1）：{@code (N·V)^p}——{@code N} 是顶点的球面外法线、
     * {@code V} 是"顶点 → 相机"的单位方向；正对球心处最大、球缘趋 0，与顶点侧既有的
     * {@code pow(1 − N·V, p)}（边缘提亮）<b>恰好相反</b>，不可混用。
     * <b>相机在球内必须换一支</b>：此时保留的是背离相机的半边、{@code N·V} 恒为负，照球外那支 clamp 会让
     * 权重全归 0，故改用 {@code −(N·V)}（同 {@link #lensWeight}、{@link #facesCamera} 口径）。
     */
    protected float sphereWeight(Vector3f corner, float sx, float sy, float sz,
                                 float px, float py, float pz, float power, boolean cameraInside) {
        Vector3f offset = new Vector3f(corner).mul(sx, sy, sz).rotate(this.rotation);
        if (offset.lengthSquared() < 1.0E-8F) {
            return 1.0F;
        }
        Vector3f normal = new Vector3f(offset).normalize();
        Vector3f toCamera = new Vector3f(offset).add(px, py, pz).negate();
        if (toCamera.lengthSquared() < 1.0E-8F) {
            // 顶点正好落在相机上：无从定义视线方向，按"正对"处理
            return 1.0F;
        }
        toCamera.normalize();
        float facing = normal.dot(toCamera);
        // 与 lensWeight 同一支口径：球内保留的是背离相机的半边、facing 恒为负，照球外那支 clamp 会让整层权重归 0
        float nv = cameraInside
            ? Mth.clamp(-facing, 0.0F, 1.0F)
            : Mth.clamp(facing, 0.0F, 1.0F);
        return (float) Math.pow(nv, power);
    }
    
    /**
     * 按<b>透镜空间权重</b>算出某个网格顶点处的畸变不透明度（0~255），口径与依据见 {@link #lensWeight}。
     *
     * @param depthScale 视深标度（{@link RefractionDepthScale}）；由调用方逐层算一次
     */
    protected int distortionAlpha(Vector3f corner, float sx, float sy, float sz,
                                  float px, float py, float pz, float refraction, float lifeAlpha,
                                  boolean cameraInside, float depthScale) {
        return toMaskAlpha(refraction * lifeAlpha * depthScale,
            this.lensWeight(corner, sx, sy, sz, px, py, pz, cameraInside));
    }
    
    /**
     * 按<b>透镜空间权重</b>算出某个网格顶点处的权重（0~1）——折射与材质色彩滤镜<b>共用</b>这一份。
     * <b>不用弦长</b>：弦长口径只在相机位于球外时才给出"中心浓、边缘淡"，而本类球壳膨胀后<b>相机会进入球内</b>、
     * 弦长被压平。故改用与弦长同形且球内外都成立的球面法线朝向：{@code facing = dot(n, 球心→相机)}，
     * 球外取 {@code saturate(facing)}、球内取 {@code saturate(−facing)}。
     */
    protected float lensWeight(Vector3f corner, float sx, float sy, float sz,
                               float px, float py, float pz, boolean cameraInside) {
        float lengthSquared = px * px + py * py + pz * pz;
        if (lengthSquared < 1.0E-8F) {
            // 相机正好落在球心：球心投影无处定义，按"整个视野都在球心方向"处理（权重 1）
            return 1.0F;
        }
        Vector3f normal = new Vector3f(corner).mul(sx, sy, sz).rotate(this.rotation).normalize();
        float inverseLength = 1.0F / Mth.sqrt(lengthSquared);
        float vx = -px * inverseLength;
        float vy = -py * inverseLength;
        float vz = -pz * inverseLength;
        float facing = normal.x * vx + normal.y * vy + normal.z * vz;
        return cameraInside
            ? Mth.clamp(-facing, 0.0F, 1.0F)
            : Mth.clamp(facing, 0.0F, 1.0F);
    }
    
    /**
     * 判断某个三角形是否属于"应当写入遮罩的那一半球壳"。
     * <b>为什么必须过滤</b>：球壳是<b>单层</b>网格而视点经常落在壳内，前后两半会投影到同一批屏幕像素——两半都写时，
     * 折射通道里两份<b>方向相反</b>的法线互相抵消，滤镜通道则取决于绘制顺序，观感即"特效范围内撕裂"。
     * 判定用三角形重心与网格法线：相机在原点，{@code dot(法线, 重心) < 0} 即该面朝向相机；球外保留朝向面、
     * 球内保留背离面，故每个屏幕像素最多被一个三角形覆盖。
     */
    protected boolean facesCamera(ObjMesh.Triangle triangle, float sx, float sy, float sz,
                                  float px, float py, float pz, boolean cameraInside) {
        Vector3f normal = new Vector3f(triangle.normal()).rotate(this.rotation).normalize();
        Vector3f centroid = new Vector3f(triangle.p0())
            .add(triangle.p1())
            .add(triangle.p2())
            .div(3.0F)
            .mul(sx, sy, sz)
            .rotate(this.rotation)
            .add(px, py, pz);
        boolean towardCamera = normal.dot(centroid) < 0.0F;
        return cameraInside != towardCamera;
    }
    
    /**
     * 把 0~1 的基础强度乘上透镜空间权重后打包成遮罩顶点色的 A 通道（0~255），三条遮罩通道共用。
     */
    protected static int toMaskAlpha(float strength, float weight) {
        return (int) (strength * weight * 255.0F);
    }
    
    /**
     * 把"屏幕偏移方向"的单个分量打包成 0~255 的通道值：{@code -1~1} 线性映射到 {@code 0~1}，与后处理的
     * {@code (mask.rg - 0.5) * 2.0} 互为逆运算。
     */
    protected static int packDirection(float direction) {
        return (int) (Mth.clamp(direction * 0.5F + 0.5F, 0.0F, 1.0F) * 255.0F);
    }
    
    /**
     * 把单个局部坐标顶点写入遮罩缓冲（{@code PARTICLE} 格式）——三条遮罩通道共用它，写的是同一批四边形，
     * 只是顶点色的含义不同（折射：RG 方向 / B 缩放 / A 强度；滤镜与增益：RGB 目标色 / A 强度）。
     */
    protected void putMaskVertex(VertexConsumer buffer, Vector3f p,
                                 float sx, float sy, float sz,
                                 float px, float py, float pz,
                                 int r, int g, int b, int a) {
        Vector3f world = new Vector3f(p).mul(sx, sy, sz).rotate(this.rotation).add(px, py, pz);
        // 遮罩缓冲与面片粒子共用 PARTICLE 顶点格式，UV0 / UV2 必须写全，缺一个就会在 endLastVertex 抛
        // "Missing elements in vertex"；网格类没有形状贴图，绘制侧绑的是全白图，故两者都可以给 0
        buffer.addVertex(world.x, world.y, world.z)
            .setUv(0.0F, 0.0F)
            .setUv2(0, 0)
            .setColor(r, g, b, a);
    }
    
    @Override
    public ParticleRenderType getRenderType() {
        // 相交发光层：只在与场景物体相交处亮起，走自己的着色器与渲染状态
        if (this.view.intersectGlow) {
            return MeshParticleRenderType.intersecting(this.view.dissolveLayerKey, this.batchIndex,
                this.view.texture != null ? this.view.texture : MeshParticleRenderType.DEFAULT_TEXTURE);
        }
        // 溶解 / 遮罩层：用该层该批专属的渲染类型（绑定 mesh_dissolve），保证桶内只有同一层同一批的粒子——溶解阈值、纹波相位与亮度都是逐批写入的 uniform
        if (this.view.meshClip != null || this.view.texture != null) {
            return MeshParticleRenderType.dissolving(this.view.dissolveLayerKey, this.batchIndex,
                this.view.texture != null ? this.view.texture : MeshParticleRenderType.DEFAULT_TEXTURE);
        }
        return MeshParticleRenderType.TRANSLUCENT;
    }
    
    /**
     * 给出覆盖<b>实际渲染尺寸</b>的包围盒，供粒子引擎做视锥剔除。
     * <b>为什么必须覆写</b>：默认实现只覆盖以粒子位置为中心的约 2.2 格，而本项目网格层半径可达二三十格、
     * 又以角色（第一人称相机所在）为中心，那个小盒会落在近平面之外、<b>整层被判掉</b>；
     * 覆写成真实尺寸后，剔除才回到"整层是否与视野相交"这一本意。
     */
    @Override
    public AABB getRenderBoundingBox(float partialTicks) {
        double centerX = Mth.lerp(partialTicks, this.xo, this.x);
        double centerY = Mth.lerp(partialTicks, this.yo, this.y);
        double centerZ = Mth.lerp(partialTicks, this.zo, this.z);
        float extent = this.renderHalfExtent();
        return new AABB(centerX - extent, centerY - extent, centerZ - extent,
            centerX + extent, centerY + extent, centerZ + extent);
    }
    
    /**
     * 当前这一帧网格的外接半径（格），即"几何中心到最远顶点的距离"：各轴缩放的最大值 × 网格自身外接球半径。
     * 旋转只改变方向、不改变长度，故旋转后的最远顶点必然落在此半径内；对压扁的椭球偏保守，但包围盒偏大只会少剔除。
     */
    public float renderHalfExtent() {
        float maxScale = Math.max(this.view.scaleX, Math.max(this.view.scaleY, this.view.scaleZ))
            * this.sizeScalar * this.scaleNow * this.view.sizeScale;
        // 网格为空（资源缺失）时 boundRadius 返回 0，此时给 0.5 兜底——反正也画不出东西
        return Math.max(0.5F, maxScale * Math.max(MeshLibrary.boundRadius(this.view.resource), 0.5F));
    }
}
