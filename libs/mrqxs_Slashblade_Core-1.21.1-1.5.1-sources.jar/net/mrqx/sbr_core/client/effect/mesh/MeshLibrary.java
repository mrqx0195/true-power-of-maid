package net.mrqx.sbr_core.client.effect.mesh;

import mods.flammpfeil.slashblade.client.renderer.model.obj.ModelFormatException;
import mods.flammpfeil.slashblade.client.renderer.model.obj.WavefrontObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.mrqx.sbr_core.MrqxSlashBladeCore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 网格资源库：按 obj 的资源 id 解析、归一化并缓存网格几何。
 * <p>
 * 各网格层的 {@code EfxTypeMesh.resource} 就是该层各自的 obj，本类让模型能按层区分。
 * 归一化一律经 {@link ObjMesh#normalizedToUnit()}（几何中心平移到原点、最大包围盒跨度缩放到 1），
 * 故预设里的 {@code scaleX/Y/Z × scaleMultiplier} 是统一的"格"，与 obj 原始尺度无关。
 */
public final class MeshLibrary {
    /**
     * 已加载的归一化网格，键为 obj 的资源 id。
     */
    public static final Map<ResourceLocation, List<ObjMesh.Triangle>> CACHE = new HashMap<>();
    
    /**
     * 加载失败的资源：记下来避免每次绘制都重试（失败返回空列表，粒子不可见但不崩溃）。
     */
    public static final Map<ResourceLocation, Boolean> FAILED = new HashMap<>();
    
    /**
     * 已加载网格的包围半径（归一化后顶点到原点的最大距离），键为 obj 的资源 id；须实测，不能拿常数 0.5 当半径。
     */
    public static final Map<ResourceLocation, Float> RADII = new HashMap<>();
    
    private MeshLibrary() {
    }
    
    /**
     * 取得指定 obj 的归一化三角形列表（首次调用解析并缓存，调用发生在客户端主线程，故不做同步）。
     *
     * @return 资源缺失或解析失败时返回空列表
     */
    public static List<ObjMesh.Triangle> triangles(ResourceLocation location) {
        List<ObjMesh.Triangle> cached = CACHE.get(location);
        if (cached != null) {
            return cached;
        }
        if (FAILED.containsKey(location)) {
            return List.of();
        }
        try {
            WavefrontObject wavefront = new WavefrontObject(location);
            List<ObjMesh.Triangle> triangles =
                ObjMesh.fromWavefront(wavefront).normalizedToUnit().triangles();
            CACHE.put(location, triangles);
            return triangles;
        } catch (ModelFormatException e) {
            FAILED.put(location, Boolean.TRUE);
            MrqxSlashBladeCore.LOGGER.error("加载网格失败: {}", location, e);
            return List.of();
        }
    }
    
    /**
     * 取得指定 obj 归一化后的外接球半径（顶点到原点最大距离，格）；供 {@code GenericMeshParticle#getRenderBoundingBox} 使用。
     * <p>
     * 坑：{@code Particle#getRenderBoundingBox} 默认只覆盖中心附近约 2.2 格，而本项目的网格层尺寸动辄二三十格。
     *
     * @return 资源缺失或解析失败时返回 0
     */
    public static float boundRadius(ResourceLocation location) {
        List<ObjMesh.Triangle> triangles = triangles(location);
        Float cached = RADII.get(location);
        if (cached != null) {
            return cached;
        }
        float squared = 0.0F;
        for (ObjMesh.Triangle triangle : triangles) {
            squared = Math.max(squared, maxLengthSquared(triangle));
        }
        float radius = Mth.sqrt(squared);
        RADII.put(location, radius);
        return radius;
    }
    
    /**
     * 取一个三角形里离原点最远的那个顶点的距离平方（内部辅助）。
     *
     * @return 三个顶点中最大的 {@code |p|²}
     */
    public static float maxLengthSquared(ObjMesh.Triangle triangle) {
        return Math.max(triangle.p0().lengthSquared(),
            Math.max(triangle.p1().lengthSquared(), triangle.p2().lengthSquared()));
    }
    
    /**
     * 清空缓存（资源重载时调用）：让下一次取用时按新的资源包重新解析。
     */
    public static void clear() {
        CACHE.clear();
        FAILED.clear();
        RADII.clear();
    }
}
