package net.mrqx.sbr_core.client.effect.mesh;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.Minecraft;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL30;

/**
 * <b>场景深度副本</b>：把主帧缓冲的深度缓冲拷进一张可采样的深度纹理。
 * <p>
 * 用途是"<b>相交发光</b>"——{@code ドーム} 那种"火焰附着在球面与任意物体相交处"的效果。
 * 做法是在片元着色器里比较"该像素的场景深度"与"当前片元的深度"：两者接近（即球面正好穿过
 * 场景里某个表面）的地方才发光，于是火焰看起来是沿着球面与地面 / 墙面的交线烧起来的。
 * <p>
 * <b>为什么需要单独拷一份</b>：Minecraft 的主帧缓冲只暴露颜色附件，深度附件无法直接作为纹理采样；
 * 而且粒子是在地形与实体之后绘制的，只有在那个时刻之后拷贝，得到的深度才包含地面与实体。
 * 因此本类在 {@link RenderLevelStageEvent.Stage#AFTER_ENTITIES}（地形与实体都画完、
 * 粒子尚未绘制）时执行一次 {@code glBlitFramebuffer}，把深度整体搬进自己的 FBO。
 * <p>
 * <b>开销</b>：一次全屏深度 blit（每帧仅在真的存在相交层时才做），不需要时完全不参与。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class SceneDepthCopy {
    /**
     * 是否有层需要场景深度。
     * <p>
     * 由相交层在自己的 {@code render} 里置位（每 tick 由 {@code MeshEmitterManager} 的活跃列表决定），
     * 避免没有相交层时白做一次全屏 blit。
     */
    public static boolean requested;
    
    /**
     * 深度纹理的 GL 名称；0 表示尚未创建。
     */
    public static int depthTexture;
    
    /**
     * 承载深度纹理的 FBO；0 表示尚未创建。
     */
    public static int depthFramebuffer;
    
    /**
     * 当前深度纹理的尺寸（屏幕尺寸变化时重建）。
     */
    public static int width;
    
    /**
     * 当前深度纹理的高度。
     */
    public static int height;
    
    private SceneDepthCopy() {
    }
    
    /**
     * 声明"本帧需要场景深度"，由相交层在每帧渲染时调用。
     */
    public static void request() {
        requested = true;
    }
    
    /**
     * 取深度纹理的 GL 名称（供着色器以 {@code Sampler1} 采样）。
     *
     * @return 深度纹理名称；不可用时返回 0
     */
    public static int depthTextureId() {
        return depthTexture;
    }
    
    /**
     * 取当前深度纹理的宽度（像素）。
     */
    public static int textureWidth() {
        return width;
    }
    
    /**
     * 取当前深度纹理的高度（像素）。
     */
    public static int textureHeight() {
        return height;
    }
    
    /**
     * 在地形与实体绘制完成后拷贝深度，并复位"本帧需要深度"标记。
     * <p>
     * 该阶段之后才是粒子渲染，因此相交层采样到的深度正好是"不含粒子自身"的场景深度。
     */
    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }
        boolean needed = requested;
        requested = false;
        if (!needed) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        RenderTarget main = minecraft.getMainRenderTarget();
        int targetWidth = main.width;
        int targetHeight = main.height;
        if (targetWidth <= 0 || targetHeight <= 0) {
            return;
        }
        ensureTarget(targetWidth, targetHeight);
        if (depthFramebuffer == 0) {
            return;
        }
        // 读主帧缓冲的深度、写到自己的深度附件；NEAREST 足够（深度不做插值）
        int previousRead = GL30.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int previousDraw = GL30.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, depthFramebuffer);
        GL30.glBlitFramebuffer(0, 0, targetWidth, targetHeight, 0, 0, targetWidth, targetHeight,
            GL11.GL_DEPTH_BUFFER_BIT, GL11.GL_NEAREST);
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, previousRead);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, previousDraw);
        // blit 之后立刻把 FBO 绑回主帧缓冲：后续的粒子渲染仍然画在主画面上
        main.bindWrite(true);
    }
    
    /**
     * 按需创建 / 重建深度纹理与 FBO。
     *
     * @param targetWidth  目标宽度（像素）
     * @param targetHeight 目标高度（像素）
     */
    public static void ensureTarget(int targetWidth, int targetHeight) {
        if (depthTexture != 0 && width == targetWidth && height == targetHeight) {
            return;
        }
        release();
        depthTexture = GlStateManager._genTexture();
        GlStateManager._bindTexture(depthTexture);
        // 深度纹理：不参与 mipmap，边界夹取，NEAREST 过滤。必须用 GL_CLAMP_TO_EDGE：
        // GL_CLAMP 在 3.2 core profile 里已被移除，传它会得到 GL_INVALID_ENUM、寻址停留在默认的 REPEAT。
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GlStateManager._texImage2D(GL11.GL_TEXTURE_2D, 0, GL30.GL_DEPTH_COMPONENT24,
            targetWidth, targetHeight, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, null);
        
        depthFramebuffer = GlStateManager.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, depthFramebuffer);
        GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT,
            GL11.GL_TEXTURE_2D, depthTexture, 0);
        // 该 FBO 只做深度拷贝，不产生颜色输出：按 GL 规范必须显式声明"无颜色附件"。
        // 这里用 LWJGL 直接调用——GlStateManager 并没有包装 _glDrawBuffers / _glReadBuffer。
        GL11.glDrawBuffer(GL11.GL_NONE);
        GL11.glReadBuffer(GL11.GL_NONE);
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
        GlStateManager._bindTexture(0);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            MrqxSlashBladeCore.LOGGER.error("场景深度缓冲创建失败（状态 {}），相交发光将不可用", status);
            release();
            return;
        }
        width = targetWidth;
        height = targetHeight;
    }
    
    /**
     * 释放深度纹理与 FBO（尺寸变化时重建、或资源重载时调用）。
     */
    public static void release() {
        if (depthFramebuffer != 0) {
            GlStateManager._glDeleteFramebuffers(depthFramebuffer);
            depthFramebuffer = 0;
        }
        if (depthTexture != 0) {
            GlStateManager._deleteTexture(depthTexture);
            depthTexture = 0;
        }
        width = 0;
        height = 0;
    }
}
