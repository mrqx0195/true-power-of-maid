package net.mrqx.sbr_core.client.effect.mesh;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxMeshView;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;

import java.util.ArrayList;
import java.util.List;

/**
 * 网格粒子发射管理器（われ 层）：按 {@link EfxMeshView} 采样发射粒子，并维护参与畸变的粒子追踪列表；
 * 分批靠每批不同的出生延迟实现，粒子交由原版 {@code ParticleEngine} 驱动。
 */
public final class MeshEmitterManager {
    /**
     * 当前活跃的畸变粒子引用，渲染遮罩时遍历
     */
    private static final List<GenericMeshParticle> TRACKED_DISTORTION = new ArrayList<>();
    
    private MeshEmitterManager() {
    }
    
    /**
     * 以该层自身的随机策略发射一次特效
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config) {
        spawn(level, origin, config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 以该层自身的随机策略发射一次特效，并指定本段演出的收尾时刻。
     *
     * @param sustainedKeepTicks 从本层触发时刻到本段演出收尾的 tick 数（语义见 {@code EfxEffectManager#spawn}）
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks) {
        spawn(level, origin, new EfxMeshView(config, sustainedKeepTicks));
    }
    
    /**
     * 同上，并指定本场演出的<b>效果范围倍率</b>（逐层的 {@code EfxAttributeCharacterSpace} 仍可把它压回 {@code 1.0}）。
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, int sustainedKeepTicks,
                             float effectRangeScale) {
        spawn(level, origin, new EfxMeshView(config, sustainedKeepTicks, effectRangeScale));
    }
    
    /**
     * 使用外部随机源发射，供时间轴让同一 Entry 的多次触发共享同一条随机序列
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, RandomSource rnd) {
        spawn(level, origin, new EfxMeshView(config), rnd);
    }
    
    /**
     * 以该层自身的随机策略发射（随机源构造见 {@link #randomSource}）
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxMeshView view) {
        spawn(level, origin, view, randomSource(view, origin));
    }
    
    /**
     * 按 {@link EfxMeshView} 的随机策略构造随机源：有有效种子槽位时用"种子 + 原点坐标 64 位"派生可复现种子，
     * 否则退回 {@link RandomSource#create()} 的真随机（不再使用"配置内容哈希"这类恒定种子）。
     */
    public static RandomSource randomSource(EfxMeshView view, Vec3 origin) {
        if (view.fixRandomGenerator == null || view.randomSeed == null) {
            // 没有 FixRandomGenerator（或它没给出任何有效种子槽位）→ 每次触发都真随机
            return RandomSource.create();
        }
        long seed = view.randomSeed;
        // 触发上下文：原点坐标的 64 位表示（与 Minecraft 的 Vec3.hashCode 无关，只做位混合）
        seed = seed * 31L + Double.hashCode(origin.x);
        seed = seed * 31L + Double.hashCode(origin.y);
        seed = seed * 31L + Double.hashCode(origin.z);
        return RandomSource.create(seed);
    }
    
    /**
     * 用给定视图与随机源发射；每颗粒子按"采样位置 → 三轴朝向 → 整体尺寸"的顺序消耗随机数
     */
    public static void spawn(ClientLevel level, Vec3 origin, EfxMeshView view, RandomSource rnd) {
        // 口径与 PolygonEmitterManager 一致：每批 ⌈总数 ÷ 批次数⌉；批次数多于总数时退化为每批 1 个
        int batches = Math.max(1, view.spawnBatches);
        int perBatch = Math.max(1, (view.spawnTotal + batches - 1) / batches);
        int actualBatches = Math.max(1, (view.spawnTotal + perBatch - 1) / perBatch);
        for (int batch = 0; batch < actualBatches; batch++) {
            int count = Math.min(perBatch, view.spawnTotal - batch * perBatch);
            int delayTicks = batch * Math.max(1, view.spawnIntervalTicks);
            for (int i = 0; i < count; i++) {
                Vec3 pos = sampleEllipsoid(origin, view, rnd);
                // 批序号必须一路传到粒子，它决定粒子进哪个渲染桶：两批共用一次 draw call 时，
                // 逐 age 变化的材质 uniform 会被后写的那批整个覆盖（见 GenericMeshParticle#batchIndex）。
                GenericMeshParticle particle = new GenericMeshParticle(
                    level, pos.x, pos.y, pos.z, view, rnd, delayTicks, batch);
                Minecraft.getInstance().particleEngine.add(particle);
                // 三条屏幕空间遮罩通道（折射、材质色彩滤镜、逐通道增益）各写各的缓冲，启用任一即需跟踪；
                // 只按 enableDistortion 判断会漏掉只做增益或滤镜的层。
                if (view.enableDistortion || view.enableColorFilter || view.enableScreenGrading) {
                    TRACKED_DISTORTION.add(particle);
                }
            }
        }
    }
    
    /**
     * 返回仍活跃的遮罩来源粒子列表（自动剔除已移除者）；剔除条件是三条通道都不再需要，
     * 只看 {@code hasDistortion()}（活着且启用折射）会把只做滤镜或增益的粒子立刻剔掉。
     */
    public static List<GenericMeshParticle> activeDistortionParticles() {
        TRACKED_DISTORTION.removeIf(particle -> !particle.hasDistortion() && !particle.hasColorFilter()
            && !particle.hasScreenGrading());
        return TRACKED_DISTORTION;
    }
    
    /**
     * 在椭球内均匀采样并叠加配置的固定偏移；{@code u/v} 球面角 + {@code cbrt(1 - ξ³)} 半径的公式与 nextDouble 消耗顺序需保持稳定。
     */
    public static Vec3 sampleEllipsoid(Vec3 origin, EfxMeshView view, RandomSource rnd) {
        double u = rnd.nextDouble();
        double v = rnd.nextDouble();
        double theta = 2.0 * Math.PI * u;
        double phi = Math.acos(2.0 * v - 1.0);
        double radius = Math.cbrt(1 - Math.pow(rnd.nextDouble(), 3));
        double sinPhi = Math.sin(phi);
        double dx = sinPhi * Math.cos(theta) * radius;
        double dy = Math.cos(phi) * radius;
        double dz = sinPhi * Math.sin(theta) * radius;
        return new Vec3(
            origin.x + view.localOffset.x + dx * view.rangeXYZ.x,
            origin.y + view.localOffset.y + dy * view.rangeXYZ.y,
            origin.z + view.localOffset.z + dz * view.rangeXYZ.z);
    }
}
