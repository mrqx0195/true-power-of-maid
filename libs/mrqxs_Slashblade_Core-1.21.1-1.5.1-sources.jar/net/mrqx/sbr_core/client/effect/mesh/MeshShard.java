package net.mrqx.sbr_core.client.effect.mesh;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;

import java.util.List;

/**
 * われ 网格碎片（{@code dimension_slashes.obj}）的几何入口：按 obj 资源委托 {@link MeshLibrary} 缓存，
 * 本类只负责给出われ 的资源 id。
 * <p>
 * われ 各层预设的 {@code EfxTypeMesh.resource} 仍然指向 {@link #MODEL_LOCATION}（通过 {@code EfxMeshView} 的兜底），
 * 因此われ 的行为与从前完全一致。
 */
public final class MeshShard {
    /**
     * われ 网格碎片的模型资源。
     */
    public static final ResourceLocation MODEL_LOCATION =
        MrqxSlashBladeCore.prefix("model/effect/dimension_slashes.obj");
    
    private MeshShard() {
    }
    
    /**
     * 取得われ 的归一化三角形列表。
     *
     * @return 归一化后的三角形列表（进程内按资源缓存）
     */
    public static List<ObjMesh.Triangle> triangles() {
        return MeshLibrary.triangles(MODEL_LOCATION);
    }
    
    /**
     * 清空网格缓存（资源重载时调用）。
     */
    public static void reload() {
        MeshLibrary.clear();
    }
}
