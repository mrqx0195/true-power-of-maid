package net.mrqx.sbr_core.client.effect.mesh;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxMeshView;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * 相交发光的自定义着色器（{@code sbr_core:mesh_intersect}，资源见 {@code shaders/core/mesh_intersect.json/vsh/fsh}）：
 * 片元着色器同时采样本层火焰贴图（{@code Sampler0}）与 {@link SceneDepthCopy} 的场景深度（{@code Sampler1}），
 * 只在“球面深度 ≈ 场景深度”的一圈加算发光。
 * <p>
 * 必须自建：原版粒子着色器没有第二张纹理的采样通道，也没有屏幕像素坐标与深度还原所需的 uniform（这两个 uniform 每帧由粒子侧写入，渲染桶 = 同层 + 同批）。
 */
@EventBusSubscriber(modid = MrqxSlashBladeCore.MODID, value = Dist.CLIENT)
public final class MeshIntersectShaders {
    /**
     * 着色器资源 id（对应 {@code shaders/core/mesh_intersect.json}）。
     */
    public static final ResourceLocation MESH_INTERSECT = MrqxSlashBladeCore.prefix("mesh_intersect");
    
    /**
     * 编译后的着色器实例；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    public static ShaderInstance intersectShader;
    
    private MeshIntersectShaders() {
    }
    
    /**
     * 注册着色器（资源重载时由 NeoForge 调用）。
     */
    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        try {
            event.registerShader(
                new ShaderInstance(event.getResourceProvider(), MESH_INTERSECT, DefaultVertexFormat.PARTICLE),
                shader -> intersectShader = shader);
        } catch (IOException e) {
            intersectShader = null;
            MrqxSlashBladeCore.LOGGER.error("加载相交发光着色器失败: {}", MESH_INTERSECT, e);
        }
    }
    
    /**
     * 取得着色器实例；未加载成功时返回 null，调用方需回退到原版粒子着色器。
     * <p>
     * <b>调用方不得关闭该实例</b>：它是全局共享缓存，资源重载时由 NeoForge 替换为新实例，旧实例由引擎自行关闭。
     */
    @Nullable
    public static ShaderInstance shader() {
        return intersectShader;
    }
    
    /**
     * 把场景深度副本绑到 {@code Sampler1}。
     * <p>
     * 必须走 {@link RenderSystem#setShaderTexture(int, int)}，不能用 {@code GlStateManager._bindTexture}：
     * {@code ShaderInstance#apply()} 在绘制前会按 {@code RenderSystem} 的 {@code shaderTextures[]} 逐个重绑 sampler，
     * 手工绑定会被顶回 0，深度副本失效使片元全部 discard（曾经的“整层一个像素都不出”）；{@code textureId} 为 0 时等价于解绑，无需额外判断。
     */
    public static void bindSceneDepth() {
        RenderSystem.setShaderTexture(1, SceneDepthCopy.depthTextureId());
    }
    
    /**
     * 写入屏幕尺寸的倒数（把 {@code gl_FragCoord.xy} 换算成 0~1 的 UV）。
     */
    public static void setScreenSize(int width, int height) {
        ShaderInstance shader = intersectShader;
        if (shader == null || width <= 0 || height <= 0) {
            return;
        }
        shader.safeGetUniform("InvScreenSize").set(1.0F / width, 1.0F / height);
    }
    
    /**
     * 写入深度还原所需的近 / 远平面。
     */
    public static void setDepthRange(float nearPlane, float farPlane) {
        ShaderInstance shader = intersectShader;
        if (shader == null) {
            return;
        }
        shader.safeGetUniform("NearPlane").set(nearPlane);
        shader.safeGetUniform("FarPlane").set(farPlane);
    }
    
    /**
     * 写入相交火焰的全部剖面与颜色 uniform（剖面值来自 EFX 覆写，各项含义见 {@code EfxAttributeIntersectGlow} 的类注释）。
     * <p>
     * {@code ColorParam} 必须取该层的 {@code color1}（材质基色，Base 通路会乘上它）：曾经写死成白色，使 Base 通路恒为白、压掉蓝色，
     * 实机表现为“火焰未被染为蓝色”。
     */
    public static void setGlow(EfxMeshView view) {
        ShaderInstance shader = intersectShader;
        if (shader == null) {
            return;
        }
        shader.safeGetUniform("WidthTop").set(view.intersectWidth);
        shader.safeGetUniform("WidthBottom").set(view.intersectWidthBottom);
        shader.safeGetUniform("VolumePower").set(view.intersectVolumePower);
        shader.safeGetUniform("AlphaFadePower").set(view.intersectAlphaFadePower);
        shader.safeGetUniform("BaseIntensity").set(view.intersectBaseIntensity);
        shader.safeGetUniform("BasePower").set(view.intersectBasePower);
        shader.safeGetUniform("LimIntensity").set(view.intersectLimIntensity);
        shader.safeGetUniform("LimPower").set(view.intersectLimPower);
        int limColor = view.intersectColor;
        shader.safeGetUniform("LimColor").set(
            (limColor >> 16 & 0xFF) / 255.0F,
            (limColor >> 8 & 0xFF) / 255.0F,
            (limColor & 0xFF) / 255.0F,
            (limColor >>> 24 & 0xFF) / 255.0F);
        int colorParam = view.color1;
        shader.safeGetUniform("ColorParam").set(
            (colorParam >> 16 & 0xFF) / 255.0F,
            (colorParam >> 8 & 0xFF) / 255.0F,
            (colorParam & 0xFF) / 255.0F,
            (colorParam >>> 24 & 0xFF) / 255.0F);
    }
    
    /**
     * 写入火焰贴图在网格表面上的平铺次数。
     * <p>
     * 缺了它，网格自身的球面 UV 只会把火焰图案铺在球壳的一小块上，其余区域采样到贴图透明区被 discard。
     */
    public static void setGlowUvScale(float uScale, float vScale) {
        ShaderInstance shader = intersectShader;
        if (shader == null) {
            return;
        }
        shader.safeGetUniform("GlowUvScale").set(uScale, vScale);
    }
    
    /**
     * 写入火焰贴图的滚动相位（0~1），相位循环使火焰图案在球面上流动。
     */
    public static void setGlowUvScroll(float uScroll, float vScroll) {
        ShaderInstance shader = intersectShader;
        if (shader == null) {
            return;
        }
        shader.safeGetUniform("GlowUvScroll").set(uScroll, vScroll);
    }
}
