package net.mrqx.sbr_core.client.effect.util;

import net.minecraft.world.phys.Vec3;

/**
 * 骨骼锚点的固定偏移表。
 * <p>
 * EFX 的 {@code LocalPosition} 是<b>相对骨骼锚点</b>的偏移，而本项目尚无骨骼系统，
 * 因此所有骨骼绑定降级为<b>固定偏移</b>：
 * 层的最终位置 = 演出原点 + 本表的偏移 + EFX 自身的 {@code LocalPosition}。
 * <p>
 * <b>前提</b>：本项目两个特效的施法者位置与命中点一致，故可以直接把演出原点当作骨骼锚点。
 * <p>
 * 偏移量一律以公开常量给出，方便实机验收后直接微调——调整时只需改这里，不必翻各层预设。
 */
public final class BoneOffset {
    /**
     * 无骨骼：直接以演出原点为心。
     */
    public static final Vec3 NONE = Vec3.ZERO;
    
    /**
     * {@code Waist}（腰）：演出原点上方 1 格。
     * <p>
     * 与 {@code EfxJcePolygonPresets.CENTER_ONE_ABOVE_ORIGIN}（旧面片层的抬高量）取齐，
     * 使同一批刀光的中心高度在两条时间轴之间保持一致。
     */
    public static final Vec3 WAIST = new Vec3(0.0D, 1.0D, 0.0D);
    
    /**
     * {@code Chest}（胸）：演出原点上方 1.5 格（胸口约在腰部上方 0.5 格）。
     */
    public static final Vec3 CHEST = new Vec3(0.0D, 1.5D, 0.0D);
    
    /**
     * {@code Head}（头）：演出原点上方 1.8 格。
     * <p>
     * 目前<b>没有任何调用点</b>：唯一沾边的 {@code 歪み_eff2} 层在 EFX 里并没有绑定骨骼，本项目按"头部高度"近似；
     * 本常量保留给后续出现真正绑头部的层使用。
     */
    public static final Vec3 HEAD = new Vec3(0.0D, 1.8D, 0.0D);
    
    private BoneOffset() {
    }
    
    /**
     * 按骨骼名取固定偏移。
     * <p>
     * 用于把 EFX 数据里的骨骼名（{@code "Waist"} / {@code "Chest"} …）直接翻译成偏移量，
     * 各层预设只需照抄骨骼名即可，不必自己算高度。未识别的骨骼名按 {@link #NONE} 处理。
     *
     * @param boneName 骨骼名；空串或未识别时返回 {@link #NONE}
     * @return 该骨骼对应的固定偏移
     */
    public static Vec3 of(String boneName) {
        return switch (boneName) {
            case "Waist" -> WAIST;
            case "Chest" -> CHEST;
            case "Head" -> HEAD;
            default -> NONE;
        };
    }
}
