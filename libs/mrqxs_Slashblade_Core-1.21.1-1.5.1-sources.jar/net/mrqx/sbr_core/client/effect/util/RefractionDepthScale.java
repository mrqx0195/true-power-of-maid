package net.mrqx.sbr_core.client.effect.util;

import net.minecraft.util.Mth;
import net.mrqx.sbr_core.config.MrqxSlashBladeClientConfig;

/**
 * 屏幕空间折射的<b>视深标度</b>：把「偏移随视深反比衰减」折成遮罩顶点色 A 通道上的一个乘数。
 * <p>
 * <b>为什么需要它</b>：该族材质的折射偏移是
 * {@code 2e-4 × (RefractiveIndex − 1) × ColorParam.w ÷ v0.w}——分母 {@code v0.w} 是视深，
 * 即折射幅度<b>随离屏距离反比衰减</b>。本项目的后处理
 * （{@code dis_ware_distortion.fsh} 的 {@code amount = mask.a * Strength}）把幅度摊成了一个
 * <b>全局常数</b> {@code Strength}，等于用一个常数吸收了一个<b>逐像素</b>的深度因子，
 * 于是近处不放大、远处不衰减，球壳拉近拉远观感一样。
 * <p>
 * <b>题外：本项与像素宽无关</b>。原作在 4.4 节乘过一次 {@code screenSize.x}、
 * 在 4.5 节又乘过一次 {@code screenInverseSize}，两者在 UV 空间里<b>正好抵消</b>，
 * 故换算到本项目时不应再按分辨率折算——这一项已经并进上面的算式。
 * <p>
 * <b>做法</b>：遮罩 A 通道写入时逐顶点乘上本标度，后处理侧一行都不用改。之所以能放进 A 通道而不必另开
 * 一张逐来源的缓冲：A 参与的是「偏移向量的加权叠加」（{@code dir * amount} 与
 * {@code blendFuncSeparate} 的 {@code SRC_ALPHA}），乘一个常数与该层的语义完全相容。
 * <p>
 * <b>标度不是"绝对幅度"</b>：{@link #factor} 返回 {@code 参考视深 ÷ 视深}，即参考距离处恒为 1、
 * 观感与补这一项之前<b>完全一致</b>，只有远近的相对关系被还原。真正的绝对幅度仍由
 * {@code shaders/post/dis_ware_distortion.json} 的 {@code Strength} 承担——这也就是为什么补上本项之后
 * {@code Strength = 0.5} 必须重新标定：参考距离取 10 格时，薄片层与球壳层的实际观感距离从
 * 「恒定」变成「10 格基准」，靠近到 5 格即翻倍、退到 40 格只剩四分之一。
 */
public final class RefractionDepthScale {
    /**
     * 参考视深的配置兜底值（单位：格）。
     * <p>
     * 取 10 格：折射球壳与薄片出生点通常就在这个距离上，取它意味着"补项之前标定好的 {@code Strength}
     * 对这一档距离仍然成立"，实机校准时只需照顾两端而非重标整条曲线。
     */
    public static final float DEFAULT_REFERENCE = 10.0F;
    
    /**
     * 视深下限（单位：格）。
     * <p>
     * {@code 参考视深 ÷ 视深} 在视深趋近 0 时发散：相机贴到粒子中心时（相机进入球壳完全可能）
     * 会得到一个天文数字的标度，一层就把整屏拖花。夹在这个下限上，最多把幅度放大到参考距离的 10 倍。
     */
    public static final float MIN_DEPTH = 1.0F;
    
    /**
     * 参考视深上限（单位：格）：配置项的取值范围。超过它基本等于"关掉深度项"。
     */
    public static final float MAX_REFERENCE = 64.0F;
    
    private RefractionDepthScale() {
    }
    
    /**
     * 当前配置的参考视深（单位：格）；配置项非正时退回 {@link #DEFAULT_REFERENCE}。
     */
    public static float reference() {
        float configured = MrqxSlashBladeClientConfig.DISTORTION_DEPTH_REFERENCE.get().floatValue();
        return configured > 0.0F ? configured : DEFAULT_REFERENCE;
    }
    
    /**
     * 算出某点处应当乘进遮罩 A 通道的深度标度。
     *
     * @param viewDepth 该点相对相机的视深（单位：格；取到相机中心的欧氏距离即可，球壳半径远小于典型视深）
     * @return {@code 参考视深 ÷ max(视深, 1)}，参考距离处恒为 1
     */
    public static float factor(float viewDepth) {
        return reference() / Mth.clamp(viewDepth, MIN_DEPTH, MAX_REFERENCE);
    }
    
    /**
     * 由相机相对坐标直接算出深度标度（省得每个调用点各写一遍 {@code sqrt}）。
     *
     * @param px 相机相对 x（格）
     * @param py 相机相对 y（格）
     * @param pz 相机相对 z（格）
     * @return {@code 参考视深 ÷ max(视深, 1)}
     */
    public static float factorOf(float px, float py, float pz) {
        return factor(Mth.sqrt(px * px + py * py + pz * pz));
    }
}
