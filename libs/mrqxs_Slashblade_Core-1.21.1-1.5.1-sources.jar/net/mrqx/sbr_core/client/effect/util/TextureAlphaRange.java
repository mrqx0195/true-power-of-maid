package net.mrqx.sbr_core.client.effect.util;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.mrqx.sbr_core.MrqxSlashBladeCore;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * 贴图 alpha 上下限的<b>一次性预处理</b>缓存。
 * <p>
 * <b>为什么需要它</b>：材质的 alpha 曲线是
 * {@code saturate((贴图 alpha ^ 4.84 − lowPass) ÷ highPass)}，其中 {@code lowPass} / {@code highPass}
 * 是按<b>材质自带贴图</b>标定的（那张图的 alpha 上限为 1.0）。本项目多数层改用就近复用的替代贴图，
 * 上限往往明显更低（例如 {@code crack_ring_purple} 只有 0.81，其 4.84 次幂仅约 0.36），
 * 于是照抄 EFX 原值会把整层压成全透明——这不是"参数不对"，而是**贴图的 alpha 量程不同**。
 * <p>
 * <b>做法</b>：首次用到某张贴图时读一次 PNG、扫出 alpha 的上下限并缓存；
 * 着色器先用 {@code (alpha − min) ÷ (max − min)} 把它缩放到 0~1 再进曲线。
 * 这样 {@code lowPass} 就恢复了"相对满量程"的原义，<b>不必逐层手调阈值</b>。
 * <p>
 * 每个贴图只测一次；资源重载时由 {@code PolygonShaders} 调 {@link #clear()} 让它失效。
 * 读取失败（资源缺失、解码异常）时退回 {@link Range#IDENTITY}，即不缩放——宁可保持原行为，
 * 也不要因为测不到就把整层压没。
 */
public final class TextureAlphaRange {
    /**
     * alpha 区间。
     * <p>
     * {@link #IDENTITY} 表示"不做缩放"：贴图读不到、或本来就是满量程。
     */
    public record Range(float min, float max) {
        /**
         * 恒等区间 {@code [0, 1]}：缩放前后一致。
         */
        public static final Range IDENTITY = new Range(0.0F, 1.0F);
        
        /**
         * 该区间是否可用于缩放。
         *
         * @return 量程大于千分之一时为 {@code true}
         */
        public boolean usable() {
            return this.max - this.min > 1.0e-3F;
        }
    }
    
    /**
     * 已测贴图的缓存；键是贴图资源 id。
     */
    private static final Map<ResourceLocation, Range> CACHE = new HashMap<>();
    
    private TextureAlphaRange() {
    }
    
    /**
     * 取得某张贴图的 alpha 上下限；首次调用时测量并缓存。
     *
     * @param texture 贴图资源 id
     * @return alpha 区间；读取失败时为 {@link Range#IDENTITY}
     */
    public static Range of(ResourceLocation texture) {
        return CACHE.computeIfAbsent(texture, TextureAlphaRange::measure);
    }
    
    /**
     * 清空缓存。资源重载后贴图内容可能已变，必须调用。
     */
    public static void clear() {
        CACHE.clear();
    }
    
    /**
     * 读取并扫描一张贴图。
     *
     * @param texture 贴图资源 id
     * @return alpha 区间；任何失败都退回 {@link Range#IDENTITY}
     */
    private static Range measure(ResourceLocation texture) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null) {
            return Range.IDENTITY;
        }
        Optional<Resource> resource = minecraft.getResourceManager().getResource(texture);
        if (resource.isEmpty()) {
            MrqxSlashBladeCore.LOGGER.warn("测不了贴图的 alpha 区间（资源不存在）：{}", texture);
            return Range.IDENTITY;
        }
        try (InputStream stream = resource.get().open(); NativeImage image = NativeImage.read(stream)) {
            return scan(image);
        } catch (IOException e) {
            MrqxSlashBladeCore.LOGGER.warn("测不了贴图的 alpha 区间（读取失败）：{}", texture, e);
            return Range.IDENTITY;
        }
    }
    
    /**
     * 扫描像素的 alpha 通道取上下限。
     * <p>
     * {@link NativeImage#getPixelRGBA} 返回的是 ABGR 打包值，alpha 在最高 8 位。
     *
     * @param image 已解码的贴图
     * @return alpha 区间；全透明图退回 {@link Range#IDENTITY}
     */
    private static Range scan(NativeImage image) {
        int lowest = 255;
        int highest = 0;
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int alpha = image.getPixelRGBA(x, y) >>> 24 & 0xFF;
                if (alpha < lowest) {
                    lowest = alpha;
                }
                if (alpha > highest) {
                    highest = alpha;
                }
            }
        }
        if (highest <= 0) {
            return Range.IDENTITY;
        }
        return new Range(lowest / 255.0F, highest / 255.0F);
    }
}
