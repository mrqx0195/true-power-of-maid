package net.mrqx.sbr_core.client.effect.util;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * 地面采样工具：把特效的生成点吸附到"可以立足的方块顶面"。
 * <p>
 * 对应 EFX 的 {@code EFXAttributePtCollision} 的简化实现：本项目的粒子只做解析运动
 * （不做逐帧物理），因此改为<b>在生成时</b>把高度吸附到地表——以触发位置所在的水平面为基准，
 * 先向下、再向上遍历该 (x, z) 柱上的方块，找到第一个"上表面稳固且上方有空间"的方块，
 * 把特效放在它的顶面上。
 * <p>
 * 这样地面烟与纵烟无论触发点在地面、半空还是方块内部，都会稳定地出现在可见的地表上。
 */
public final class GroundSurface {
    /**
     * 垂直搜索范围（格）：超出该范围仍未找到地表时，保持原始高度不变。
     */
    public static final int SEARCH_RANGE = 32;
    
    /**
     * 贴面时向上抬起的微小偏移（格），避免与方块表面重叠产生闪烁。
     */
    public static final double SURFACE_OFFSET = 0.02D;
    
    private GroundSurface() {
    }
    
    /**
     * 把给定坐标的高度吸附到地表。
     *
     * @param level 客户端世界（需已加载对应区块）
     * @param x     世界坐标 X
     * @param y     参考高度：通常为特效触发点的高度
     * @param z     世界坐标 Z
     * @return 吸附后的高度；搜索范围内没有可立足的地表时返回原始 {@code y}
     */
    public static double snap(ClientLevel level, double x, double y, double z) {
        int startY = Mth.floor(y);
        // 先向下找：绝大多数情况下特效落在地面之上
        int minY = Math.max(level.getMinBuildHeight(), startY - SEARCH_RANGE);
        for (int cy = startY; cy >= minY; cy--) {
            Double surface = surfaceAt(level, x, cy, z);
            if (surface != null) {
                return surface + SURFACE_OFFSET;
            }
        }
        // 再向上找：触发点位于地下或方块内部时，取上方第一处空地
        int maxY = Math.min(level.getMaxBuildHeight() - 1, startY + SEARCH_RANGE);
        for (int cy = startY + 1; cy <= maxY; cy++) {
            Double surface = surfaceAt(level, x, cy, z);
            if (surface != null) {
                return surface + SURFACE_OFFSET;
            }
        }
        return y;
    }
    
    /**
     * 把给定坐标的高度吸附到地表（带碰撞半径容差）。
     * <p>
     * 对应 EFX {@code EFXAttributePtCollision.Radius}：点碰撞体是有半径的，
     * 因此不能只看正下方那一根柱子，而要在<b>半径范围内取最高的可立足顶面</b>——
     * 这样烟层跨过小台阶、斜坡或方块缝时仍会铺在同一个水平面上，不会一半沉进去。
     * 层序与 {@link #snap(ClientLevel, double, double, double)} 保持一致（先向下、再向上）。
     *
     * @param level  客户端世界
     * @param x      世界坐标 X
     * @param y      参考高度
     * @param z      世界坐标 Z
     * @param radius 碰撞半径（格）；{@code <= 0} 时退化为只采样正下方
     * @return 吸附后的高度；搜索范围内没有可立足的地表时返回原始 {@code y}
     */
    public static double snap(ClientLevel level, double x, double y, double z, double radius) {
        if (radius <= 0.0D) {
            return snap(level, x, y, z);
        }
        int startY = Mth.floor(y);
        // 采样半径方形的四角与中心：地面烟半径只有 0.1 格，五点足以覆盖
        double[] offsets = {-radius, 0.0D, radius};
        for (int offsetY = 0; offsetY <= SEARCH_RANGE * 2; offsetY++) {
            int below = startY - offsetY;
            double best = Double.NEGATIVE_INFINITY;
            if (below >= level.getMinBuildHeight()) {
                best = highestSurfaceAt(level, x, below, z, offsets);
            }
            if (best == Double.NEGATIVE_INFINITY) {
                int above = startY + offsetY + 1;
                if (above <= level.getMaxBuildHeight() - 1) {
                    best = highestSurfaceAt(level, x, above, z, offsets);
                }
            }
            if (best != Double.NEGATIVE_INFINITY) {
                return best + SURFACE_OFFSET;
            }
        }
        return y;
    }
    
    /**
     * 在同一水平层上，于给定偏移集合内取最高的可立足顶面。
     *
     * @param offsets 相对采样点的水平偏移（格）
     * @return 最高的顶面高度；该层没有任何可立足顶面时返回 {@link Double#NEGATIVE_INFINITY}
     */
    public static double highestSurfaceAt(ClientLevel level, double x, int y, double z, double[] offsets) {
        double best = Double.NEGATIVE_INFINITY;
        for (double dx : offsets) {
            for (double dz : offsets) {
                Double surface = surfaceAt(level, x + dx, y, z + dz);
                if (surface != null && surface > best) {
                    best = surface;
                }
            }
        }
        return best;
    }
    
    /**
     * 判断某一层是否为"可立足的顶面"。
     *
     * @return 该方块顶面的高度（方块 Y + 1）；不满足条件时返回 null
     */
    @Nullable
    public static Double surfaceAt(ClientLevel level, double x, int y, double z) {
        BlockPos pos = new BlockPos(Mth.floor(x), y, Mth.floor(z));
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) {
            return null;
        }
        // 顶面必须稳固（能站人），否则不是"地面"
        if (!state.isFaceSturdy(level, pos, Direction.UP)) {
            return null;
        }
        // 上方必须有空间，否则特效会被埋进方块里
        BlockPos above = pos.above();
        if (!level.getBlockState(above).getCollisionShape(level, above).isEmpty()) {
            return null;
        }
        return (double) (y + 1);
    }
}
