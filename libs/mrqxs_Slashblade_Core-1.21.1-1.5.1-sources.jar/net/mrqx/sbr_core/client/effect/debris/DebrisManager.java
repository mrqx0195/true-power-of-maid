package net.mrqx.sbr_core.client.effect.debris;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxDebrisView;

import java.util.ArrayList;
import java.util.List;
import net.mrqx.sbr_core.client.effect.mesh.ObjMesh;
import org.joml.Vector3f;

/**
 * 玻璃碎片发射管理器：采样偏移与初速度、随机分配形状组，并把分批节奏转为出生延迟。
 * <p>
 * 直接消费 EFX 的 {@link EfxConfig}（摊平成 {@link EfxDebrisView}），缺失属性落回 {@code DEFAULT}，
 * 即"没有该属性就不走那段逻辑"。
 */
public final class DebrisManager {
    
    /**
     * 需要在折射遮罩里出现的碎片粒子：碎片层走独立渲染路径，不经过 {@code MeshEmitterManager} 的跟踪表，
     * 故自建一份，查询时按 {@link DebrisParticle#hasDistortion()} 就地剔除。
     */
    private static final List<DebrisParticle> TRACKED_DISTORTION = new ArrayList<>();

    /** EFX 速度单位为"格 / 帧"，1 tick = 3 帧。 */
    public static final double TICK_TO_FRAME = 3.0D;

    private DebrisManager() {
    }

    /** 以该层自身的随机策略发射（内部摊平配置）。 */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config) {
        spawn(level, origin, new EfxDebrisView(config));
    }

    /** 使用外部随机源发射。 */
    public static void spawn(ClientLevel level, Vec3 origin, EfxConfig config, RandomSource rnd) {
        spawn(level, origin, new EfxDebrisView(config), rnd);
    }

    /** 使用已摊平的视图发射，随机源由 {@link #randomSource} 按该层策略构造。 */
    public static void spawn(ClientLevel level, Vec3 origin, EfxDebrisView view) {
        spawn(level, origin, view, randomSource(view, origin));
    }

    /**
     * 按视图的随机策略构造随机源：ガラス 系列无 {@code EFXAttributeFixRandomGenerator}，恒走真随机，
     * 故每次散落形态都不同；有种子时再以原点坐标做位混合派生。曾用常量种子导致布局逐位相同，勿回归。
     */
    public static RandomSource randomSource(EfxDebrisView view, Vec3 origin) {
        if (view.fixRandomGenerator == null || view.randomSeed == null) {
            return RandomSource.create();
        }
        long seed = view.randomSeed;
        // 触发上下文：原点坐标的位混合（不用 Vec3.hashCode）
        seed = seed * 31L + Double.hashCode(origin.x);
        seed = seed * 31L + Double.hashCode(origin.y);
        seed = seed * 31L + Double.hashCode(origin.z);
        return RandomSource.create(seed);
    }

    /** 使用给定视图与随机源发射：每块碎片依次抽取偏移、初速度，再随机取形状组与实例朝向/尺寸。 */
    public static void spawn(ClientLevel level, Vec3 origin, EfxDebrisView view, RandomSource rnd) {
        int batches = Math.max(1, view.batches);
        int perBatch = Math.max(1, view.count / batches);
        int remainder = view.count % batches;
        for (int batch = 0; batch < batches; batch++) {
            int count = perBatch + (batch < remainder ? 1 : 0);
            float delayTicks = batch * Math.max(0.0F, view.intervalTicks);
            for (int i = 0; i < count; i++) {
                Vector3f offset = sampleOffset(view, rnd);
                double[] velocity = sampleVelocity(offset, view, rnd);
                ObjMesh mesh = DebrisMesh.randomGroupOf(
                        view.meshLocation, rnd, view.startingFrameMin, view.startingFrameMax);
                DebrisParticle particle = new DebrisParticle(
                        level,
                        origin.x + offset.x, origin.y + offset.y, origin.z + offset.z,
                        view, mesh, rnd, delayTicks,
                        velocity[0], velocity[1], velocity[2]);
                Minecraft.getInstance().particleEngine.add(particle);
                // 只有需要写折射遮罩的碎片才入表：碎片层走独立渲染路径，不在此登记则遮罩来源恒为空
                if (view.enableDistortion) {
                    TRACKED_DISTORTION.add(particle);
                }
            }
        }
    }
    
    /**
     * 取当前仍活跃、且启用了折射的碎片粒子（供 {@code DistortionRenderHook} 写折射遮罩）。
     * <p>
     * 剔除口径与 {@code MeshEmitterManager} 一致：{@link DebrisParticle#hasDistortion()} 意为"活着且启用折射"。
     */
    public static List<DebrisParticle> activeDistortionParticles() {
        TRACKED_DISTORTION.removeIf(particle -> !particle.hasDistortion());
        return TRACKED_DISTORTION;
    }

    /**
     * 采样发射偏移（格）：形状 0 盒采样、1 球/椭球内均匀采样、2 圆柱采样
     * （对应 EFX {@code Shape3DType}：0 = Box、1 = Sphere、2 = Cylinder）。
     */
    public static Vector3f sampleOffset(EfxDebrisView view, RandomSource rnd) {
        Vector3f range = view.rangeXYZ;
        if (view.shapeType == 2) {
            // 圆柱：底面半径按面积均匀、高度线性
            double theta = rnd.nextDouble() * Math.PI * 2.0D;
            double radius = Math.sqrt(rnd.nextDouble());
            double height = rnd.nextDouble();
            return new Vector3f(
                    (float) (Math.cos(theta) * radius * range.x),
                    (float) (height * range.y),
                    (float) (Math.sin(theta) * radius * range.z));
        }
        if (view.shapeType == 1) {
            double u = rnd.nextDouble();
            double v = rnd.nextDouble();
            double theta = 2.0D * Math.PI * u;
            double phi = Math.acos(2.0D * v - 1.0D);
            double radius = Math.cbrt(rnd.nextDouble());
            double sinPhi = Math.sin(phi);
            return new Vector3f(
                    (float) (sinPhi * Math.cos(theta) * radius * range.x),
                    (float) (Math.cos(phi) * radius * range.y),
                    (float) (sinPhi * Math.sin(theta) * radius * range.z));
        }
        return new Vector3f(
                (float) ((rnd.nextDouble() * 2.0D - 1.0D) * range.x),
                (float) ((rnd.nextDouble() * 2.0D - 1.0D) * range.y),
                (float) ((rnd.nextDouble() * 2.0D - 1.0D) * range.z));
    }

    /**
     * 采样初速度（格 / tick，按 {@link #TICK_TO_FRAME} 从 EFX 的格 / 帧换算）：径向发射沿偏移方向向外，否则随机方向。
     */
    public static double[] sampleVelocity(Vector3f offset, EfxDebrisView view, RandomSource rnd) {
        double speed = view.speed * TICK_TO_FRAME
                * (1.0D + (rnd.nextDouble() - 0.5D) * 2.0D * view.speedRandom);
        double dx;
        double dy;
        double dz;
        if (view.radial && offset.lengthSquared() > 1.0E-6F) {
            Vector3f direction = new Vector3f(offset).normalize();
            dx = direction.x;
            dy = direction.y;
            dz = direction.z;
        } else {
            double theta = rnd.nextDouble() * Math.PI * 2.0D;
            double phi = Math.acos(2.0D * rnd.nextDouble() - 1.0D);
            double sinPhi = Math.sin(phi);
            dx = sinPhi * Math.cos(theta);
            dy = Math.cos(phi);
            dz = sinPhi * Math.sin(theta);
        }
        return new double[]{dx * speed, dy * speed, dz * speed};
    }
}
