package net.mrqx.sbr_core.client.effect.debris;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * 玻璃碎片的自定义着色器（{@code sbr_core:glass_debris}）。
 * <p>
 * 之所以需要它：玻璃碎片有真实的 ALB（基础色）与 NRM（切线空间法线）两张贴图，
 * 原版粒子着色器只能采样一张贴图、也不做任何法线计算，无法表现玻璃表面的斜向高光与
 * 掠射边缘的透亮感。该着色器同时采样两张贴图，用法线做"固定斜向光 + Fresnel 边缘提亮"的近似。
 * <p>
 * 对应的资源：{@code shaders/core/glass_debris.json/vsh/fsh}。
 */
@EventBusSubscriber(modid = MrqxSlashBladeCore.MODID, value = Dist.CLIENT)
public final class DebrisShaders {
    
    /**
     * 着色器资源 id（对应 {@code shaders/core/glass_debris.json}）。
     */
    public static final ResourceLocation GLASS_DEBRIS = MrqxSlashBladeCore.prefix("glass_debris");
    
    /**
     * 编译后的着色器实例；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    private static ShaderInstance glassDebrisShader;
    
    private DebrisShaders() {
    }
    
    /**
     * 注册着色器（在资源重载时由 NeoForge 调用）。
     */
    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        try {
            event.registerShader(
                new ShaderInstance(event.getResourceProvider(), GLASS_DEBRIS, DefaultVertexFormat.PARTICLE),
                shader -> glassDebrisShader = shader);
        } catch (IOException e) {
            glassDebrisShader = null;
            MrqxSlashBladeCore.LOGGER.error("Failed to load shader: {}", GLASS_DEBRIS, e);
        }
    }
    
    /**
     * 取得玻璃碎片着色器实例。
     * <p>
     * <b>调用方不得关闭该实例</b>：它是全局共享的缓存（资源重载时由 NeoForge 替换为新实例，
     * 旧实例由引擎自行关闭）。{@link ShaderInstance#close()} 会删除 GL program，
     * 对共享实例调用会让之后的所有绘制使用已失效的 program。
     *
     * @return 着色器实例；未加载成功时返回 null（此时回退到原版粒子着色器）
     */
    @Nullable
    public static ShaderInstance shader() {
        return glassDebrisShader;
    }
}
