package net.mrqx.sbr_core.client.effect.debris;

import mods.flammpfeil.slashblade.client.renderer.model.obj.Face;
import mods.flammpfeil.slashblade.client.renderer.model.obj.GroupObject;
import mods.flammpfeil.slashblade.client.renderer.model.obj.ModelFormatException;
import mods.flammpfeil.slashblade.client.renderer.model.obj.WavefrontObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.mesh.ObjMesh;

import javax.annotation.Nullable;
import java.util.*;

/**
 * 碎片网格库：把碎片类 OBJ 的每个形状组分别展开并归一化后缓存，实例随机取组，
 * 实现"N 帧形状序列、每个实例随机选取不同切面"的效果。
 * <p>
 * 玻璃与小石两种变体共用同一套展开 / 归一化逻辑；与われ 共用 {@link ObjMesh}，
 * 区别在于此处按组保留，不把全部组混合成一个网格。逐组归一化是必需的，
 * 否则实例随机取组时会因组间尺寸差异表现为碎片忽大忽小。
 */
public final class DebrisMesh {
    /**
     * 玻璃碎片网格资产（{@code ガラス 大0}），内含 8 个形状组。
     */
    public static final ResourceLocation MODEL_LOCATION =
        MrqxSlashBladeCore.prefix("model/effect/glass_debris.obj");
    
    /**
     * 小石碎片网格资产（{@code 小石メッシュ0}），内含 3 个形状组（玻璃是 8 个），
     * 对应 EFX 的 {@code frameCount = 3}。
     */
    public static final ResourceLocation STONE_LOCATION =
        MrqxSlashBladeCore.prefix("model/effect/stone_debris.obj");
    
    /**
     * 按模型路径缓存的形状组；{@link #FAILED} 另行记录解析失败的模型，避免反复重试。
     */
    private static final Map<ResourceLocation, List<ObjMesh>> CACHE = new HashMap<>();
    
    /**
     * 加载失败的模型（避免重复尝试解析）。
     */
    private static final Set<ResourceLocation> FAILED = new HashSet<>();
    
    private DebrisMesh() {
    }
    
    /**
     * 取指定模型的全部形状组；首次调用时解析并按组归一化，之后走缓存。
     * <p>
     * 解析失败的模型记入 {@link #FAILED}，之后一律返回空列表，不再重复尝试。
     */
    public static List<ObjMesh> groupsOf(ResourceLocation location) {
        List<ObjMesh> cached = CACHE.get(location);
        if (cached != null) {
            return cached;
        }
        if (FAILED.contains(location)) {
            return List.of();
        }
        List<ObjMesh> loaded = load(location);
        if (loaded.isEmpty()) {
            FAILED.add(location);
            CACHE.put(location, List.of());
            return List.of();
        }
        CACHE.put(location, loaded);
        return loaded;
    }
    
    /**
     * 清空全部缓存，供资源包热重载时调用。
     */
    public static void reload() {
        CACHE.clear();
        FAILED.clear();
    }
    
    /**
     * 解析一个碎片模型：把每个形状组独立展开成三角形并归一化到单位尺寸。
     *
     * @return 各形状组；解析失败时记录日志并返回空列表
     */
    public static List<ObjMesh> load(ResourceLocation location) {
        try {
            WavefrontObject wavefront = new WavefrontObject(location);
            List<ObjMesh> loaded = new ArrayList<>();
            for (GroupObject group : wavefront.groupObjects) {
                List<ObjMesh.Triangle> triangles = new ArrayList<>();
                for (Face face : group.faces) {
                    if (face.vertices.length < 3) {
                        continue;
                    }
                    triangles.add(ObjMesh.toTriangle(face, 0, 1, 2));
                    if (face.vertices.length == 4) {
                        triangles.add(ObjMesh.toTriangle(face, 0, 2, 3));
                    }
                }
                if (!triangles.isEmpty()) {
                    loaded.add(new ObjMesh(List.copyOf(triangles)).normalizedToUnit());
                }
            }
            return List.copyOf(loaded);
        } catch (ModelFormatException e) {
            MrqxSlashBladeCore.LOGGER.error("Failed to load debris mesh: {}", location, e);
            return List.of();
        }
    }
    
    /**
     * 在指定起始帧区间内随机取一个形状组（用于实例之间的形状随机化）。
     * <p>
     * {@code frameMin} / {@code frameMax} 对应 EFX {@code EFXAttributeTypeMesh} 的
     * {@code startingFrameMin} / {@code startingFrameMax}：{@code frameCount} 是网格的形状组总数，
     * 而 {@code startingFrameMax} 限定实例只从第 {@code 0 ~ startingFrameMax} 组中随机取起始形状，
     * 越界时按可用组数截断；{@code location} 为 {@code null} 时返回空网格。
     */
    public static ObjMesh randomGroupOf(@Nullable ResourceLocation location, RandomSource rnd, int frameMin, int frameMax) {
        if (location == null) {
            return new ObjMesh(List.of());
        }
        List<ObjMesh> available = groupsOf(location);
        if (available.isEmpty()) {
            return new ObjMesh(List.of());
        }
        int last = available.size() - 1;
        int min = Mth.clamp(Math.min(frameMin, frameMax), 0, last);
        int max = Mth.clamp(Math.max(frameMin, frameMax), 0, last);
        return available.get(min + rnd.nextInt(max - min + 1));
    }
}
