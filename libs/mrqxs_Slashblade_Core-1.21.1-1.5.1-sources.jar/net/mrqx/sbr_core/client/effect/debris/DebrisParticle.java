package net.mrqx.sbr_core.client.effect.debris;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.util.FastColor;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.client.effect.efx.EfxDebrisView;
import net.mrqx.sbr_core.client.effect.efx.EfxMeshView;
import net.mrqx.sbr_core.client.effect.mesh.MeshParticleRenderType;
import net.mrqx.sbr_core.client.effect.mesh.ObjMesh;
import net.mrqx.sbr_core.client.effect.post.DistortionSource;
import net.mrqx.sbr_core.client.effect.util.RefractionDepthScale;
import net.mrqx.sbr_core.client.utils.ParticleUtils;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * 玻璃碎片粒子（ガラス 大0）：随机取一形状组，做"翻滚（角速度衰减）+ 重力下落 + 长时间留存"的写实收尾。
 * 进度以游戏时间对齐（{@code elapsed = 游戏时间差 + partialTick - delay}），翻滚角速度为解析积分（等比数列求和）；
 * 参数取自 {@link EfxDebrisView}（EFX 配置的只读派生视图）；渲染逐三角形写 {@code PARTICLE} 格式 + ALB / NRM 双贴图，
 * 方向光与边缘提亮交由 {@link DebrisShaders}，CPU 侧只写基础色调与透明度。
 */
public class DebrisParticle extends Particle implements DistortionSource {
    /**
     * 强制全亮光照，模拟玻璃自发光不受环境光影响。
     */
    public static final int FULLBRIGHT_LIGHTMAP = 0xF000F0;
    
    /**
     * 1 tick = 3 EFX 帧。
     */
    public static final float TICK_TO_FRAME = 3.0F;
    
    /**
     * 形状组几何（归一化到单位包围盒）。
     */
    protected final ObjMesh mesh;
    
    /**
     * 发射配置视图（构造时已把 EFX 属性摊平成扁平字段）。
     */
    protected final EfxDebrisView view;
    
    /**
     * 出生时的游戏时间。
     */
    protected final long spawnGameTime;
    
    /**
     * 出生延迟（tick）。
     */
    protected final float delayTicks;
    
    /**
     * 初始随机朝向。
     */
    protected final Quaternionf initialRotation = new Quaternionf();
    
    /**
     * 尺寸（格）。
     */
    protected final float scale;
    
    /**
     * 本实例的尺寸增量（格 / tick）：出生时按 {@link EfxDebrisView#sizeAddRandomPerTick} 逐实例抽定，
     * 之后由 {@link #sizeScalarAt} 沿生命期累加；{@code ガラス 大0} 无 {@code ScaleAnim} ⇒ 恒为 0。
     */
    protected final float sizeAdd;
    
    /**
     * 本帧的尺寸标量（1 = 出生尺寸），由 {@link #render} / {@link #buildDistortionQuads} 在开头刷新，
     * 供两个顶点写入方法共用：几何与遮罩必须取<b>同一份</b>标量，否则折射作用范围会与碎片大小错位。
     */
    protected float scaleScalar = 1.0F;
    
    /**
     * 速度分量（格 / tick）。
     */
    protected double vx;
    protected double vy;
    protected double vz;
    
    /**
     * 本片的翻滚角速度（<b>度 / EFX 帧</b>），出生时抽定，见构造器。
     */
    protected final float spinX;
    protected final float spinY;
    protected final float spinZ;
    
    /**
     * 创建一块玻璃碎片。
     */
    public DebrisParticle(ClientLevel level, double x, double y, double z,
                          EfxDebrisView view, ObjMesh mesh, RandomSource rnd, float delayTicks,
                          double vx, double vy, double vz) {
        super(level, x, y, z);
        this.view = view;
        this.mesh = mesh;
        this.spawnGameTime = level.getGameTime();
        this.delayTicks = Math.max(0.0F, delayTicks);
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        // 随机抽取顺序固定：先尺寸、再尺寸增量、最后三轴朝向（逐实例序列因此可复现）
        this.scale = Math.max(0.01F, view.scale * (1.0F + (rnd.nextFloat() - 0.5F) * 2.0F * view.scaleRandom));
        this.sizeAdd = view.sizeAddPerTick
            + (rnd.nextFloat() - 0.5F) * 2.0F * view.sizeAddRandomPerTick;
        this.initialRotation.rotationXYZ(
            rnd.nextFloat() * (float) Math.PI * 2.0F,
            rnd.nextFloat() * (float) Math.PI * 2.0F,
            rnd.nextFloat() * (float) Math.PI * 2.0F);
        // 翻滚角速度逐片抽一次（基准 + 随机全宽 ×（随机 − 0.5））：
        // 碎片层的数据把角速度整段放在随机全宽里（基准为 0），整层共用一个值会让"一堆碎片乱翻"变成"整块一起转"
        this.spinX = view.spinX + (rnd.nextFloat() - 0.5F) * view.spinXVariation;
        this.spinY = view.spinY + (rnd.nextFloat() - 0.5F) * view.spinYVariation;
        this.spinZ = view.spinZ + (rnd.nextFloat() - 0.5F) * view.spinZVariation;
        this.lifetime = Mth.ceil(view.totalTicks()) + 2;
        this.hasPhysics = false;
        this.gravity = 0.0F;
    }
    
    /**
     * 当前动画进度（tick，含帧间插值）；小于 0 表示仍在出生延迟期。
     */
    public float elapsedTicks(float partialTicks) {
        return (float) (this.level.getGameTime() - this.spawnGameTime) + partialTicks - this.delayTicks;
    }
    
    /**
     * 当前的尺寸标量（生命期尺寸曲线）：出生为 1，逐 tick 累加并按系数衰减；总量用等比级数求和，
     * 与 {@code PolygonParticle#integrateSize} 同一口径，系数已由视图折算为每 tick。
     *
     * @return 尺寸缩放标量；不小于 0（负值会让网格翻转，视觉上等同于消失）
     */
    protected float sizeScalarAt(float elapsed) {
        if (this.sizeAdd == 0.0F) {
            return 1.0F;
        }
        float coef = Mth.clamp(this.view.sizeAddCoefPerTick, 0.0F, 1.0F);
        float total;
        if (coef >= 1.0F) {
            total = this.sizeAdd * elapsed;
        } else if (coef <= 0.0F) {
            total = this.sizeAdd;
        } else {
            total = this.sizeAdd * (1.0F - (float) Math.pow(coef, elapsed)) / (1.0F - coef);
        }
        return Math.max(0.0F, 1.0F + total);
    }
    
    @Override
    public void tick() {
        float elapsed = this.elapsedTicks(0.0F);
        if (elapsed < 0.0F) {
            return;
        }
        if (elapsed > this.view.totalTicks()) {
            this.remove();
            return;
        }
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        this.x += this.vx;
        this.y += this.vy;
        this.z += this.vz;
        this.vy -= this.view.gravityRate;
        // 空气阻力：EFX Velocity3D.SpeedCoef（视图已折算为每 tick 系数）
        float decay = Mth.clamp(this.view.speedDecay, 0.0F, 1.0F);
        if (decay < 1.0F) {
            this.vx *= decay;
            this.vy *= decay;
            this.vz *= decay;
        }
    }
    
    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        float elapsed = this.elapsedTicks(partialTicks);
        if (elapsed < 0.0F || elapsed > this.view.totalTicks() || this.mesh.triangles().isEmpty()) {
            return;
        }
        this.scaleScalar = this.sizeScalarAt(elapsed);
        float alpha = this.lifeAlpha(elapsed) * FastColor.ARGB32.alpha(this.view.color) / 255.0F;
        if (alpha <= 0.0F) {
            return;
        }
        
        Vec3 camPos = camera.getPosition();
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - camPos.x);
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - camPos.y);
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - camPos.z);
        // 距离淡出：口径同网格 / 面片路径
        alpha *= ParticleUtils.distanceAlpha(px, py, pz, this.view.fadeNearEnd, this.view.fadeNearStart, this.view.fadeFarEnd, this.view.fadeFarStart);
        if (alpha <= 0.0F) {
            return;
        }
        
        Quaternionf rotation = this.rotationAt(elapsed);
        // 顶点色只承载"基础色调 × 亮度"；表面方向光与边缘掠射提亮由片元着色器采样 NRM 完成
        float intensity = this.view.intensity;
        float r = Mth.clamp(FastColor.ARGB32.red(this.view.color) / 255.0F * intensity, 0.0F, 1.0F);
        float g = Mth.clamp(FastColor.ARGB32.green(this.view.color) / 255.0F * intensity, 0.0F, 1.0F);
        float b = Mth.clamp(FastColor.ARGB32.blue(this.view.color) / 255.0F * intensity, 0.0F, 1.0F);
        
        for (ObjMesh.Triangle triangle : this.mesh.triangles()) {
            putVertex(buffer, triangle.p0(), triangle.u0(), triangle.v0(), rotation, px, py, pz, r, g, b, alpha);
            putVertex(buffer, triangle.p1(), triangle.u1(), triangle.v1(), rotation, px, py, pz, r, g, b, alpha);
            putVertex(buffer, triangle.p2(), triangle.u2(), triangle.v2(), rotation, px, py, pz, r, g, b, alpha);
        }
    }
    
    /**
     * 翻滚朝向：角速度按 EFX「度 / 帧」记录并随各自的 {@code spinDecay*} 逐 tick 衰减，累计转角取等比数列求和。
     */
    protected Quaternionf rotationAt(float elapsed) {
        return new Quaternionf(this.initialRotation)
            .rotateX(toRadians(integrateSpin(this.spinX, this.view.spinDecayX, elapsed)))
            .rotateY(toRadians(integrateSpin(this.spinY, this.view.spinDecayY, elapsed)))
            .rotateZ(toRadians(integrateSpin(this.spinZ, this.view.spinDecayZ, elapsed)));
    }
    
    /**
     * 累计转角（度）：{@code Σ 每 tick 角速度 × decay^k}，decay 为每 tick 衰减系数。
     * <p>
     * ⚠ 三轴各有自己的 decay（数据里 X/Z 常是 `0.95`、Y 常是 `1`），故必须逐轴传入，不能共用一个。
     */
    protected float integrateSpin(float degPerFrame, float decayPerTick, float elapsed) {
        float perTick = degPerFrame * TICK_TO_FRAME;
        float decay = Mth.clamp(decayPerTick, 0.0F, 1.0F);
        if (decay >= 1.0F) {
            return perTick * elapsed;
        }
        if (decay <= 0.0F) {
            return perTick;
        }
        return perTick * (1.0F - (float) Math.pow(decay, elapsed)) / (1.0F - decay);
    }
    
    /**
     * 生命三段（Appear / Keep / Vanish）的不透明度。
     */
    protected float lifeAlpha(float elapsed) {
        if (elapsed < this.view.appearTicks) {
            return this.view.appearTicks <= 0.0F
                ? 1.0F
                : Mth.clamp(elapsed / this.view.appearTicks, 0.0F, 1.0F);
        }
        float keepEnd = this.view.appearTicks + this.view.keepTicks;
        if (elapsed < keepEnd) {
            return 1.0F;
        }
        return this.view.vanishTicks <= 0.0F
            ? 0.0F
            : Mth.clamp(1.0F - (elapsed - keepEnd) / this.view.vanishTicks, 0.0F, 1.0F);
    }
    
    /**
     * 写入单个顶点（相机相对坐标）。
     */
    protected void putVertex(VertexConsumer buffer, Vector3f p, float u, float v,
                             Quaternionf rotation, float px, float py, float pz,
                             float r, float g, float b, float alpha) {
        // 逐轴比例：scaleY / scaleZ 相对 scaleX 决定"薄片"形状，不能当等比缩放
        Vector3f world = new Vector3f(p.x, p.y * view.scaleYAspect, p.z * view.scaleZAspect)
            .mul(this.scale * this.scaleScalar).rotate(rotation).add(px, py, pz);
        buffer.addVertex(world.x, world.y, world.z)
            .setColor(r, g, b, alpha)
            .setUv(u, v)
            .setLight(FULLBRIGHT_LIGHTMAP);
    }
    
    @Override
    public ParticleRenderType getRenderType() {
        // 贴图随层走：两支类型共用同一支着色器与渲染状态，只有贴图 / 法线不同；写死 GLASS 会让石头顶着玻璃的贴图
        return DebrisMesh.STONE_LOCATION.equals(this.view.meshLocation)
            ? MeshParticleRenderType.STONE
            : MeshParticleRenderType.GLASS;
    }
    
    @Override
    public boolean hasDistortion() {
        return this.view.enableDistortion && !this.removed;
    }
    
    /**
     * 把碎片的几何写进<b>屏幕空间折射遮罩</b>（顶点格式与 RGBA 约定见 {@link DistortionSource}）：几何与
     * {@link #render} 完全一致，故折射的作用范围与碎片画出来的范围是同一件事。碎片走独立渲染路径（不经
     * {@code GenericMeshParticle}），须自行补遮罩几何；
     * 偏移方向<b>取负</b>（直接用法线投影会让凸透镜表现成凹），折射为负时整体反向；B 通道碎片层恒为 0。
     * A 通道写的是<b>已乘视深标度</b>的强度（见 {@link RefractionDepthScale}）。
     */
    @Override
    public void buildDistortionQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
        float elapsed = this.elapsedTicks(partialTicks);
        if (elapsed < 0.0F || elapsed > this.view.totalTicks() || this.mesh.triangles().isEmpty()) {
            return;
        }
        this.scaleScalar = this.sizeScalarAt(elapsed);
        float lifeAlpha = this.lifeAlpha(elapsed);
        if (lifeAlpha <= 0.0F) {
            return;
        }
        float refraction = Mth.clamp(
            Math.abs(this.view.distortionRefractive) / EfxMeshView.REFRACTIVE_FULL_STRENGTH,
            0.0F, 1.0F) * lifeAlpha;
        float lensSign = this.view.distortionRefractive < 0.0F ? -1.0F : 1.0F;
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - camPos.x);
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - camPos.y);
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - camPos.z);
        Quaternionf rotation = this.rotationAt(elapsed);
        // 视深因子折进 A 通道：该族材质的折射偏移与视深成反比，而后处理的 Strength 是逐帧常量、
        // 吸收不了逐像素的深度（详见 RefractionDepthScale）。碎片中心离屏距离即深度标度的依据。
        float depthScale = RefractionDepthScale.factorOf(px, py, pz);
        int alpha = (int) (Mth.clamp(refraction * depthScale, 0.0F, 1.0F) * 255.0F);
        for (ObjMesh.Triangle triangle : this.mesh.triangles()) {
            Vector3f normal = new Vector3f(triangle.normal()).rotate(rotation).normalize();
            float dx = -normal.dot(camRight) * lensSign;
            float dy = -normal.dot(camUp) * lensSign;
            int rCol = (int) (Mth.clamp(dx * 0.5F + 0.5F, 0.0F, 1.0F) * 255.0F);
            int gCol = (int) (Mth.clamp(dy * 0.5F + 0.5F, 0.0F, 1.0F) * 255.0F);
            putMaskVertex(buffer, triangle.p0(), rotation, px, py, pz, rCol, gCol, 0, alpha);
            putMaskVertex(buffer, triangle.p1(), rotation, px, py, pz, rCol, gCol, 0, alpha);
            putMaskVertex(buffer, triangle.p2(), rotation, px, py, pz, rCol, gCol, 0, alpha);
        }
    }
    
    /**
     * 写入单个遮罩顶点（相机相对坐标）：变换与 {@link #putVertex} 逐项一致，格式降为遮罩用的 {@code PARTICLE}。
     */
    @SuppressWarnings("SameParameterValue")
    protected void putMaskVertex(VertexConsumer buffer, Vector3f p, Quaternionf rotation,
                                 float px, float py, float pz, int r, int g, int b, int a) {
        Vector3f world = new Vector3f(p.x, p.y * this.view.scaleYAspect, p.z * this.view.scaleZAspect)
            .mul(this.scale * this.scaleScalar).rotate(rotation).add(px, py, pz);
        // 与面片粒子共用 PARTICLE 顶点格式，UV0 / UV2 缺一个就会在 endLastVertex 抛 "Missing elements in vertex"；
        // 碎片没有形状贴图，绘制侧绑的是全白图，故两者给 0 即可
        buffer.addVertex(world.x, world.y, world.z)
            .setUv(0.0F, 0.0F)
            .setUv2(0, 0)
            .setColor(r, g, b, a);
    }
    
    /**
     * 角度转弧度（内部工具）。
     */
    protected static float toRadians(float degrees) {
        return degrees * 0.017453292F;
    }
}
