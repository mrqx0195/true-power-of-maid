package net.mrqx.sbr_core.client.effect.post;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * 屏幕空间遮罩的自定义着色器（{@code sbr_core:mask_particle}）：把来源的顶点色乘上<b>该来源贴图的 alpha</b> 后写入遮罩。
 * <p>
 * <b>为什么需要它</b>：遮罩的形状必须跟着贴图走。弧线刀光的形状全部来自贴图 alpha，只按几何写遮罩得到的是一个
 * 实心四边形——实测观感是"有棱有角的片状折射"，且强度不随贴图 alpha 变化。网格类来源没有形状贴图、强度由
 * 逐顶点几何权重给出，故它们绑白图，乘 1 即原样通过。
 * <p>
 * 顶点格式与面片粒子共用 {@link DefaultVertexFormat#PARTICLE}，遮罩几何因此可直接复用粒子侧算出的 UV。
 */
@EventBusSubscriber(modid = MrqxSlashBladeCore.MODID, value = Dist.CLIENT)
public final class MaskParticleShaders {
    /**
     * 着色器资源 id。
     */
    public static final ResourceLocation MASK_PARTICLE = MrqxSlashBladeCore.prefix("mask_particle");
    
    /**
     * 编译后的着色器实例；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    private static ShaderInstance maskParticleShader;
    
    private MaskParticleShaders() {
    }
    
    /**
     * 注册着色器（资源重载时由 NeoForge 调用）。
     */
    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        try {
            event.registerShader(
                new ShaderInstance(event.getResourceProvider(), MASK_PARTICLE, DefaultVertexFormat.PARTICLE),
                shader -> maskParticleShader = shader);
        } catch (IOException e) {
            maskParticleShader = null;
            MrqxSlashBladeCore.LOGGER.error("加载遮罩着色器失败: {}", MASK_PARTICLE, e);
        }
    }
    
    /**
     * 取得遮罩着色器实例。
     * <p>
     * <b>调用方不得关闭该实例</b>：它是全局共享的缓存，{@link ShaderInstance#close()} 会删除 GL program，
     * 对共享实例调用会让之后的所有绘制使用已失效的 program。
     *
     * @return 着色器实例；未加载成功时返回 null，此时调用方应整帧跳过遮罩绘制
     */
    @Nullable
    public static ShaderInstance shader() {
        return maskParticleShader;
    }
}
