package net.mrqx.sbr_core.client.effect.post;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * 屏幕空间遮罩的几何来源：实现本接口的粒子（{@code TypeMesh} / {@code TypePolygon} 等）由
 * {@code DistortionRenderHook} 在 {@code AFTER_PARTICLES} 阶段写进遮罩缓冲；顶点格式
 * {@code PARTICLE}、顶点为<b>相机相对坐标</b>（与粒子渲染同一空间）；该格式含 UV0 与 UV2，遮罩用 UV0 采样
 * <b>形状贴图</b>（见 {@link #maskTexture()}）、UV2 恒为 0。
 * <p>
 * 三条通道各占一张缓冲，但共用 {@code dis_ware_distortion} 链，故任一通道有内容时整条链
 * 本帧都要执行；通道 RGBA 约定如下：
 * <ul>
 *   <li>折射（{@link #buildDistortionQuads}）：RG 屏幕偏移方向（0~1 映射自 -1~1）、
 *       B 放大倍率增量（zoom − 1）、A 折射强度<b>乘以视深标度</b>
 *       （该族材质的偏移与视深成反比，而消费侧的 {@code Strength} 是逐帧常量，只能由写入侧逐顶点折算）；</li>
 *   <li>滤镜（{@link #buildFilterQuads}）：RGB 目标色、A 强度；</li>
 *   <li>增益（{@link #buildScreenGradingQuads}）：RGB 增益色、A 融合权重。</li>
 * </ul>
 * <b>实现时须成对做</b>：只有被汇入 {@code MeshEmitterManager} 等来源列表的粒子才会被绘制，不汇入则遮罩恒为空。
 */
public interface DistortionSource {
    /**
     * 该来源是否仍需参与折射遮罩绘制（活跃<b>且</b>启用了折射）；<b>不能</b>单独用作"是否还活着"
     * 的判据——只做滤镜 / 增益的层恒为 false，但必须留在跟踪表里。
     */
    boolean hasDistortion();
    
    /**
     * 该来源是否仍需参与滤镜遮罩绘制，与 {@link #hasDistortion()} 相互独立（可只做其中一条）。
     * <b>默认返回 false</b>：不重写即完全不参与滤镜通道（本项目面片路径 {@code PolygonParticle} 即如此）。
     */
    default boolean hasColorFilter() {
        return false;
    }
    
    /**
     * 把本来源的几何写入<b>折射遮罩</b>缓冲，不写即本帧无折射（RGBA 含义见类注释）。
     *
     * @param buffer   遮罩缓冲（{@code PARTICLE} 格式；UV0 承载形状贴图的采样坐标、UV2 恒为 0）
     * @param camPos   相机世界坐标
     * @param camRight 相机屏幕右方向的世界基向量（单位向量）
     * @param camUp    相机屏幕上方向的世界基向量（单位向量）
     */
    void buildDistortionQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks);
    
    /**
     * 把本来源的几何写入<b>滤镜遮罩</b>缓冲：RGB 写滤镜目标色，A 写
     * {@code 透镜空间权重 × 滤镜强度 × 生命不透明度}；几何与权重口径须与 {@link #buildDistortionQuads}
     * <b>完全相同</b>（同一批四边形），参数含义亦同；<b>默认实现为空</b>，不重写即无滤镜。
     */
    default void buildFilterQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
    }
    
    /**
     * 该来源是否仍需参与<b>逐通道增益</b>（{@code カラコレ}）遮罩绘制，与另两条通道相互独立：
     * 它是"逐通道乘性增益 + 色散"，与滤镜的"向目标色收敛"语义不同，故另开一张缓冲。
     * <b>默认返回 false</b>，不重写即不参与该通道。
     */
    default boolean hasScreenGrading() {
        return false;
    }
    
    /**
     * 把本来源的几何写入<b>增益遮罩</b>缓冲：RGB 写增益目标色（{@code ColorParam.rgb}），
     * A 写 {@code w × (N·V)^p × 生命不透明度}（球心方向最大，与顶点侧 {@code pow(1 − N·V, p)} 相反），
     * 后处理侧据此做 {@code scene *= 1 + A·(rgb − 1)}；参数含义同 {@link #buildDistortionQuads}。
     * <b>默认实现为空</b>，不重写即该来源不写增益遮罩。
     */
    default void buildScreenGradingQuads(VertexConsumer buffer, Vec3 camPos, Vector3f camRight, Vector3f camUp, float partialTicks) {
    }
    
    /**
     * 本来源写入遮罩时要绑定的<b>形状贴图</b>；{@code null} 表示顶点色原样写入、不乘贴图 alpha。
     * <p>
     * 面片类来源的形状完全由贴图 alpha 决定（弧线刀光、模糊面片），必须返回它——否则写进遮罩的只是一个实心
     * 四边形，观感上"有棱有角"，且强度不随贴图 alpha 变化；网格类来源的强度由几何权重逐顶点给出、没有"形状
     * 贴图"，返回 {@code null}，绘制侧会绑白图使采样恒为 1。
     *
     * @return 形状贴图；{@code null} 表示不采样
     */
    @Nullable
    default ResourceLocation maskTexture() {
        return null;
    }
}
