package net.mrqx.sbr_core.client.effect.post;

import com.mojang.blaze3d.pipeline.RenderTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.mixin.client.AccessorPostChain;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * LUT 色彩校正（EFX 层 ☆カラコレ）：用立方 LUT 对全屏画面做短暂的色调映射。
 * <p>
 * EFX 里这一层是"不绘制"粒子携带 {@code via.effect.script.EffectColorCorrect} 行为，这里等价实现为全屏 PostChain。
 * <p>
 * 两个 pass 全部在 Java 侧添加：{@link PostChain} 只暴露 {@link PostChain#addPass} 的返回值
 * （{@link PostPass#getEffect()}），而 LUT 纹理必须在运行时绑到 sampler 上。
 */
public final class LutColorCorrectionPostEffect implements PostEffect {
    /**
     * 单例。
     */
    public static final LutColorCorrectionPostEffect INSTANCE = new LutColorCorrectionPostEffect();
    
    /**
     * PostChain 资源 id（对应 {@code shaders/post/lut_color_correction.json}）。
     */
    public static final ResourceLocation CHAIN_ID = MrqxSlashBladeCore.prefix("shaders/post/lut_color_correction.json");
    
    /**
     * 默认的立方 LUT 贴图 {@code tex_03_lut_000_0001}。
     * <p>
     * 收尾段的「カラコレ」用<b>另一张</b> {@code tex_03_lut_000_0006}，由
     * {@link #trigger(int, int, int, ResourceLocation)} 逐层指定——{@code Cube2Texture}
     * 参数本来就是逐层给出的。两张 png 都是 256×128 的立方 LUT 图集
     * （32 片 32×32 按 8 列 4 行拼成）。
     */
    public static final ResourceLocation DEFAULT_LUT =
        MrqxSlashBladeCore.prefix("textures/effect/tex_03_lut_000_0001.png");
    
    /**
     * 着色器中 LUT 采样器的名字（见 {@code shaders/program/lut_color_correction.json}）。
     */
    public static final String LUT_SAMPLER = "LutSampler";
    
    /**
     * 调色 pass 的 program 名。
     */
    public static final String GRADING_PASS = "sbr_core:lut_color_correction";
    
    /**
     * 回写 pass 复用原版的 blit program。
     */
    public static final String BLIT_PASS = "minecraft:blit";
    
    /**
     * 临时渲染目标名（与 post json 的 targets 一致）。
     */
    public static final String SWAP_TARGET = "swap";
    
    /**
     * 已加载的后处理链；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    private PostChain chain;
    
    /**
     * 效果结束时的游戏时间。
     */
    private long endGameTime;
    
    /**
     * 本次效果的起始游戏时间与三段时长（EFX {@code Life} 的 Appear / Keep / Vanish，单位 tick）。
     */
    private long startGameTime;
    private int appearTicks;
    private int keepTicks;
    private int vanishTicks;
    
    /**
     * 本层 EFX {@code Cube2BlendRateMax}：混合率上限，<b>允许大于 1</b>（见 {@link #trigger(int, int, int, ResourceLocation, float)}）。
     */
    private float blendRateMax = 1.0F;
    
    /**
     * 本次效果使用的 LUT 贴图。
     * <p>
     * 采样器绑定的是"取纹理 id 的供应器"、每帧求值，因此换一张 LUT 只需改这个字段，
     * 下一帧即生效，无需重建后处理链。
     */
    public ResourceLocation currentLut = DEFAULT_LUT;
    
    /**
     * 最近一次 resize 的宽高。
     */
    private int lastWidth = -1;
    private int lastHeight = -1;
    
    private LutColorCorrectionPostEffect() {
    }
    
    /**
     * 触发一次 LUT 色彩校正（无渐变，整体算作保持段）。
     *
     * @param durationTicks 持续 tick 数
     */
    public static void trigger(int durationTicks) {
        trigger(0, durationTicks, 0);
    }
    
    /**
     * 触发一次 LUT 色彩校正，按 EFX {@code Life} 的三段做渐入渐出。
     * <p>
     * {@code LutBlendRate=1} 表示"完全应用 LUT"，包络是乘在它上面的强度系数。
     *
     * @param appearTicks 渐入段（tick）
     * @param keepTicks   满强度段（tick）
     * @param vanishTicks 渐出段（tick）
     */
    public static void trigger(int appearTicks, int keepTicks, int vanishTicks) {
        trigger(appearTicks, keepTicks, vanishTicks, DEFAULT_LUT);
    }
    
    /**
     * 触发一次 LUT 色彩校正，并指定本层使用的 LUT 贴图与混合率上限。
     * <p>
     * 贴图必须逐层传入：{@code Cube2Texture} 是逐层给出的，
     * 共用一张会让后触发的那层把前一层的 LUT 顶掉。
     *
     * @param appearTicks   渐入段（tick）
     * @param keepTicks     满强度段（tick）
     * @param vanishTicks   渐出段（tick）
     * @param lut           本层使用的 LUT 贴图
     * @param blendRateMax  该层的 EFX {@code Cube2BlendRateMax}：乘在强度包络上的混合率上限，
     *                      <b>允许大于 1</b>（数据里 {@code カラコレ} 是 {@code 1.25}，表示比"完全应用"再多一点）
     */
    public static void trigger(int appearTicks, int keepTicks, int vanishTicks, @Nullable ResourceLocation lut,
                              float blendRateMax) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        // 该层没给出 LUT 时退回默认那张，而不是让采样器指向 null
        INSTANCE.currentLut = lut != null ? lut : DEFAULT_LUT;
        INSTANCE.blendRateMax = blendRateMax;
        long now = minecraft.level.getGameTime();
        INSTANCE.startGameTime = now;
        INSTANCE.appearTicks = Math.max(0, appearTicks);
        INSTANCE.keepTicks = Math.max(0, keepTicks);
        INSTANCE.vanishTicks = Math.max(0, vanishTicks);
        int total = INSTANCE.appearTicks + INSTANCE.keepTicks + INSTANCE.vanishTicks;
        INSTANCE.endGameTime = now + Math.max(1, total);
    }
    
    /**
     * 触发一次 LUT 色彩校正，并指定本层使用的 LUT 贴图（混合率上限按 1 处理）。
     *
     * @param appearTicks 渐入段（tick）
     * @param keepTicks   满强度段（tick）
     * @param vanishTicks 渐出段（tick）
     * @param lut         本层使用的 LUT 贴图
     */
    public static void trigger(int appearTicks, int keepTicks, int vanishTicks, @Nullable ResourceLocation lut) {
        trigger(appearTicks, keepTicks, vanishTicks, lut, 1.0F);
    }
    
    /**
     * 当前强度包络（0~1）：Appear 渐入 → Keep 满强度 → Vanish 渐出。
     *
     * @param elapsedTicks 已经过的 tick 数
     * @return 0~1 的强度系数
     */
    public float envelope(float elapsedTicks) {
        if (elapsedTicks < 0.0F) {
            return 0.0F;
        }
        if (elapsedTicks < this.appearTicks) {
            return this.appearTicks <= 0 ? 1.0F : elapsedTicks / (float) this.appearTicks;
        }
        float keepEnd = (float) (this.appearTicks + this.keepTicks);
        if (elapsedTicks < keepEnd) {
            return 1.0F;
        }
        if (this.vanishTicks <= 0) {
            return 1.0F;
        }
        return Math.max(0.0F, 1.0F - (elapsedTicks - keepEnd) / (float) this.vanishTicks);
    }
    
    @Override
    public String id() {
        return "lut_color_correction";
    }
    
    @Override
    public void reload(ResourceManager resourceManager) {
        this.close();
        Minecraft minecraft = Minecraft.getInstance();
        try {
            this.chain = new PostChain(minecraft.getTextureManager(), resourceManager,
                minecraft.getMainRenderTarget(), CHAIN_ID);
            this.buildPasses(minecraft);
            int width = minecraft.getWindow().getWidth();
            int height = minecraft.getWindow().getHeight();
            this.chain.resize(width, height);
            this.lastWidth = width;
            this.lastHeight = height;
        } catch (Exception e) {
            MrqxSlashBladeCore.LOGGER.error("加载 LUT 色彩校正后处理链失败: {}", CHAIN_ID, e);
            this.chain = null;
        }
    }
    
    /**
     * 装配两个 pass：调色（{@code main} → {@code swap}）与回写（{@code swap} → {@code main}）。
     * <p>
     * 调色 pass 建立后立刻把 LUT 贴图绑到 {@link #LUT_SAMPLER} 上——绑定的是"纹理 id 的供应器"，
     * 每帧求值，因此资源包重载换掉贴图也会跟着更新。
     *
     * @param minecraft 客户端实例（提供主渲染目标）
     */
    public void buildPasses(Minecraft minecraft) throws IOException {
        PostChain currentChain = this.chain;
        if (currentChain == null) {
            return;
        }
        RenderTarget swap = currentChain.getTempTarget(SWAP_TARGET);
        RenderTarget main = minecraft.getMainRenderTarget();
        PostPass grading = currentChain.addPass(GRADING_PASS, main, swap, true);
        grading.getEffect().setSampler(LUT_SAMPLER, this::lutTextureId);
        currentChain.addPass(BLIT_PASS, swap, main, true);
    }
    
    /**
     * 取 LUT 贴图的 GL 纹理 id（首次访问时由纹理管理器加载）。
     *
     * @return 纹理 id；纹理不可用时返回 0（等价于不采样）
     */
    public int lutTextureId() {
        AbstractTexture texture = Minecraft.getInstance().getTextureManager().getTexture(this.currentLut);
        return texture.getId();
    }
    
    @Override
    public void close() {
        if (this.chain != null) {
            this.chain.close();
            this.chain = null;
        }
    }
    
    @Override
    public void composite(float partialTick) {
        if (this.chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.level.getGameTime() >= this.endGameTime) {
            return;
        }
        this.checkResize();
        // 强度包络（Appear 渐入 / Keep 满强度 / Vanish 渐出）× 该层的 Cube2BlendRateMax（可 > 1，由着色器外插）；
        // 带上 partialTick，否则渐入渐出会呈 20Hz 的阶梯
        float intensity = this.envelope(
            (float) (minecraft.level.getGameTime() - this.startGameTime) + partialTick);
        if (intensity <= 0.0F) {
            return;
        }
        float blendRate = intensity * this.blendRateMax;
        ((AccessorPostChain) this.chain).getPasses().stream()
            .filter(postPass -> postPass.getName().equals(GRADING_PASS))
            .map(PostPass::getEffect).findAny()
            .ifPresent(effect -> effect.safeGetUniform("LutBlendRate").set(blendRate));
        this.chain.process(partialTick);
    }
    
    /**
     * 窗口尺寸变化时同步调整后处理链尺寸。
     */
    public void checkResize() {
        if (this.chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.getWindow().getWidth();
        int height = minecraft.getWindow().getHeight();
        if (width != this.lastWidth || height != this.lastHeight) {
            this.chain.resize(width, height);
            this.lastWidth = width;
            this.lastHeight = height;
        }
    }
}
