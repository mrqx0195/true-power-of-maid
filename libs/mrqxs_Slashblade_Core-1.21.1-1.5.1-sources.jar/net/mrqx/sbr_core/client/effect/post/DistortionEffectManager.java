package net.mrqx.sbr_core.client.effect.post;

import com.mojang.blaze3d.pipeline.RenderTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EffectInstance;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.mixin.client.AccessorPostChain;

import javax.annotation.Nullable;

/**
 * 屏幕空间遮罩的后处理链生命周期管理器：负责 {@link PostChain} 的加载、尺寸跟随、逐帧合成与资源释放，
 * 只被 {@link DistortionRenderHook} 在客户端渲染流程中驱动。三条遮罩通道共用同一条
 * {@code dis_ware_distortion} 链，只要任一通道有内容本帧整条链就必须执行，故 {@link #markActive()} 不区分通道。
 */
public final class DistortionEffectManager {
    /**
     * PostChain 资源 id，对应 {@code shaders/post/dis_ware_distortion.json}
     */
    public static final ResourceLocation CHAIN_ID = MrqxSlashBladeCore.prefix("shaders/post/dis_ware_distortion.json");
    
    /**
     * 折射遮罩缓冲名（PostChain 的 targets 声明）：R/G = 偏移方向、B = zoom−1、A = 透镜空间权重
     */
    public static final String DISTORTION_TARGET = "distortion";
    
    /**
     * 材质色彩滤镜遮罩缓冲名：RGB = 滤镜目标色、A = 该像素的滤镜强度
     */
    public static final String FILTER_TARGET = "filter";
    
    /**
     * 逐通道增益遮罩缓冲名：RGB = 增益目标色、A = 乘积权重；与 {@link #FILTER_TARGET} 的代数形式不同，故另开一张缓冲
     */
    public static final String GRADING_TARGET = "grading";
    
    /**
     * 主 pass 名（{@code shaders/post/dis_ware_distortion.json} 的 {@code passes[0].name}）；逐层 uniform 写到它的实例上
     */
    public static final String DISTORTION_PASS = "sbr_core:dis_ware_distortion";
    
    /**
     * 已加载的后处理链；为 null 表示尚未加载或加载失败
     */
    @Nullable
    private static PostChain chain;
    
    /**
     * 折射遮罩缓冲（声明名 {@code distortion}）
     */
    @Nullable
    private static RenderTarget distortionTarget;
    
    /**
     * 材质色彩滤镜遮罩缓冲（声明名 {@code filter}）
     */
    @Nullable
    private static RenderTarget filterTarget;
    
    /**
     * 逐通道增益遮罩缓冲（声明名 {@code grading}）
     */
    @Nullable
    private static RenderTarget gradingTarget;
    
    /**
     * 主 pass 的着色器实例，供逐层 uniform 写入；为 null 表示未解析到
     */
    @Nullable
    private static EffectInstance distortionEffect;
    
    /**
     * 本帧是否已有遮罩来源（任一通道），决定 {@link #composite} 是否执行
     */
    private static boolean activeThisFrame;
    
    /**
     * 最近一次 resize 的宽高，用于检测窗口尺寸变化
     */
    private static int lastWidth = -1;
    private static int lastHeight = -1;
    
    private DistortionEffectManager() {
    }
    
    /**
     * 重新加载后处理链：按 CHAIN_ID 重建、随当前窗口尺寸 resize，并缓存三张遮罩缓冲与主 pass
     */
    public static void reload(ResourceManager resourceManager) {
        close();
        Minecraft minecraft = Minecraft.getInstance();
        try {
            chain = new PostChain(minecraft.getTextureManager(), resourceManager, minecraft.getMainRenderTarget(), CHAIN_ID);
            int width = minecraft.getWindow().getWidth();
            int height = minecraft.getWindow().getHeight();
            chain.resize(width, height);
            lastWidth = width;
            lastHeight = height;
            distortionTarget = chain.getTempTarget(DISTORTION_TARGET);
            filterTarget = chain.getTempTarget(FILTER_TARGET);
            gradingTarget = chain.getTempTarget(GRADING_TARGET);
            // 缓存 EffectInstance：逐层 uniform 每帧每粒子都要写，不宜每次都遍历 passes 查找
            distortionEffect = ((AccessorPostChain) chain).getPasses().stream()
                .filter(postPass -> postPass.getName().equals(DISTORTION_PASS))
                .map(PostPass::getEffect)
                .findAny()
                .orElse(null);
        } catch (Exception e) {
            MrqxSlashBladeCore.LOGGER.error("加载次元斩畸变后处理链失败: {}", CHAIN_ID, e);
            chain = null;
            distortionTarget = null;
            filterTarget = null;
            gradingTarget = null;
            distortionEffect = null;
        }
    }
    
    /**
     * 关闭并释放后处理链
     */
    public static void close() {
        if (chain != null) {
            chain.close();
            chain = null;
            distortionTarget = null;
            filterTarget = null;
            gradingTarget = null;
            distortionEffect = null;
        }
    }
    
    /**
     * 标记本帧存在活跃遮罩来源（不区分通道），允许 {@link #composite} 真正执行合成
     */
    public static void markActive() {
        activeThisFrame = true;
    }
    
    @Nullable
    public static PostChain chain() {
        return chain;
    }
    
    @Nullable
    public static RenderTarget distortionTarget() {
        return distortionTarget;
    }
    
    @Nullable
    public static RenderTarget filterTarget() {
        return filterTarget;
    }
    
    @Nullable
    public static RenderTarget gradingTarget() {
        return gradingTarget;
    }
    
    /**
     * 写入当前层的材质色调 uniform（{@code Emit_ToneLevel} / {@code EmissiveIntensity} /
     * {@code DetoneRate}），与几何无关，每层写一次、最后一个写入者生效。
     * <b>已知局限</b>：链一帧只跑一次，两层滤镜同时可见时只有最后写入的一组值生效；当前两项预设
     * 这些值在 LDR 下近似恒等，故实际不会撞上。
     *
     * @param toneLevel     色阶指数 k（1 = 恒等）
     * @param emissiveClamp LDR 下的自发光上限（0~1）
     * @param detoneRate    滤镜与色调曲线之间的插值（0 = 纯滤镜）
     */
    public static void setFilterProfile(float toneLevel, float emissiveClamp, float detoneRate) {
        EffectInstance effect = distortionEffect;
        if (effect == null) {
            return;
        }
        effect.safeGetUniform("FilterToneLevel").set(toneLevel);
        effect.safeGetUniform("FilterEmissive").set(emissiveClamp);
        effect.safeGetUniform("FilterDetone").set(detoneRate);
    }
    
    /**
     * 写入当前层的屏幕空间增益 uniform，与 {@link #setFilterProfile} 同一惯例：逐层常量，每层写一次、
     * 最后一个写入者生效；当前仅 {@code カラコレ} 使用该通道。
     *
     * @param dispersion 色散幅度（屏幕 UV 单位）；{@code 0} 表示不色散
     * @param edge       屏幕边缘遮罩的渐变宽度（屏幕 UV 单位）；{@code 0} 表示不做边缘压平
     */
    public static void setGradingProfile(float dispersion, float edge) {
        EffectInstance effect = distortionEffect;
        if (effect == null) {
            return;
        }
        effect.safeGetUniform("GradingDispersion").set(dispersion);
        effect.safeGetUniform("GradingEdge").set(edge);
    }
    
    /**
     * 窗口尺寸变化时同步调整后处理链与遮罩缓冲的尺寸
     */
    public static void checkResize() {
        if (chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.getWindow().getWidth();
        int height = minecraft.getWindow().getHeight();
        if (width != lastWidth || height != lastHeight) {
            chain.resize(width, height);
            lastWidth = width;
            lastHeight = height;
        }
    }
    
    /**
     * 执行一帧遮罩合成；仅当本帧被 {@link #markActive} 标记时生效，结束后重置标记
     */
    public static void composite(float partialTick) {
        if (chain == null || !activeThisFrame) {
            return;
        }
        checkResize();
        chain.process(partialTick);
        activeThisFrame = false;
    }
}
