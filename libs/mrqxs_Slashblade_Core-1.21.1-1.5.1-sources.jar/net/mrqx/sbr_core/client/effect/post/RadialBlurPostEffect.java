package net.mrqx.sbr_core.client.effect.post;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.mixin.client.AccessorPostChain;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 径向模糊：以效果中心为原点、沿半径方向收缩采样，制造斩击瞬间的"视觉冲击定格"感。
 * <p>
 * EFX 里另有"距摄像机一定距离外效果消失"的距离衰减，屏幕空间后处理无法按场景深度逐像素淡出，
 * 故此处以持续时间控制。
 */
public final class RadialBlurPostEffect implements PostEffect {
    /**
     * 单例。
     */
    public static final RadialBlurPostEffect INSTANCE = new RadialBlurPostEffect();
    
    /**
     * PostChain 资源 id（对应 {@code shaders/post/radial_blur.json}）。
     */
    public static final ResourceLocation CHAIN_ID = MrqxSlashBladeCore.prefix("shaders/post/radial_blur.json");
    
    /**
     * 已加载的后处理链；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    private PostChain chain;
    
    /**
     * 效果结束时的游戏时间（小于等于当前游戏时间即视为未激活）。
     */
    private long endGameTime;
    
    /**
     * 最近一次 resize 的宽高。
     */
    private int lastWidth = -1;
    private int lastHeight = -1;
    
    /**
     * 后处理链里承载径向模糊的 pass 名，用于取出 {@code EffectInstance} 并写入 {@code BlurPower}。
     */
    public static final String BLUR_PASS_NAME = "sbr_core:radial_blur";
    
    /**
     * json 里给 {@code BlurPower} 的默认值（调用方未指定强度时使用）。
     */
    public static final float DEFAULT_BLUR_POWER = 5.0F;
    
    /**
     * 效果中心（世界坐标），{@code null} 表示以屏幕中心为中心：以<b>特效发射点</b>为心，合成时投影成屏幕 UV 写进 {@code Center}。
     */
    @Nullable
    private Vec3 origin;
    
    /**
     * 本次效果的起始游戏时间与三段时长（EFX {@code Life} 的 Appear / Keep / Vanish，单位 tick）。
     */
    private long startGameTime;
    private int appearTicks;
    private int keepTicks;
    private int vanishTicks;
    
    /**
     * 最近一次触发请求的模糊强度（写进 {@code BlurPower}，最终会乘上强度包络）。
     */
    private float blurPower = DEFAULT_BLUR_POWER;
    
    /**
     * 最近一次触发请求的模糊遮罩（写进 {@code MaskRate} / {@code MaskSmoothstep} / {@code ScreenPosition}），默认 {@link BlurMask#NONE} 即全屏均匀模糊。
     */
    public BlurMask mask = BlurMask.NONE;
    
    /**
     * 最近一次触发请求的色差强度（写进 {@code ColorRate}）；为 0 时退化成纯亮度模糊。
     */
    public float colorRate;
    
    private RadialBlurPostEffect() {
    }
    
    /**
     * 触发一次径向模糊：使用 json 的默认强度 {@link #DEFAULT_BLUR_POWER}，无渐入渐出。
     */
    public static void trigger(int durationTicks) {
        trigger(durationTicks, DEFAULT_BLUR_POWER);
    }
    
    /**
     * 触发一次径向模糊：无渐入渐出，时长整体算作保持段（{@code blurPower} 对应 EFX {@code BlurPower}）。
     */
    public static void trigger(int durationTicks, float blurPower) {
        trigger(null, 0, durationTicks, 0, blurPower);
    }
    
    /**
     * 触发一次径向模糊：带 Appear / Keep / Vanish 三段与效果中心；{@code origin} 为 {@code null} 时以屏幕中心为心。
     */
    public static void trigger(@Nullable Vec3 origin, int appearTicks, int keepTicks, int vanishTicks, float blurPower) {
        trigger(origin, appearTicks, keepTicks, vanishTicks, blurPower, 0.0F, BlurMask.NONE);
    }
    
    /**
     * 触发一次带遮罩的径向模糊（<b>局部</b>模糊、无色差）：对应 {@code radial_blur0}，用遮罩把模糊限制在画面一角而非整屏均匀糊住。
     */
    public static void trigger(@Nullable Vec3 origin, int appearTicks, int keepTicks, int vanishTicks,
                               float blurPower, BlurMask mask) {
        trigger(origin, appearTicks, keepTicks, vanishTicks, blurPower, 0.0F, mask);
    }
    
    /**
     * 触发一次完整的径向模糊（强度 + <b>色差</b> + 遮罩）：色差让 R / B 通道沿半径反向偏移形成彩色描边。
     */
    public static void trigger(@Nullable Vec3 origin, int appearTicks, int keepTicks, int vanishTicks,
                               float blurPower, float colorRate, BlurMask mask) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        long now = minecraft.level.getGameTime();
        INSTANCE.origin = origin;
        INSTANCE.startGameTime = now;
        INSTANCE.appearTicks = Math.max(0, appearTicks);
        INSTANCE.keepTicks = Math.max(0, keepTicks);
        INSTANCE.vanishTicks = Math.max(0, vanishTicks);
        INSTANCE.blurPower = blurPower;
        INSTANCE.colorRate = colorRate;
        INSTANCE.mask = mask;
        int total = INSTANCE.appearTicks + INSTANCE.keepTicks + INSTANCE.vanishTicks;
        INSTANCE.endGameTime = now + Math.max(1, total);
    }
    
    /**
     * 当前强度包络（0~1）：Appear 渐入 → Keep 满强度 → Vanish 渐出，对应 EFX {@code Life} 的三段；
     * 无消散段时保持满强度，由 {@code endGameTime} 决定结束。
     */
    public float envelope(float elapsedTicks) {
        if (elapsedTicks < 0.0F) {
            return 0.0F;
        }
        if (elapsedTicks < this.appearTicks) {
            return this.appearTicks <= 0 ? 1.0F : elapsedTicks / (float) this.appearTicks;
        }
        float keepEnd = (float) (this.appearTicks + this.keepTicks);
        if (elapsedTicks < keepEnd) {
            return 1.0F;
        }
        if (this.vanishTicks <= 0) {
            return 1.0F;
        }
        return Math.max(0.0F, 1.0F - (elapsedTicks - keepEnd) / (float) this.vanishTicks);
    }
    
    /**
     * 取链里的第一个 pass（径向模糊本身）；链未加载时返回 {@code null}。
     */
    @Nullable
    public PostPass firstPass() {
        if (this.chain == null) {
            return null;
        }
        List<PostPass> passes = ((AccessorPostChain) this.chain).getPasses();
        return passes.isEmpty() ? null : passes.getFirst();
    }
    
    /**
     * 把效果中心（世界坐标）投影成屏幕 UV（0~1）；未指定中心、或中心位于相机背后时返回 {@code null}。
     */
    @Nullable
    public Vector2f screenCenter(Minecraft minecraft) {
        if (this.origin == null) {
            return null;
        }
        Camera camera = minecraft.gameRenderer.getMainCamera();
        Vec3 camPos = camera.getPosition();
        Vector3f rel = new Vector3f(
            (float) (this.origin.x - camPos.x),
            (float) (this.origin.y - camPos.y),
            (float) (this.origin.z - camPos.z));
        // 转到相机局部坐标：Minecraft 的相机看向 -Z，因此 z 必须为负才在镜头前方
        rel.rotate(camera.rotation().conjugate(new Quaternionf()));
        if (rel.z >= -0.05F) {
            return null;
        }
        // 固定取 90°（默认 FOV）：第一人称自施法时施法者与相机重合，上面的 rel.z >= -0.05 已返回 null，
        // 投影实际只在第三人称 / 他人施法时生效；若要跟随玩家 FOV，可改用 GameRenderer 的 FOV 取值
        double fov = 90;
        float tanHalf = (float) Math.tan(Math.toRadians(fov) * 0.5D);
        int width = Math.max(1, minecraft.getWindow().getWidth());
        int height = Math.max(1, minecraft.getWindow().getHeight());
        float aspect = (float) width / (float) height;
        float ndcX = -rel.x / (rel.z * tanHalf * aspect);
        float ndcY = -rel.y / (rel.z * tanHalf);
        return new Vector2f(ndcX * 0.5F + 0.5F, ndcY * 0.5F + 0.5F);
    }
    
    @Override
    public String id() {
        return "radial_blur";
    }
    
    @Override
    public void reload(ResourceManager resourceManager) {
        this.close();
        Minecraft minecraft = Minecraft.getInstance();
        try {
            this.chain = new PostChain(minecraft.getTextureManager(), resourceManager,
                minecraft.getMainRenderTarget(), CHAIN_ID);
            int width = minecraft.getWindow().getWidth();
            int height = minecraft.getWindow().getHeight();
            this.chain.resize(width, height);
            this.lastWidth = width;
            this.lastHeight = height;
        } catch (Exception e) {
            MrqxSlashBladeCore.LOGGER.error("加载径向模糊后处理链失败: {}", CHAIN_ID, e);
            this.chain = null;
        }
    }
    
    @Override
    public void close() {
        if (this.chain != null) {
            this.chain.close();
            this.chain = null;
        }
    }
    
    @Override
    public void composite(float partialTick) {
        if (this.chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.level.getGameTime() >= this.endGameTime) {
            return;
        }
        this.checkResize();
        // 强度包络（Appear 渐入 / Keep 满强度 / Vanish 渐出），必须带上 partialTick，
        // 否则渐入渐出与模糊强度会呈 20Hz 的阶梯
        float elapsed = (float) (minecraft.level.getGameTime() - this.startGameTime) + partialTick;
        float intensity = this.envelope(elapsed);
        if (intensity <= 0.0F) {
            return;
        }
        // 强度与中心都写在承载模糊的那个 pass 上，BlurPower 乘上包络
        PostPass pass = this.firstPass();
        if (pass != null) {
            pass.getEffect().safeGetUniform("BlurPower").set(this.blurPower * intensity);
            // 色差同样随强度包络：渐入渐出时彩色描边与模糊一起淡，不会先出现彩色再出现模糊
            pass.getEffect().safeGetUniform("ColorRate").set(this.colorRate * intensity);
            // 遮罩参数不随强度包络变化：它决定的是"模糊出现在画面的哪一块"，而不是模糊多强
            pass.getEffect().safeGetUniform("MaskRate").set(this.mask.rate());
            pass.getEffect().safeGetUniform("MaskSmoothstep").set(this.mask.start(), this.mask.end());
            pass.getEffect().safeGetUniform("ScreenPosition").set(this.mask.centerX(), this.mask.centerY());
            Vector2f center = this.screenCenter(minecraft);
            if (center != null) {
                pass.getEffect().safeGetUniform("Center").set(center.x, center.y);
            }
        }
        this.chain.process(partialTick);
    }
    
    /**
     * 窗口尺寸变化时同步调整后处理链尺寸。
     */
    public void checkResize() {
        if (this.chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.getWindow().getWidth();
        int height = minecraft.getWindow().getHeight();
        if (width != this.lastWidth || height != this.lastHeight) {
            this.chain.resize(width, height);
            this.lastWidth = width;
            this.lastHeight = height;
        }
    }
    
    /**
     * 径向模糊的遮罩参数：以 {@code (centerX, centerY)} 为心、距离在 {@code start ~ end} 间平滑过渡，范围内按 {@code rate} 取模糊
     * （0 = 全屏均匀模糊，1 = 遮罩外完全不模糊），范围外取原画面；三项对应 {@code EffectRadialBlur} 的
     * {@code MaskRate} / {@code MaskSmoothstep} / {@code ScreenPosition}。
     */
    public record BlurMask(float rate, float start, float end, float centerX, float centerY) {
        
        /**
         * 不遮罩：全屏均匀模糊。
         */
        public static final BlurMask NONE = new BlurMask(0.0F, 0.0F, 1.0F, 0.5F, 0.5F);
    }
}
