package net.mrqx.sbr_core.client.effect.post;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.debris.DebrisManager;
import net.mrqx.sbr_core.client.effect.mesh.MeshEmitterManager;
import net.mrqx.sbr_core.client.effect.polygon.PolygonEmitterManager;
import net.mrqx.sbr_core.config.MrqxSlashBladeClientConfig;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL30;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 屏幕空间遮罩的分阶段渲染挂钩：{@code AFTER_PARTICLES} 阶段把活跃来源的几何分别写入折射 /
 * 材质色彩滤镜 / 逐通道增益三张遮罩缓冲，{@code AFTER_LEVEL} 阶段交由 {@link DistortionEffectManager}
 * 执行 PostChain 合成。不使用 MRT：{@code RenderTarget} 不支持多颜色附件，三条通道只能各画一遍，
 * 复用同一批来源与四边形可保证滤镜范围与折射严丝合缝。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class DistortionRenderHook {
    /** 遮罩通道：折射（RG = 偏移方向、B = 缩放增量、A = 强度）。 */
    public static final int CHANNEL_DISTORTION = 0;
    
    /** 遮罩通道：材质色彩滤镜（RGB = 目标色、A = 权重），语义是向目标色收敛。 */
    public static final int CHANNEL_FILTER = 1;
    
    /** 遮罩通道：屏幕空间逐通道增益（RGB = 增益目标色、A = 乘积权重），语义是逐通道乘性增益。 */
    public static final int CHANNEL_GRADING = 2;
    
    /**
     * 没有形状贴图的来源（网格类）绑定的<b>全白贴图</b>：采样 alpha 恒为 1，顶点色原样写入遮罩。
     */
    public static final ResourceLocation MASK_WHITE =
        MrqxSlashBladeCore.prefix("textures/effect/nullwhite.png");
    
    /** {@code AFTER_PARTICLES} 阶段：绘制三张遮罩。 */
    @SubscribeEvent
    public static void onRenderLevelStageAfterParticles(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }
        renderDistortionMask(event);
    }
    
    /** {@code AFTER_LEVEL} 阶段：执行遮罩合成。 */
    @SubscribeEvent
    public static void onRenderLevelStageAfterLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(true);
        PostEffectRegistry.composite(partialTick);
    }
    
    /**
     * 把活跃来源的几何写进各遮罩缓冲：三条通道各自独立判断本帧有无内容，但只要任一通道有内容，
     * 就要 {@link DistortionEffectManager#markActive()}——三张遮罩共用同一条 PostChain。
     */
    public static void renderDistortionMask(RenderLevelStageEvent event) {
        if (!MrqxSlashBladeClientConfig.ENABLE_TRUE_DISTORTION.get()) {
            return;
        }
        List<DistortionSource> sources = new ArrayList<>(MeshEmitterManager.activeDistortionParticles());
        sources.addAll(PolygonEmitterManager.activeDistortionParticles());
        // 玻璃碎片走独立渲染路径，来源必须显式汇入，否则实现了 DistortionSource 也没人问它
        sources.addAll(DebrisManager.activeDistortionParticles());
        if (sources.isEmpty()) {
            return;
        }
        int maxTracked = MrqxSlashBladeClientConfig.MAX_TRACKED_DISTORTION_PARTICLES.get();
        if (sources.size() > maxTracked) {
            sources = new ArrayList<>(sources.subList(0, maxTracked));
        }
        PostChain chain = DistortionEffectManager.chain();
        if (chain == null) {
            return;
        }
        RenderTarget distortionTarget = DistortionEffectManager.distortionTarget();
        RenderTarget filterTarget = DistortionEffectManager.filterTarget();
        RenderTarget gradingTarget = DistortionEffectManager.gradingTarget();
        boolean needDistortion = distortionTarget != null && anyHasDistortion(sources);
        boolean needFilter = filterTarget != null && anyHasColorFilter(sources);
        boolean needGrading = gradingTarget != null && anyHasScreenGrading(sources);
        if (!needDistortion && !needFilter && !needGrading) {
            return;
        }
        
        DistortionEffectManager.markActive();
        
        Camera camera = event.getCamera();
        Vec3 camPos = camera.getPosition();
        // 用相机真实基向量换算屏幕右/上方向，使任意旋转角度下碎片畸变方向都贴合观察视角
        Vector3f look = new Vector3f(camera.getLookVector());
        Vector3f up = new Vector3f(camera.getUpVector());
        Vector3f right = new Vector3f(look).cross(up).normalize();
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(true);
        
        // 记录当前帧缓冲绑定，画完遮罩后原样恢复，避免干扰 Fabulous 图形下的半透明渲染目标
        int previousFramebuffer = GL30.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
        if (needDistortion) {
            // 折射遮罩中性值：RG = 0.5 表示无偏移方向、A = 0 表示无强度
            drawMask(sources, distortionTarget, 0.5F, 0.5F, 0.0F, 0.0F, CHANNEL_DISTORTION,
                camPos, right, up, partialTick);
        }
        if (needFilter) {
            // 滤镜遮罩中性值：A = 0 表示不滤镜（RGB 在 A 为 0 时不被读取）
            drawMask(sources, filterTarget, 1.0F, 1.0F, 1.0F, 0.0F, CHANNEL_FILTER,
                camPos, right, up, partialTick);
        }
        if (needGrading) {
            // 增益遮罩中性值同上；它单独占一张缓冲，使逐通道乘性增益与向目标色收敛两条语义可共存
            drawMask(sources, gradingTarget, 1.0F, 1.0F, 1.0F, 0.0F, CHANNEL_GRADING,
                camPos, right, up, partialTick);
        }
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, previousFramebuffer);
    }
    
    /** 来源列表中是否至少有一个仍需写折射遮罩。 */
    public static boolean anyHasDistortion(List<DistortionSource> sources) {
        for (DistortionSource source : sources) {
            if (source.hasDistortion()) {
                return true;
            }
        }
        return false;
    }
    
    /** 来源列表中是否至少有一个仍需写材质色彩滤镜遮罩。 */
    public static boolean anyHasColorFilter(List<DistortionSource> sources) {
        for (DistortionSource source : sources) {
            if (source.hasColorFilter()) {
                return true;
            }
        }
        return false;
    }
    
    /** 来源列表中是否至少有一个仍需写屏幕空间逐通道增益遮罩。 */
    public static boolean anyHasScreenGrading(List<DistortionSource> sources) {
        for (DistortionSource source : sources) {
            if (source.hasScreenGrading()) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 把一批来源画进某一个遮罩缓冲。
     * <p>
     * 混合方式随通道而异，这是刻意的：折射通道按 alpha 混合（方向与强度是要叠加的量）；滤镜 / 增益
     * 通道则<b>关闭混合、覆盖写</b>——它们的 RGB 是不可叠加的目标色本身，按 alpha 混合会被清屏色洗白；
     * 覆盖写下 A 仍是插值出的空间权重。
     */
    public static void drawMask(List<DistortionSource> sources, RenderTarget target,
                                float clearR, float clearG, float clearB, float clearA, int channel,
                                Vec3 camPos, Vector3f right, Vector3f up, float partialTick) {
        target.bindWrite(false);
        RenderSystem.clearColor(clearR, clearG, clearB, clearA);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
        
        if (channel == CHANNEL_DISTORTION) {
            RenderSystem.enableBlend();
            // 面片粒子的减法刀光可能把混合方程残留为 REVERSE_SUBTRACT，必须显式复位，否则污染遮罩缓冲
            RenderSystem.blendEquation(GL14.GL_FUNC_ADD);
            // RGB 按 alpha 加权叠加：方向与强度本就是可叠加的量，多层同写即自然叠加，
            // 不按优先级互相屏蔽（观感上的"谁压过谁"由各层数值本身造成）；A 覆盖写，使单层权重不被重叠层数放大
            RenderSystem.blendFuncSeparate(
                GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        } else {
            RenderSystem.disableBlend();
        }
        RenderSystem.depthMask(false);
        // 遮罩的深度附件从未清过：开深度测试会让球壳三角形被上一帧残留深度随机剔除（实机即特效范围内撕裂）；
        // 前后半球重叠已由 facesCamera 在几何侧消除，故直接关闭是安全的
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        
        // 着色器与贴图由 drawSources 按来源分组各自绑定（遮罩的形状要跟着来源贴图的 alpha 走）
        drawSources(sources, channel, camPos, right, up, partialTick);
        
        RenderSystem.depthMask(true);
        // 深度测试是引擎全局状态，这里临时关过，退出前必须还原，否则后续粒子 / 半透明层会全部永远通过
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
    }
    
    /**
     * 把一批来源的几何按通道分派给各自的构建方法，用调用方已设好的混合状态提交绘制。
     * <p>
     * <b>按形状贴图分组</b>：遮罩的形状与强度都要跟着来源自己的贴图 alpha 走（见 {@link MaskParticleShaders}），
     * 而贴图是逐 draw call 绑定的，故一张贴图一批、绑好再画；没有形状贴图的来源统一绑全白贴图，
     * 采样恒为 1、顶点色原样写入。
     */
    public static void drawSources(List<DistortionSource> sources, int channel,
                                   Vec3 camPos, Vector3f right, Vector3f up, float partialTick) {
        ShaderInstance maskShader = MaskParticleShaders.shader();
        if (maskShader == null) {
            // 着色器没加载成功时整帧不写遮罩：顶点格式已换成 PARTICLE，回退原版位置色着色器会因属性对不上而崩
            return;
        }
        Map<ResourceLocation, List<DistortionSource>> grouped = new LinkedHashMap<>();
        for (DistortionSource source : sources) {
            ResourceLocation texture = source.maskTexture();
            grouped.computeIfAbsent(texture != null ? texture : MASK_WHITE, key -> new ArrayList<>()).add(source);
        }
        for (Map.Entry<ResourceLocation, List<DistortionSource>> entry : grouped.entrySet()) {
            Tesselator tesselator = Tesselator.getInstance();
            BufferBuilder buffer = tesselator.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.PARTICLE);
            for (DistortionSource source : entry.getValue()) {
                if (channel == CHANNEL_DISTORTION) {
                    source.buildDistortionQuads(buffer, camPos, right, up, partialTick);
                } else if (channel == CHANNEL_FILTER) {
                    source.buildFilterQuads(buffer, camPos, right, up, partialTick);
                } else {
                    source.buildScreenGradingQuads(buffer, camPos, right, up, partialTick);
                }
            }
            MeshData meshData = buffer.build();
            if (meshData == null) {
                continue;
            }
            RenderSystem.setShader(() -> maskShader);
            RenderSystem.setShaderTexture(0, entry.getKey());
            BufferUploader.drawWithShader(meshData);
        }
    }
}
