package net.mrqx.sbr_core.client.effect.post;

import net.minecraft.server.packs.resources.ResourceManager;

/**
 * 屏幕空间畸变（割れ Dis 1 / Dis空間われ）在 {@link PostEffectRegistry} 中的效果入口。
 * <p>
 * 本类只是把既有的 {@link DistortionEffectManager} 适配为统一的 {@link PostEffect}，
 * 具体的 PostChain 管理与激活判定仍由该管理器负责（畸变需要在粒子阶段先写入遮罩缓冲）。
 */
public final class DistortionPostEffect implements PostEffect {
    /**
     * 单例（畸变是全局唯一效果）。
     */
    public static final DistortionPostEffect INSTANCE = new DistortionPostEffect();
    
    private DistortionPostEffect() {
    }
    
    @Override
    public String id() {
        return "dis_ware_distortion";
    }
    
    @Override
    public void reload(ResourceManager resourceManager) {
        DistortionEffectManager.reload(resourceManager);
    }
    
    @Override
    public void close() {
        DistortionEffectManager.close();
    }
    
    @Override
    public void composite(float partialTick) {
        DistortionEffectManager.composite(partialTick);
    }
}
