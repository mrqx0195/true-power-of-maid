package net.mrqx.sbr_core.client.effect.post;

import net.minecraft.server.packs.resources.ResourceManager;

/**
 * 全屏后处理效果：由 {@link PostEffectRegistry} 统一管理生命周期与逐帧合成顺序。
 * <p>
 * 实现方自行判断"本帧是否需要合成"（例如畸变仅在存在活跃畸变粒子时执行），
 * 因此 {@link #composite(float)} 内部应包含激活判定与帧末状态重置；
 * 各效果各自持有一条 {@link net.minecraft.client.renderer.PostChain}，
 * 约定为"读 {@code minecraft:main} → 写临时 target → 再写回 main"，从而可以按注册顺序串联叠加。
 */
public interface PostEffect {
    /**
     * 效果标识（用于日志与调试）。
     *
     * @return 唯一标识
     */
    String id();
    
    /**
     * 资源包重载（F3+T / 切换资源包）时重建后处理链。
     *
     * @param resourceManager 当前资源管理器
     */
    void reload(ResourceManager resourceManager);
    
    /**
     * 释放后处理链。
     */
    void close();
    
    /**
     * 执行一帧合成；实现方内部判断是否真正需要执行。
     *
     * @param partialTick 渲染部分 tick
     */
    void composite(float partialTick);
}
