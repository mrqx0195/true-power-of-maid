package net.mrqx.sbr_core.client.effect.post;

import net.minecraft.server.packs.resources.ResourceManager;

import java.util.ArrayList;
import java.util.List;

/**
 * 全屏后处理注册表：统一管理各效果的加载、释放与逐帧合成顺序。
 * <p>
 * 合成顺序即为叠加顺序——每个链都是"读 {@code minecraft:main} → 写临时 target → 写回 main"，
 * 因此按注册顺序依次执行就能叠加多个全屏效果（径向模糊 → 屏幕辉光 / 压暗 → 色彩校正 → 屏幕空间畸变）。
 * 所有效果都在关卡渲染结束（{@code RenderLevelStageEvent.Stage.AFTER_LEVEL}）后统一合成，
 * 避免各自抢绑 {@code minecraft:main} 造成相互覆盖。
 */
public final class PostEffectRegistry {
    /**
     * 已注册的效果（按叠加顺序）
     */
    private static final List<PostEffect> EFFECTS = new ArrayList<>();
    
    static {
        register(RadialBlurPostEffect.INSTANCE);
        // 辉光 / 压暗属于"场景照明"，排在色校之前，好让色校统一收尾并对辉光本身也生效
        register(GlowPostEffect.INSTANCE);
        // 球体调色的旧通道已退役：カラコレ 就是 TypeMesh 层，现直接以 EFX 配置触发（见 EfxJceChromaPresets.CHROMA_BALL）
        register(LutColorCorrectionPostEffect.INSTANCE);
        register(DistortionPostEffect.INSTANCE);
    }
    
    private PostEffectRegistry() {
    }
    
    /**
     * 注册一个后处理效果（在内置效果之后追加）。
     *
     * @param effect 效果实例
     */
    public static void register(PostEffect effect) {
        EFFECTS.add(effect);
    }
    
    /**
     * 重建全部后处理链。
     *
     * @param resourceManager 当前资源管理器
     */
    public static void reload(ResourceManager resourceManager) {
        for (PostEffect effect : EFFECTS) {
            effect.reload(resourceManager);
        }
    }
    
    /**
     * 释放全部后处理链。
     */
    public static void close() {
        for (PostEffect effect : EFFECTS) {
            effect.close();
        }
    }
    
    /**
     * 按注册顺序合成全部效果（各效果内部自行判断是否激活）。
     *
     * @param partialTick 渲染部分 tick
     */
    public static void composite(float partialTick) {
        for (PostEffect effect : EFFECTS) {
            effect.composite(partialTick);
        }
    }
}
