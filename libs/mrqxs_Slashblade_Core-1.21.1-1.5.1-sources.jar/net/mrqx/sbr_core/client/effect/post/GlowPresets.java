package net.mrqx.sbr_core.client.effect.post;

/**
 * 屏幕空间辉光的两个整体倍率，以及唯一一条<b>没有 EFX 依据</b>的观感补偿光斑。
 * <p>
 * 本类不再承载"某一层长什么样"：六层 {@code Billboard3D} 预设已写回 {@code EfxJceGlowPresets}，
 * 两个脚本光照层由 {@code EfxJceNoDrawPresets} / {@code EfxJceRangeNoDrawPresets} 驱动。
 */
public final class GlowPresets {
    /**
     * 辉光整体尺寸倍率：在 EFX 换算出的半径之上再乘该倍数。
     * 面片边长换成半径后实机偏小，故整体放大到 5 倍；改这一处即可统一调整所有辉光尺寸。
     */
    public static final float RADIUS_SCALE = 5.0F;
    
    /**
     * 加亮层的整体强度倍率（"整体透明度"）。
     * <b>只作用于加亮层</b>：压暗层的公式是 {@code scene × (1 − color × strength × falloff)}，
     * 乘同一个系数只会让压暗更弱——{@link #RADIAL_BLUR_DARKEN} 曾因此只剩约 1% 的压暗量，
     * 实机看到的"全屏压暗"几乎不存在。故压暗层一律取绝对强度、不乘本系数。
     */
    public static final float STRENGTH_SCALE = 0.1F;
    
    /**
     * {@code radial_blur0} 附带的<b>全屏压暗</b>（实测"较弱的模糊同时会有一个全屏压暗"）。
     * 用一个半径远大于视距的压暗光斑铺满画面，半径取 64 格再乘 {@link #RADIUS_SCALE}；
     * 生命三段与时间轴里的 {@code radial_blur0} 一致（3 / 40 / 7）。
     * <p>
     * 不写成 EFX 预设，因为压暗不在 EFX 属性表里、没有可照抄的原值，
     * 硬造一层"Billboard3D + 观感参数"只会让人误以为它有依据。
     */
    public static final GlowSpec RADIAL_BLUR_DARKEN = GlowSpec.of(
        // 强度取绝对值、不乘 STRENGTH_SCALE：乘 0.1 只会让压暗变弱（实测只剩约 1%，肉眼不可辨）
        64.0F * RADIUS_SCALE, 0xFF101828, 0.8F, GlowSpec.MODE_DARKEN, 0.9F, 0.0F,
        3, 40, 7);
    
    private GlowPresets() {
    }
}
