package net.mrqx.sbr_core.client.effect.post;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.efx.EfxConfig;
import net.mrqx.sbr_core.client.effect.efx.EfxGlowView;
import net.mrqx.sbr_core.client.effect.timeline.EfxTimeline;
import net.mrqx.sbr_core.mixin.client.AccessorPostChain;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 屏幕空间辉光 / 压暗：以特效发射点为中心、向边缘柔和衰减的径向光斑。
 * <p>
 * 改用屏幕空间后处理而不是用面片模拟全屏光效：面片被视角斜切时会拉伸成椭圆、贴图边缘被硬裁切、
 * 多层半透明叠加出现色带；这里一次合成即可叠加多个光斑。各层的具体数值见 {@link GlowPresets}。
 */
public final class GlowPostEffect implements PostEffect {
    /**
     * 单例。
     */
    public static final GlowPostEffect INSTANCE = new GlowPostEffect();
    
    /**
     * PostChain 资源 id（对应 {@code shaders/post/screen_glow.json}）。
     */
    public static final ResourceLocation CHAIN_ID = MrqxSlashBladeCore.prefix("shaders/post/screen_glow.json");
    
    /**
     * 承载辉光叠加的 pass 名（见 {@code shaders/post/screen_glow.json}）。
     */
    public static final String GLOW_PASS = "sbr_core:screen_glow";
    
    /**
     * 光斑槽位数量，必须与 {@code screen_glow.fsh} 里声明的 uniform 组数一致。
     */
    public static final int MAX_GLOWS = 6;
    
    /**
     * 各槽位的 uniform 名。
     * <p>
     * 写成数组而不是逐帧拼字符串，是为了不在渲染热路径上产生多余的对象分配。
     */
    public static final String[] COLOR_UNIFORMS = {
        "GlowColor0", "GlowColor1", "GlowColor2", "GlowColor3", "GlowColor4", "GlowColor5"
    };
    public static final String[] CENTER_UNIFORMS = {
        "GlowCenter0", "GlowCenter1", "GlowCenter2", "GlowCenter3", "GlowCenter4", "GlowCenter5"
    };
    public static final String[] PARAMS_UNIFORMS = {
        "GlowParams0", "GlowParams1", "GlowParams2", "GlowParams3", "GlowParams4", "GlowParams5"
    };
    
    /**
     * 投影矩阵不可用时使用的参考视场角（度）。
     */
    public static final float DEFAULT_FOV = 70.0F;
    
    /**
     * {@link #DEFAULT_FOV} 对应的半视场角正切。
     */
    public static final float DEFAULT_TAN_HALF_FOV = (float) Math.tan(Math.toRadians(DEFAULT_FOV * 0.5D));
    
    /**
     * 判定投影矩阵退化的最小缩放量。
     */
    public static final float MIN_PROJECTION_SCALE = 1.0E-4F;
    
    /**
     * 投影时允许的最小相机前方距离（格）。
     * <p>
     * 发射点贴到相机或位于相机背后时钳到该距离：既避免除零，也让辉光铺满画面。
     */
    public static final float MIN_PROJECTION_DISTANCE = 0.05F;
    
    /**
     * 正在生效的光斑，按触发顺序排列。
     */
    public final List<ActiveGlow> activeGlows = new ArrayList<>();
    
    /**
     * 已加载的后处理链；为 null 表示尚未加载或加载失败。
     */
    @Nullable
    public PostChain chain;
    
    /**
     * 最近一次 resize 的宽高。
     */
    public int lastWidth = -1;
    public int lastHeight = -1;
    
    private GlowPostEffect() {
    }
    
    /**
     * 触发一个屏幕空间光斑。
     * <p>
     * 同时最多保留 {@link #MAX_GLOWS} 个，超出时挤掉最早触发的那个。
     *
     * @param origin 发射点（世界坐标），光斑以此为圆心
     * @param spec   光斑参数
     */
    public static void trigger(Vec3 origin, GlowSpec spec) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        if (INSTANCE.activeGlows.size() >= MAX_GLOWS) {
            INSTANCE.activeGlows.removeFirst();
        }
        INSTANCE.activeGlows.add(new ActiveGlow(origin, spec, minecraft.level.getGameTime()));
    }
    
    /**
     * 触发一个屏幕空间光斑，参数直接来自 EFX 层（颜色与生命三段由层给出，
     * 半径 / 增益 / 模式 / 柔和度 / 场景模糊由该层的扩展属性 {@code EfxAttributeGlowRender} 给出）。
     *
     * @param origin 发射点（世界坐标），光斑以此为圆心
     * @param config 该层的 EFX 配置（应含 {@code EfxAttributeGlowRender}）
     */
    public static void trigger(Vec3 origin, EfxConfig config) {
        trigger(origin, config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 触发一个屏幕空间光斑，并指定本段演出的收尾时刻。
     *
     * @param origin             发射点（世界坐标），光斑以此为圆心
     * @param config             该层的 EFX 配置（应含 {@code EfxAttributeGlowRender}）
     * @param sustainedKeepTicks 从本层触发时刻到本段演出收尾的 tick 数；
     *                           {@link EfxTimeline#USE_DEFAULT_SUSTAINED_KEEP} 表示由视图自行取默认值
     */
    public static void trigger(Vec3 origin, EfxConfig config, int sustainedKeepTicks) {
        trigger(origin, specOf(config, sustainedKeepTicks));
    }
    
    /**
     * 把一层 EFX 配置摊平成光斑参数。
     *
     * @param config 该层的 EFX 配置
     * @return 光斑参数
     */
    public static GlowSpec specOf(EfxConfig config) {
        return specOf(config, EfxTimeline.USE_DEFAULT_SUSTAINED_KEEP);
    }
    
    /**
     * 把一层 EFX 配置摊平成光斑参数，并指定本段演出的收尾时刻。
     *
     * @param config             该层的 EFX 配置
     * @param sustainedKeepTicks 从本层触发时刻到本段演出收尾的 tick 数
     * @return 光斑参数
     */
    public static GlowSpec specOf(EfxConfig config, int sustainedKeepTicks) {
        EfxGlowView view = new EfxGlowView(config, sustainedKeepTicks);
        // 强度调制一律关闭：那是脚本层点光源的特性，这一族 Billboard3D 辉光层没有强度跳变
        return new GlowSpec(view.radius, view.color, view.strength, view.mode, view.softness,
            view.sceneBlur, view.appearTicks, view.keepTicks, view.vanishTicks, 1.0F, 1.0F, 1);
    }
    
    /**
     * 取得本帧的投影参数。
     * <p>
     * 直接读当前投影矩阵而不是去问 {@code GameRenderer}：矩阵里已包含视场角设置与各类视场角修正
     * （冲刺 / 望远镜 / 状态效果），据此换算的光斑半径才与画面几何一致。
     *
     * @param width  当前帧缓冲宽度
     * @param height 当前帧缓冲高度
     * @return 投影参数；矩阵退化时回退到默认视场角与窗口宽高比
     */
    public static Projection currentProjection(int width, int height) {
        Matrix4f matrix = RenderSystem.getProjectionMatrix();
        float m00 = matrix.m00();
        float m11 = matrix.m11();
        // 透视投影下 m11 = 1 / tan(半视场角)、m00 = m11 / 宽高比；非正说明矩阵不可用
        if (m11 > MIN_PROJECTION_SCALE && m00 > MIN_PROJECTION_SCALE) {
            return new Projection(1.0F / m11, m11 / m00);
        }
        return new Projection(DEFAULT_TAN_HALF_FOV, (float) width / (float) height);
    }
    
    /**
     * 把一个世界坐标的发射点投影成屏幕 UV，并把光斑的世界半径换算成屏幕半径。
     * <p>
     * 效果中心取特效发射点而非屏幕中心，半径按该点的投影尺度换算，
     * 因此同一个光斑会随距离自然变大变小。
     *
     * @param origin     发射点（世界坐标）
     * @param cameraPos  相机位置
     * @param camera     当前相机（用于取朝向）
     * @param projection 本帧投影参数
     * @param radius     光斑的世界半径（格）
     * @return {@code (x, y)} 为屏幕 UV（0~1，允许越界，越界时光斑从屏幕外渗入），
     * {@code z} 为屏幕半径（以屏幕高度为单位）
     */
    public static Vector3f project(Vec3 origin, Vec3 cameraPos, Camera camera, Projection projection,
                                   float radius) {
        Vector3f relative = new Vector3f(
            (float) (origin.x - cameraPos.x),
            (float) (origin.y - cameraPos.y),
            (float) (origin.z - cameraPos.z));
        // Minecraft 的相机看向 -Z，因此转到相机局部坐标后 z 必须为负才在镜头前方
        relative.rotate(camera.rotation().conjugate(new Quaternionf()));
        float depth = Math.min(relative.z, -MIN_PROJECTION_DISTANCE);
        float distance = -depth;
        // 该距离处屏幕高度对应 2 * distance * tan(半视场角) 格世界尺寸
        float radiusUV = radius / (2.0F * distance * projection.tanHalfFov());
        float ndcX = -relative.x / (depth * projection.tanHalfFov() * projection.aspect());
        float ndcY = -relative.y / (depth * projection.tanHalfFov());
        return new Vector3f(ndcX * 0.5F + 0.5F, ndcY * 0.5F + 0.5F, radiusUV);
    }
    
    /**
     * 清空一个未使用的光斑槽位：着色器以"强度不大于 0"判定该槽位不参与叠加。
     *
     * @param pass 辉光 pass
     * @param slot 槽位下标
     */
    public void clearSlot(PostPass pass, int slot) {
        pass.getEffect().safeGetUniform(COLOR_UNIFORMS[slot]).set(0.0F, 0.0F, 0.0F);
        pass.getEffect().safeGetUniform(CENTER_UNIFORMS[slot]).set(0.0F, 0.0F);
        pass.getEffect().safeGetUniform(PARAMS_UNIFORMS[slot]).set(0.0F, 0.0F, 0.0F, 0.0F);
    }
    
    /**
     * 取链里承载辉光叠加的 pass。
     *
     * @return 该 pass；链未加载或未找到时返回 {@code null}
     */
    @Nullable
    public PostPass glowPass() {
        if (this.chain == null) {
            return null;
        }
        List<PostPass> passes = ((AccessorPostChain) this.chain).getPasses();
        for (PostPass postPass : passes) {
            if (postPass.getName().equals(GLOW_PASS)) {
                return postPass;
            }
        }
        return null;
    }
    
    @Override
    public String id() {
        return "screen_glow";
    }
    
    @Override
    public void reload(ResourceManager resourceManager) {
        this.close();
        Minecraft minecraft = Minecraft.getInstance();
        try {
            this.chain = new PostChain(minecraft.getTextureManager(), resourceManager,
                minecraft.getMainRenderTarget(), CHAIN_ID);
            int width = minecraft.getWindow().getWidth();
            int height = minecraft.getWindow().getHeight();
            this.chain.resize(width, height);
            this.lastWidth = width;
            this.lastHeight = height;
        } catch (Exception e) {
            MrqxSlashBladeCore.LOGGER.error("加载屏幕辉光后处理链失败: {}", CHAIN_ID, e);
            this.chain = null;
        }
    }
    
    @Override
    public void close() {
        this.activeGlows.clear();
        if (this.chain != null) {
            this.chain.close();
            this.chain = null;
        }
    }
    
    @Override
    public void composite(float partialTick) {
        if (this.chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        long gameTime = minecraft.level.getGameTime();
        // 包络与闪烁按 partialTick 求值，否则 20Hz 的整数 tick 阶梯会被直接渲染出来
        float renderTime = (float) gameTime + partialTick;
        this.activeGlows.removeIf(activeGlow -> gameTime >= activeGlow.endGameTime);
        if (this.activeGlows.isEmpty()) {
            return;
        }
        this.checkResize();
        PostPass pass = this.glowPass();
        if (pass == null) {
            return;
        }
        int width = Math.max(1, minecraft.getWindow().getWidth());
        int height = Math.max(1, minecraft.getWindow().getHeight());
        pass.getEffect().safeGetUniform("Aspect").set((float) width / (float) height);
        Projection projection = currentProjection(width, height);
        Camera camera = minecraft.gameRenderer.getMainCamera();
        Vec3 cameraPos = camera.getPosition();
        // 场景模糊是整个画面的属性，无法逐光斑区分，故取所有活跃光斑中的最大值
        float sceneBlur = 0.0F;
        for (int i = 0; i < MAX_GLOWS; i++) {
            if (i >= this.activeGlows.size()) {
                this.clearSlot(pass, i);
                continue;
            }
            ActiveGlow activeGlow = this.activeGlows.get(i);
            float intensity = activeGlow.spec.envelope(renderTime - activeGlow.startGameTime);
            if (intensity <= 0.0F) {
                this.clearSlot(pass, i);
                continue;
            }
            float strength = activeGlow.spec.strength() * intensity * activeGlow.spec.pulseFactor(renderTime);
            sceneBlur = Math.max(sceneBlur, activeGlow.spec.sceneBlur() * intensity);
            Vector3f color = activeGlow.spec.colorComponents();
            Vector3f projected = project(activeGlow.origin, cameraPos, camera, projection,
                activeGlow.spec.radius());
            pass.getEffect().safeGetUniform(COLOR_UNIFORMS[i]).set(color.x, color.y, color.z);
            pass.getEffect().safeGetUniform(CENTER_UNIFORMS[i]).set(projected.x, projected.y);
            pass.getEffect().safeGetUniform(PARAMS_UNIFORMS[i])
                .set(strength, projected.z, (float) activeGlow.spec.mode(), activeGlow.spec.softness());
        }
        pass.getEffect().safeGetUniform("SceneBlur").set(sceneBlur);
        this.chain.process(partialTick);
    }
    
    /**
     * 窗口尺寸变化时同步调整后处理链尺寸。
     */
    public void checkResize() {
        if (this.chain == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.getWindow().getWidth();
        int height = minecraft.getWindow().getHeight();
        if (width != this.lastWidth || height != this.lastHeight) {
            this.chain.resize(width, height);
            this.lastWidth = width;
            this.lastHeight = height;
        }
    }
    
    /**
     * 一帧的投影参数。
     *
     * @param tanHalfFov 半视场角的正切
     * @param aspect     屏幕宽高比（宽 ÷ 高）
     */
    public record Projection(float tanHalfFov, float aspect) {
    }
    
    /**
     * 一个正在生效的光斑：把静态参数与本次触发的位置、起始时间绑在一起。
     */
    public static final class ActiveGlow {
        
        /**
         * 发射点（世界坐标），即光斑圆心。
         */
        public final Vec3 origin;
        
        /**
         * 静态参数。
         */
        public final GlowSpec spec;
        
        /**
         * 本次触发的起始游戏时间。
         */
        public final long startGameTime;
        
        /**
         * 本次触发的结束游戏时间：起始时间 + {@link GlowSpec#totalTicks()}。
         */
        public final long endGameTime;
        
        /**
         * 记录一次光斑触发。
         *
         * @param origin        发射点（世界坐标）
         * @param spec          光斑参数
         * @param startGameTime 起始游戏时间
         */
        public ActiveGlow(Vec3 origin, GlowSpec spec, long startGameTime) {
            this.origin = origin;
            this.spec = spec;
            this.startGameTime = startGameTime;
            this.endGameTime = startGameTime + spec.totalTicks();
        }
    }
}
