package net.mrqx.sbr_core.client.effect.post;

import org.joml.Vector3f;

/**
 * 单个屏幕辉光光斑的参数：EFX 数值取自各层的原值，逐层换算与各层取值见 {@link GlowPresets}。
 *
 * @param color             ARGB，照抄 EFX {@code Color}；alpha 一并作为亮度折减乘入
 * @param strength          满强度时的有效增益，即 EFX {@code Intensity}
 * @param mode              叠加模式，见 {@link #MODE_ADD} / {@link #MODE_SCREEN} / {@link #MODE_DARKEN}
 * @param sceneBlur         场景模糊半径（像素），0 表示不模糊，对应 {@code ブラー}
 * @param pulseChangeFrames 强度调制的跳变间隔，单位为 EFX 帧（见 {@link #TICK_TO_FRAME}）
 * @param pulseAmplitudeMin 强度调制下限（1.0 表示不调制）
 * @param pulseAmplitudeMax 强度调制上限（1.0 表示不调制）
 */
public record GlowSpec(
    float radius,
    int color,
    float strength,
    int mode,
    float softness,
    float sceneBlur,
    int appearTicks,
    int keepTicks,
    int vanishTicks,
    float pulseAmplitudeMin,
    float pulseAmplitudeMax,
    int pulseChangeFrames
) {
    /**
     * 线性加法，对应 EFX {@code Flags} 的加法混合（bit0 / bit1 置位）。
     */
    public static final int MODE_ADD = 0;
    
    /**
     * 滤色（过曝）：复现 {@code ColorRate} 极值层"中心曝白、边缘留色"的渐变，且不产生硬截断。
     */
    public static final int MODE_SCREEN = 1;
    
    /**
     * 乘法压暗，对应 EFX {@code Flags=4} 的减算；按比例压暗可避免暗部死黑与硬边。
     */
    public static final int MODE_DARKEN = 2;
    
    /**
     * 1 tick 对应的 EFX 帧数（EFX 帧率是本项目的 3 倍）。
     */
    public static final int TICK_TO_FRAME = 3;
    
    /**
     * 强度调制所用的确定性散列参数：把一个整数桶号散列成 0~1 的噪声。
     */
    public static final double PULSE_NOISE_FREQUENCY = 12.9898D;
    public static final double PULSE_NOISE_SCALE = 43758.5453D;
    
    /**
     * 构造一个不做强度调制的光斑（上下限均为 1.0），绝大多数层都属此类。
     */
    public static GlowSpec of(float radius, int color, float strength, int mode, float softness,
                              float sceneBlur, int appearTicks, int keepTicks, int vanishTicks) {
        return new GlowSpec(radius, color, strength, mode, softness, sceneBlur,
            appearTicks, keepTicks, vanishTicks, 1.0F, 1.0F, 1);
    }
    
    /**
     * 本光斑的颜色分量：ARGB 拆成 0~1 的 RGB，并把 alpha 作为亮度折减一并乘入。
     */
    public Vector3f colorComponents() {
        float alpha = (float) ((this.color >>> 24) & 0xFF) / 255.0F;
        float red = (float) ((this.color >>> 16) & 0xFF) / 255.0F;
        float green = (float) ((this.color >>> 8) & 0xFF) / 255.0F;
        float blue = (float) (this.color & 0xFF) / 255.0F;
        return new Vector3f(red * alpha, green * alpha, blue * alpha);
    }
    
    /**
     * 强度包络（0~1）：Appear 渐入 → Keep 满强度 → Vanish 渐出，与 EFX {@code Life} 三段一一对应。
     */
    public float envelope(float elapsedTicks) {
        if (elapsedTicks < 0.0F) {
            return 0.0F;
        }
        if (elapsedTicks < this.appearTicks) {
            return this.appearTicks <= 0 ? 1.0F : elapsedTicks / (float) this.appearTicks;
        }
        float keepEnd = (float) (this.appearTicks + this.keepTicks);
        if (elapsedTicks < keepEnd) {
            return 1.0F;
        }
        if (this.vanishTicks <= 0) {
            return 1.0F;
        }
        return Math.max(0.0F, 1.0F - (elapsedTicks - keepEnd) / (float) this.vanishTicks);
    }
    
    /**
     * 本光斑的总时长（tick），为 Appear + Keep + Vanish，下界取 1。
     */
    public int totalTicks() {
        return Math.max(1, this.appearTicks + this.keepTicks + this.vanishTicks);
    }
    
    /**
     * 点光源的强度调制系数，对应 {@code PtBehavior} 的 {@code IntensityAmplitudeMin / Max}：
     * 用"时间分桶 + 确定性散列"实现——桶号只随游戏时间变化，故同一 tick 内渲染多帧取到同一个值，
     * 不会因一 tick 渲染多帧而抖成噪点；上下限相等或跳变间隔非正时不调制。
     */
    public float pulseFactor(float gameTime) {
        if (this.pulseAmplitudeMin >= this.pulseAmplitudeMax || this.pulseChangeFrames <= 0) {
            return 1.0F;
        }
        long bucket = (long) (gameTime * TICK_TO_FRAME / this.pulseChangeFrames);
        double noise = Math.sin((double) bucket * PULSE_NOISE_FREQUENCY) * PULSE_NOISE_SCALE;
        float unit = (float) (noise - Math.floor(noise));
        return this.pulseAmplitudeMin + (this.pulseAmplitudeMax - this.pulseAmplitudeMin) * unit;
    }
}
