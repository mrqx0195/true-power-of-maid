package net.mrqx.sbr_core.client.utils;

import net.minecraft.util.Mth;

public final class ParticleUtils {
    /**
     * 按相机距离淡出（EFX {@code FadeByDepth}：过近与过远都淡出），口径同 {@code GenericMeshParticle#distanceAlpha}；
     * 近端阈值已在视图侧压到 0.3 / 0.8 格，"相机贴在碎片附近"这一常见情形因此不会被误伤。
     */
    public static float distanceAlpha(float px, float py, float pz, float fadeNearEnd, float fadeNearStart, float fadeFarEnd, float fadeFarStart) {
        float result = 1.0F;
        float squared = px * px + py * py + pz * pz;
        if (fadeNearEnd > fadeNearStart) {
            float distance = Mth.sqrt(squared);
            if (distance < fadeNearEnd) {
                result *= Mth.clamp(
                    (distance - fadeNearStart) / (fadeNearEnd - fadeNearStart),
                    0.0F, 1.0F);
            }
        }
        if (fadeFarEnd > fadeFarStart) {
            float distance = Mth.sqrt(squared);
            if (distance > fadeFarStart) {
                result *= Mth.clamp(
                    1.0F - (distance - fadeFarStart) / (fadeFarEnd - fadeFarStart),
                    0.0F, 1.0F);
            }
        }
        return result;
    }
}
