package net.mrqx.sbr_core.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import mods.flammpfeil.slashblade.client.renderer.model.BladeModelManager;
import mods.flammpfeil.slashblade.client.renderer.model.obj.WavefrontObject;
import mods.flammpfeil.slashblade.client.renderer.util.BladeRenderState;
import mods.flammpfeil.slashblade.client.renderer.util.MSAutoCloser;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.entity.EntitySlashString;

public class RendererSlashString<T extends EntitySlashString> extends EntityRenderer<T> {
    private static final ResourceLocation TEXTURE = MrqxSlashBladeCore.prefix("textures/effect/nullwhite.png");
    private static final ResourceLocation MODEL = MrqxSlashBladeCore.prefix("model/the_string.obj");
    
    public RendererSlashString(EntityRendererProvider.Context context) {
        super(context);
    }
    
    @Override
    public ResourceLocation getTextureLocation(T p_114482_) {
        return TEXTURE;
    }
    
    @Override
    public void render(T entity, float entityYaw, float partialTicks, PoseStack matrixStack, MultiBufferSource bufferIn, int packedLightIn) {
        try (MSAutoCloser ignored = MSAutoCloser.pushMatrix(matrixStack)) {
            float lifetime = entity.getLifetime();
            double deathTime = (double) lifetime + 5;
            double baseAlpha = Math.clamp(lifetime - (float) entity.tickCount, 0.0F, deathTime) / deathTime;
            baseAlpha = Math.max(0.0F, -Math.pow(baseAlpha - (double) 1.0F, 4.0F) + (double) 0.75F);
            matrixStack.mulPose(Axis.YP.rotationDegrees(Mth.rotLerp(partialTicks, entity.yRotO, entity.getYRot()) - 90.0F));
            matrixStack.mulPose(Axis.ZP.rotationDegrees(Mth.rotLerp(partialTicks, entity.xRotO, entity.getXRot())));
            matrixStack.mulPose(Axis.XP.rotationDegrees(entity.getRotX()));
            matrixStack.mulPose(Axis.YP.rotationDegrees(entity.getRotY()));
            float scale = 0.015F;
            matrixStack.scale(scale, scale, scale * 5);
            matrixStack.mulPose(Axis.YP.rotationDegrees(90.0F));
            int color = entity.getColor() & 16777215;
            int alpha = (255 & (int) ((double) 255.0F * baseAlpha)) << 24;
            WavefrontObject model = BladeModelManager.getInstance().getModel(MODEL);
            BladeRenderState.setCol(color | alpha);
            BladeRenderState.renderOverridedLuminous(ItemStack.EMPTY, model, "base", TEXTURE, matrixStack, bufferIn, packedLightIn);
        }
        
    }
}
