package net.mrqx.sbr_core.client;

import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.client.effect.debris.DebrisMesh;
import net.mrqx.sbr_core.client.effect.mesh.MeshShard;
import net.mrqx.sbr_core.client.effect.mesh.SceneDepthCopy;
import net.mrqx.sbr_core.client.effect.post.PostEffectRegistry;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;

/**
 * 本 Mod 客户端侧 MOD 总线事件订阅者。
 * <p>
 * 目前负责在资源重载（F3+T / 资源包切换）时重建依赖资源的客户端资产：
 * 全部后处理链（{@link PostEffectRegistry}）、われ网格（{@link MeshShard}）与玻璃碎片网格（{@link DebrisMesh}），
 * 以及释放场景深度副本（{@link SceneDepthCopy}）持有的 GL 纹理与 FBO。
 */
@EventBusSubscriber(modid = MrqxSlashBladeCore.MODID, value = Dist.CLIENT)
public final class ClientModBusEvents {
    
    private ClientModBusEvents() {
    }
    
    /**
     * 注册客户端资源重载监听器，资源重载完成后重建畸变 PostChain 与网格缓存，并释放场景深度副本。
     */
    @SubscribeEvent
    public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener(new SimplePreparableReloadListener<ResourceManager>() {
            @Override
            protected ResourceManager prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
                return resourceManager;
            }
            
            @Override
            protected void apply(ResourceManager object, ResourceManager resourceManager, ProfilerFiller profiler) {
                PostEffectRegistry.reload(resourceManager);
                MeshShard.reload();
                DebrisMesh.reload();
                // 深度副本是纯粹的 GL 资源、不依赖资源包内容，但重载是一次"该收拾的都收拾"的时机；
                // 尺寸变化时的重建在 SceneDepthCopy 内部另有处理，这里只补上"重载时释放"这一半。
                SceneDepthCopy.release();
            }
        });
    }
}
