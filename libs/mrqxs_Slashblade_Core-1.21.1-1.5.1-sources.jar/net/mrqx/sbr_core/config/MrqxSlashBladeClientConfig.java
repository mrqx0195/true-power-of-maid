package net.mrqx.sbr_core.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class MrqxSlashBladeClientConfig {
    public static final ModConfigSpec CLIENT_CONFIG;
    
    public static final ModConfigSpec.BooleanValue ENABLE_TRUE_DISTORTION;
    public static final ModConfigSpec.DoubleValue DISTORTION_STRENGTH;
    public static final ModConfigSpec.DoubleValue DISTORTION_DEPTH_REFERENCE;
    public static final ModConfigSpec.IntValue MAX_TRACKED_DISTORTION_PARTICLES;
    
    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        
        ENABLE_TRUE_DISTORTION = builder
            .comment("是否启用真实屏幕空间遮罩（后处理）。这条链同时承载两条通道：",
                "  ① 折射：空间的撕裂 / 凸凹透镜（われ、割れ Dis、两个透镜球）；",
                "  ② 材质色彩滤镜：白黒 的黑白滤镜、開始　青 的青色滤镜。",
                "关闭后这两条通道都不再执行，仅保留 Fresnel 加算发光观感，兼容性更好。")
            .define("enable_true_distortion", true);
        
        DISTORTION_STRENGTH = builder
            .comment("畸变整体强度，预留项：当前实际生效值以 shaders/post/dis_ware_distortion.json 中的 Strength 为准，修改此处需同步修改 shader。")
            .defineInRange("distortion_strength", 0.035, 0.0, 0.2);
        
        DISTORTION_DEPTH_REFERENCE = builder
            .comment("折射偏移的参考视深（格）：该族材质的折射偏移与视深成反比，本项是\"把深度因子折进遮罩\"时的基准距离。",
                "取 10 表示\"离屏 10 格处的观感与补深度项之前完全一致\"，比 10 格近则按比例放大、远则衰减；",
                "调小它会让近距折射更夸张、调大则整体更平；0 或负值退回内置默认 10。",
                "注意：绝对幅度仍在 shaders/post/dis_ware_distortion.json 的 Strength 里，本项只改远近的相对关系。")
            .defineInRange("distortion_depth_reference", 10.0, 0.0, 64.0);
        
        MAX_TRACKED_DISTORTION_PARTICLES = builder
            .comment("同屏参与畸变合成的碎片数量上限，超出部分仅发光、不参与折射，用于防止多玩家同屏时的性能开销。")
            .defineInRange("max_tracked_distortion_particles", 64, 1, 1024);
        
        CLIENT_CONFIG = builder.build();
    }
}
