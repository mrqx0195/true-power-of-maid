package net.mrqx.sbr_core.events;

import mods.flammpfeil.slashblade.compat.playerAnim.VmdAnimation;
import mods.flammpfeil.slashblade.event.client.PlayerAnimationInitEvent;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

import java.util.Map;

/**
 * Use {@link PlayerAnimationInitEvent} instead.
 * <p>
 * Note: register PlayerAnimationInitEvent handler in {@link FMLCommonSetupEvent} or earlier
 */
@Deprecated
public class SlashBladePlayerAnimationRegistryEvent extends Event {
    private final Map<ResourceLocation, VmdAnimation> animation;
    
    public SlashBladePlayerAnimationRegistryEvent(Map<ResourceLocation, VmdAnimation> animation) {
        this.animation = animation;
    }
    
    /**
     * 获取动画映射表（可修改）。
     */
    public Map<ResourceLocation, VmdAnimation> getAnimation() {
        return this.animation;
    }
    
    
    private static boolean hasInit = false;
    
    /**
     * 动画是否已完成初始化。
     */
    public static boolean hasInit() {
        return hasInit;
    }
    
    /**
     * 标记动画系统已初始化完成。
     */
    public static void setInit() {
        hasInit = true;
    }
}
