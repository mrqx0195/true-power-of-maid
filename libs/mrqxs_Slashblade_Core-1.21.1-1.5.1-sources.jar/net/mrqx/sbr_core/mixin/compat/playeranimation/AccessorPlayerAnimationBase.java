package net.mrqx.sbr_core.mixin.compat.playeranimation;

import mods.flammpfeil.slashblade.compat.playerAnim.PlayerAnimationBase;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = PlayerAnimationBase.class, remap = false)
public interface AccessorPlayerAnimationBase {
    @Accessor("loc")
    ResourceLocation sbr_core$getLoc();
    
    @Accessor("start")
    double sbr_core$getStart();
    
    @Accessor("end")
    double sbr_core$getEnd();
    
    @Accessor("span")
    double sbr_core$getSpan();
    
    @Accessor("speed")
    double sbr_core$getSpeed();
    
    @Accessor("loop")
    boolean sbr_core$isLoop();
    
    @Accessor("blendArms")
    boolean sbr_core$isBlendArms();
    
    @Accessor("blendLegs")
    boolean sbr_core$isBlendLegs();
    
    @Accessor("currentTick")
    double sbr_core$getCurrentTick();
    
    @Accessor("lastCachedTick")
    double sbr_core$getLastCachedTick();
    
    @Accessor("lastCachedPartial")
    float sbr_core$getLastCachedPartial();
    
    @Accessor("isRunning")
    boolean sbr_core$isRunning();
}
