package net.mrqx.sbr_core.mixin.compat.playeranimation;

import mods.flammpfeil.slashblade.compat.playerAnim.PlayerAnimationOverrider;
import mods.flammpfeil.slashblade.compat.playerAnim.VmdAnimation;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.events.SlashBladePlayerAnimationRegistryEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

@Mixin(PlayerAnimationOverrider.class)
public abstract class MixinPlayerAnimationOverrider {
    @Final
    @Shadow(remap = false)
    private Map<ResourceLocation, VmdAnimation> animation;
    
    @Inject(method = "onBladeAnimationStart(Lmods/flammpfeil/slashblade/event/BladeMotionEvent;)V", at = @At("HEAD"), remap = false)
    private void injectInit(CallbackInfo ci) {
        if (!SlashBladePlayerAnimationRegistryEvent.hasInit()) {
            SlashBladePlayerAnimationRegistryEvent.setInit();
            NeoForge.EVENT_BUS.post(new SlashBladePlayerAnimationRegistryEvent(animation));
        }
    }
}
