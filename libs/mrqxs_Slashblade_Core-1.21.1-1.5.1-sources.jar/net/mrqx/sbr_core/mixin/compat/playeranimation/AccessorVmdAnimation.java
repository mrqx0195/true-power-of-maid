package net.mrqx.sbr_core.mixin.compat.playeranimation;

import com.google.common.collect.Maps;
import jp.nyatla.nymmd.MmdMotionPlayerGL2;
import jp.nyatla.nymmd.MmdPmdModelMc;
import mods.flammpfeil.slashblade.compat.playerAnim.VmdAnimation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

@Mixin(VmdAnimation.class)
public interface AccessorVmdAnimation {
    @Accessor(value = "nameMap", remap = false)
    static Map<String, String> sbr_core$getNameMap() {
        return Maps.newHashMap();
    }
    
    @Accessor(value = "alex", remap = false)
    @Nullable
    static MmdPmdModelMc sbr_core$getAlex() {
        return null;
    }
    
    @Accessor(value = "motionPlayer", remap = false)
    @Nullable
    static MmdMotionPlayerGL2 sbr_core$getMotionPlayer() {
        return null;
    }
    
    @Accessor(value = "arms", remap = false)
    static List<String> sbr_core$getArms() {
        return List.of();
    }
    
    @Accessor(value = "legs", remap = false)
    static List<String> sbr_core$getLegs() {
        return List.of();
    }
}
