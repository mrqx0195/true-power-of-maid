package net.mrqx.sbr_core.mixin.common;

import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.enchantment.Enchantment;
import net.mrqx.sbr_core.events.ExEnchantmentRegistryEvent;
import net.neoforged.fml.ModLoader;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;

@Mixin(ItemSlashBlade.class)
public abstract class MixinItemSlashBlade {
    @Shadow(remap = false)
    @Final
    @Mutable
    public static Set<ResourceKey<Enchantment>> EX_ENCHANTMENTS;
    
    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void injectClinit(CallbackInfo ci) {
        if (EX_ENCHANTMENTS != null) {
            ExEnchantmentRegistryEvent event = new ExEnchantmentRegistryEvent(EX_ENCHANTMENTS);
            ModLoader.postEvent(event);
            EX_ENCHANTMENTS = event.getNewExEnchantments();
        }
    }
}
